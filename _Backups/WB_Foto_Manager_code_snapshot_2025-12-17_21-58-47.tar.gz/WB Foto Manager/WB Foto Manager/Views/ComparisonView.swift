//
//  ComparisonView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI

/// Compare/Culling Mode (Lightroom-like): Hauptfoto + Vergleichs-Strip rechts.
struct CompareModeView: View {
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    private var mainPhoto: PhotoItem? { store.currentPhoto }
    private let burstMaxCount: Int = 12
    private let burstWindowSeconds: TimeInterval = 0.8
    
    /// Selected photos in current order (filteredPhotos preserves sorting).
    private var selectedOrdered: [PhotoItem] {
        store.filteredPhotos.filter { store.selectedPhotoIDs.contains($0.id) }
    }
    
    private func comparisonCandidates(for main: PhotoItem) -> [PhotoItem] {
        let selectedOthers = selectedOrdered.filter { $0.id != main.id }
        if !selectedOthers.isEmpty {
            return Array(selectedOthers.prefix(12))
        }
        
        // Smart Culling: Burst-Group anhand Aufnahmedatum (sehr nützlich bei Sport/Serien).
        let burst = burstGroup(around: main, in: store.filteredPhotos, maxCount: burstMaxCount, windowSeconds: burstWindowSeconds)
        let burstOthers = burst.filter { $0.id != main.id }
        if !burstOthers.isEmpty {
            return Array(burstOthers.prefix(burstMaxCount))
        }
        
        // Fallback: wenn keine Mehrfachauswahl aktiv ist, nimm die nächsten Fotos als "Compare Strip".
        if let idx = store.currentPhotoIndexInFiltered {
            let next = store.filteredPhotos.dropFirst(idx + 1).prefix(12)
            return Array(next)
        }
        return []
    }
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            if let main = mainPhoto {
                let candidates = comparisonCandidates(for: main)
                if candidates.isEmpty {
                    CompareEmptyStateView(
                        canSelectBurst: burstGroup(around: main, in: store.filteredPhotos, maxCount: burstMaxCount, windowSeconds: burstWindowSeconds).count > 1,
                        onSelectBurst: { selectBurst(around: main) }
                    )
                } else {
                    ComparisonView(
                        mainPhoto: main,
                        comparisonPhotos: candidates,
                        store: store
                    )
                    .overlay(alignment: .topLeading) {
                        CompareTopOverlay(
                            onSelectBurst: { selectBurst(around: main) }
                        )
                        .padding(10)
                    }
                }
            } else {
                VStack(spacing: 10) {
                    Text("Compare")
                        .font(DesignSystem.Fonts.semibold(size: 18))
                        .foregroundColor(.white)
                    Text("Wähle ein Foto aus, um zu vergleichen.")
                        .font(DesignSystem.Fonts.regular(size: 12))
                        .foregroundColor(.white.opacity(0.75))
                    
                    Button("Zur Grid‑Ansicht") {
                        uiState.viewMode = .grid
                    }
                    .buttonStyle(.borderedProminent)
                }
            }
        }
    }
    
    private func selectBurst(around main: PhotoItem) {
        let burst = burstGroup(around: main, in: store.filteredPhotos, maxCount: burstMaxCount, windowSeconds: burstWindowSeconds)
        guard burst.count > 1 else { return }
        uiState.selectionMode = true
        store.selectedPhotoIDs = Set(burst.map(\.id))
        store.currentPhotoID = main.id
    }
}

private struct CompareTopOverlay: View {
    let onSelectBurst: () -> Void
    
    var body: some View {
        HStack(spacing: 8) {
            Button(action: onSelectBurst) {
                Label("Burst auswählen", systemImage: "bolt.fill")
                    .font(DesignSystem.Fonts.medium(size: 12))
            }
            .buttonStyle(.borderedProminent)
            .help("Wählt ähnliche Shots rund um das aktuelle Foto (serien/burst) aus")
        }
    }
}

private struct CompareEmptyStateView: View {
    @EnvironmentObject var uiState: UIState
    let canSelectBurst: Bool
    let onSelectBurst: () -> Void
    
    var body: some View {
        VStack(spacing: 12) {
            Text("Compare / Culling")
                .font(DesignSystem.Fonts.semibold(size: 18))
                .foregroundColor(.white)
            
            Text("Tipp: Aktiviere „Mehrfachauswahl“ und wähle mindestens 2 Fotos aus.\nDann kannst du rechts schnell durch ähnliche Shots klicken.")
                .font(DesignSystem.Fonts.regular(size: 12))
                .foregroundColor(.white.opacity(0.75))
                .multilineTextAlignment(.center)
            
            HStack(spacing: 10) {
                Button("Mehrfachauswahl aktivieren") {
                    uiState.selectionMode = true
                }
                .buttonStyle(.borderedProminent)
                
                if canSelectBurst {
                    Button("Burst auswählen") {
                        onSelectBurst()
                    }
                    .buttonStyle(.bordered)
                }
                
                Button("Zur Grid‑Ansicht") {
                    uiState.viewMode = .grid
                }
                .buttonStyle(.bordered)
            }
        }
        .padding(24)
    }
}

/// Survey Mode (Lightroom-like): mehrere ausgewählte Fotos groß vergleichen.
struct SurveyModeView: View {
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    private var selectedOrdered: [PhotoItem] {
        store.filteredPhotos.filter { store.selectedPhotoIDs.contains($0.id) }
    }
    
    private var columnsCount: Int {
        let n = selectedOrdered.count
        if n <= 1 { return 1 }
        if n == 2 { return 2 }
        if n <= 4 { return 2 }
        if n <= 9 { return 3 }
        return 4
    }
    
    private var grid: [GridItem] {
        Array(repeating: GridItem(.flexible(minimum: 180, maximum: 1000), spacing: 8), count: columnsCount)
    }
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            if selectedOrdered.count <= 1 {
                SurveyEmptyStateView(
                    canSelectBurst: (store.currentPhoto != nil) && burstGroup(around: store.currentPhoto!, in: store.filteredPhotos, maxCount: 12, windowSeconds: 0.8).count > 1,
                    onSelectBurst: {
                        if let main = store.currentPhoto {
                            let burst = burstGroup(around: main, in: store.filteredPhotos, maxCount: 12, windowSeconds: 0.8)
                            guard burst.count > 1 else { return }
                            uiState.selectionMode = true
                            store.selectedPhotoIDs = Set(burst.map(\.id))
                            store.currentPhotoID = main.id
                        }
                    }
                )
            } else {
                ScrollView {
                    LazyVGrid(columns: grid, alignment: .center, spacing: 8) {
                        ForEach(selectedOrdered) { photo in
                            SurveyPhotoCell(
                                photo: photo,
                                store: store,
                                isActive: store.currentPhotoID == photo.id
                            )
                            .aspectRatio(1.5, contentMode: .fit)
                            .contentShape(Rectangle())
                            .onTapGesture {
                                store.selectPhoto(photo)
                            }
                            .contextMenu {
                                Button("In Detail anzeigen") {
                                    store.selectPhoto(photo)
                                    uiState.viewMode = .detail
                                }
                            }
                        }
                    }
                    .padding(10)
                }
                .focusable()
                .onKeyPress(.space) {
                    uiState.viewMode = .detail
                    return .handled
                }
                .onKeyPress("g") {
                    uiState.viewMode = .grid
                    return .handled
                }
            }
        }
    }
}

private struct SurveyEmptyStateView: View {
    @EnvironmentObject var uiState: UIState
    let canSelectBurst: Bool
    let onSelectBurst: () -> Void
    
    var body: some View {
        VStack(spacing: 12) {
            Text("Survey")
                .font(DesignSystem.Fonts.semibold(size: 18))
                .foregroundColor(.white)
            
            Text("Tipp: Aktiviere „Mehrfachauswahl“ und wähle mindestens 2 Fotos aus.\nDann kannst du die Serie groß vergleichen.")
                .font(DesignSystem.Fonts.regular(size: 12))
                .foregroundColor(.white.opacity(0.75))
                .multilineTextAlignment(.center)
            
            HStack(spacing: 10) {
                Button("Mehrfachauswahl aktivieren") { uiState.selectionMode = true }
                    .buttonStyle(.borderedProminent)
                
                if canSelectBurst {
                    Button("Burst auswählen") { onSelectBurst() }
                        .buttonStyle(.bordered)
                }
                
                Button("Zur Grid‑Ansicht") { uiState.viewMode = .grid }
                    .buttonStyle(.bordered)
            }
        }
        .padding(24)
    }
}

private struct SurveyPhotoCell: View {
    @ObservedObject var photo: PhotoItem
    @ObservedObject var store: PhotoStore
    let isActive: Bool
    
    var body: some View {
        ZStack {
            // Medium preview is a sweet spot for fast survey browsing.
            AsyncThumbnailView(photo: photo, previewSize: .medium, interpolation: .high)
                .cornerRadius(8)
            
            PhotoBadgesOverlay(photo: photo, style: .grid)
            
            if isActive {
                RoundedRectangle(cornerRadius: 10)
                    .stroke(DesignSystem.Colors.accent, lineWidth: 3)
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.white.opacity(0.18), lineWidth: 1)
                    .shadow(color: DesignSystem.Colors.accent.opacity(0.35), radius: 10, x: 0, y: 0)
            } else if store.selectedPhotoIDs.contains(photo.id) {
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.white.opacity(0.10), lineWidth: 1)
            }
        }
    }
}

struct ComparisonView: View {
    let mainPhoto: PhotoItem
    let comparisonPhotos: [PhotoItem]
    @ObservedObject var store: PhotoStore
    
    var body: some View {
        HStack(spacing: 4) {
            // Hauptfoto (groß, zoom/pan wie in Detail)
            CompareMainPhotoCell(photo: mainPhoto, store: store)
                .frame(maxWidth: .infinity)
            
            // Vergleichsfotos
            VStack(spacing: 4) {
                ForEach(comparisonPhotos) { photo in
                    PhotoComparisonCell(photo: photo, store: store, isMain: false)
                        .onTapGesture {
                            store.selectPhoto(photo)
                        }
                }
            }
            .frame(width: 200)
        }
        .background(Color.black)
    }
}

// MARK: - Smart Culling helpers

private func burstGroup(
    around main: PhotoItem,
    in list: [PhotoItem],
    maxCount: Int,
    windowSeconds: TimeInterval
) -> [PhotoItem] {
    guard maxCount >= 2 else { return [main] }
    guard let baseDate = main.iptcMetadata?.date else { return [main] }
    
    // Nutze eine Date-sortierte Liste, unabhängig von aktueller UI-Sortierung.
    let sorted = list.sorted { (a, b) in
        let da = a.iptcMetadata?.date ?? Date.distantPast
        let db = b.iptcMetadata?.date ?? Date.distantPast
        if da != db { return da > db }
        return a.fileName < b.fileName
    }
    guard let idx = sorted.firstIndex(where: { $0.id == main.id }) else { return [main] }
    
    func date(_ p: PhotoItem) -> Date? { p.iptcMetadata?.date }
    
    var left = idx
    var right = idx
    
    // Expand left/right by adjacency, stop when time jumps too much.
    while left > 0, (right - left + 1) < maxCount {
        guard let d0 = date(sorted[left]), let dPrev = date(sorted[left - 1]) else { break }
        if abs(dPrev.timeIntervalSince(d0)) <= windowSeconds {
            left -= 1
        } else {
            break
        }
    }
    
    while right < sorted.count - 1, (right - left + 1) < maxCount {
        guard let d0 = date(sorted[right]), let dNext = date(sorted[right + 1]) else { break }
        if abs(dNext.timeIntervalSince(d0)) <= windowSeconds {
            right += 1
        } else {
            break
        }
    }
    
    var group = Array(sorted[left...right])
    
    // If burst is tiny but there are still close photos within window to base date, include them (best-effort).
    if group.count < 2 {
        let extra = sorted.filter { p in
            guard p.id != main.id, let d = p.iptcMetadata?.date else { return false }
            return abs(d.timeIntervalSince(baseDate)) <= windowSeconds
        }
        group = [main] + extra.prefix(max(0, maxCount - 1))
    }
    
    // Ensure main is included.
    if !group.contains(where: { $0.id == main.id }) {
        group.insert(main, at: 0)
    }
    return Array(group.prefix(maxCount))
}

private struct CompareMainPhotoCell: View {
    let photo: PhotoItem
    @ObservedObject var store: PhotoStore
    @State private var preview: NSImage?
    
    var body: some View {
        ZStack {
            PhotoDetailView(photo: photo, store: store, image: preview)
            
            PhotoBadgesOverlay(photo: photo, style: .grid)
                .padding(10)
            
            if store.currentPhotoID == photo.id {
                Rectangle()
                    .stroke(Color.accentColor, lineWidth: 3)
                    .padding(2)
            }
        }
        .onAppear(perform: loadPreview)
        .onChange(of: photo.id) { _, _ in loadPreview() }
        .contentShape(Rectangle())
        .onTapGesture {
            store.selectPhoto(photo)
        }
    }
    
    private func loadPreview() {
        preview = nil
        Task(priority: .userInitiated) {
            // Größeres Thumbnail, damit Zoom/Culling brauchbar ist.
            let img = await photo.loadThumbnail(size: CGSize(width: 2200, height: 2200))
            await MainActor.run { self.preview = img }
        }
    }
}

struct PhotoComparisonCell: View {
    let photo: PhotoItem
    @ObservedObject var store: PhotoStore
    let isMain: Bool
    @State private var thumbnail: NSImage?
    
    var body: some View {
        ZStack(alignment: .topTrailing) {
            if let thumb = thumbnail {
                Image(nsImage: thumb)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            } else {
                Rectangle()
                    .fill(Color.gray.opacity(0.2))
                    .overlay(ProgressView())
            }
            
            PhotoBadgesOverlay(photo: photo, style: .grid)
                .padding(6)
            
            // Selection Indicator
            if store.currentPhotoID == photo.id {
                Rectangle()
                    .stroke(Color.accentColor, lineWidth: isMain ? 4 : 2)
            }
        }
        .frame(maxHeight: isMain ? .infinity : 200)
        .onAppear {
            loadThumbnail()
        }
    }
    
    private func loadThumbnail() {
        Task(priority: .userInitiated) {
            let size = isMain ? CGSize(width: 1000, height: 1000) : CGSize(width: 200, height: 200)
            let thumb = await photo.loadThumbnail(size: size)
            await MainActor.run {
                self.thumbnail = thumb
            }
        }
    }
}

