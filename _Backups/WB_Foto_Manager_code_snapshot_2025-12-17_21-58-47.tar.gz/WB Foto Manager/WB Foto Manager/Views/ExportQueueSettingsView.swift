//
//  ExportQueueSettingsView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit

struct ExportQueueSettingsView: View {
    @ObservedObject var store: PhotoStore
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("Export‑Queue")
                    .font(DesignSystem.Fonts.semibold(size: 16))
                    .foregroundColor(DesignSystem.Colors.text)
                Spacer()
                Button("Schließen") { dismiss() }
                    .buttonStyle(LightroomSecondaryButtonStyle())
            }
            
            Toggle("Export‑Queue aktivieren", isOn: $store.exportQueueEnabled)
                .tint(DesignSystem.Colors.accent)
            
            if store.exportQueueEnabled {
                VStack(alignment: .leading, spacing: 12) {
                    // Min Rating
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Mindest-Rating: \(store.exportQueueMinRating) Sterne")
                            .font(DesignSystem.Fonts.regular(size: 12))
                            .foregroundColor(DesignSystem.Colors.text2)
                        HStack {
                            ForEach(1...5, id: \.self) { rating in
                                Button(action: {
                                    store.exportQueueMinRating = rating
                                }) {
                                    HStack(spacing: 2) {
                                        ForEach(0..<rating, id: \.self) { _ in
                                            Image(systemName: "star.fill")
                                                .font(.caption2)
                                                .foregroundColor(DesignSystem.Colors.star)
                                        }
                                    }
                                }
                                .buttonStyle(.plain)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(store.exportQueueMinRating == rating ? DesignSystem.Colors.accent.opacity(0.25) : Color.clear)
                                .cornerRadius(6)
                            }
                        }
                    }
                    
                    // Preset Selection
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Export Preset")
                            .font(DesignSystem.Fonts.regular(size: 11))
                            .foregroundColor(DesignSystem.Colors.text3)
                        Picker("Preset", selection: $store.exportQueuePreset) {
                            Text("Kein Preset").tag(ExportPreset?.none)
                            ForEach(store.exportPresets) { preset in
                                Text(preset.name).tag(ExportPreset?.some(preset))
                            }
                        }
                        .pickerStyle(.menu)
                    }
                    
                    // Output Directory
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Ausgabeordner")
                            .font(DesignSystem.Fonts.regular(size: 11))
                            .foregroundColor(DesignSystem.Colors.text3)
                        HStack {
                            Text(store.exportQueueOutputDirectory?.path ?? "Nicht ausgewählt")
                                .font(DesignSystem.Fonts.regular(size: 11))
                                .foregroundColor(DesignSystem.Colors.text2)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .lineLimit(1)
                                .truncationMode(.middle)
                            
                            Button("Auswählen...") {
                                store.chooseExportQueueDirectory()
                            }
                            .buttonStyle(LightroomSecondaryButtonStyle())
                        }
                    }
                    
                    // Status
                    if store.isExportQueueRunning {
                        VStack(alignment: .leading, spacing: 8) {
                            ProgressView(value: store.exportQueueProgress)
                                .tint(DesignSystem.Colors.accent)
                            
                            HStack {
                                Text("\(store.exportQueueProcessedCount)/\(max(1, store.exportQueueTotalCount))")
                                    .font(DesignSystem.Fonts.medium(size: 11))
                                    .foregroundColor(DesignSystem.Colors.text2)
                                    .monospacedDigit()
                                
                                Spacer()
                                
                                Button("Abbrechen") {
                                    store.cancelExportQueue()
                                }
                                .buttonStyle(LightroomSecondaryButtonStyle())
                            }
                            
                            if !store.exportQueueCurrentName.isEmpty {
                                Text("Aktuell: \(store.exportQueueCurrentName)")
                                    .font(DesignSystem.Fonts.regular(size: 11))
                                    .foregroundColor(DesignSystem.Colors.text3)
                                    .lineLimit(1)
                            }
                        }
                    }
                    
                    HStack(spacing: 10) {
                        Button("Jetzt prüfen") {
                            store.checkAndExportQueue()
                        }
                        .buttonStyle(LightroomSecondaryButtonStyle())
                        .disabled(store.isExportQueueRunning || store.exportQueuePreset == nil || store.exportQueueOutputDirectory == nil)
                        
                        Spacer()
                        
                        if store.exportQueuePreset == nil || store.exportQueueOutputDirectory == nil {
                            Text("Preset und Ordner wählen, damit die Queue starten kann.")
                                .font(DesignSystem.Fonts.regular(size: 10))
                                .foregroundColor(DesignSystem.Colors.text3)
                                .lineLimit(1)
                        }
                    }
                    
                    // Info
                    Text("Fotos mit \(store.exportQueueMinRating) oder mehr Sternen werden automatisch exportiert, sobald das Rating gesetzt wird.")
                        .font(DesignSystem.Fonts.regular(size: 11))
                        .foregroundColor(DesignSystem.Colors.text3)
                }
                .padding()
                .background(DesignSystem.Colors.background4)
                .cornerRadius(DesignSystem.CornerRadius.small)
                .overlay(
                    RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                        .stroke(DesignSystem.Colors.border, lineWidth: 1)
                )
            }
            
            Spacer()
        }
        .padding()
        .frame(width: 500, height: 400)
        .background(DesignSystem.Colors.background)
        .lightroomSidebarTheme()
    }
}

