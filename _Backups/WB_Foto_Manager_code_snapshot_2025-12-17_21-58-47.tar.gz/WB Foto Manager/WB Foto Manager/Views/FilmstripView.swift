//
//  FilmstripView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit

struct FilmstripView: View {
    let photos: [PhotoItem]
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    var body: some View {
        ScrollViewReader { proxy in
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 4) {
                    ForEach(photos) { photo in
                        FilmstripPhotoCell(
                            photo: photo,
                            store: store,
                            isCurrent: store.currentPhotoID == photo.id,
                            isMultiSelected: store.selectedPhotoIDs.contains(photo.id),
                            showMultiSelectIndicator: uiState.selectionMode
                        )
                        .id(photo.id)
                        .onTapGesture {
                            // Wichtig: Fokus aus TextEditor/TextField lösen, damit ⌘A danach wirklich "Fotos auswählen" triggert.
                            // (FirstResponder-Wechsel ist in SwiftUI manchmal "sticky" → daher endEditing + async)
                            DispatchQueue.main.async {
                                let win = NSApp.keyWindow ?? NSApp.mainWindow
                                win?.endEditing(for: nil)
                                win?.makeFirstResponder(nil)
                            }
                            store.selectPhoto(photo)
                        }
                    }
                }
                .padding(.horizontal, 4)
            }
            .background(DesignSystem.Colors.background4)
            .overlay(
                Rectangle()
                    .fill(DesignSystem.Colors.border)
                    .frame(height: 1),
                alignment: .top
            )
            .onChange(of: store.currentPhotoID) { _, newID in
                if let id = newID {
                    withAnimation {
                        proxy.scrollTo(id, anchor: .center)
                    }
                    
                    // Prefetch Thumbnails rund um das aktuelle Bild (hilft bei iCloud/PhotoKit enorm)
                    if let idx = photos.firstIndex(where: { $0.id == id }) {
                        let start = max(0, idx - 14)
                        let end = min(photos.count - 1, idx + 14)
                        let urls = Array(photos[start...end]).map { $0.url }
                        SmartImageLoader.shared.prefetchThumbnails(urls: urls, count: urls.count)
                    }
                }
            }
        }
    }
}

struct FilmstripPhotoCell: View {
    @ObservedObject var photo: PhotoItem
    @ObservedObject var store: PhotoStore
    let isCurrent: Bool
    let isMultiSelected: Bool
    let showMultiSelectIndicator: Bool
    
    private let renderedMaxDimension: CGFloat = 420
    
    var body: some View {
        ZStack {
            Group {
                if photo.isMaster {
                    AsyncThumbnailView(photo: photo, previewSize: .thumbnail, interpolation: .high)
                } else {
                    RenderedThumbnailView(photo: photo, maxDimension: renderedMaxDimension, interpolation: .high)
                }
            }
            .cornerRadius(4)
            
            PhotoBadgesOverlay(photo: photo, style: .filmstrip)
            
            // Multi-Select Indicator (macht Mehrfachauswahl im Filmstrip sofort sichtbar)
            if showMultiSelectIndicator && isMultiSelected {
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: isCurrent ? 16 : 14, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.accent)
                    .padding(5)
                    .background(Color.black.opacity(0.55))
                    .clipShape(Circle())
                    .overlay(
                        Circle()
                            .stroke(Color.white.opacity(0.10), lineWidth: 1)
                    )
                    .shadow(color: Color.black.opacity(0.55), radius: 2, x: 0, y: 1)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                    .padding(.bottom, 4)
            }
            
            if isCurrent {
                RoundedRectangle(cornerRadius: 6)
                    .stroke(DesignSystem.Colors.accent, lineWidth: 3)
                RoundedRectangle(cornerRadius: 6)
                    .stroke(Color.white.opacity(0.18), lineWidth: 1)
                    .shadow(color: DesignSystem.Colors.accent.opacity(0.35), radius: 8, x: 0, y: 0)
            } else if showMultiSelectIndicator && isMultiSelected {
                RoundedRectangle(cornerRadius: 6)
                    .stroke(DesignSystem.Colors.accent.opacity(0.55), lineWidth: 2)
            }
        }
        .frame(width: isCurrent ? 112 : 100, height: isCurrent ? 112 : 100)
        .background(isCurrent ? DesignSystem.Colors.accent.opacity(0.12) : Color.clear)
        .cornerRadius(6)
        .animation(.easeOut(duration: 0.12), value: isCurrent)
    }
}
