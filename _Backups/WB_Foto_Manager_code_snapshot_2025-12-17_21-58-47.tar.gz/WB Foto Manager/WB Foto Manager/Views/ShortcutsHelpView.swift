//
//  ShortcutsHelpView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 16.12.2025.
//

import SwiftUI

struct ShortcutsHelpView: View {
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        ZStack {
            DesignSystem.Colors.background3
                .ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 12) {
                header
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 14) {
                        ShortcutSection(title: "Navigation") {
                            ShortcutRow(keys: "← / →", description: "Vorheriges / nächstes Foto")
                            ShortcutRow(keys: "Leertaste", description: "Zur Detailansicht (aus Grid)")
                            ShortcutRow(keys: "⌃⌘3", description: "Compare / Culling Ansicht")
                            ShortcutRow(keys: "⌃⌘4", description: "Survey Ansicht")
                            ShortcutRow(keys: "⌘\\", description: "Sidebar links ein/aus")
                            ShortcutRow(keys: "⌥⌘\\", description: "Sidebar rechts ein/aus")
                        }
                        
                        ShortcutSection(title: "Zoom") {
                            ShortcutRow(keys: "⌘⌥0", description: "Zoom zurücksetzen")
                            ShortcutRow(keys: "⌘⌥=", description: "Zoom vergrößern")
                            ShortcutRow(keys: "⌘⌥-", description: "Zoom verkleinern")
                        }
                        
                        ShortcutSection(title: "Bewertung / Auswahl") {
                            ShortcutRow(keys: "1–5", description: "Rating setzen")
                            ShortcutRow(keys: "0", description: "Rating entfernen")
                            ShortcutRow(keys: "P / X / U", description: "Pick / Reject / Unflag")
                            ShortcutRow(keys: "⌘A", description: "Alle sichtbaren Fotos auswählen (Multi-Select)")
                            ShortcutRow(keys: "⌘P / ⌘X", description: "Nur Picks / Nur Rejects anzeigen")
                            ShortcutRow(keys: "⌘L", description: "Filter zurücksetzen")
                        }
                        
                        ShortcutSection(title: "Color Labels") {
                            ShortcutRow(keys: "6 / 7 / 8 / 9", description: "Rot / Gelb / Grün / Blau toggeln")
                        }
                        
                        ShortcutSection(title: "Quick Collection") {
                            ShortcutRow(keys: "B", description: "Zu Quick Collection hinzufügen/entfernen")
                            ShortcutRow(keys: "⌘B", description: "Quick Collection Filter an/aus")
                            ShortcutRow(keys: "⇧⌘B", description: "Quick Collection leeren")
                        }
                        
                        ShortcutSection(title: "Virtuelle Kopien") {
                            ShortcutRow(keys: "⌘'", description: "Virtuelle Kopie erstellen")
                            ShortcutRow(keys: "⇧⌘'", description: "Virtuelle Kopie löschen")
                        }
                        
                        ShortcutSection(title: "Suchen") {
                            ShortcutRow(keys: "⌘F", description: "Suchfeld fokussieren")
                        }
                        
                        ShortcutSection(title: "Bearbeitung / Workflow") {
                            ShortcutRow(keys: "⌘Z / ⇧⌘Z", description: "Undo / Redo")
                            ShortcutRow(keys: "⇧⌘C / ⇧⌘V", description: "Einstellungen kopieren / einfügen")
                            ShortcutRow(keys: "⌥⌘S", description: "Synchronisieren…")
                        }
                        
                        ShortcutSection(title: "Speichern / Export") {
                            ShortcutRow(keys: "⌘S", description: "Speichern (Original, destruktiv – mit Warnung)")
                            ShortcutRow(keys: "⇧⌘S", description: "Kopie speichern unter…")
                            ShortcutRow(keys: "⇧⌘E", description: "Exportieren…")
                            ShortcutRow(keys: "⇧⌘B", description: "Batch Export…")
                        }
                    }
                    .padding(.top, 6)
                }
            }
            .padding(DesignSystem.Spacing.large)
            .background(DesignSystem.Colors.background2)
            .cornerRadius(12)
            .padding(18)
        }
        .frame(width: 720, height: 680)
        .lightroomSidebarTheme()
    }
    
    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("Tastenkürzel")
                    .font(DesignSystem.Fonts.semibold(size: 16))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Text("Schneller arbeiten – Lightroom-like Workflow")
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text2)
            }
            
            Spacer()
            
            Button("Schließen") { dismiss() }
                .buttonStyle(LightroomSecondaryButtonStyle())
        }
    }
}

private struct ShortcutSection<Content: View>: View {
    let title: String
    @ViewBuilder let content: Content
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(title)
                .font(DesignSystem.Fonts.semibold(size: 13))
                .foregroundColor(DesignSystem.Colors.text)
            
            VStack(spacing: 6) {
                content
            }
            .padding(10)
            .background(DesignSystem.Colors.background4)
            .cornerRadius(10)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
            )
        }
    }
}

private struct ShortcutRow: View {
    let keys: String
    let description: String
    
    var body: some View {
        HStack(alignment: .firstTextBaseline, spacing: 10) {
            Text(keys)
                .font(.system(size: 12, weight: .semibold, design: .monospaced))
                .foregroundColor(.white)
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(Color.black.opacity(0.55))
                .cornerRadius(8)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(Color.white.opacity(0.08), lineWidth: 1)
                )
                .frame(width: 140, alignment: .leading)
            
            Text(description)
                .font(DesignSystem.Fonts.regular(size: 12))
                .foregroundColor(DesignSystem.Colors.text2)
            
            Spacer(minLength: 0)
        }
    }
}


