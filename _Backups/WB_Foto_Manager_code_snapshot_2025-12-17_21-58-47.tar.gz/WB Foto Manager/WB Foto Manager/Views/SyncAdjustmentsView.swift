//
//  SyncAdjustmentsView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 15.12.2025.
//

import SwiftUI

/// Sheet für Sync‑Einstellungen (Lightroom‑Like: Welche Kategorien sollen synchronisiert werden?)
struct SyncAdjustmentsView: View {
    @EnvironmentObject var store: PhotoStore
    @Environment(\.dismiss) var dismiss
    
    // Scope-Kategorien (Lightroom-Style)
    @State private var syncWhiteBalance = true
    @State private var syncExposure = true
    @State private var syncContrast = true
    @State private var syncTone = true // highlights, shadows, whites, blacks
    @State private var syncPresence = true // clarity, vibrance, saturation
    @State private var syncDetails = true // sharpness, noise
    @State private var syncColorAdjustments = true // hue shifts
    @State private var syncCropAndRotation = false
    
    private var targetCount: Int {
        store.selectedPhotoIDs.count
    }
    
    private var allSelected: Bool {
        syncWhiteBalance && syncExposure && syncContrast && syncTone && syncPresence && syncDetails && syncColorAdjustments && syncCropAndRotation
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Text("Einstellungen synchronisieren")
                    .font(DesignSystem.Fonts.semibold(size: 16))
                    .foregroundColor(DesignSystem.Colors.text)
                Spacer()
                Button("Abbrechen") {
                    dismiss()
                }
                .buttonStyle(LightroomSecondaryButtonStyle())
            }
            .padding(DesignSystem.Spacing.large)
            .background(DesignSystem.Colors.background2)
            
            Divider()
            
            // Content
            ScrollView {
                VStack(alignment: .leading, spacing: DesignSystem.Spacing.medium) {
                    // Info
                    HStack(spacing: 8) {
                        Image(systemName: "info.circle")
                            .foregroundColor(DesignSystem.Colors.accent)
                        Text("Einstellungen vom aktuellen Bild auf \(targetCount) ausgewählte Bilder übertragen")
                            .font(DesignSystem.Fonts.regular(size: 13))
                            .foregroundColor(DesignSystem.Colors.text2)
                    }
                    .padding(DesignSystem.Spacing.medium)
                    .background(DesignSystem.Colors.background3.opacity(0.5))
                    .cornerRadius(DesignSystem.CornerRadius.small)
                    
                    Divider()
                    
                    // Quick Actions
                    HStack(spacing: DesignSystem.Spacing.medium) {
                        Button(allSelected ? "Keine auswählen" : "Alle auswählen") {
                            let newValue = !allSelected
                            syncWhiteBalance = newValue
                            syncExposure = newValue
                            syncContrast = newValue
                            syncTone = newValue
                            syncPresence = newValue
                            syncDetails = newValue
                            syncColorAdjustments = newValue
                            syncCropAndRotation = newValue
                        }
                        .buttonStyle(LightroomSecondaryButtonStyle())
                        
                        Button("Standard") {
                            syncWhiteBalance = true
                            syncExposure = true
                            syncContrast = true
                            syncTone = true
                            syncPresence = true
                            syncDetails = true
                            syncColorAdjustments = true
                            syncCropAndRotation = false
                        }
                        .buttonStyle(LightroomSecondaryButtonStyle())
                    }
                    
                    Divider()
                    
                    // Kategorien (Lightroom-Style)
                    VStack(alignment: .leading, spacing: DesignSystem.Spacing.medium) {
                        Text("Zu synchronisierende Einstellungen")
                            .font(DesignSystem.Fonts.semibold(size: 11))
                            .foregroundColor(DesignSystem.Colors.text3)
                            .textCase(.uppercase)
                        
                        Toggle("Weißabgleich", isOn: $syncWhiteBalance)
                            .toggleStyle(.checkbox)
                        
                        Toggle("Belichtung", isOn: $syncExposure)
                            .toggleStyle(.checkbox)
                        
                        Toggle("Kontrast", isOn: $syncContrast)
                            .toggleStyle(.checkbox)
                        
                        Toggle("Tonwerte (Lichter, Tiefen, Weiß, Schwarz)", isOn: $syncTone)
                            .toggleStyle(.checkbox)
                        
                        Toggle("Präsenz (Klarheit, Lebendigkeit, Sättigung)", isOn: $syncPresence)
                            .toggleStyle(.checkbox)
                        
                        Toggle("Details (Schärfe, Rauschreduzierung)", isOn: $syncDetails)
                            .toggleStyle(.checkbox)
                        
                        Toggle("Farbanpassungen (Farbton-Verschiebungen)", isOn: $syncColorAdjustments)
                            .toggleStyle(.checkbox)
                        
                        Divider()
                        
                        Toggle("Zuschnitt & Drehung", isOn: $syncCropAndRotation)
                            .toggleStyle(.checkbox)
                    }
                    .foregroundColor(DesignSystem.Colors.text)
                }
                .padding(DesignSystem.Spacing.large)
            }
            
            Divider()
            
            // Footer Actions
            HStack {
                Spacer()
                Button("Abbrechen") {
                    dismiss()
                }
                .buttonStyle(LightroomSecondaryButtonStyle())
                
                Button("Synchronisieren") {
                    performSync()
                    dismiss()
                }
                .buttonStyle(LightroomPrimaryButtonStyle())
                .disabled(targetCount == 0)
            }
            .padding(DesignSystem.Spacing.large)
            .background(DesignSystem.Colors.background2)
        }
        .frame(width: 500, height: 600)
        .background(DesignSystem.Colors.background)
        .lightroomSidebarTheme()
    }
    
    private func performSync() {
        let scope = SyncScope(
            whiteBalance: syncWhiteBalance,
            exposure: syncExposure,
            contrast: syncContrast,
            tone: syncTone,
            presence: syncPresence,
            details: syncDetails,
            colorAdjustments: syncColorAdjustments,
            cropAndRotation: syncCropAndRotation
        )
        store.syncFromCurrentToSelection(scope: scope)
    }
}

// MARK: - Lightroom Button Styles (falls noch nicht global definiert)

struct LightroomPrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(DesignSystem.Fonts.regular(size: 13))
            .foregroundColor(.white)
            .padding(.horizontal, DesignSystem.Spacing.medium)
            .padding(.vertical, DesignSystem.Spacing.small)
            .background(DesignSystem.Colors.accent)
            .cornerRadius(DesignSystem.CornerRadius.small)
            .opacity(configuration.isPressed ? 0.8 : 1.0)
    }
}

