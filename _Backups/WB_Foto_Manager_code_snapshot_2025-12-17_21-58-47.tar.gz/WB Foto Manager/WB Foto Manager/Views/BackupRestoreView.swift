//
//  BackupRestoreView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit
import UniformTypeIdentifiers

struct BackupRestoreView: View {
    @ObservedObject var store: PhotoStore
    @State private var isBackingUp = false
    @State private var isRestoring = false
    @State private var isValidatingBackup = false
    @State private var showDetails = false
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        ZStack {
            DesignSystem.Colors.background3
                .ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 14) {
                Text("Backup & Wiederherstellung")
                    .font(DesignSystem.Fonts.semibold(size: 16))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Text("Erstellt eine einzelne .json Datei mit Ihren App‑Daten (keine Fotos).")
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text2)
                
                Divider().opacity(0.6)
                
                // Backup Section
                VStack(alignment: .leading, spacing: 10) {
                    Text("Backup erstellen")
                        .font(DesignSystem.Fonts.semibold(size: 13))
                        .foregroundColor(DesignSystem.Colors.text)
                    
                    Text("Enthält:")
                        .font(DesignSystem.Fonts.regular(size: 11))
                        .foregroundColor(DesignSystem.Colors.text2)
                    
                    VStack(alignment: .leading, spacing: 6) {
                        BackupItem(name: "Export‑Presets", count: store.exportPresets.count)
                        BackupItem(name: "Adjustment‑Presets", count: store.adjustmentPresets.count)
                        BackupItem(name: "Preset‑Kategorien", count: store.presetGroups.count)
                        BackupItem(name: "IPTC‑Templates", count: store.iptcTemplates.count)
                        BackupItem(name: "Upload‑Ziele", count: store.uploadTargets.count)
                        BackupItem(name: "Finder‑Favoriten", count: favoriteFolderCount)
                        BackupItem(name: "Zuletzt geöffnet", count: recentFolderCount)
                        BackupItem(name: "Ordner‑Berechtigungen (Bookmarks)", count: folderBookmarkCount)
                        BackupItem(name: "App‑Einstellungen", count: 1)
                    }
                    .padding(12)
                    .background(DesignSystem.Colors.background4)
                    .cornerRadius(DesignSystem.CornerRadius.medium)
                    .overlay(
                        RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.medium)
                            .stroke(DesignSystem.Colors.border, lineWidth: 1)
                    )
                    
                    DisclosureGroup(isExpanded: $showDetails) {
                        ScrollView {
                            VStack(alignment: .leading, spacing: 10) {
                                BackupNameList(title: "Export‑Presets", names: store.exportPresets.map(\.name))
                                BackupNameList(title: "Adjustment‑Presets", names: store.adjustmentPresets.map(\.name))
                                BackupNameList(title: "IPTC‑Templates", names: store.iptcTemplates.map(\.name))
                                BackupNameList(title: "Upload‑Ziele", names: store.uploadTargets.map(\.name))
                            }
                            .padding(.top, 8)
                        }
                        .frame(maxHeight: 170)
                    } label: {
                        Text("Details anzeigen")
                            .font(DesignSystem.Fonts.medium(size: 12))
                            .foregroundColor(DesignSystem.Colors.text)
                    }
                    .tint(DesignSystem.Colors.text)
                    
                    Button("Backup erstellen…") {
                        createBackup()
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(isBackingUp || isRestoring)
                }
                
                Divider().opacity(0.6)
                
                // Restore Section
                VStack(alignment: .leading, spacing: 10) {
                    Text("Wiederherstellen")
                        .font(DesignSystem.Fonts.semibold(size: 13))
                        .foregroundColor(DesignSystem.Colors.text)
                    
                    Text("Warnung: Beim Wiederherstellen werden alle aktuellen App‑Daten überschrieben.")
                        .font(DesignSystem.Fonts.regular(size: 11))
                        .foregroundColor(DesignSystem.Colors.text2)
                    
                    HStack(spacing: 10) {
                        Button("Backup prüfen…") {
                            validateBackup()
                        }
                        .buttonStyle(LightroomSecondaryButtonStyle())
                        .disabled(isBackingUp || isRestoring || isValidatingBackup)
                        
                        Button("Aus Backup wiederherstellen…") {
                            restoreBackup()
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(isBackingUp || isRestoring || isValidatingBackup)
                    }
                }
                
                if isBackingUp {
                    HStack(spacing: 10) {
                        ProgressView().controlSize(.small)
                        Text("Backup wird erstellt…")
                            .font(DesignSystem.Fonts.regular(size: 12))
                            .foregroundColor(DesignSystem.Colors.text2)
                    }
                }
                
                if isRestoring {
                    HStack(spacing: 10) {
                        ProgressView().controlSize(.small)
                        Text("Wiederherstellung läuft…")
                            .font(DesignSystem.Fonts.regular(size: 12))
                            .foregroundColor(DesignSystem.Colors.text2)
                    }
                }

                if isValidatingBackup {
                    HStack(spacing: 10) {
                        ProgressView().controlSize(.small)
                        Text("Backup wird geprüft…")
                            .font(DesignSystem.Fonts.regular(size: 12))
                            .foregroundColor(DesignSystem.Colors.text2)
                    }
                }
                
                Spacer(minLength: 0)
                
                Button("Fertig") {
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
                .frame(maxWidth: .infinity)
            }
            .padding(DesignSystem.Spacing.large)
        }
        .lightroomSidebarTheme()
        .frame(width: 560, height: 560)
    }
    
    private func createBackup() {
        let savePanel = NSSavePanel()
        savePanel.allowedContentTypes = [.json]
        let timestamp = Int(Date().timeIntervalSince1970)
        savePanel.nameFieldStringValue = "WB_Foto_Manager_Backup_\(timestamp).json"
        savePanel.prompt = "Sichern"
        
        if savePanel.runModal() == .OK, let url = savePanel.url {
            isBackingUp = true
            
            Task {
                do {
                    let backup = BackupData(
                        exportPresets: store.exportPresets,
                        adjustmentPresets: store.adjustmentPresets,
                        iptcTemplates: store.iptcTemplates,
                        uploadTargets: store.uploadTargets,
                        exportQueueEnabled: store.exportQueueEnabled,
                        exportQueueMinRating: store.exportQueueMinRating,
                        presetGroups: store.presetGroups,
                        favoriteFolders: UserDefaults.standard.stringArray(forKey: "favoriteFolders"),
                        recentFolders: UserDefaults.standard.stringArray(forKey: "recentFolders"),
                        folderBookmarks: UserDefaults.standard.dictionary(forKey: "folderBookmarks") as? [String: Data],
                        appSettings: AppSettingsBackup(settings: AppSettings.shared),
                        createdAt: Date(),
                        version: 2
                    )
                    
                    let encoder = JSONEncoder()
                    encoder.outputFormatting = .prettyPrinted
                    let data = try encoder.encode(backup)
                    
                    try data.write(to: url, options: [.atomic])
                    
                    // Roundtrip-Check: Datei direkt wieder einlesen & decodieren
                    let verified = try loadBackup(from: url)
                    
                    DispatchQueue.main.async {
                        self.isBackingUp = false
                        
                        let alert = NSAlert()
                        alert.messageText = "Backup erstellt & geprüft"
                        alert.informativeText = "Datei: \(url.lastPathComponent)\n\n\(backupSummary(for: verified))"
                        alert.alertStyle = .informational
                        alert.runModal()
                    }
                } catch {
                    print("Backup error: \(error)")
                    DispatchQueue.main.async {
                        self.isBackingUp = false
                        
                        let alert = NSAlert()
                        alert.messageText = "Backup fehlgeschlagen"
                        alert.informativeText = error.localizedDescription
                        alert.alertStyle = .warning
                        alert.runModal()
                    }
                }
            }
        }
    }

    private func validateBackup() {
        let openPanel = NSOpenPanel()
        openPanel.allowedContentTypes = [.json]
        openPanel.allowsMultipleSelection = false
        openPanel.canChooseFiles = true
        openPanel.canChooseDirectories = false
        
        if openPanel.runModal() == .OK, let url = openPanel.url {
            isValidatingBackup = true
            
            Task {
                do {
                    let backup = try loadBackup(from: url)
                    
                    DispatchQueue.main.async {
                        self.isValidatingBackup = false
                        
                        let alert = NSAlert()
                        alert.messageText = "Backup gültig"
                        alert.informativeText = "Datei: \(url.lastPathComponent)\n\n\(backupSummary(for: backup))"
                        alert.alertStyle = .informational
                        alert.runModal()
                    }
                } catch {
                    DispatchQueue.main.async {
                        self.isValidatingBackup = false
                        
                        let alert = NSAlert()
                        alert.messageText = "Backup ungültig"
                        alert.informativeText = error.localizedDescription
                        alert.alertStyle = .warning
                        alert.runModal()
                    }
                }
            }
        }
    }
    
    private func restoreBackup() {
        let alert = NSAlert()
        alert.messageText = "Backup wiederherstellen?"
        alert.informativeText = "Alle aktuellen Einstellungen, Presets und Templates werden überschrieben. Diese Aktion kann nicht rückgängig gemacht werden."
        alert.alertStyle = .warning
        alert.addButton(withTitle: "Wiederherstellen")
        alert.addButton(withTitle: "Abbrechen")
        
        if alert.runModal() != .alertFirstButtonReturn {
            return
        }
        
        let openPanel = NSOpenPanel()
        openPanel.allowedContentTypes = [.json]
        openPanel.allowsMultipleSelection = false
        openPanel.canChooseFiles = true
        openPanel.canChooseDirectories = false
        
        if openPanel.runModal() == .OK, let url = openPanel.url {
            isRestoring = true
            
            Task {
                do {
                    let data = try Data(contentsOf: url)
                    let decoder = JSONDecoder()
                    let backup = try decoder.decode(BackupData.self, from: data)
                    
                    DispatchQueue.main.async {
                        store.exportPresets = backup.exportPresets
                        store.adjustmentPresets = backup.adjustmentPresets
                        store.iptcTemplates = backup.iptcTemplates
                        store.uploadTargets = backup.uploadTargets
                        store.exportQueueEnabled = backup.exportQueueEnabled
                        store.exportQueueMinRating = backup.exportQueueMinRating
                        
                        if let groups = backup.presetGroups {
                            store.presetGroups = groups
                            store.savePresetGroups()
                        }
                        
                        if let favorites = backup.favoriteFolders {
                            UserDefaults.standard.set(favorites, forKey: "favoriteFolders")
                        }
                        if let recents = backup.recentFolders {
                            UserDefaults.standard.set(recents, forKey: "recentFolders")
                        }
                        if let bookmarks = backup.folderBookmarks {
                            UserDefaults.standard.set(bookmarks, forKey: "folderBookmarks")
                        }
                        if let settings = backup.appSettings {
                            settings.apply(to: AppSettings.shared)
                        }
                        
                        NotificationCenter.default.post(name: NSNotification.Name("SidebarFoldersUpdated"), object: nil)
                        
                        // Speichere alle Daten
                        store.saveExportPresets()
                        store.saveAdjustmentPresets()
                        store.saveIPTCTemplates()
                        store.saveUploadTargets()
                        
                        self.isRestoring = false
                        
                        let successAlert = NSAlert()
                        successAlert.messageText = "Wiederherstellung erfolgreich"
                        successAlert.informativeText = "Alle Einstellungen wurden wiederhergestellt."
                        successAlert.alertStyle = .informational
                        successAlert.runModal()
                    }
                } catch {
                    print("Restore error: \(error)")
                    DispatchQueue.main.async {
                        self.isRestoring = false
                        
                        let alert = NSAlert()
                        alert.messageText = "Wiederherstellung fehlgeschlagen"
                        alert.informativeText = error.localizedDescription
                        alert.alertStyle = .warning
                        alert.runModal()
                    }
                }
            }
        }
    }

    private func loadBackup(from url: URL) throws -> BackupData {
        let data = try Data(contentsOf: url)
        let decoder = JSONDecoder()
        return try decoder.decode(BackupData.self, from: data)
    }

    private func backupSummary(for backup: BackupData) -> String {
        var lines: [String] = []
        
        if let createdAt = backup.createdAt {
            let stamp = DateFormatter.localizedString(from: createdAt, dateStyle: .medium, timeStyle: .short)
            lines.append("Erstellt: \(stamp)")
        }
        if let version = backup.version {
            lines.append("Backup‑Version: \(version)")
        }
        
        lines.append("Export‑Presets: \(backup.exportPresets.count)")
        lines.append("Adjustment‑Presets: \(backup.adjustmentPresets.count)")
        lines.append("Preset‑Kategorien: \(backup.presetGroups?.count ?? 0)")
        lines.append("IPTC‑Templates: \(backup.iptcTemplates.count)")
        lines.append("Upload‑Ziele: \(backup.uploadTargets.count)")
        lines.append("Finder‑Favoriten: \(backup.favoriteFolders?.count ?? 0)")
        lines.append("Zuletzt geöffnet: \(backup.recentFolders?.count ?? 0)")
        lines.append("Folder‑Bookmarks: \(backup.folderBookmarks?.count ?? 0)")
        lines.append("App‑Einstellungen: \(backup.appSettings == nil ? 0 : 1)")
        
        return lines.joined(separator: "\n")
    }
}

struct BackupItem: View {
    let name: String
    let count: Int
    
    var body: some View {
        HStack {
            Text(name)
                .foregroundColor(DesignSystem.Colors.text)
            Spacer()
            Text("\(count)")
                .foregroundColor(DesignSystem.Colors.text2)
        }
        .font(DesignSystem.Fonts.regular(size: 12))
    }
}

private struct BackupNameList: View {
    let title: String
    let names: [String]
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("\(title) (\(names.count))")
                .font(DesignSystem.Fonts.semibold(size: 11))
                .foregroundColor(DesignSystem.Colors.text2)
                .tracking(0.5)
            
            if names.isEmpty {
                Text("—")
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text2)
            } else {
                Text(names.sorted().joined(separator: ", "))
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(10)
        .background(DesignSystem.Colors.background3)
        .cornerRadius(DesignSystem.CornerRadius.small)
        .overlay(
            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
    }
}

struct BackupData: Codable {
    let exportPresets: [ExportPreset]
    let adjustmentPresets: [AdjustmentPreset]
    let iptcTemplates: [IPTCTemplate]
    let uploadTargets: [UploadTarget]
    let exportQueueEnabled: Bool
    let exportQueueMinRating: Int

    // v2 additions (optional, damit alte Backups weiterhin geladen werden können)
    let presetGroups: [String]?
    let favoriteFolders: [String]?
    let recentFolders: [String]?
    let folderBookmarks: [String: Data]?
    let appSettings: AppSettingsBackup?
    let createdAt: Date?
    let version: Int?
}

struct AppSettingsBackup: Codable {
    let autoOpenLastFolder: Bool
    let searchSubfolders: Bool
    let saveRatingInXMP: Bool
    let autoLoadIPTC: Bool
    let backupBeforeOverwrite: Bool
    let previewQuality: Double
    let maxCacheSize: Int
    let hardwareAcceleration: Bool
    let progressiveRendering: Bool
    let defaultExportFormat: String
    let defaultExportQuality: Double
    let filenameTemplate: String
    let theme: String
    let sidebarAlwaysVisible: Bool
    let showSidebarIcons: Bool
    let autoAdvanceAfterRating: Bool
    
    init(settings: AppSettings) {
        self.autoOpenLastFolder = settings.autoOpenLastFolder
        self.searchSubfolders = settings.searchSubfolders
        self.saveRatingInXMP = settings.saveRatingInXMP
        self.autoLoadIPTC = settings.autoLoadIPTC
        self.backupBeforeOverwrite = settings.backupBeforeOverwrite
        self.previewQuality = settings.previewQuality
        self.maxCacheSize = settings.maxCacheSize
        self.hardwareAcceleration = settings.hardwareAcceleration
        self.progressiveRendering = settings.progressiveRendering
        self.defaultExportFormat = settings.defaultExportFormat
        self.defaultExportQuality = settings.defaultExportQuality
        self.filenameTemplate = settings.filenameTemplate
        self.theme = settings.theme
        self.sidebarAlwaysVisible = settings.sidebarAlwaysVisible
        self.showSidebarIcons = settings.showSidebarIcons
        self.autoAdvanceAfterRating = settings.autoAdvanceAfterRating
    }
    
    func apply(to settings: AppSettings) {
        settings.autoOpenLastFolder = autoOpenLastFolder
        settings.searchSubfolders = searchSubfolders
        settings.saveRatingInXMP = saveRatingInXMP
        settings.autoLoadIPTC = autoLoadIPTC
        settings.backupBeforeOverwrite = backupBeforeOverwrite
        settings.previewQuality = previewQuality
        settings.maxCacheSize = maxCacheSize
        settings.hardwareAcceleration = hardwareAcceleration
        settings.progressiveRendering = progressiveRendering
        settings.defaultExportFormat = defaultExportFormat
        settings.defaultExportQuality = defaultExportQuality
        settings.filenameTemplate = filenameTemplate
        settings.theme = theme
        settings.sidebarAlwaysVisible = sidebarAlwaysVisible
        settings.showSidebarIcons = showSidebarIcons
        settings.autoAdvanceAfterRating = autoAdvanceAfterRating
    }
}

private extension BackupRestoreView {
    var favoriteFolderCount: Int {
        UserDefaults.standard.stringArray(forKey: "favoriteFolders")?.count ?? 0
    }
    
    var recentFolderCount: Int {
        UserDefaults.standard.stringArray(forKey: "recentFolders")?.count ?? 0
    }
    
    var folderBookmarkCount: Int {
        UserDefaults.standard.dictionary(forKey: "folderBookmarks")?.count ?? 0
    }
}

