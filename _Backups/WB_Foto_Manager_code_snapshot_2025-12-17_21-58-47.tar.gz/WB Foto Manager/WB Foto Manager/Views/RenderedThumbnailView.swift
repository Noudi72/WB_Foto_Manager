//
//  RenderedThumbnailView.swift
//  WB Foto Manager
//
//  Shows a thumbnail that includes non-destructive edits (for Virtual Copies)
//

import SwiftUI

struct RenderedThumbnailView: View {
    @ObservedObject var photo: PhotoItem
    let maxDimension: CGFloat
    let interpolation: Image.Interpolation
    
    @State private var image: NSImage?
    @State private var isRendering: Bool = false
    @State private var task: Task<Void, Never>?
    
    init(photo: PhotoItem, maxDimension: CGFloat, interpolation: Image.Interpolation = .high) {
        self.photo = photo
        self.maxDimension = maxDimension
        self.interpolation = interpolation
    }
    
    var body: some View {
        ZStack {
            if let img = image {
                Image(nsImage: img)
                    .interpolation(interpolation)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            } else {
                Rectangle().fill(DesignSystem.Colors.background3)
            }
            
            if image == nil || isRendering {
                ProgressView()
                    .scaleEffect(0.7)
                    .opacity(image == nil ? 1.0 : 0.75)
            }
        }
        .clipped()
        .onAppear(perform: render)
        .onDisappear {
            task?.cancel()
            task = nil
        }
        // Re-render when edit state changes
        .onChange(of: photo.id) { _, _ in render() }
        .onChange(of: photo.adjustments) { _, _ in render() }
        .onChange(of: photo.localMasks) { _, _ in render() }
        .onChange(of: photo.lensProfileSettings) { _, _ in render() }
        .onChange(of: photo.cropRect) { _, _ in render() }
        .onChange(of: photo.rotation) { _, _ in render() }
    }
    
    private func render() {
        task?.cancel()
        isRendering = true
        
        task = Task(priority: .userInitiated) {
            let rendered = await RenderedThumbnailService.shared.renderedThumbnail(for: photo, maxDimension: maxDimension)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                self.image = rendered ?? self.image
                self.isRendering = false
            }
        }
    }
}


