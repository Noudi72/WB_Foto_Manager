//
//  HistogramView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import CoreImage

struct HistogramView: View {
    let image: CIImage?
    var toneAdjustments: Binding<PhotoAdjustments>? = nil
    var onRequestImageUpdate: (() -> Void)? = nil
    var onBeginToneEdit: (() -> Void)? = nil
    var onEndToneEdit: (() -> Void)? = nil
    @State private var histogramData: [Int] = []
    @State private var channel: HistogramChannel = .luminance
    @State private var histogramTask: Task<Void, Never>?
    
    @State private var activeToneZone: ToneZone?
    @State private var toneDragStart: PhotoAdjustments?
    @State private var toneUpdateTask: Task<Void, Never>?
    
    nonisolated private static let histogramContext = CIContext(options: [
        // Für Histogramm bewusst Software-Renderer nutzen:
        // - stabil (keine IOSurface/GPU-Edgecases)
        // - schnell genug, weil wir eh auf kleines Downsample rendern
        .useSoftwareRenderer: true,
        .cacheIntermediates: false,
        .workingColorSpace: NSNull(),
        .outputColorSpace: NSNull()
    ])
    
    enum HistogramChannel {
        case luminance
        case red
        case green
        case blue
    }
    
    enum ToneZone: String {
        case blacks = "Schwarz"
        case shadows = "Tiefen"
        case exposure = "Belichtung"
        case highlights = "Lichter"
        case whites = "Weiß"
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            // Channel Selector (Label getrennt, damit es nicht vertikal umbrechen kann)
            Text("Kanal")
                .font(DesignSystem.Fonts.regular(size: 11))
                .foregroundColor(DesignSystem.Colors.text2)
                .lineLimit(1)
                .fixedSize(horizontal: true, vertical: false)
            
            Picker("", selection: $channel) {
                Text("Luminanz").tag(HistogramChannel.luminance)
                Text("Rot").tag(HistogramChannel.red)
                Text("Grün").tag(HistogramChannel.green)
                Text("Blau").tag(HistogramChannel.blue)
            }
            .labelsHidden()
            .pickerStyle(.segmented)
            .onChange(of: channel) { _, _ in updateHistogram() }
            
            // Histogram Display
            if !histogramData.isEmpty {
                GeometryReader { geometry in
                    ZStack(alignment: .topLeading) {
                        HistogramChart(
                            data: histogramData,
                            size: geometry.size,
                            color: channelColor
                        )
                        
                        HistogramClippingIndicators(data: histogramData)
                        
                        if let zone = activeToneZone, let adjustments = toneAdjustments?.wrappedValue {
                            Text(overlayText(for: zone, adjustments: adjustments))
                                .font(DesignSystem.Fonts.medium(size: 11))
                                .foregroundColor(DesignSystem.Colors.text)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 6)
                                .background(DesignSystem.Colors.background4.opacity(0.95))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 6)
                                        .stroke(DesignSystem.Colors.border, lineWidth: 1)
                                )
                                .cornerRadius(6)
                                .padding(8)
                        }
                    }
                    .contentShape(Rectangle())
                    .gesture(histogramToneGesture(in: geometry.size))
                }
                .frame(height: 150)
            } else {
                Rectangle()
                    .fill(DesignSystem.Colors.background4)
                    .frame(height: 150)
                    .overlay(
                        Text("Kein Histogramm verfügbar")
                            .font(DesignSystem.Fonts.regular(size: 12))
                            .foregroundColor(DesignSystem.Colors.text2)
                    )
                    .overlay(
                        Rectangle()
                            .stroke(DesignSystem.Colors.border, lineWidth: 1)
                    )
            }
            
            // Statistics
            if !histogramData.isEmpty {
                HistogramStats(data: histogramData)
            }
        }
        .padding(DesignSystem.Spacing.medium)
        .onAppear {
            updateHistogram()
        }
        .onChange(of: image) { _, _ in updateHistogram() }
    }
    
    private func histogramToneGesture(in size: CGSize) -> some Gesture {
        DragGesture(minimumDistance: 4)
            .onChanged { value in
                guard let toneAdjustments else { return }
                guard size.width > 0 else { return }
                
                // Wähle Zone anhand Startposition (wie Lightroom)
                let xNorm = max(0, min(1, value.startLocation.x / size.width))
                let zone = toneZone(for: xNorm)
                
                if activeToneZone == nil {
                    activeToneZone = zone
                    toneDragStart = toneAdjustments.wrappedValue
                    onBeginToneEdit?()
                }
                
                guard let start = toneDragStart else { return }
                
                // Hauptsächlich horizontale Drags berücksichtigen (sonst fühlt sich Scrollen kaputt an)
                if abs(value.translation.height) > abs(value.translation.width) * 1.2 {
                    return
                }
                
                var next = start
                let dx = Double(value.translation.width)
                let w = max(1.0, Double(size.width))
                let dxNorm = dx / w // normiert, damit sich das über alle Sidebar-Breiten gleich anfühlt
                
                switch zone {
                case .blacks:
                    next.blacks = clamp(start.blacks + dxNorm * 160.0, -100, 100)
                case .shadows:
                    next.shadows = clamp(start.shadows + dxNorm * 160.0, -100, 100)
                case .exposure:
                    next.exposure = clamp(start.exposure + dxNorm * 2.4, -2.0, 2.0)
                case .highlights:
                    next.highlights = clamp(start.highlights + dxNorm * 160.0, -100, 100)
                case .whites:
                    next.whites = clamp(start.whites + dxNorm * 160.0, -100, 100)
                }
                
                toneAdjustments.wrappedValue = next
                scheduleToneImageUpdate()
            }
            .onEnded { _ in
                // Commit Update (sofort) und Overlay ausblenden
                toneUpdateTask?.cancel()
                onRequestImageUpdate?()
                onEndToneEdit?()
                activeToneZone = nil
                toneDragStart = nil
            }
    }
    
    private func scheduleToneImageUpdate() {
        toneUpdateTask?.cancel()
        toneUpdateTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 90_000_000) // ~90ms
            onRequestImageUpdate?()
        }
    }
    
    private func toneZone(for x: CGFloat) -> ToneZone {
        switch x {
        case ..<0.2: return .blacks
        case ..<0.4: return .shadows
        case ..<0.6: return .exposure
        case ..<0.8: return .highlights
        default: return .whites
        }
    }
    
    private func overlayText(for zone: ToneZone, adjustments: PhotoAdjustments) -> String {
        switch zone {
        case .blacks:
            return "\(zone.rawValue): \(Int(adjustments.blacks))"
        case .shadows:
            return "\(zone.rawValue): \(Int(adjustments.shadows))"
        case .exposure:
            return "\(zone.rawValue): \(adjustments.exposure.formatted(.number.precision(.fractionLength(2)))) EV"
        case .highlights:
            return "\(zone.rawValue): \(Int(adjustments.highlights))"
        case .whites:
            return "\(zone.rawValue): \(Int(adjustments.whites))"
        }
    }
    
    private func clamp<T: Comparable>(_ value: T, _ minValue: T, _ maxValue: T) -> T {
        max(minValue, min(maxValue, value))
    }
    
    private var channelColor: Color {
        switch channel {
        case .luminance:
            return DesignSystem.Colors.accent
        case .red:
            return .red
        case .green:
            return .green
        case .blue:
            return .blue
        }
    }
    
    private func updateHistogram() {
        histogramTask?.cancel()
        
        guard let img = image else {
            histogramData = []
            return
        }
        
        let selectedChannel = channel
        histogramTask = Task.detached(priority: .userInitiated) {
            let data = Self.computeHistogram(for: img, channel: selectedChannel)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                self.histogramData = data
            }
        }
    }

    nonisolated private static func computeHistogram(for img: CIImage, channel: HistogramChannel) -> [Int] {
        let extent = img.extent.integral
        guard extent.width > 0, extent.height > 0 else { return [] }
        
        // Downsample für Performance & Stabilität (funktioniert für JPG + RAW)
        let maxDim: CGFloat = 512
        let longest = max(extent.width, extent.height)
        let scale = max(0.01, min(1.0, maxDim / longest))
        
        let scaled = img
            .transformed(by: CGAffineTransform(scaleX: scale, y: scale))
            .cropped(to: CGRect(origin: .zero, size: CGSize(width: extent.width * scale, height: extent.height * scale)).integral)
        
        let scaledExtent = scaled.extent.integral
        let width = max(1, Int(scaledExtent.width))
        let height = max(1, Int(scaledExtent.height))
        
        var bytes = [UInt8](repeating: 0, count: width * height * 4)
        let cs = CGColorSpaceCreateDeviceRGB()
        Self.histogramContext.render(
            scaled,
            toBitmap: &bytes,
            rowBytes: width * 4,
            bounds: scaledExtent,
            format: .RGBA8,
            colorSpace: cs
        )
        
        var histogram = [Int](repeating: 0, count: 256)
        histogram.reserveCapacity(256)
        
        var i = 0
        while i + 2 < bytes.count {
            let r = Int(bytes[i])
            let g = Int(bytes[i + 1])
            let b = Int(bytes[i + 2])
            
            let value: Int
            switch channel {
            case .luminance:
                value = Int(0.299 * Double(r) + 0.587 * Double(g) + 0.114 * Double(b))
            case .red:
                value = r
            case .green:
                value = g
            case .blue:
                value = b
            }
            
            histogram[max(0, min(255, value))] += 1
            i += 4
        }
        
        return histogram
    }
}

/// Lightroom-ähnliche Clipping-Indikatoren (links: Schatten, rechts: Lichter)
private struct HistogramClippingIndicators: View {
    let data: [Int]
    
    private var total: Int { data.reduce(0, +) }
    private var blackClippingCount: Int {
        // sehr dunkle Pixel (0..1)
        guard data.count >= 2 else { return 0 }
        return (data[0] + data[1])
    }
    private var whiteClippingCount: Int {
        // sehr helle Pixel (254..255)
        guard data.count >= 2 else { return 0 }
        return (data[data.count - 1] + data[data.count - 2])
    }
    
    private var blackClipFraction: Double {
        guard total > 0 else { return 0 }
        return Double(blackClippingCount) / Double(total)
    }
    private var whiteClipFraction: Double {
        guard total > 0 else { return 0 }
        return Double(whiteClippingCount) / Double(total)
    }
    
    // Kleine Deadzone, damit es nicht permanent "an" ist bei minimalem Rauschen
    private var blackActive: Bool { blackClipFraction > 0.0005 }
    private var whiteActive: Bool { whiteClipFraction > 0.0005 }
    
    var body: some View {
        ZStack(alignment: .top) {
            // Subtile Overlays an den Rändern (schnell erfassbar)
            HStack(spacing: 0) {
                Rectangle()
                    .fill(blackActive ? Color.blue.opacity(0.12) : Color.clear)
                    .frame(width: 20)
                
                Spacer(minLength: 0)
                
                Rectangle()
                    .fill(whiteActive ? Color.red.opacity(0.12) : Color.clear)
                    .frame(width: 20)
            }
            
            HStack {
                ClippingTriangle(
                    isActive: blackActive,
                    color: .blue,
                    help: blackActive ? "Schatten‑Clipping: \(formatPercent(blackClipFraction))" : "Kein Schatten‑Clipping"
                )
                
                Spacer()
                
                ClippingTriangle(
                    isActive: whiteActive,
                    color: .red,
                    help: whiteActive ? "Lichter‑Clipping: \(formatPercent(whiteClipFraction))" : "Kein Lichter‑Clipping"
                )
            }
            .padding(6)
        }
        .allowsHitTesting(false) // rein informativ
    }
    
    private func formatPercent(_ value: Double) -> String {
        let pct = value * 100.0
        if pct < 0.1 { return "<0.1%" }
        return String(format: "%.1f%%", pct)
    }
}

private struct ClippingTriangle: View {
    let isActive: Bool
    let color: Color
    let help: String
    
    var body: some View {
        Image(systemName: "triangle.fill")
            .rotationEffect(.degrees(180)) // nach unten zeigen
            .font(.system(size: 9, weight: .semibold))
            .foregroundColor(isActive ? color : DesignSystem.Colors.text3)
            .shadow(color: Color.black.opacity(isActive ? 0.25 : 0), radius: 1, x: 0, y: 1)
            .help(help)
    }
}

struct HistogramChart: View {
    let data: [Int]
    let size: CGSize
    let color: Color
    
    private var maxValue: Int {
        max(1, data.max() ?? 1)
    }
    
    var body: some View {
        GeometryReader { geometry in
            Path { path in
                let width = geometry.size.width
                let height = geometry.size.height
                let binWidth = width / CGFloat(data.count)
                
                for (index, value) in data.enumerated() {
                    let x = CGFloat(index) * binWidth
                    let normalizedValue = CGFloat(value) / CGFloat(maxValue)
                    let barHeight = normalizedValue * height
                    
                    path.move(to: CGPoint(x: x, y: height))
                    path.addLine(to: CGPoint(x: x, y: height - barHeight))
                }
            }
            .stroke(color, lineWidth: 1)
        }
    }
}

struct HistogramStats: View {
    let data: [Int]
    
    private var mean: Double {
        let total = data.reduce(0, +)
        guard total > 0 else { return 0 }
        var sum = 0.0
        for (index, count) in data.enumerated() {
            sum += Double(index) * Double(count)
        }
        return sum / Double(total)
    }
    
    private var stdDev: Double {
        let m = mean
        let total = data.reduce(0, +)
        guard total > 0 else { return 0 }
        var sum = 0.0
        for (index, count) in data.enumerated() {
            let diff = Double(index) - m
            sum += diff * diff * Double(count)
        }
        return sqrt(sum / Double(total))
    }
    
    var body: some View {
        HStack(spacing: 16) {
            StatItem(label: "Mittelwert", value: String(format: "%.1f", mean))
            StatItem(label: "Std. Abw.", value: String(format: "%.1f", stdDev))
            StatItem(label: "Max", value: "\(data.max() ?? 0)")
        }
        .font(DesignSystem.Fonts.regular(size: 11))
        .foregroundColor(DesignSystem.Colors.text)
    }
}

struct StatItem: View {
    let label: String
    let value: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(label)
                .font(DesignSystem.Fonts.regular(size: 10))
                .foregroundColor(DesignSystem.Colors.text)
            Text(value)
                .font(DesignSystem.Fonts.medium(size: 12))
                .foregroundColor(DesignSystem.Colors.text)
                .monospacedDigit()
        }
    }
}

