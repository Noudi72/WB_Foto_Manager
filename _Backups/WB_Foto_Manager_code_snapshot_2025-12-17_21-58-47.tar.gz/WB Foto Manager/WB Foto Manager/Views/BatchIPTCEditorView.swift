//
//  BatchIPTCEditorView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI

struct BatchIPTCEditorView: View {
    @ObservedObject var store: PhotoStore
    @State private var selectedTemplate: IPTCTemplate?
    @State private var tokenValues: [String: String] = [:]
    @State private var isApplying = false
    @State private var progress: Double = 0.0
    @Environment(\.dismiss) private var dismiss
    
    var photosToProcess: [PhotoItem] {
        if store.selectedPhotoIDs.isEmpty {
            return [store.currentPhoto].compactMap { $0 }
        } else {
            return store.photos.filter { store.selectedPhotoIDs.contains($0.id) }
        }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Stapelverarbeitung - IPTC-Metadaten")
                .font(.headline)
            
            Text("\(photosToProcess.count) Foto(s) werden bearbeitet")
                .font(.caption)
                .foregroundColor(.secondary)
            
            // Template Selection
            Picker("Template", selection: $selectedTemplate) {
                Text("Kein Template").tag(IPTCTemplate?.none)
                ForEach(store.iptcTemplates) { template in
                    Text(template.name).tag(IPTCTemplate?.some(template))
                }
            }
            .pickerStyle(.menu)
            .disabled(isApplying)
            
            if selectedTemplate != nil {
                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Token-Werte")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        // Allgemeine Tokens
                        TokenField(label: "EVENT", value: Binding(
                            get: { tokenValues["{EVENT}"] ?? "" },
                            set: { tokenValues["{EVENT}"] = $0.isEmpty ? nil : $0 }
                        ))
                        TokenField(label: "LOCATION", value: Binding(
                            get: { tokenValues["{LOCATION}"] ?? "" },
                            set: { tokenValues["{LOCATION}"] = $0.isEmpty ? nil : $0 }
                        ))
                        TokenField(label: "VENUE", value: Binding(
                            get: { tokenValues["{VENUE}"] ?? "" },
                            set: { tokenValues["{VENUE}"] = $0.isEmpty ? nil : $0 }
                        ))
                        TokenField(label: "CITY", value: Binding(
                            get: { tokenValues["{CITY}"] ?? "" },
                            set: { tokenValues["{CITY}"] = $0.isEmpty ? nil : $0 }
                        ))
                        TokenField(label: "DESCRIPTION", value: Binding(
                            get: { tokenValues["{DESCRIPTION}"] ?? "" },
                            set: { tokenValues["{DESCRIPTION}"] = $0.isEmpty ? nil : $0 }
                        ))
                        TokenField(label: "PHOTOGRAPHER", value: Binding(
                            get: { tokenValues["{PHOTOGRAPHER}"] ?? "" },
                            set: { tokenValues["{PHOTOGRAPHER}"] = $0.isEmpty ? nil : $0 }
                        ))
                        
                        // Sport-spezifische Tokens
                        Text("Sport")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .padding(.top)
                        
                        TokenField(label: "TEAM_A", value: Binding(
                            get: { tokenValues["{TEAM_A}"] ?? "" },
                            set: { tokenValues["{TEAM_A}"] = $0.isEmpty ? nil : $0 }
                        ))
                        TokenField(label: "TEAM_B", value: Binding(
                            get: { tokenValues["{TEAM_B}"] ?? "" },
                            set: { tokenValues["{TEAM_B}"] = $0.isEmpty ? nil : $0 }
                        ))
                        TokenField(label: "LEAGUE", value: Binding(
                            get: { tokenValues["{LEAGUE}"] ?? "" },
                            set: { tokenValues["{LEAGUE}"] = $0.isEmpty ? nil : $0 }
                        ))
                        TokenField(label: "ARENA", value: Binding(
                            get: { tokenValues["{ARENA}"] ?? "" },
                            set: { tokenValues["{ARENA}"] = $0.isEmpty ? nil : $0 }
                        ))
                        TokenField(label: "PLAYER_NAME", value: Binding(
                            get: { tokenValues["{PLAYER_NAME}"] ?? "" },
                            set: { tokenValues["{PLAYER_NAME}"] = $0.isEmpty ? nil : $0 }
                        ))
                        TokenField(label: "PLAYER_NUMBER", value: Binding(
                            get: { tokenValues["{PLAYER_NUMBER}"] ?? "" },
                            set: { tokenValues["{PLAYER_NUMBER}"] = $0.isEmpty ? nil : $0 }
                        ))
                        TokenField(label: "SITUATION", value: Binding(
                            get: { tokenValues["{SITUATION}"] ?? "" },
                            set: { tokenValues["{SITUATION}"] = $0.isEmpty ? nil : $0 }
                        ))
                    }
                    .padding()
                }
                .frame(height: 300)
            }
            
            if isApplying {
                VStack(alignment: .leading, spacing: 8) {
                    ProgressView(value: progress)
                    Text("\(Int(progress * 100))%")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            HStack {
                Button("Abbrechen") {
                    dismiss()
                }
                .disabled(isApplying)
                
                Spacer()
                
                Button("Anwenden") {
                    applyMetadata()
                }
                .buttonStyle(.borderedProminent)
                .disabled(selectedTemplate == nil || isApplying)
            }
        }
        .padding()
        .frame(width: 600, height: 500)
    }
    
    private func applyMetadata() {
        guard let template = selectedTemplate else { return }
        
        let photos = photosToProcess
        guard !photos.isEmpty else { return }
        
        isApplying = true
        progress = 0.0
        
        Task {
            for (index, photo) in photos.enumerated() {
                let metadata = template.apply(
                    tokenValues: tokenValues,
                    photoDate: photo.iptcMetadata?.date
                )
                
                photo.iptcMetadata = metadata
                
                // Speichere Metadaten
                do {
                    try await Task.detached {
                        try IPTCMetadataService.shared.writeMetadata(metadata, to: photo.url)
                    }.value
                } catch {
                    print("Error saving metadata for \(photo.fileName): \(error)")
                }
                
                DispatchQueue.main.async {
                    self.progress = Double(index + 1) / Double(photos.count)
                }
            }
            
            DispatchQueue.main.async {
                self.isApplying = false
                self.dismiss()
            }
        }
    }
}

