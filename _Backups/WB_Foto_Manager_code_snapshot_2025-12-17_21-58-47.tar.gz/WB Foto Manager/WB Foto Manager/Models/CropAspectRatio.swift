//
//  CropAspectRatio.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation

/// Seitenverhältnisse für Cropping
struct CropAspectRatio: Identifiable, Hashable {
    let id: UUID
    let name: String
    let ratio: Double? // width/height, nil = frei
    
    init(id: UUID = UUID(), name: String, ratio: Double?) {
        self.id = id
        self.name = name
        self.ratio = ratio
    }
    
    static var commonRatios: [CropAspectRatio] {
        [
            CropAspectRatio(name: "Frei", ratio: nil),
            CropAspectRatio(name: "1:1", ratio: 1.0),
            CropAspectRatio(name: "4:3", ratio: 4.0/3.0),
            CropAspectRatio(name: "3:2", ratio: 3.0/2.0),
            CropAspectRatio(name: "16:9", ratio: 16.0/9.0),
            CropAspectRatio(name: "21:9", ratio: 21.0/9.0),
            CropAspectRatio(name: "5:4", ratio: 5.0/4.0),
            CropAspectRatio(name: "2:1", ratio: 2.0/1.0)
        ]
    }
}

