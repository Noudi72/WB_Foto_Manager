//
//  LocalAdjustmentMask.swift
//  WB Foto Manager
//
//  Created by GPT-5.2 on 16.12.2025.
//

import Foundation

/// Normierter Punkt im Bild (0...1), Ursprung oben-links (wie SwiftUI).
nonisolated struct NormalizedPoint: Codable, Hashable, Sendable {
    var x: Double
    var y: Double
    
    init(x: Double, y: Double) {
        self.x = x
        self.y = y
    }
    
    static let center = NormalizedPoint(x: 0.5, y: 0.5)
}

nonisolated enum LocalMaskKind: String, Codable, CaseIterable, Hashable, Sendable {
    case linear
    case radial
    case brush
    
    var title: String {
        switch self {
        case .linear: return "Linear"
        case .radial: return "Radial"
        case .brush: return "Pinsel"
        }
    }
    
    var systemImage: String {
        switch self {
        case .linear: return "line.diagonal"
        case .radial: return "circle.dotted"
        case .brush: return "paintbrush"
        }
    }
}

nonisolated struct LinearMask: Codable, Hashable, Sendable {
    var start: NormalizedPoint
    var end: NormalizedPoint
    
    init(start: NormalizedPoint, end: NormalizedPoint) {
        self.start = start
        self.end = end
    }
    
    static let `default` = LinearMask(
        start: NormalizedPoint(x: 0.35, y: 0.5),
        end: NormalizedPoint(x: 0.65, y: 0.5)
    )
}

nonisolated struct RadialMask: Codable, Hashable, Sendable {
    var center: NormalizedPoint
    /// Radius relativ zur kleineren Bildkante (0...1)
    var radius: Double
    
    init(center: NormalizedPoint, radius: Double) {
        self.center = center
        self.radius = radius
    }
    
    static let `default` = RadialMask(center: .center, radius: 0.28)
}

/// Brush ist (vorerst) nur Daten-Container – die UI/Rendering kommen im nächsten Schritt.
nonisolated struct BrushMask: Codable, Hashable, Sendable {
    var strokes: [BrushStroke] = []
    /// Basis-Radius relativ zur kleineren Bildkante (0...1)
    var baseRadius: Double = 0.035
}

nonisolated struct BrushStroke: Codable, Hashable, Sendable {
    var points: [NormalizedPoint]
    var radius: Double
    
    init(points: [NormalizedPoint], radius: Double) {
        self.points = points
        self.radius = radius
    }
}

/// Eine lokale Maske (Lightroom-Style): Form + Feather/Invert/Opacity + Delta-Adjustments.
nonisolated struct LocalAdjustmentMask: Identifiable, Codable, Hashable, Sendable {
    var id: UUID
    var name: String
    var kind: LocalMaskKind
    
    var isEnabled: Bool = true
    var inverted: Bool = false
    
    /// 0...1 (0 = harte Kante, 1 = sehr weich)
    var feather: Double = 0.35
    /// 0...1 (Stärke der lokalen Anpassung)
    var opacity: Double = 1.0
    
    /// Delta-Adjustments (relativ zu Defaults)
    var adjustments: PhotoAdjustments = PhotoAdjustments()
    
    // Form-Daten (nur jeweils relevant für `kind`)
    var linear: LinearMask? = nil
    var radial: RadialMask? = nil
    var brush: BrushMask? = nil
    
    init(
        id: UUID = UUID(),
        name: String,
        kind: LocalMaskKind,
        isEnabled: Bool = true,
        inverted: Bool = false,
        feather: Double = 0.35,
        opacity: Double = 1.0,
        adjustments: PhotoAdjustments = PhotoAdjustments(),
        linear: LinearMask? = nil,
        radial: RadialMask? = nil,
        brush: BrushMask? = nil
    ) {
        self.id = id
        self.name = name
        self.kind = kind
        self.isEnabled = isEnabled
        self.inverted = inverted
        self.feather = feather
        self.opacity = opacity
        self.adjustments = adjustments
        self.linear = linear
        self.radial = radial
        self.brush = brush
    }
    
    static func makeDefault(kind: LocalMaskKind, name: String? = nil) -> LocalAdjustmentMask {
        let n = name ?? "\(kind.title) Maske"
        switch kind {
        case .linear:
            return LocalAdjustmentMask(name: n, kind: .linear, linear: .default)
        case .radial:
            return LocalAdjustmentMask(name: n, kind: .radial, radial: .default)
        case .brush:
            return LocalAdjustmentMask(name: n, kind: .brush, brush: BrushMask())
        }
    }
}


