//
//  SyncScope.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 15.12.2025.
//

import Foundation

/// Definiert, welche Kategorien von Einstellungen synchronisiert werden sollen (Lightroom-Style)
struct SyncScope {
    var whiteBalance: Bool
    var exposure: Bool
    var contrast: Bool
    var tone: Bool // highlights, shadows, whites, blacks
    var presence: Bool // clarity, vibrance, saturation
    var details: Bool // sharpness, noise
    var colorAdjustments: Bool // hue shifts
    var cropAndRotation: Bool
    
    static var all: SyncScope {
        SyncScope(
            whiteBalance: true,
            exposure: true,
            contrast: true,
            tone: true,
            presence: true,
            details: true,
            colorAdjustments: true,
            cropAndRotation: true
        )
    }
}

