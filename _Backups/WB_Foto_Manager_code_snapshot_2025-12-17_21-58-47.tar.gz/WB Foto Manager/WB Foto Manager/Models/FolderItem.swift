//
//  FolderItem.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import Darwin

/// Repräsentiert einen Ordner in der Sidebar
struct FolderItem: Identifiable, Hashable {
    let id: UUID
    let url: URL
    let name: String
    let type: FolderType
    var isExpanded: Bool
    var children: [FolderItem]
    
    init(id: UUID = UUID(), url: URL, name: String? = nil, type: FolderType, isExpanded: Bool = false, children: [FolderItem] = []) {
        self.id = id
        self.url = url
        self.name = name ?? url.lastPathComponent
        self.type = type
        self.isExpanded = isExpanded
        self.children = children
    }
}

enum FolderType: Hashable {
    case standard(StandardFolder)
    case favorite
    case recent
    case volume
    case regular
    
    var icon: String {
        switch self {
        case .standard(let standard):
            switch standard {
            case .home: return "house.fill"
            case .desktop: return "desktopcomputer"
            case .documents: return "doc.fill"
            case .downloads: return "arrow.down.circle.fill"
            case .pictures: return "photo.fill"
            case .photosLibrary: return "photo.on.rectangle"
            }
        case .favorite: return "star.fill"
        case .recent: return "clock.fill"
        case .volume: return "externaldrive.fill"
        case .regular: return "folder.fill"
        }
    }
}

enum StandardFolder: String, Hashable {
    case home = "Home"
    case desktop = "Desktop"
    case documents = "Documents"
    case downloads = "Downloads"
    case pictures = "Pictures"
    case photosLibrary = "Photos Library"
    
    var url: URL? {
        // In der App-Sandbox zeigen die SearchPathDirectories oft auf Container-Pfade.
        // Für echte Finder-Pfade nutzen wir den Home-Pfad.
        let homeURL: URL = {
            if let pw = getpwuid(getuid()), let dir = pw.pointee.pw_dir {
                return URL(fileURLWithPath: String(cString: dir))
            }
            if let home = NSHomeDirectoryForUser(NSUserName()) {
                return URL(fileURLWithPath: home)
            }
            // Fallback ohne fileExists(), da Sandbox fileExists() manchmal "false" liefert.
            return URL(fileURLWithPath: "/Users").appendingPathComponent(NSUserName())
        }()
        switch self {
        case .home:
            return homeURL
        case .desktop:
            return homeURL.appendingPathComponent("Desktop")
        case .documents:
            return homeURL.appendingPathComponent("Documents")
        case .downloads:
            return homeURL.appendingPathComponent("Downloads")
        case .pictures:
            return homeURL.appendingPathComponent("Pictures")
        case .photosLibrary:
            return homeURL.appendingPathComponent("Pictures").appendingPathComponent("Photos Library.photoslibrary")
        }
    }
    
    private var directoryType: FileManager.SearchPathDirectory {
        switch self {
        case .home: return .userDirectory
        case .desktop: return .desktopDirectory
        case .documents: return .documentDirectory
        case .downloads: return .downloadsDirectory
        case .pictures: return .picturesDirectory
        case .photosLibrary: return .picturesDirectory
        }
    }
}

