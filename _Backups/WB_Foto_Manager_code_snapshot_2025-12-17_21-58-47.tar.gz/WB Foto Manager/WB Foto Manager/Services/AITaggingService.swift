//
//  AITaggingService.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 15.12.2025.
//

import Foundation
import CoreImage
import Vision
import AppKit

/// AI-basierter Service für automatische Keyword-Generierung via Vision Framework
nonisolated final class AITaggingService {
    static let shared = AITaggingService()
    
    private init() {}
    
    /// Analysiert ein Bild und generiert automatische Keywords
    func generateKeywords(for photo: PhotoItem) async -> [String] {
        let image: CIImage
        if let cached = await MainActor.run(body: { photo.loadFullImage() }) {
            image = cached
        } else if let loaded = await photo.loadFullImageAsync() {
            image = loaded
        } else {
            return []
        }
        
        return await Task.detached(priority: .userInitiated) { [weak self] in
            guard let self else { return [] }
            return self.generateKeywords(from: image)
        }.value
    }
    
    /// Analysiert ein CIImage und gibt relevante Keywords zurück
    private func generateKeywords(from image: CIImage) -> [String] {
        // Work on a downscaled copy for Vision (much faster, usually same/better accuracy).
        let analysisImage: CIImage = {
            let extent = image.extent
            let maxDim = max(extent.width, extent.height)
            let targetMax: CGFloat = 1800
            guard maxDim > targetMax, maxDim > 0 else { return image }
            let scale = targetMax / maxDim
            return image.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        }()
        
        let extent = analysisImage.extent
        guard extent.width > 0, extent.height > 0 else { return [] }
        
        // Convert CIImage → CGImage for Vision
        let context = CIContext(options: [.useSoftwareRenderer: false])
        guard let cgImage = context.createCGImage(analysisImage, from: extent) else {
            return []
        }
        
        var keywords: Set<String> = []
        
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        
        func addKeywords(from results: [VNClassificationObservation], topLimit: Int, top3Min: Float, restMin: Float) {
            let top = Array(results.prefix(topLimit))
            for (idx, observation) in top.enumerated() {
                let confidence = observation.confidence
                let minConf: Float = (idx < 3) ? top3Min : restMin
                guard confidence >= minConf else { continue }
                
                // Identifier kann mehrere Labels enthalten, z.B. "outdoor scene, nature"
                // Wichtig: NICHT an Leerzeichen splitten, sonst geht z.B. "ice hockey" kaputt.
                let labels = observation.identifier
                    .split(separator: ",")
                    .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                    .filter { !$0.isEmpty }
                
                for label in labels {
                    let normalized = normalizeLabel(label)
                    guard isUsefulKeyword(normalized) else { continue }
                    keywords.insert(translateToGerman(normalized))
                }
            }
        }
        
        // 1) Scene Classification (Hauptquelle für Keywords)
        do {
            let classifyRequest = VNClassifyImageRequest()
            try handler.perform([classifyRequest])
            
            if let results = classifyRequest.results, !results.isEmpty {
                addKeywords(from: results, topLimit: 12, top3Min: 0.25, restMin: 0.45)
            }
        } catch {
            // ignore
        }
        
        // 1.1) Saliency → ROI Classification (hilft bei kleinen Motiven wie Vögeln)
        do {
            func classifyROI(_ rect: CGRect) {
                let roi = rect.intersection(extent)
                guard roi.width > 8, roi.height > 8 else { return }
                
                // Padding, damit das Motiv nicht "zu eng" wird.
                let pad: CGFloat = 0.18
                let padded = roi.insetBy(dx: -(roi.width * pad), dy: -(roi.height * pad)).intersection(extent)
                
                let crop = analysisImage.cropped(to: padded)
                guard let cropCG = context.createCGImage(crop, from: crop.extent) else { return }
                
                let h = VNImageRequestHandler(cgImage: cropCG, options: [:])
                let req = VNClassifyImageRequest()
                try? h.perform([req])
                if let r = req.results, !r.isEmpty {
                    // ROI ist oft etwas noisier → thresholds minimal lockerer.
                    addKeywords(from: r, topLimit: 10, top3Min: 0.20, restMin: 0.35)
                }
            }
            
            // Try attention-based saliency first.
            let saliencyRequest = VNGenerateAttentionBasedSaliencyImageRequest()
            try handler.perform([saliencyRequest])
            if let obs = saliencyRequest.results?.first as? VNSaliencyImageObservation {
                if let rects = obs.salientObjects, !rects.isEmpty {
                    // Pick the most confident ROI(s)
                    for r in rects.prefix(2) {
                        let px = VNImageRectForNormalizedRect(
                            r.boundingBox,
                            Int(extent.width),
                            Int(extent.height)
                        )
                        classifyROI(px)
                    }
                } else {
                    // Fallback: objectness-based saliency (sometimes better for animals)
                    let objectness = VNGenerateObjectnessBasedSaliencyImageRequest()
                    try? handler.perform([objectness])
                    if let o = objectness.results?.first as? VNSaliencyImageObservation {
                        if let rects = o.salientObjects, !rects.isEmpty {
                            for r in rects.prefix(2) {
                                let px = VNImageRectForNormalizedRect(
                                    r.boundingBox,
                                    Int(extent.width),
                                    Int(extent.height)
                                )
                                classifyROI(px)
                            }
                        }
                    }
                }
            }
        } catch {
            // ignore
        }
        
        // 2) Face Detection (falls Gesichter vorhanden)
        do {
            let faceRequest = VNDetectFaceRectanglesRequest()
            try handler.perform([faceRequest])
            if let faces = faceRequest.results, !faces.isEmpty {
                keywords.insert("Person")
                if faces.count > 1 {
                    keywords.insert("Gruppe")
                }
                
                // "Portrait" nur, wenn Gesichter wirklich prominent sind (sonst bei Sport zu oft falsch).
                let union = faces.reduce(CGRect.null) { acc, face in
                    acc.union(face.boundingBox)
                }
                let area = union.isNull ? 0.0 : (union.width * union.height) // normalized 0...1
                if area >= 0.06 {
                    keywords.insert("Portrait")
                }
            } else {
                // Fallback: auch ohne Gesicht können Menschen im Bild sein (Sport, Rückenansichten)
                if #available(macOS 10.15, *) {
                    let humanRequest = VNDetectHumanRectanglesRequest()
                    try? handler.perform([humanRequest])
                    if let humans = humanRequest.results, !humans.isEmpty {
                        keywords.insert("Person")
                    }
                }
            }
        } catch {
            // ignore
        }
        
        // 3) Text Recognition (OCR) – nützlich bei Sport (Jersey/Sponsoren) oder Dokumenten
        do {
            let textRequest = VNRecognizeTextRequest()
            textRequest.recognitionLevel = .fast
            textRequest.usesLanguageCorrection = true
            textRequest.minimumTextHeight = 0.02
            textRequest.recognitionLanguages = ["de-DE", "en-US"]
            
            try handler.perform([textRequest])
            
            if let observations = textRequest.results, !observations.isEmpty {
                // Wenn Text erkannt wird, mindestens "Text" hinzufügen
                keywords.insert("Text")
                
                var extracted: [String] = []
                extracted.reserveCapacity(12)
                
                for obs in observations.prefix(12) {
                    guard let cand = obs.topCandidates(1).first else { continue }
                    // Strenger, sonst kommen viele OCR-Artefakte.
                    guard cand.confidence >= 0.60 else { continue }
                    extracted.append(cand.string)
                }
                
                // Aus OCR Strings plausible Tokens ziehen (nur alphanumerische Sequenzen).
                let tokens = extractOCRTokens(from: extracted.joined(separator: " "))
                
                var added = 0
                for token in tokens {
                    guard isUsefulOCRToken(token) else { continue }
                    // Brands/Teams als Uppercase speichern (stabiler, weniger Duplikate)
                    let out = token.uppercased()
                    keywords.insert(out)
                    added += 1
                    if added >= 3 { break }
                }
            }
        } catch {
            // ignore
        }
        
        // 4) Kontext-Postfilter: bei klarer Sport-Szene generische Gebäude/Struktur-Wörter reduzieren
        if keywords.contains("Eishockey") || keywords.contains("Sport") || keywords.contains("Mannschaftssport") {
            keywords.remove("Gebäude")
            keywords.remove("Struktur")
            keywords.remove("Architektur")
        }
        
        // Sortiere Keywords alphabetisch und gib als Array zurück
        return Array(keywords).sorted()
    }
    
    /// Einfache Übersetzung englischer Vision-Keywords ins Deutsche
    private func translateToGerman(_ english: String) -> String {
        let lower = english.lowercased()
        
        // Phrase translations first (mehr Genauigkeit, v.a. Sport)
        let phrase: [String: String] = [
            "ice hockey": "Eishockey",
            "hockey": "Eishockey",
            "ice rink": "Eisbahn",
            "hockey rink": "Eishalle",
            "rink": "Eisbahn",
            "sports arena": "Arena",
            "arena": "Arena",
            "sport": "Sport",
            "sports": "Sport",
            "recreation": "Freizeit",
            "building": "Gebäude",
            "structure": "Struktur",
            "team sport": "Mannschaftssport",
            "stadium": "Stadion",
            // Wildlife / Nature
            "bird": "Vogel",
            "perching bird": "Vogel",
            "songbird": "Singvogel",
            "bird of prey": "Greifvogel",
            "raptor": "Greifvogel",
            "eagle": "Adler",
            "hawk": "Greifvogel",
            "falcon": "Falke",
            "owl": "Eule",
            "branch": "Ast",
            "twig": "Zweig",
            "plant": "Pflanze",
            "foliage": "Laub",
            "tree branch": "Ast",
            "indoor": "Drinnen",
            "outdoor": "Draußen",
            "night": "Nacht",
            "day": "Tag",
            "sunset": "Sonnenuntergang",
            "sunrise": "Sonnenaufgang",
            "landscape": "Landschaft",
            "nature": "Natur",
            "city": "Stadt",
            "architecture": "Architektur",
            "sky": "Himmel",
            "cloud": "Wolke",
            "snow": "Schnee",
            "forest": "Wald",
            "tree": "Baum",
            "flower": "Blume",
            "animal": "Tier",
            "dog": "Hund",
            "cat": "Katze",
            "food": "Essen",
            "restaurant": "Restaurant",
            "document": "Dokument",
            "text": "Text",
            "person": "Person",
            "people": "Personen",
            "group": "Gruppe",
            "portrait": "Portrait"
        ]
        
        if let t = phrase[lower] {
            return t
        }
        
        // If it's a short phrase we don't know, keep it readable (Title Case)
        return titleCase(english)
    }
    
    // MARK: - Normalization / Filtering
    
    private func normalizeLabel(_ s: String) -> String {
        let cleaned = s
            .replacingOccurrences(of: "_", with: " ")
            .replacingOccurrences(of: "  ", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return cleaned
    }
    
    private func isUsefulKeyword(_ s: String) -> Bool {
        let lower = s.lowercased()
        guard lower.count >= 3 else { return false }
        
        // Stopwords / zu generisch
        let stop: Set<String> = [
            "photograph", "photography", "photo", "image", "snapshot",
            "scene", "outdoor scene", "indoor scene", "background", "pattern", "wallpaper", "texture",
            "no person", "nobody",
            // sehr generisch in fast allen Fällen:
            "recreation"
        ]
        if stop.contains(lower) { return false }
        
        // Kein reiner "junk"
        if lower.allSatisfy({ $0.isNumber }) { return false }
        return true
    }
    
    private func extractOCRTokens(from text: String) -> [String] {
        // Extrahiere alphanumerische Sequenzen (Punctuation/Artefakte fallen automatisch weg).
        // Dadurch vermeiden wir Tokens wie "ri_c!_o(" oder "j,".
        let cleaned = text
            .replacingOccurrences(of: "\n", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "©®™"))
        
        var out: [String] = []
        out.reserveCapacity(24)
        
        var current = ""
        current.reserveCapacity(16)
        
        func flush() {
            guard !current.isEmpty else { return }
            out.append(current)
            current.removeAll(keepingCapacity: true)
        }
        
        for ch in cleaned {
            if ch.isLetter || ch.isNumber {
                current.append(ch)
            } else {
                flush()
            }
        }
        flush()
        
        return out
    }
    
    private func isUsefulOCRToken(_ s: String) -> Bool {
        // OCR-Keywords sollen eher "Brands/Teams" sein, sonst wird es schnell noisy.
        // Darum: min. 3 Zeichen, max. 16, muss Buchstaben enthalten, und idealerweise ALLCAPS.
        guard s.count >= 3, s.count <= 16 else { return false }
        
        let lower = s.lowercased()
        if lower.allSatisfy({ $0.isNumber }) { return false }
        guard lower.contains(where: { $0.isLetter }) else { return false }
        
        // Exclude very common tokens
        let stop: Set<String> = ["www", "com", "net", "org", "the", "and", "und", "der", "die", "das", "wb"]
        if stop.contains(lower) { return false }
        
        // Bevorzuge AllCaps (TISSOT, EVZ, HCD, IIHF, ...)
        let isAllCaps = s == s.uppercased()
        let hasDigit = s.contains(where: { $0.isNumber })
        if isAllCaps { return true }
        if hasDigit && s.count >= 4 { return true }
        
        return false
    }
    
    private func titleCase(_ s: String) -> String {
        // Keep acronyms
        if s == s.uppercased(), s.count <= 6 { return s }
        return s
            .split(separator: " ")
            .map { part in
                let w = String(part)
                guard let first = w.first else { return w }
                return String(first).uppercased() + w.dropFirst().lowercased()
            }
            .joined(separator: " ")
    }
    
    /// Batch-Tagging für mehrere Fotos
    func generateKeywordsBatch(for photos: [PhotoItem], progress: @escaping (Int, Int) -> Void) async -> [UUID: [String]] {
        var results: [UUID: [String]] = [:]
        let total = photos.count
        
        for (index, photo) in photos.enumerated() {
            if Task.isCancelled { break }
            let keywords = await generateKeywords(for: photo)
            if Task.isCancelled { break }
            results[photo.id] = keywords
            progress(index + 1, total)
        }
        
        return results
    }
}

