//
//  SaveService.swift
//  WB Foto Manager
//
//  Created by Cursor on 15.12.2025.
//

import Foundation
import AppKit
import UniformTypeIdentifiers

/// "Speichern" / "Speichern unter…" für das aktuell bearbeitete Foto.
@MainActor
final class SaveService {
    static let shared = SaveService()

    private init() {}

    enum SaveError: LocalizedError {
        case noWritableOriginal
        case couldNotLoadImage
        case couldNotRender

        var errorDescription: String? {
            switch self {
            case .noWritableOriginal:
                return "Das Original kann nicht überschrieben werden. Bitte „Kopie speichern unter…“ verwenden."
            case .couldNotLoadImage:
                return "Das Bild konnte nicht geladen werden."
            case .couldNotRender:
                return "Das Bild konnte nicht gerendert werden."
            }
        }
    }

    /// Speichert die aktuelle Bearbeitung direkt ins Original (destruktiv).
    func saveOriginal(photo: PhotoItem) {
        // Photos Library ist read-only (nicht überschreiben – kann die Mediathek beschädigen).
        if photo.url.scheme?.lowercased() == PHAssetURL.scheme || photo.url.path.lowercased().contains(".photoslibrary/") {
            showAlert(
                title: "Photos‑Mediathek ist schreibgeschützt",
                message: "Bitte „Kopie speichern unter…“ verwenden (Export in einen normalen Ordner)."
            )
            return
        }
        
        guard let format = formatForOriginal(photo.url) else {
            showAlert(
                title: "Original nicht überschreibbar",
                message: SaveError.noWritableOriginal.localizedDescription
            )
            return
        }

        let alert = NSAlert()
        alert.messageText = "Original speichern?"
        alert.informativeText = "Die Bearbeitungen (Anpassungen, Zuschnitt/Rotation) werden direkt ins Original geschrieben. Diese Aktion kann nicht rückgängig gemacht werden."
        alert.addButton(withTitle: "Speichern")
        alert.addButton(withTitle: "Abbrechen")
        alert.alertStyle = .warning

        guard alert.runModal() == .alertFirstButtonReturn else { return }

        Task { @MainActor in
            do {
                try await writeProcessedImage(photo: photo, to: photo.url, format: format, quality: 0.95)
                showToastLikeAlert(title: "Gespeichert", message: "Original wurde aktualisiert.")
            } catch {
                showAlert(title: "Speichern fehlgeschlagen", message: error.localizedDescription)
            }
        }
    }

    /// Speichert eine Kopie unter neuem Namen/Ort (NSSavePanel).
    func saveCopyAs(photo: PhotoItem) {
        let savePanel = NSSavePanel()
        savePanel.allowedContentTypes = [.jpeg, .png]

        let baseName = (photo.fileName as NSString).deletingPathExtension
        let suggested = "\(baseName)-bearbeitet.jpg"
        savePanel.nameFieldStringValue = suggested
        savePanel.prompt = "Sichern"

        savePanel.begin { response in
            guard response == .OK, let url = savePanel.url else { return }

            Task { @MainActor in
                do {
                    let format: ExportFormat = url.pathExtension.lowercased() == "png" ? .png : .jpeg
                    try await self.writeProcessedImage(photo: photo, to: url, format: format, quality: 0.95)
                    self.showToastLikeAlert(title: "Gespeichert", message: "Kopie wurde erstellt.")
                } catch {
                    self.showAlert(title: "Speichern fehlgeschlagen", message: error.localizedDescription)
                }
            }
        }
    }

    // MARK: - Private

    private func formatForOriginal(_ url: URL) -> ExportFormat? {
        let ext = url.pathExtension.lowercased()
        switch ext {
        case "jpg", "jpeg":
            return .jpeg
        case "png":
            return .png
        default:
            // RAW/HEIC/TIFF etc. nicht destruktiv überschreiben.
            return nil
        }
    }

    private func writeProcessedImage(photo: PhotoItem, to url: URL, format: ExportFormat, quality: Double) async throws {
        // Hinweis: Läuft aktuell auf MainActor (kompatibel mit EditEngine-Actor-Isolation).
        // Falls nötig können wir später die Render-Pipeline entkoppeln (nonisolated CIContext) für noch bessere Responsiveness.
        let originalImage: CIImage
        if let cached = photo.loadFullImage() {
            originalImage = cached
        } else if let loaded = await photo.loadFullImageAsync() {
            originalImage = loaded
        } else {
            throw SaveError.couldNotLoadImage
        }

        let editEngine = EditEngine.shared
        var processed = originalImage

        if photo.adjustments.hasAdjustments {
            if let adjusted = editEngine.applyAdjustments(to: processed, adjustments: photo.adjustments) {
                processed = adjusted
            }
        }
        
        // Lens Profile Corrections (Lightroom-like)
        let lensSettings = photo.lensProfileSettings
        let lensMeta = await LensProfileService.shared.lensMeta(for: photo.url)
        let resolvedLensProfile = await LensProfileService.shared.resolveProfile(for: photo.url, settings: lensSettings)
        processed = editEngine.applyLensProfileCorrections(
            to: processed,
            settings: lensSettings,
            profile: resolvedLensProfile,
            meta: lensMeta
        )

        processed = editEngine.applyCropAndRotation(
            to: processed,
            cropRect: photo.cropRect,
            rotation: photo.rotation
        )
        
        // Lokale Masken (Masking)
        if let masked = editEngine.applyLocalMasks(to: processed, masks: photo.localMasks) {
            processed = masked
        }

        guard let imageData = editEngine.renderToData(processed, format: format, quality: quality) else {
            throw SaveError.couldNotRender
        }

        try imageData.write(to: url, options: [.atomic])

        // IPTC-Metadaten übernehmen (wenn vorhanden)
        if let metadata = photo.iptcMetadata {
            try? IPTCMetadataService.shared.writeMetadata(metadata, to: url)
        }
    }

    private func showAlert(title: String, message: String) {
        let alert = NSAlert()
        alert.messageText = title
        alert.informativeText = message
        alert.addButton(withTitle: "OK")
        alert.alertStyle = .warning
        alert.runModal()
    }

    /// Mini-Feedback ohne extra UI: kurzer Info-Alert (kann später als Toast ersetzt werden).
    private func showToastLikeAlert(title: String, message: String) {
        let alert = NSAlert()
        alert.messageText = title
        alert.informativeText = message
        alert.addButton(withTitle: "OK")
        alert.alertStyle = .informational
        alert.runModal()
    }
}


