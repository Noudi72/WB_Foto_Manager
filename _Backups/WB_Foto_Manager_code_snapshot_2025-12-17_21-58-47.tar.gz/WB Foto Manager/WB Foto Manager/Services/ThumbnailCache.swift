//
//  ThumbnailCache.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import AppKit

@MainActor
class ThumbnailCache {
    static let shared = ThumbnailCache()
    
    private let cache = NSCache<NSString, NSImage>()
    
    private init() {
        // Configure the cache
        cache.countLimit = 200 // Store up to 200 thumbnails
        cache.totalCostLimit = 1024 * 1024 * 100 // 100 MB limit
    }
    
    /// Generates a unique key for a given URL and size.
    nonisolated func key(for url: URL, size: CGSize) -> NSString {
        return "\(url.absoluteString)-\(size.width)x\(size.height)" as NSString
    }
    
    /// Retrieves an image from the cache.
    func get(forKey key: NSString) -> NSImage? {
        return cache.object(forKey: key)
    }
    
    /// Stores an image in the cache.
    func set(_ image: NSImage, forKey key: NSString) {
        // Calculate the "cost" of the image to help NSCache with eviction.
        // A simple approximation is based on pixel count.
        let cost = Int(image.size.width * image.size.height)
        cache.setObject(image, forKey: key, cost: cost)
    }
}
