//
//  LensProfileService.swift
//  WB Foto Manager
//
//  Auto-detection and resolution of profile-based lens corrections.
//

import Foundation
import ImageIO
import Photos

extension Notification.Name {
    static let lensProfileDatabaseDidChange = Notification.Name("LensProfileDatabaseDidChange")
}

actor LensProfileService {
    static let shared = LensProfileService()
    
    private var metaCache: [String: LensMeta] = [:] // key: url.absoluteString
    private var autoProfileCache: [String: String] = [:] // key: url.absoluteString → profile.id
    
    private var loadedUserProfiles: Bool = false
    private var userProfiles: [LensProfile] = []
    private var saveTask: Task<Void, Never>?
    
    private init() {}
    
    func availableProfiles() async -> [LensProfile] {
        await ensureUserProfilesLoaded()
        // Built-in profiles first, user profiles appended (manual selection can still pick either).
        return LensProfileCatalog.builtIn + userProfiles
    }
    
    func userProfilesSnapshot() async -> [LensProfile] {
        await ensureUserProfilesLoaded()
        return userProfiles
    }
    
    func upsertUserProfile(_ profile: LensProfile) async {
        await ensureUserProfilesLoaded()
        if let idx = userProfiles.firstIndex(where: { $0.id == profile.id }) {
            userProfiles[idx] = profile
        } else {
            userProfiles.append(profile)
        }
        invalidateMatchCache()
        await MainActor.run {
            NotificationCenter.default.post(name: .lensProfileDatabaseDidChange, object: nil)
        }
        scheduleSave()
    }
    
    func upsertUserProfiles(_ profiles: [LensProfile]) async {
        await ensureUserProfilesLoaded()
        guard !profiles.isEmpty else { return }
        
        for profile in profiles {
            if let idx = userProfiles.firstIndex(where: { $0.id == profile.id }) {
                userProfiles[idx] = profile
            } else {
                userProfiles.append(profile)
            }
        }
        
        invalidateMatchCache()
        await MainActor.run {
            NotificationCenter.default.post(name: .lensProfileDatabaseDidChange, object: nil)
        }
        scheduleSave()
    }
    
    func deleteUserProfile(id: String) async {
        await ensureUserProfilesLoaded()
        userProfiles.removeAll { $0.id == id }
        invalidateMatchCache()
        await MainActor.run {
            NotificationCenter.default.post(name: .lensProfileDatabaseDidChange, object: nil)
        }
        scheduleSave()
    }
    
    func resetUserProfiles() async {
        await ensureUserProfilesLoaded()
        userProfiles = []
        invalidateMatchCache()
        await MainActor.run {
            NotificationCenter.default.post(name: .lensProfileDatabaseDidChange, object: nil)
        }
        scheduleSave()
    }
    
    func importUserProfiles(from url: URL) async throws {
        let data = try Data(contentsOf: url)
        
        // Accept either plain `[LensProfile]` or wrapped payload.
        if let list = try? JSONDecoder().decode([LensProfile].self, from: data) {
            await replaceUserProfiles(list)
            return
        }
        let payload = try JSONDecoder().decode(PersistedLensProfiles.self, from: data)
        await replaceUserProfiles(payload.profiles)
    }
    
    func importLCP(from url: URL) async throws {
        let data = try Data(contentsOf: url)
        let baseName = url.deletingPathExtension().lastPathComponent
        let profiles = try parseLCP(data: data, fallbackName: baseName)
        let merged = await mergeIncomingProfilesByMatchKey(profiles)
        await upsertUserProfiles(merged)
    }
    
    func previewLCP(from url: URL) async throws -> [LensProfile] {
        let data = try Data(contentsOf: url)
        let baseName = url.deletingPathExtension().lastPathComponent
        return try parseLCP(data: data, fallbackName: baseName)
    }
    
    func exportUserProfiles(to url: URL) async throws {
        await ensureUserProfilesLoaded()
        var payload = PersistedLensProfiles()
        payload.updatedAt = Date()
        payload.profiles = userProfiles
        let enc = JSONEncoder()
        enc.outputFormatting = [.prettyPrinted, .sortedKeys]
        let data = try enc.encode(payload)
        try data.write(to: url, options: [.atomic])
    }
    
    func resolveProfile(for url: URL, settings: LensProfileSettings) async -> LensProfile? {
        guard settings.enabled else { return nil }
        
        let profiles = await availableProfiles()
        
        switch settings.mode {
        case .manual:
            guard !settings.manualProfileID.isEmpty else { return nil }
            return profiles.first(where: { $0.id == settings.manualProfileID })
        case .auto:
            return await autoProfile(for: url, profiles: profiles)
        }
    }
    
    func lensMeta(for url: URL) async -> LensMeta? {
        let key = url.absoluteString
        if let cached = metaCache[key] { return cached }
        
        let meta: LensMeta?
        if let assetID = PHAssetURL.localIdentifier(from: url) {
            meta = await loadMetaFromPhotoKit(assetLocalIdentifier: assetID)
        } else {
            meta = await loadMetaFromFile(url: url)
        }
        
        if let meta {
            metaCache[key] = meta
        }
        return meta
    }
    
    func clearCache() {
        metaCache.removeAll()
        autoProfileCache.removeAll()
    }
    
    // MARK: - Private
    
    private struct PersistedLensProfiles: Codable, Sendable {
        var version: Int = 1
        var updatedAt: Date = Date()
        var profiles: [LensProfile] = []
    }
    
    private func catalogURL() -> URL? {
        guard let appSupport = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
            return nil
        }
        let folder = appSupport.appendingPathComponent("WB Foto Manager", isDirectory: true)
        return folder.appendingPathComponent("lens-profiles.json", isDirectory: false)
    }
    
    private func ensureUserProfilesLoaded() async {
        if loadedUserProfiles { return }
        loadedUserProfiles = true
        await loadUserProfilesFromDisk()
    }
    
    private func loadUserProfilesFromDisk() async {
        guard let url = catalogURL() else {
            userProfiles = []
            return
        }
        do {
            let data = try Data(contentsOf: url)
            if let list = try? JSONDecoder().decode([LensProfile].self, from: data) {
                userProfiles = list
                return
            }
            let payload = try JSONDecoder().decode(PersistedLensProfiles.self, from: data)
            userProfiles = payload.profiles
        } catch {
            userProfiles = []
        }
    }
    
    private func scheduleSave() {
        saveTask?.cancel()
        saveTask = Task { [weak self] in
            guard let self else { return }
            try? await Task.sleep(nanoseconds: 350_000_000)
            await self.saveUserProfilesToDisk()
        }
    }
    
    private func saveUserProfilesToDisk() async {
        guard let url = catalogURL() else { return }
        do {
            let folder = url.deletingLastPathComponent()
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)
            
            var payload = PersistedLensProfiles()
            payload.updatedAt = Date()
            payload.profiles = userProfiles
            
            let enc = JSONEncoder()
            enc.outputFormatting = []
            let data = try enc.encode(payload)
            try data.write(to: url, options: [.atomic])
        } catch {
            // best effort
        }
        
        await MainActor.run {
            NotificationCenter.default.post(name: .lensProfileDatabaseDidChange, object: nil)
        }
    }
    
    private func replaceUserProfiles(_ profiles: [LensProfile]) async {
        await ensureUserProfilesLoaded()
        userProfiles = profiles
        invalidateMatchCache()
        await MainActor.run {
            NotificationCenter.default.post(name: .lensProfileDatabaseDidChange, object: nil)
        }
        scheduleSave()
    }
    
    private func invalidateMatchCache() {
        autoProfileCache.removeAll()
    }
    
    private func mergeIncomingProfilesByMatchKey(_ incoming: [LensProfile]) async -> [LensProfile] {
        await ensureUserProfilesLoaded()
        
        // Try to avoid duplicates on re-import by matching on normalized rules + name (stable across runs).
        // If we find a match, we preserve the existing ID so manual selections keep working.
        let existing = userProfiles
        
        return incoming.map { p in
            if let match = existing.first(where: { $0.normalizedMatchKey == p.normalizedMatchKey }) {
                return p.copy(withID: match.id)
            }
            return p
        }
    }
    
    // MARK: - LCP Import (Adobe Lens Correction Profile)
    
    private enum LCPImportError: LocalizedError {
        case notUTF8
        case noProfilesFound
        
        var errorDescription: String? {
            switch self {
            case .notUTF8:
                return "Die LCP-Datei konnte nicht als Text gelesen werden."
            case .noProfilesFound:
                return "In der LCP-Datei wurde kein gültiges Profil gefunden."
            }
        }
    }
    
    private struct LCPRecord {
        var profileName: String
        var make: String
        var model: String
        var lens: String
        var focalLength: Double?
        var distortion: Double
        var distortionScale: Double
        var vignette: Double
        var ca: Double
    }
    
    private func parseLCP(data: Data, fallbackName: String) throws -> [LensProfile] {
        guard let xml = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .isoLatin1) else {
            throw LCPImportError.notUTF8
        }
        
        // Split into <rdf:li ... parseType="Resource"> blocks (each is one calibration record; zoom lenses may contain several).
        let blocks = Self.regexMatches(
            pattern: #"<rdf:li[^>]*rdf:parseType="Resource"[^>]*>([\s\S]*?)</rdf:li>"#,
            in: xml,
            group: 1
        )
        
        guard !blocks.isEmpty else {
            throw LCPImportError.noProfilesFound
        }
        
        var records: [LCPRecord] = []
        
        for block in blocks {
            let profileName = Self.firstTagValue(in: block, tag: "stCamera:ProfileName") ?? fallbackName
            let make = Self.firstTagValue(in: block, tag: "stCamera:Make") ?? ""
            let model = Self.firstTagValue(in: block, tag: "stCamera:Model") ?? ""
            let lens = Self.firstTagValue(in: block, tag: "stCamera:Lens") ??
            Self.firstTagValue(in: block, tag: "stCamera:LensPrettyName") ??
            profileName
            
            let focalLength = Self.firstTagValue(in: block, tag: "stCamera:FocalLength").flatMap(Double.init)
            
            // Perspective / Distortion
            let perspective = Self.firstTagBlock(in: block, tag: "stCamera:PerspectiveModel")
            let fx = Self.firstTagValue(in: perspective ?? block, tag: "stCamera:FocalLengthX").flatMap(Double.init) ?? 1.0
            let fy = Self.firstTagValue(in: perspective ?? block, tag: "stCamera:FocalLengthY").flatMap(Double.init) ?? fx
            let p1 = Self.firstTagValue(in: perspective ?? block, tag: "stCamera:RadialDistortParam1").flatMap(Double.init) ?? 0.0
            let p2 = Self.firstTagValue(in: perspective ?? block, tag: "stCamera:RadialDistortParam2").flatMap(Double.init) ?? 0.0
            
            // Approx: combine p1/p2 at a representative corner radius (based on focal length normalization).
            let rCorner = Self.cornerRadiusNormalized(fx: fx, fy: fy)
            let kEff = p1 + (p2 * (rCorner * rCorner))
            let distortion = max(-0.5, min(0.5, kEff))
            let distortionScale = max(0.8, min(1.2, 1.0 + abs(distortion) * 0.10))
            
            // Vignetting
            let vignetteBlock = Self.firstTagBlock(in: block, tag: "stCamera:VignetteModel")
            let vfx = Self.firstTagValue(in: vignetteBlock ?? block, tag: "stCamera:FocalLengthX").flatMap(Double.init) ?? fx
            let vfy = Self.firstTagValue(in: vignetteBlock ?? block, tag: "stCamera:FocalLengthY").flatMap(Double.init) ?? fy
            let v1 = Self.firstTagValue(in: vignetteBlock ?? block, tag: "stCamera:VignetteModelParam1").flatMap(Double.init) ?? 0.0
            let v2 = Self.firstTagValue(in: vignetteBlock ?? block, tag: "stCamera:VignetteModelParam2").flatMap(Double.init) ?? 0.0
            let v3 = Self.firstTagValue(in: vignetteBlock ?? block, tag: "stCamera:VignetteModelParam3").flatMap(Double.init) ?? 0.0
            let vr = Self.cornerRadiusNormalized(fx: vfx, fy: vfy)
            let poly = (v1 * pow(vr, 2)) + (v2 * pow(vr, 4)) + (v3 * pow(vr, 6))
            // Common LCP model is exponential falloff; clamp to sane range.
            let falloff = max(0.05, min(1.0, exp(poly)))
            let vignette = max(0.0, min(1.0, ((1.0 / falloff) - 1.0) / 2.0))
            
            // Chromatic Aberration (use ScaleFactor deltas; good, stable proxy)
            let redBlock = Self.firstTagBlock(in: block, tag: "stCamera:ChromaticRedGreenModel")
            let blueBlock = Self.firstTagBlock(in: block, tag: "stCamera:ChromaticBlueGreenModel")
            let redScale = Self.firstTagValue(in: redBlock ?? "", tag: "stCamera:ScaleFactor").flatMap(Double.init)
            let blueScale = Self.firstTagValue(in: blueBlock ?? "", tag: "stCamera:ScaleFactor").flatMap(Double.init)
            let maxDiff = max(abs((redScale ?? 1.0) - 1.0), abs((blueScale ?? 1.0) - 1.0))
            let ca = max(0.0, min(1.0, maxDiff * 600.0))
            
            records.append(
                LCPRecord(
                    profileName: profileName,
                    make: make,
                    model: model,
                    lens: lens,
                    focalLength: focalLength,
                    distortion: distortion,
                    distortionScale: distortionScale,
                    vignette: vignette,
                    ca: ca
                )
            )
        }
        
        // Group into LensProfile(s). Usually one lens per file, but we support multiple.
        let grouped = Dictionary(grouping: records) { r in
            "\(r.make)|\(r.model)|\(r.lens)|\(r.profileName)"
        }
        
        var results: [LensProfile] = []
        for (_, recs) in grouped {
            let first = recs.first!
            
            // Build correction points (dedupe by focal length if needed).
            let points: [LensProfileCorrectionPoint] = Self.mergeByFocalLength(recs: recs).map { r in
                LensProfileCorrectionPoint(
                    focalLengthMM: r.focalLength ?? 50,
                    distortion: r.distortion,
                    distortionScale: r.distortionScale,
                    vignette: r.vignette,
                    chromaticAberration: r.ca
                )
            }
            let sortedPoints = points.sorted(by: { $0.focalLengthMM < $1.focalLengthMM })
            
            let minFL = sortedPoints.first?.focalLengthMM
            let maxFL = sortedPoints.last?.focalLengthMM
            
            let avg = Self.averagePoint(sortedPoints)
            
            let profile = LensProfile(
                id: "user-\(UUID().uuidString)",
                name: first.profileName.isEmpty ? first.lens : first.profileName,
                cameraMakeContains: first.make.isEmpty ? [] : [first.make],
                cameraModelContains: first.model.isEmpty ? [] : [first.model],
                lensModelContains: first.lens.isEmpty ? [] : [first.lens],
                minFocalLengthMM: minFL,
                maxFocalLengthMM: maxFL,
                correctionPoints: sortedPoints,
                distortion: avg.distortion,
                distortionScale: avg.scale,
                vignette: avg.vignette,
                chromaticAberration: avg.ca
            )
            
            results.append(profile)
        }
        
        if results.isEmpty {
            throw LCPImportError.noProfilesFound
        }
        
        return results
    }
    
    private static func regexMatches(pattern: String, in text: String, group: Int) -> [String] {
        guard let re = try? NSRegularExpression(pattern: pattern, options: []) else { return [] }
        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        let matches = re.matches(in: text, options: [], range: range)
        return matches.compactMap { m in
            guard m.numberOfRanges > group else { return nil }
            let r = m.range(at: group)
            guard let sr = Range(r, in: text) else { return nil }
            return String(text[sr])
        }
    }
    
    private static func firstTagValue(in text: String, tag: String) -> String? {
        guard !text.isEmpty else { return nil }
        let pattern = "<\(NSRegularExpression.escapedPattern(for: tag))>([\\s\\S]*?)</\(NSRegularExpression.escapedPattern(for: tag))>"
        guard let re = try? NSRegularExpression(pattern: pattern, options: []) else { return nil }
        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        guard let m = re.firstMatch(in: text, options: [], range: range), m.numberOfRanges > 1 else { return nil }
        guard let r = Range(m.range(at: 1), in: text) else { return nil }
        let raw = String(text[r])
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmed.isEmpty ? nil : trimmed
    }
    
    private static func firstTagBlock(in text: String, tag: String) -> String? {
        guard !text.isEmpty else { return nil }
        let pattern = "<\(NSRegularExpression.escapedPattern(for: tag))[^>]*>([\\s\\S]*?)</\(NSRegularExpression.escapedPattern(for: tag))>"
        guard let re = try? NSRegularExpression(pattern: pattern, options: []) else { return nil }
        let range = NSRange(text.startIndex..<text.endIndex, in: text)
        guard let m = re.firstMatch(in: text, options: [], range: range), m.numberOfRanges > 1 else { return nil }
        guard let r = Range(m.range(at: 1), in: text) else { return nil }
        return String(text[r])
    }
    
    /// Representative normalized corner radius used by Adobe's models: r = sqrt((0.5/fx)^2 + (0.5/fy)^2)
    private static func cornerRadiusNormalized(fx: Double, fy: Double) -> Double {
        let fxSafe = max(0.000_1, fx)
        let fySafe = max(0.000_1, fy)
        let rx = 0.5 / fxSafe
        let ry = 0.5 / fySafe
        return sqrt((rx * rx) + (ry * ry))
    }
    
    private static func mergeByFocalLength(recs: [LCPRecord]) -> [LCPRecord] {
        // Group by rounded focal length (to handle 23.9999 etc).
        let grouped = Dictionary(grouping: recs) { r in
            Int(((r.focalLength ?? 50) * 10.0).rounded()) // 0.1mm buckets
        }
        return grouped.values.map { bucket in
            guard let first = bucket.first else { return nil }
            // Average numeric fields
            func avg(_ f: (LCPRecord) -> Double) -> Double {
                bucket.map(f).reduce(0, +) / Double(bucket.count)
            }
            return LCPRecord(
                profileName: first.profileName,
                make: first.make,
                model: first.model,
                lens: first.lens,
                focalLength: bucket.compactMap { $0.focalLength }.first,
                distortion: avg { $0.distortion },
                distortionScale: avg { $0.distortionScale },
                vignette: avg { $0.vignette },
                ca: avg { $0.ca }
            )
        }.compactMap { $0 }
    }
    
    private static func averagePoint(_ points: [LensProfileCorrectionPoint]) -> (distortion: Double, scale: Double, vignette: Double, ca: Double) {
        guard !points.isEmpty else { return (0, 1.0, 0, 0) }
        let n = Double(points.count)
        let d = points.map { $0.distortion }.reduce(0, +) / n
        let s = points.map { $0.distortionScale }.reduce(0, +) / n
        let v = points.map { $0.vignette }.reduce(0, +) / n
        let c = points.map { $0.chromaticAberration }.reduce(0, +) / n
        return (d, s, v, c)
    }
    
    private func autoProfile(for url: URL, profiles: [LensProfile]) async -> LensProfile? {
        let key = url.absoluteString
        if let cachedID = autoProfileCache[key] {
            return profiles.first(where: { $0.id == cachedID })
        }
        
        guard let meta = await lensMeta(for: url) else { return nil }
        
        var best: (profile: LensProfile, score: Int)? = nil
        for p in profiles {
            let s = p.score(for: meta)
            if s <= 0 { continue }
            if best == nil || s > best!.score {
                best = (p, s)
            }
        }
        
        if let best {
            autoProfileCache[key] = best.profile.id
            return best.profile
        }
        
        return nil
    }
    
    private func loadMetaFromFile(url: URL) async -> LensMeta? {
        await Task.detached(priority: .utility) { () -> LensMeta? in
            guard FileManager.default.fileExists(atPath: url.path) else { return nil }
            guard let src = CGImageSourceCreateWithURL(url as CFURL, nil),
                  let props = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [String: Any] else {
                return nil
            }
            return Self.parseLensMeta(from: props)
        }.value
    }
    
    private func loadMetaFromPhotoKit(assetLocalIdentifier: String) async -> LensMeta? {
        let fetched = PHAsset.fetchAssets(withLocalIdentifiers: [assetLocalIdentifier], options: nil)
        guard let asset = fetched.firstObject else { return nil }
        
        let options = PHImageRequestOptions()
        options.isNetworkAccessAllowed = true
        options.deliveryMode = .fastFormat
        options.version = .current
        options.isSynchronous = false
        
        return await withCheckedContinuation { continuation in
            PHImageManager.default().requestImageDataAndOrientation(for: asset, options: options) { data, _, _, _ in
                guard let data else {
                    continuation.resume(returning: nil)
                    return
                }
                guard let src = CGImageSourceCreateWithData(data as CFData, nil),
                      let props = CGImageSourceCopyPropertiesAtIndex(src, 0, nil) as? [String: Any] else {
                    continuation.resume(returning: nil)
                    return
                }
                continuation.resume(returning: Self.parseLensMeta(from: props))
            }
        }
    }
    
    private static func parseLensMeta(from props: [String: Any]) -> LensMeta {
        var meta = LensMeta()
        
        if let tiff = props[kCGImagePropertyTIFFDictionary as String] as? [String: Any] {
            meta.cameraMake = (tiff[kCGImagePropertyTIFFMake as String] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines)
            meta.cameraModel = (tiff[kCGImagePropertyTIFFModel as String] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        
        if let exif = props[kCGImagePropertyExifDictionary as String] as? [String: Any] {
            meta.lensModel = (exif[kCGImagePropertyExifLensModel as String] as? String)?.trimmingCharacters(in: .whitespacesAndNewlines)
            
            let flAny = exif[kCGImagePropertyExifFocalLength as String]
            if let fl = flAny as? Double {
                meta.focalLengthMM = fl
            } else if let fl = flAny as? Int {
                meta.focalLengthMM = Double(fl)
            } else if let fl = flAny as? NSNumber {
                meta.focalLengthMM = fl.doubleValue
            }
        }
        
        return meta
    }
}


