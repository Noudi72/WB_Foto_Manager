//
//  UIState.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import Combine
import SwiftUI

// MARK: - Sortierung

enum PhotoSortMode: String, CaseIterable, Codable {
    case captureDateDesc
    case captureDateAsc
    case fileNameAsc
    case ratingDesc
    case ratingAsc
    
    var title: String {
        switch self {
        case .captureDateDesc: return "Aufnahmedatum (neueste)"
        case .captureDateAsc: return "Aufnahmedatum (älteste)"
        case .fileNameAsc: return "Dateiname (A→Z)"
        case .ratingDesc: return "Rating (hoch→tief)"
        case .ratingAsc: return "Rating (tief→hoch)"
        }
    }
}

class UIState: ObservableObject {
    @Published var viewMode: ViewMode = .detail
    @Published var zoomLevel: Double = 1.0
    @Published var showBeforeAfter: Bool = false

    // Multi-selection (für Sync-Workflows wie Lightroom)
    @Published var selectionMode: Bool = false
    
    // Watermark Vorschau (nur Anzeige, nicht Export)
    @Published var watermarkPreviewEnabled: Bool = false
    @Published var watermarkPreviewPresetID: UUID? = nil
    
    // Masking (lokale Anpassungen)
    @Published var showMaskOverlay: Bool = true
    @Published var activeMaskID: UUID? = nil
    
    // Sheets / Modals (zentral, damit Menüs + Topbar zuverlässig funktionieren)
    @Published var activeSheet: SheetRoute? = nil
    
    // Filters
    @Published var ratingFilter: Int? = nil {
        didSet {
            // This is a good place to notify the PhotoStore to re-filter
        }
    }
    @Published var searchQuery: String = "" {
        didSet {
            // Trigger re-filtering when search changes
        }
    }
    @Published var pickStatusFilter: PickStatus? = nil {
        didSet {
            // Trigger re-filtering when pick status filter changes
        }
    }
    @Published var showQuickCollectionOnly: Bool = false {
        didSet {
            // Trigger re-filtering when quick collection filter changes
        }
    }
    @Published var colorTagFilter: ColorTag? = nil {
        didSet {
            // Trigger re-filtering when color tag filter changes
        }
    }
    @Published var activeSmartCollectionID: UUID? = nil {
        didSet {
            // Trigger re-filtering when smart collection changes
        }
    }
    
    // Sortierung
    @Published var sortMode: PhotoSortMode = .captureDateDesc {
        didSet {
            UserDefaults.standard.set(sortMode.rawValue, forKey: "photoSortModeV1")
        }
    }
    
    // Focus helpers
    @Published var focusSearchField: Bool = false
    
    // Sidebar visibility
    @Published var showLeftSidebar: Bool = true
    @Published var showRightSidebar: Bool = true
    
    init() {
        if let raw = UserDefaults.standard.string(forKey: "photoSortModeV1"),
           let mode = PhotoSortMode(rawValue: raw) {
            self.sortMode = mode
        }
    }
}

// MARK: - Modal Routing

extension UIState {
    enum SheetRoute: Identifiable {
        case settings
        case export
        case batchExport
        case uploadSettings
        case exportQueueSettings
        case backupRestore
        case syncAdjustments
        case surveyView
        case smartCollections
        case shortcutsHelp
        
        var id: String {
            switch self {
            case .settings: return "settings"
            case .export: return "export"
            case .batchExport: return "batchExport"
            case .uploadSettings: return "uploadSettings"
            case .exportQueueSettings: return "exportQueueSettings"
            case .backupRestore: return "backupRestore"
            case .syncAdjustments: return "syncAdjustments"
            case .surveyView: return "surveyView"
            case .smartCollections: return "smartCollections"
            case .shortcutsHelp: return "shortcutsHelp"
            }
        }
    }
}

// We can move the ViewMode enum here as it's purely UI-related.
enum ViewMode {
    case detail
    case grid
    case compare
    case survey
}
