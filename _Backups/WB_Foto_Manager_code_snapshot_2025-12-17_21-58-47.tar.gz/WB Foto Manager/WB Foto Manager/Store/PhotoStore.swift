//
//  PhotoStore.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import SwiftUI
import Combine
import AppKit
import Photos
import UniformTypeIdentifiers

/// Zentraler State Manager für die App
class PhotoStore: ObservableObject {
    // MARK: - Published Properties
    
    @Published var photos: [PhotoItem] = []
    @Published var filteredPhotos: [PhotoItem] = []
    
    @Published var selectedPhotoIDs: Set<UUID> = []
    @Published var currentPhotoID: UUID?
    @Published var currentFolder: URL?
    
    @Published var exportPresets: [ExportPreset] = []
    @Published var adjustmentPresets: [AdjustmentPreset] = []
    /// User-definierte Preset-Kategorien (Reihenfolge wird persistiert).
    @Published var presetGroups: [String] = []
    @Published var uploadTargets: [UploadTarget] = []
    @Published var iptcTemplates: [IPTCTemplate] = []
    @Published var smartCollections: [SmartCollection] = []
    
    // MARK: - History / Snapshots (Lightroom-like)
    @Published var editSnapshotsByKey: [String: [EditSnapshot]] = [:]

    // MARK: - Copy/Paste & Sync (Lightroom-like)

    @Published var copiedAdjustments: PhotoAdjustments? = nil
    
    // Export Queue Settings
    @Published var exportQueueEnabled: Bool = false {
        didSet { saveExportQueueSettings() }
    }
    @Published var exportQueueMinRating: Int = 4 {
        didSet { saveExportQueueSettings() }
    }
    @Published var exportQueuePreset: ExportPreset? {
        didSet { saveExportQueueSettings() }
    }
    @Published var exportQueueOutputDirectory: URL? {
        didSet { saveExportQueueSettings() }
    }
    @Published var isExportQueueRunning: Bool = false
    @Published var exportQueueProgress: Double = 0.0
    @Published var exportQueueProcessedCount: Int = 0
    @Published var exportQueueTotalCount: Int = 0
    @Published var exportQueueCurrentName: String = ""
    
    // MARK: - Quick Export (1‑Klick Export)
    @Published var quickExportPresetID: UUID? = nil
    @Published var quickExportDirectory: URL? = nil
    @Published var isQuickExporting: Bool = false
    @Published var quickExportProgress: Double = 0.0
    
    // MARK: - Batch Auto (Auto + Stil‑Profil)
    @Published var isBatchAutoRunning: Bool = false
    @Published var batchAutoProgress: Double = 0.0
    @Published var batchAutoProcessedCount: Int = 0
    @Published var batchAutoTotalCount: Int = 0
    @Published var batchAutoCurrentName: String = ""
    
    // MARK: - AI Keywords (Batch)
    @Published var isAITaggingRunning: Bool = false
    @Published var aiTaggingProgress: Double = 0.0
    @Published var aiTaggingProcessedCount: Int = 0
    @Published var aiTaggingTotalCount: Int = 0
    @Published var aiTaggingCurrentName: String = ""
    
    // MARK: - Computed Properties
    
    var currentPhoto: PhotoItem? {
        guard let id = currentPhotoID else { return nil }
        // Search in the main photos array, not the filtered one.
        return photos.first { $0.id == id }
    }
    
    var currentPhotoIndexInFiltered: Int? {
        guard let currentID = currentPhotoID else { return nil }
        return filteredPhotos.firstIndex { $0.id == currentID }
    }
    
    // MARK: - Services & State
    
    private let ratingService = RatingPersistenceService.shared
    private let metadataService = IPTCMetadataService.shared
    var uiState: UIState?
    private var cancellables = Set<AnyCancellable>()
    
    private var aiTaggingTask: Task<Void, Never>?
    
    // MARK: - Photos Library (read-only) Persistenz
    // In einer Photos-Mediathek (*.photoslibrary) dürfen wir KEINE Dateien überschreiben (riskant + verändert Dates + erzeugt Duplikate).
    // Deshalb persistieren wir Rating/optional IPTC lokal in UserDefaults.
    private let localRatingsDefaultsKey: String = "localRatingsV1"
    
    private func isPhotosLibraryContext(_ url: URL) -> Bool {
        if currentFolder?.pathExtension.lowercased() == "photoslibrary" { return true }
        if url.scheme?.lowercased() == PHAssetURL.scheme { return true }
        // Fallback: falls einzelne Items aus einer Photos-Library stammen
        return url.path.lowercased().contains(".photoslibrary/")
    }
    
    private func loadLocalRatings() -> [String: Int] {
        guard let data = UserDefaults.standard.data(forKey: localRatingsDefaultsKey),
              let decoded = try? JSONDecoder().decode([String: Int].self, from: data) else {
            return [:]
        }
        return decoded
    }
    
    private func saveLocalRatings(_ dict: [String: Int]) {
        guard let data = try? JSONEncoder().encode(dict) else { return }
        UserDefaults.standard.set(data, forKey: localRatingsDefaultsKey)
    }
    
    private func loadLocalRating(for url: URL, from dict: [String: Int]? = nil) -> Int {
        let key = url.isFileURL ? url.standardizedFileURL.path : url.absoluteString
        if let dict { return dict[key] ?? 0 }
        return loadLocalRatings()[key] ?? 0
    }
    
    private func saveLocalRating(_ rating: Int, for url: URL) {
        var dict = loadLocalRatings()
        let key = url.isFileURL ? url.standardizedFileURL.path : url.absoluteString
        if rating <= 0 {
            dict.removeValue(forKey: key)
        } else {
            dict[key] = rating
        }
        saveLocalRatings(dict)
    }
    
    // MARK: - Security-Scoped Folder Access
    
    private var currentFolderAccessURL: URL?
    private var isAccessingCurrentFolder: Bool = false
    
    private struct LoadedPhotoInfo: Sendable {
        let url: URL
        let rating: Int
        let iptc: IPTCMetadata?
        let edit: EditCatalogService.EditEntry?
        let captureDate: Date?
        let originalFileName: String?
        let pixelWidth: Int?
        let pixelHeight: Int?
    }
    
    // MARK: - Initialization
    
    init() {
        // Lade alle Presets beim Start
        loadExportPresets()
        loadAdjustmentPresets() // Lädt Standard-Presets wenn keine vorhanden
        loadPresetGroups()
        loadUploadTargets()
        loadIPTCTemplates()
        loadSmartCollections()
        loadEditSnapshots()
        loadQuickExportSettings()
        loadExportQueueSettings()

        // Persist edits (non-destructive) whenever UI signals a reprocess.
        registerEditPersistenceObservers()
    }

    // MARK: - Auto + Stil-Profil
    
    /// Baut Auto-Adjustments und legt optional ein Stil-Preset (Delta ggü. Defaults) darüber.
    func buildAutoAdjustmentsForCurrent() async -> PhotoAdjustments? {
        guard let photo = currentPhoto else { return nil }
        return await buildAutoAdjustments(for: photo)
    }
    
    func buildAutoAdjustments(for photo: PhotoItem) async -> PhotoAdjustments? {
        let base = await AutoAdjustmentService.shared.analyzeAndAdjust(photo: photo)
        guard var result = base else { return nil }
        
        // Optional: Style Profile
        let settings = AppSettings.shared
        guard settings.autoUsesStyleProfile, !settings.autoStylePresetID.isEmpty,
              let presetID = UUID(uuidString: settings.autoStylePresetID),
              let preset = adjustmentPresets.first(where: { $0.id == presetID }) else {
            return result
        }
        
        let delta = preset.adjustments.delta(from: PhotoAdjustments())
        result = result.applying(delta)
        return result
    }

    // MARK: - Batch Auto (Auto + Stil‑Profil) auf Auswahl
    
    private var batchAutoTask: Task<Void, Never>? = nil
    
    @MainActor
    func applyAutoToSelection() {
        let targets = photos.filter { selectedPhotoIDs.contains($0.id) }
        guard !targets.isEmpty else { return }
        startBatchAuto(on: targets)
    }
    
    @MainActor
    func cancelBatchAuto() {
        batchAutoTask?.cancel()
        batchAutoTask = nil
        isBatchAutoRunning = false
        batchAutoProgress = 0.0
        batchAutoProcessedCount = 0
        batchAutoTotalCount = 0
        batchAutoCurrentName = ""
        objectWillChange.send()
    }
    
    @MainActor
    private func startBatchAuto(on targets: [PhotoItem]) {
        guard !isBatchAutoRunning else { return }
        
        isBatchAutoRunning = true
        batchAutoTotalCount = targets.count
        batchAutoProcessedCount = 0
        batchAutoProgress = 0.0
        batchAutoCurrentName = ""
        
        // Cancel any previous task just in case
        batchAutoTask?.cancel()
        
        batchAutoTask = Task { [weak self] in
            guard let self else { return }
            
            let total = max(1, targets.count)
            
            for (index, photo) in targets.enumerated() {
                if Task.isCancelled { break }
                
                await MainActor.run {
                    self.batchAutoCurrentName = photo.fileName
                    self.batchAutoProcessedCount = index
                    self.batchAutoProgress = Double(index) / Double(total)
                }
                
                if let adjustments = await self.buildAutoAdjustments(for: photo) {
                    await MainActor.run {
                        self.registerUndoPoint(for: photo)
                        photo.adjustments = adjustments
                        self.persistEditsForPhoto(photo)
                        
                        // Nur aktuelles Foto muss sofort re-rendern
                        if photo.id == self.currentPhotoID {
                            self.triggerReprocess(for: photo)
                        }
                    }
                }
                
                await MainActor.run {
                    self.batchAutoProcessedCount = index + 1
                    self.batchAutoProgress = Double(index + 1) / Double(total)
                }
            }
            
            await MainActor.run {
                self.isBatchAutoRunning = false
                self.batchAutoCurrentName = ""
                self.batchAutoTask = nil
            }
        }
    }

    // MARK: - Quick Export (WIP)
    private enum QuickExportKeys {
        static let presetID = "quickExportPresetID"
        static let directoryPath = "quickExportDirectoryPath"
    }
    
    private func loadQuickExportSettings() {
        // Preset
        if let raw = UserDefaults.standard.string(forKey: QuickExportKeys.presetID),
           let id = UUID(uuidString: raw) {
            quickExportPresetID = id
        }
        
        // Directory
        if let path = UserDefaults.standard.string(forKey: QuickExportKeys.directoryPath) {
            let url = URL(fileURLWithPath: path)
            // Wir versuchen zuerst ein Security-Scoped Bookmark aus den allgemeinen folderBookmarks zu resolven.
            quickExportDirectory = resolvedBookmarkURL(forPath: url.path) ?? url
        }
    }
    
    private func saveQuickExportSettings() {
        UserDefaults.standard.set(quickExportPresetID?.uuidString, forKey: QuickExportKeys.presetID)
        UserDefaults.standard.set(quickExportDirectory?.path, forKey: QuickExportKeys.directoryPath)
    }

    // MARK: - Export Queue Settings (Persistenz)
    
    private enum ExportQueueKeys {
        static let enabled = "exportQueueEnabled"
        static let minRating = "exportQueueMinRating"
        static let presetID = "exportQueuePresetID"
        static let directoryPath = "exportQueueOutputDirectoryPath"
    }
    
    private func loadExportQueueSettings() {
        exportQueueEnabled = UserDefaults.standard.object(forKey: ExportQueueKeys.enabled) as? Bool ?? false
        exportQueueMinRating = UserDefaults.standard.object(forKey: ExportQueueKeys.minRating) as? Int ?? 4
        
        if let raw = UserDefaults.standard.string(forKey: ExportQueueKeys.presetID),
           let id = UUID(uuidString: raw),
           let preset = exportPresets.first(where: { $0.id == id }) {
            exportQueuePreset = preset
        } else {
            exportQueuePreset = nil
        }
        
        if let path = UserDefaults.standard.string(forKey: ExportQueueKeys.directoryPath) {
            let url = URL(fileURLWithPath: path)
            exportQueueOutputDirectory = resolvedBookmarkURL(forPath: url.path) ?? url
        } else {
            exportQueueOutputDirectory = nil
        }
    }
    
    private func saveExportQueueSettings() {
        UserDefaults.standard.set(exportQueueEnabled, forKey: ExportQueueKeys.enabled)
        UserDefaults.standard.set(exportQueueMinRating, forKey: ExportQueueKeys.minRating)
        UserDefaults.standard.set(exportQueuePreset?.id.uuidString, forKey: ExportQueueKeys.presetID)
        UserDefaults.standard.set(exportQueueOutputDirectory?.path, forKey: ExportQueueKeys.directoryPath)
    }
    
    func chooseExportQueueDirectory() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = true
        panel.prompt = "Auswählen"
        panel.message = "Wählen Sie einen Zielordner für die Export‑Queue"
        
        if panel.runModal() == .OK, let url = panel.url {
            saveBookmark(for: url)
            exportQueueOutputDirectory = url
        }
    }
    
    func setExportQueuePreset(_ preset: ExportPreset?) {
        exportQueuePreset = preset
    }
    
    func setQuickExportPreset(_ preset: ExportPreset?) {
        quickExportPresetID = preset?.id
        saveQuickExportSettings()
        objectWillChange.send()
    }
    
    func chooseQuickExportDirectory() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = true
        panel.prompt = "Auswählen"
        panel.message = "Wählen Sie einen Zielordner für Quick Export"
        
        if panel.runModal() == .OK, let url = panel.url {
            saveBookmark(for: url)
            quickExportDirectory = url
            saveQuickExportSettings()
            objectWillChange.send()
        }
    }
    
    @MainActor
    func quickExportCurrent() {
        guard let photo = currentPhoto else { return }
        Task { [weak self] in
            await self?.quickExport(photos: [photo])
        }
    }
    
    @MainActor
    func quickExportSelection() {
        let targets = photos.filter { selectedPhotoIDs.contains($0.id) }
        guard !targets.isEmpty else { return }
        Task { [weak self] in
            await self?.quickExport(photos: targets)
        }
    }
    
    private func quickExport(photos: [PhotoItem]) async {
        guard !photos.isEmpty else { return }
        guard !isQuickExporting else { return }
        
        // Preset
        guard let presetID = quickExportPresetID,
              let preset = exportPresets.first(where: { $0.id == presetID }) else {
            await MainActor.run {
                showAlert(title: "Quick Export", message: "Bitte zuerst ein Export‑Preset auswählen (Einstellungen → Workflow oder Export‑Preset).")
            }
            return
        }
        
        // Directory
        guard let dir = quickExportDirectory else {
            await MainActor.run {
                showAlert(title: "Quick Export", message: "Bitte zuerst einen Zielordner wählen.")
            }
            return
        }
        
        await MainActor.run {
            isQuickExporting = true
            quickExportProgress = 0.0
        }
        
        let accessGranted = dir.startAccessingSecurityScopedResource()
        defer {
            if accessGranted { dir.stopAccessingSecurityScopedResource() }
        }
        
        do {
            let total = Double(photos.count)
            for (idx, photo) in photos.enumerated() {
                let outputURL = uniqueQuickExportURL(for: photo, preset: preset, in: dir)
                try await ExportService.shared.export(
                    photo: photo,
                    preset: preset,
                    to: outputURL,
                    uploadTargets: uploadTargets
                ) { progress in
                    DispatchQueue.main.async {
                        // Pro Foto wird ExportService 0..1 liefern; wir mappen auf Batch‑Progress.
                        let base = Double(idx) / total
                        self.quickExportProgress = min(1.0, base + (progress / total))
                    }
                }
            }
            
            await MainActor.run {
                isQuickExporting = false
                quickExportProgress = 1.0
            }
        } catch {
            await MainActor.run {
                isQuickExporting = false
                showAlert(title: "Quick Export fehlgeschlagen", message: error.localizedDescription)
            }
        }
    }
    
    private func uniqueQuickExportURL(for photo: PhotoItem, preset: ExportPreset, in directory: URL) -> URL {
        let fileName = buildFileName(for: photo, preset: preset)
        var candidate = directory.appendingPathComponent(fileName)
        
        let fm = FileManager.default
        if !fm.fileExists(atPath: candidate.path) { return candidate }
        
        let base = (fileName as NSString).deletingPathExtension
        let ext = (fileName as NSString).pathExtension
        var i = 2
        while fm.fileExists(atPath: candidate.path) {
            candidate = directory.appendingPathComponent("\(base)-\(i).\(ext)")
            i += 1
        }
        return candidate
    }
    
    private func buildFileName(for photo: PhotoItem, preset: ExportPreset) -> String {
        let settings = AppSettings.shared
        let template = settings.filenameTemplate
        
        let originalName = (photo.fileName as NSString).deletingPathExtension
        let presetName = preset.name
        let rating = "\(photo.rating)"
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd_HH-mm-ss"
        let date = formatter.string(from: Date())
        
        let rendered = template
            .replacingOccurrences(of: "{originalname}", with: originalName)
            .replacingOccurrences(of: "{preset}", with: presetName)
            .replacingOccurrences(of: "{date}", with: date)
            .replacingOccurrences(of: "{rating}", with: rating)
        
        let safe = sanitizeFileName(rendered)
        return "\(safe).\(preset.format.fileExtension)"
    }
    
    private func sanitizeFileName(_ name: String) -> String {
        let invalid = CharacterSet(charactersIn: "/\\?%*|\"<>:")
        let cleaned = name
            .components(separatedBy: invalid)
            .joined(separator: "_")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return cleaned.isEmpty ? "Export" : cleaned
    }
    
    private func resolvedBookmarkURL(forPath path: String) -> URL? {
        guard let bookmarks = UserDefaults.standard.dictionary(forKey: "folderBookmarks"),
              let bookmarkData = bookmarks[path] as? Data else {
            return nil
        }
        var isStale = false
        return try? URL(
            resolvingBookmarkData: bookmarkData,
            options: [.withSecurityScope],
            relativeTo: nil,
            bookmarkDataIsStale: &isStale
        )
    }
    
    private func saveBookmark(for url: URL) {
        do {
            let bookmarkData = try url.bookmarkData(
                options: [.withSecurityScope],
                includingResourceValuesForKeys: nil,
                relativeTo: nil
            )
            var bookmarks = UserDefaults.standard.dictionary(forKey: "folderBookmarks") ?? [:]
            bookmarks[url.path] = bookmarkData
            UserDefaults.standard.set(bookmarks, forKey: "folderBookmarks")
        } catch {
            print("Fehler beim Speichern des Bookmarks: \(error)")
        }
    }
    
    private func showAlert(title: String, message: String) {
        let alert = NSAlert()
        alert.messageText = title
        alert.informativeText = message
        alert.addButton(withTitle: "OK")
        alert.alertStyle = .warning
        alert.runModal()
    }
    
    deinit {
        stopAccessingCurrentFolderIfNeeded()
    }
    
    private func stopAccessingCurrentFolderIfNeeded() {
        if isAccessingCurrentFolder, let url = currentFolderAccessURL {
            url.stopAccessingSecurityScopedResource()
        }
        isAccessingCurrentFolder = false
        currentFolderAccessURL = nil
    }
    
    func setup(uiState: UIState) {
        self.uiState = uiState
        
        // Listen for filter changes from UIState
        uiState.$ratingFilter
            .debounce(for: .milliseconds(100), scheduler: RunLoop.main)
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)
        
        uiState.$pickStatusFilter
            .debounce(for: .milliseconds(100), scheduler: RunLoop.main)
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)
        
        uiState.$searchQuery
            .debounce(for: .milliseconds(150), scheduler: RunLoop.main)
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)

        // Also update when the base photos array changes
        $photos
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)

        // Quick Collection filter
        uiState.$showQuickCollectionOnly
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)

        // Color Tag filter
        uiState.$colorTagFilter
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)
        
        // Smart Collection filter
        uiState.$activeSmartCollectionID
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)
        
        // Sortierung
        uiState.$sortMode
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)

        // Selection mode: when disabled, keep a single active selection (safer for beginners).
        uiState.$selectionMode
            .sink { [weak self] enabled in
                guard let self else { return }
                guard !enabled else { return }
                if let current = self.currentPhotoID {
                    self.selectedPhotoIDs = [current]
                }
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Filtering
    
    private func updateFilteredPhotos() {
        guard let uiState = uiState else {
            self.filteredPhotos = self.photos
            return
        }
        
        var newFilteredPhotos = photos
        
        // Smart Collection Filter (zuerst, damit Kriterien wie "hasAdjustments" etc. funktionieren)
        if let activeID = uiState.activeSmartCollectionID,
           let collection = smartCollections.first(where: { $0.id == activeID }) {
            newFilteredPhotos = newFilteredPhotos.filter { collection.matches($0) }
        }
        
        // Textsuche (Dateiname, Caption, Keywords)
        let q = uiState.searchQuery.trimmingCharacters(in: .whitespacesAndNewlines)
        if !q.isEmpty {
            newFilteredPhotos = newFilteredPhotos.filter { matchesSearch($0, query: q) }
        }
        
        // Rating Filter
        if let rating = uiState.ratingFilter {
            newFilteredPhotos = newFilteredPhotos.filter { $0.rating == rating }
        }
        
        // Pick Status Filter
        if let pickStatus = uiState.pickStatusFilter {
            newFilteredPhotos = newFilteredPhotos.filter { $0.pickStatus == pickStatus }
        }
        
        // Quick Collection Filter
        if uiState.showQuickCollectionOnly {
            newFilteredPhotos = newFilteredPhotos.filter { $0.isInQuickCollection }
        }
        
        // Color Tag Filter
        if let colorTag = uiState.colorTagFilter {
            newFilteredPhotos = newFilteredPhotos.filter { $0.colorTags.contains(colorTag) }
        }
        
        // Sortierung (UI‑umschaltbar)
        newFilteredPhotos = sortPhotos(newFilteredPhotos, mode: uiState.sortMode)
        
        self.filteredPhotos = newFilteredPhotos
    }

    private func sortPhotos(_ list: [PhotoItem], mode: PhotoSortMode) -> [PhotoItem] {
        func tiebreak(_ a: PhotoItem, _ b: PhotoItem) -> Bool {
            let aName = a.url.lastPathComponent
            let bName = b.url.lastPathComponent
            if aName != bName { return aName < bName }
            return a.virtualCopyNumber < b.virtualCopyNumber
        }
        
        switch mode {
        case .captureDateDesc:
            return list.sorted { a, b in
                let da = a.iptcMetadata?.date ?? Date.distantPast
                let db = b.iptcMetadata?.date ?? Date.distantPast
                if da != db { return da > db }
                return tiebreak(a, b)
            }
        case .captureDateAsc:
            return list.sorted { a, b in
                let da = a.iptcMetadata?.date ?? Date.distantPast
                let db = b.iptcMetadata?.date ?? Date.distantPast
                if da != db { return da < db }
                return tiebreak(a, b)
            }
        case .fileNameAsc:
            return list.sorted { a, b in
                return tiebreak(a, b)
            }
        case .ratingDesc:
            return list.sorted { a, b in
                if a.rating != b.rating { return a.rating > b.rating }
                return tiebreak(a, b)
            }
        case .ratingAsc:
            return list.sorted { a, b in
                if a.rating != b.rating { return a.rating < b.rating }
                return tiebreak(a, b)
            }
        }
    }
    
    private func matchesSearch(_ photo: PhotoItem, query: String) -> Bool {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return true }
        
        // AND-Search über Tokens
        let tokens = trimmed
            .lowercased()
            .split(whereSeparator: { $0.isWhitespace })
            .map(String.init)
            .filter { !$0.isEmpty }
        
        if tokens.isEmpty { return true }
        
        let fileName = photo.fileName.lowercased()
        let caption = (photo.iptcMetadata?.caption ?? "").lowercased()
        let keywords = (photo.iptcMetadata?.keywords ?? []).joined(separator: " ").lowercased()
        let tags = photo.textTags.joined(separator: " ").lowercased()
        
        let haystack = "\(fileName) \(caption) \(keywords) \(tags)"
        return tokens.allSatisfy { haystack.contains($0) }
    }
    
    // MARK: - Folder Management
    
    @Published var isLoadingPhotos: Bool = false
    @Published var loadingProgress: Double = 0.0
    
    func loadPhotos(from folderURL: URL) {
        // Fotos-Mediathek ist durch macOS Privacy geschützt. Wir triggern explizit die Photos-Permission,
        // damit das Einlesen nicht stillschweigend leer bleibt.
        let isPhotosLibraryFolder = folderURL.pathExtension.lowercased() == "photoslibrary"
        if isPhotosLibraryFolder {
            let current = PHPhotoLibrary.authorizationStatus(for: .readWrite)
            if current == .notDetermined {
                isLoadingPhotos = true
                loadingProgress = 0.0
                Task { @MainActor in
                    let status = await requestPhotosLibraryAuthorization()
                    if status == .authorized || status == .limited {
                        self.loadPhotos(from: folderURL)
                    } else {
                        self.isLoadingPhotos = false
                        self.loadingProgress = 0.0
                        self.photos = []
                        self.currentPhotoID = nil
                        self.selectedPhotoIDs = []
                        self.updateFilteredPhotos()
                        self.showPhotosPermissionAlert()
                    }
                }
                return
            }
            if !(current == .authorized || current == .limited) {
                showPhotosPermissionAlert()
                return
            }
        }

        // Prüfe ob Ordner existiert und zugänglich ist
        // Für Photos Library verwenden wir PhotoKit – die Paket-Struktur kann in der Sandbox "Operation not permitted" liefern,
        // obwohl PhotoKit Zugriff hat. Daher hier nicht hart abbrechen.
        let fileManager = FileManager.default
        var isDirectory: ObjCBool = false
        if !isPhotosLibraryFolder {
            guard fileManager.fileExists(atPath: folderURL.path, isDirectory: &isDirectory),
                  isDirectory.boolValue else {
                print("Ordner existiert nicht oder ist nicht zugänglich: \(folderURL.path)")
                return
            }
        }
        
        // Wenn wir den Ordner wechseln: alte Security-Scope schließen & Caches leeren.
        // Wichtig: startAccessingSecurityScopedResource() ist referenzgezählt — bei erneutem Laden desselben Ordners
        // dürfen wir nicht blind erneut starten, sonst "leaken" wir die Referenzen.
        let isSameFolderAndAlreadyAccessing = (currentFolderAccessURL?.path == folderURL.path && isAccessingCurrentFolder)
        if !isSameFolderAndAlreadyAccessing {
            stopAccessingCurrentFolderIfNeeded()
            Task { @MainActor in
                SmartImageLoader.shared.clearCache()
            }
            
            // Security-Scoped Resource: während der Nutzung des Ordners offen halten
            currentFolderAccessURL = folderURL
            isAccessingCurrentFolder = folderURL.startAccessingSecurityScopedResource()
        }
        
        currentFolder = folderURL
        isLoadingPhotos = true
        loadingProgress = 0.0
        photos = [] // Leere zuerst für sofortiges UI-Update

        // Settings/Flags einmal capturen (für Concurrency/Sandbox)
        let shouldSearchSubfolders = AppSettings.shared.searchSubfolders
        let isPhotosLibrary = folderURL.pathExtension.lowercased() == "photoslibrary"
        // Ratings in Photos Library sind read-only → lokal persistieren (damit Dates/Library nicht verändert werden).
        let localRatingsSnapshot: [String: Int] = isPhotosLibrary ? loadLocalRatings() : [:]
        let scanCandidates: [URL] = {
            guard isPhotosLibrary else { return [folderURL] }
            // Photos.app Library ist ein Package. Die Originale liegen üblicherweise unter "originals" (neu) oder "Masters" (alt).
            // Wichtig: fileExists kann in Sandbox/Permissions false liefern. Daher probieren wir mehrere Kandidaten.
            return [
                folderURL.appendingPathComponent("originals"),
                folderURL.appendingPathComponent("Masters"),
                // Fallback: "resources" enthält bei iCloud "Optimierter Speicher" oft nur Proxies/Derivate – aber damit sind zumindest alle Assets sichtbar.
                folderURL.appendingPathComponent("resources"),
                folderURL
            ]
        }()

        // Photos Library: NICHT den Package-Inhalt scannen (führt zu Duplikaten/gelöschten Medien/verschiedenen Qualitätsstufen).
        // Stattdessen PhotoKit verwenden → 1 Asset = 1 Foto, keine Videos, gelöschte verschwinden automatisch.
        if isPhotosLibrary {
            Task.detached(priority: .userInitiated) {
                let fetchOptions = PHFetchOptions()
                fetchOptions.includeHiddenAssets = false
                
                // Fetch only images (no videos)
                let assets = PHAsset.fetchAssets(with: .image, options: fetchOptions)
                let total = assets.count
                
                let editSnapshot = await EditCatalogService.shared.snapshot()
                var loadedInfos: [LoadedPhotoInfo] = []
                loadedInfos.reserveCapacity(total)
                
                for idx in 0..<total {
                    let asset = assets.object(at: idx)
                    let url = PHAssetURL.url(forLocalIdentifier: asset.localIdentifier)
                    
                    let rating = localRatingsSnapshot[url.absoluteString] ?? 0
                    
                    let date = asset.creationDate
                    let iptc = IPTCMetadata(date: date)
                    
                    // Best effort filename (für UI)
                    let resources = PHAssetResource.assetResources(for: asset)
                    let fileName = resources.first(where: { r in
                        switch r.type {
                        case .photo, .fullSizePhoto, .alternatePhoto:
                            return true
                        default:
                            return false
                        }
                    })?.originalFilename ?? resources.first?.originalFilename
                    
                    let edit = editSnapshot[url.absoluteString]
                    loadedInfos.append(
                        LoadedPhotoInfo(
                            url: url,
                            rating: rating,
                            iptc: iptc,
                            edit: edit,
                            captureDate: date,
                            originalFileName: fileName,
                            pixelWidth: asset.pixelWidth > 0 ? asset.pixelWidth : nil,
                            pixelHeight: asset.pixelHeight > 0 ? asset.pixelHeight : nil
                        )
                    )
                    
                    if idx % 200 == 0 || idx == total - 1 {
                        let progress = total > 0 ? Double(idx + 1) / Double(total) : 1.0
                        DispatchQueue.main.async {
                            self.loadingProgress = progress
                        }
                    }
                }
                
                // Sortiere initial nach Aufnahmedatum (neueste zuerst). UI-Sortierung greift danach sowieso auf filteredPhotos.
                let sortedInfos = loadedInfos.sorted { a, b in
                    let da = a.captureDate ?? Date.distantPast
                    let db = b.captureDate ?? Date.distantPast
                    if da != db { return da > db }
                    return a.originalFileName ?? a.url.absoluteString < (b.originalFileName ?? b.url.absoluteString)
                }
                
                await MainActor.run {
                    func baseKey(for url: URL) -> String {
                        url.isFileURL ? url.standardizedFileURL.path : url.absoluteString
                    }
                    
                    // 1) Masters
                    var loadedPhotos: [PhotoItem] = []
                    var photosByKey: [String: PhotoItem] = [:]
                    loadedPhotos.reserveCapacity(sortedInfos.count)
                    
                    for info in sortedInfos {
                        let photo = PhotoItem(
                            url: info.url,
                            rating: info.rating,
                            originalFileName: info.originalFileName,
                            pixelWidth: info.pixelWidth,
                            pixelHeight: info.pixelHeight
                        )
                        photo.iptcMetadata = info.iptc
                        if let edit = info.edit {
                            photo.adjustments = edit.adjustments
                            photo.localMasks = edit.localMasks
                            photo.lensProfileSettings = edit.lensProfileSettings
                            photo.cropRect = edit.cropRect?.cgRect
                            photo.rotation = edit.rotation
                            photo.isMaster = edit.isMaster
                            photo.masterID = edit.masterID.flatMap { UUID(uuidString: $0) }
                            photo.virtualCopyNumber = edit.virtualCopyNumber
                        }
                        loadedPhotos.append(photo)
                        photosByKey[baseKey(for: info.url)] = photo
                    }
                    
                    // 2) Virtual Copies aus Katalog
                    for (key, edit) in editSnapshot {
                        guard key.contains("#"), !edit.isMaster else { continue }
                        let parts = key.split(separator: "#")
                        guard parts.count == 2,
                              let photoIDStr = parts.last,
                              let photoID = UUID(uuidString: String(photoIDStr)) else { continue }
                        
                        let base = String(parts[0])
                        guard let masterPhoto = photosByKey[base] else { continue }
                        
                        let virtualCopy = PhotoItem(
                            url: masterPhoto.url,
                            rating: masterPhoto.rating,
                            id: photoID,
                            originalFileName: masterPhoto.originalFileName,
                            pixelWidth: masterPhoto.pixelWidth,
                            pixelHeight: masterPhoto.pixelHeight
                        )
                        virtualCopy.adjustments = edit.adjustments
                        virtualCopy.localMasks = edit.localMasks
                        virtualCopy.lensProfileSettings = edit.lensProfileSettings
                        virtualCopy.cropRect = edit.cropRect?.cgRect
                        virtualCopy.rotation = edit.rotation
                        virtualCopy.isMaster = false
                        virtualCopy.masterID = edit.masterID.flatMap { UUID(uuidString: $0) }
                        virtualCopy.virtualCopyNumber = edit.virtualCopyNumber
                        virtualCopy.iptcMetadata = masterPhoto.iptcMetadata
                        loadedPhotos.append(virtualCopy)
                    }
                    
                    // Sort: CaptureDate (neueste) + VirtualCopyNumber
                    loadedPhotos.sort { a, b in
                        let da = a.iptcMetadata?.date ?? Date.distantPast
                        let db = b.iptcMetadata?.date ?? Date.distantPast
                        if da != db { return da > db }
                        let aName = a.fileName
                        let bName = b.fileName
                        if aName != bName { return aName < bName }
                        return a.virtualCopyNumber < b.virtualCopyNumber
                    }
                    
                    self.photos = loadedPhotos
                    self.isLoadingPhotos = false
                    self.loadingProgress = 1.0
                    
                    self.loadQuickCollection()
                    print("✅ \(loadedPhotos.count) Photos (PhotoKit) geladen")
                    
                    self.updateFilteredPhotos()
                    
                    if let firstPhoto = self.filteredPhotos.first {
                        self.currentPhotoID = firstPhoto.id
                        self.selectedPhotoIDs = [firstPhoto.id]
                    } else {
                        self.currentPhotoID = nil
                        self.selectedPhotoIDs = []
                    }
                }
            }
            return
        }
        
        Task.detached(priority: .userInitiated) {
            let fileManager = FileManager.default
            // NOTE: "data" ist KEIN Bildformat → führt in Photos-Libraries zu False-Positives (z.B. Video/DB-Blobs).
            let imageExtensions: Set<String> = [
                "jpg", "jpeg", "png", "heic", "heif", "tiff", "tif",
                "raw", "cr2", "nef", "orf", "sr2", "arw", "dng",
                "raf", "rw2", "pef", "srw", "3fr", "mef", "mos",
                "ari", "bay", "crw", "cap", "dcs", "dcr",
                "drf", "eip", "erf", "fff", "iiq", "k25", "kdc",
                "mdc", "mrw", "nrw", "obm", "ptx", "pxn", "r3d",
                "raw", "rwl", "rwz", "sr2", "srf", "srw", "x3f"
            ]
            
            var allFiles: [URL] = []

            // Unterordner optional durchsuchen (Einstellung) + Photos-Library immer rekursiv
            let recursiveScan = shouldSearchSubfolders || isPhotosLibrary
            if recursiveScan {
                let keys: [URLResourceKey] = [.isRegularFileKey, .isDirectoryKey, .isPackageKey]
                
                func scan(_ base: URL) -> Set<URL> {
                    guard let enumerator = fileManager.enumerator(
                        at: base,
                        includingPropertiesForKeys: keys,
                        options: [.skipsHiddenFiles],
                        errorHandler: nil
                    ) else {
                        return []
                    }
                    
                    var collected = Set<URL>()
                    
                    for case let url as URL in enumerator {
                        guard let values = try? url.resourceValues(forKeys: Set(keys)) else { continue }
                        
                        if values.isDirectory == true {
                            // In normalen Ordnern Packages überspringen (z.B. *.app, *.photoslibrary)
                            if !isPhotosLibrary, values.isPackage == true {
                                enumerator.skipDescendants()
                            }
                            continue
                        }
                        
                        guard values.isRegularFile == true else { continue }
                        
                        // Photos Library: Cache/DB Pfade überspringen (aber Derivatives/Proxies NICHT hart ausschliessen,
                        // da bei iCloud "Optimierter Speicher" oft nur diese lokal vorhanden sind).
                        if isPhotosLibrary, base.lastPathComponent.lowercased() == "resources" {
                            let p = url.path.lowercased()
                            if p.contains("/thumbnails/") || p.contains("/caches/") || p.contains("/private/") || p.contains("/database/") {
                                continue
                            }
                        }
                        
                        let ext = url.pathExtension.lowercased()
                        if imageExtensions.contains(ext) {
                            collected.insert(url)
                        }
                    }
                    
                    return collected
                }
                
                if isPhotosLibrary {
                    // WICHTIG: Nur EINE Quelle wählen (sonst erscheinen viele Bilder doppelt/dreifach),
                    // aber nicht blind die erste "nicht-leere" nehmen: bei iCloud/Optimierung kann "originals" nur einen Bruchteil enthalten.
                    let minAcceptableCount = 300
                    var best: Set<URL> = []
                    var bestName: String = ""
                    
                    for base in scanCandidates {
                        let found = scan(base)
                        if found.count > best.count {
                            best = found
                            bestName = base.lastPathComponent
                        }
                        
                        // Early accept: Sobald eine der typischen Quellen "gross genug" ist, stoppen wir.
                        let last = base.lastPathComponent.lowercased()
                        if (last == "resources" || last == "originals" || last == "masters"), found.count >= minAcceptableCount {
                            best = found
                            bestName = base.lastPathComponent
                            break
                        }
                    }
                    
                    allFiles = Array(best)
                    print("📸 Photos Library Scan: \(allFiles.count) Dateien (Quelle: \(bestName.isEmpty ? "?" : bestName))")
                } else {
                    allFiles = Array(scan(folderURL))
                }
            } else {
                // Nur direkte Dateien im Ordner (nicht rekursiv)
                do {
                    let contents = try fileManager.contentsOfDirectory(
                        at: folderURL,
                        includingPropertiesForKeys: [.isRegularFileKey, .contentTypeKey],
                        options: [.skipsHiddenFiles]
                    )
                    
                    for fileURL in contents {
                        guard let resourceValues = try? fileURL.resourceValues(forKeys: [.isRegularFileKey]),
                              resourceValues.isRegularFile == true else {
                            continue
                        }
                        
                        let ext = fileURL.pathExtension.lowercased()
                        if imageExtensions.contains(ext) {
                            allFiles.append(fileURL)
                        }
                    }
                } catch {
                    print("⚠️ Fehler beim Laden des Ordners: \(error.localizedDescription)")
                }
            }

            // Dedupe (nur Pfade) + stabil sortieren (finale Sortierung kommt später nach Capture Date)
            allFiles = Array(Set(allFiles))

            if !isPhotosLibrary {
                print("📸 Gefundene Bilder: \(allFiles.count) in \(folderURL.path)")
            }

            // Services lokal (keine MainActor-Abhängigkeiten über `self` im Background)
            let ratingService = RatingPersistenceService.shared
            let metadataService = IPTCMetadataService.shared
            let editSnapshot = await EditCatalogService.shared.snapshot()

            // MARK: - Photos Library: Filter (keine Videos) + Dedupe (UniqueID → beste Variante)
            struct ScanCandidate: Sendable {
                let url: URL
                let iptc: IPTCMetadata?
                let captureDate: Date?
                let uniqueID: String?
                let pixelWidth: Int?
                let pixelHeight: Int?
                let pixelArea: Int
                let fileSize: Int
                let sourceRank: Int
                let extRank: Int
            }
            
            func extRank(for url: URL) -> Int {
                let ext = url.pathExtension.lowercased()
                if ["dng","cr2","nef","orf","arw","raf","rw2","pef","srw","3fr","mef","mos","r3d","x3f"].contains(ext) { return 5 }
                if ["tif","tiff"].contains(ext) { return 4 }
                if ["heic","heif"].contains(ext) { return 3 }
                if ["jpg","jpeg"].contains(ext) { return 2 }
                if ["png"].contains(ext) { return 1 }
                return 0
            }
            
            func sourceRank(for url: URL) -> Int {
                let p = url.path.lowercased()
                // Prefer Originale/Masters, dann Derivate, dann Proxies
                if p.contains("/originals/") || p.contains("/masters/") { return 3 }
                if p.contains("/derivatives/") { return 2 }
                if p.contains("/proxies/") { return 1 }
                return 0
            }
            
            func isBetter(_ a: ScanCandidate, than b: ScanCandidate) -> Bool {
                if a.sourceRank != b.sourceRank { return a.sourceRank > b.sourceRank }
                if a.pixelArea != b.pixelArea { return a.pixelArea > b.pixelArea }
                if a.fileSize != b.fileSize { return a.fileSize > b.fileSize }
                if a.extRank != b.extRank { return a.extRank > b.extRank }
                return a.url.lastPathComponent < b.url.lastPathComponent
            }

            let totalFiles = allFiles.count
            var candidates: [ScanCandidate] = []
            candidates.reserveCapacity(totalFiles)
            
            for (index, fileURL) in allFiles.enumerated() {
                // UTType Filter: nur Bilder (keine Videos)
                if let rv = try? fileURL.resourceValues(forKeys: [.contentTypeKey, .fileSizeKey]),
                   let type = rv.contentType {
                    // explizit Videos ausschliessen
                    if type.conforms(to: .movie) || type.conforms(to: .video) || type.conforms(to: .audiovisualContent) {
                        continue
                    }
                    // nur Bildtypen zulassen (rawImage zählt als image-like)
                    if !(type.conforms(to: .image) || type.conforms(to: .rawImage)) {
                        continue
                    }
                }
                
                // Extension Filter (schnell)
                let ext = fileURL.pathExtension.lowercased()
                guard imageExtensions.contains(ext) else { continue }
                
                let scan = metadataService.loadScanMeta(from: fileURL)
                let pw = scan.pixelWidth
                let ph = scan.pixelHeight
                let pixelArea = max(0, (pw ?? 0) * (ph ?? 0))
                let fileSize = (try? fileURL.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
                
                candidates.append(
                    ScanCandidate(
                        url: fileURL,
                        iptc: scan.iptc,
                        captureDate: scan.iptc?.date,
                        uniqueID: scan.exifImageUniqueID,
                        pixelWidth: pw,
                        pixelHeight: ph,
                        pixelArea: pixelArea,
                        fileSize: fileSize,
                        sourceRank: sourceRank(for: fileURL),
                        extRank: extRank(for: fileURL)
                    )
                )
                
                if index % 75 == 0 || index == totalFiles - 1 {
                    let progress = totalFiles > 0 ? Double(index + 1) / Double(totalFiles) : 1.0
                    DispatchQueue.main.async {
                        self.loadingProgress = progress * 0.6 // Scan: 60%
                    }
                }
            }
            
            let selectedCandidates: [ScanCandidate] = {
                guard isPhotosLibrary else { return candidates }
                
                var bestByUniqueID: [String: ScanCandidate] = [:]
                var passThrough: [ScanCandidate] = []
                passThrough.reserveCapacity(candidates.count)
                
                for cand in candidates {
                    let uid = cand.uniqueID?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
                    let key: String? = {
                        if !uid.isEmpty {
                            return "uid:\(uid)"
                        }
                        // Fallback: Photos-Library legt Derivate/Proxies oft unter gleichem Basenamen ab.
                        // Kombiniere optional mit Capture-Date, um echte gleichnamige Imports nicht zu hart zu mergen.
                        let base = cand.url.deletingPathExtension().lastPathComponent
                        guard base.count >= 8 else { return nil }
                        if let d = cand.captureDate {
                            return "name:\(base)|\(Int(d.timeIntervalSince1970))"
                        }
                        return "name:\(base)"
                    }()
                    
                    if let key {
                        if let existing = bestByUniqueID[key] {
                            if isBetter(cand, than: existing) {
                                bestByUniqueID[key] = cand
                            }
                        } else {
                            bestByUniqueID[key] = cand
                        }
                    } else {
                        passThrough.append(cand)
                    }
                }
                
                let deduped = Array(bestByUniqueID.values) + passThrough
                print("📸 Photos Library Dedupe: \(candidates.count) Kandidaten → \(deduped.count) (UniqueID/Basename)")
                return deduped
            }()
            
            // MARK: - Build LoadedPhotoInfo
            var loadedInfos: [LoadedPhotoInfo] = []
            loadedInfos.reserveCapacity(selectedCandidates.count)
            
            for (index, cand) in selectedCandidates.enumerated() {
                let url = cand.url
                
                // Rating: Photos Library → lokal; sonst aus Metadaten
                let rating: Int
                if isPhotosLibrary {
                    rating = localRatingsSnapshot[url.standardizedFileURL.path] ?? 0
                } else {
                    rating = ratingService.loadRating(from: url)
                }
                
                // IPTC: schon geladen; Fallback-Datum NUR ausserhalb Photos-Library, damit "Bearbeitet"-Derivate nicht vorne landen.
                var iptc = cand.iptc
                if !isPhotosLibrary {
                    if iptc == nil { iptc = IPTCMetadata() }
                    if iptc?.date == nil {
                        // Stabiler als "modified": creationDate bleibt eher konstant.
                        let rv = try? url.resourceValues(forKeys: [.creationDateKey])
                        iptc?.date = rv?.creationDate
                    }
                }
                
                let editKey = url.isFileURL ? url.standardizedFileURL.path : url.absoluteString
                let edit = editSnapshot[editKey]
                let captureDate = iptc?.date
                loadedInfos.append(
                    LoadedPhotoInfo(
                        url: url,
                        rating: rating,
                        iptc: iptc,
                        edit: edit,
                        captureDate: captureDate,
                        originalFileName: nil,
                        pixelWidth: cand.pixelWidth,
                        pixelHeight: cand.pixelHeight
                    )
                )
                
                if index % 75 == 0 || index == selectedCandidates.count - 1 {
                    let progress = selectedCandidates.count > 0 ? Double(index + 1) / Double(max(1, selectedCandidates.count)) : 1.0
                    DispatchQueue.main.async {
                        // Metadaten-Build: weitere 40%
                        self.loadingProgress = 0.6 + (progress * 0.4)
                    }
                }
            }
            
            // Sortierung: Photos Library nach Aufnahmedatum (neueste zuerst), sonst stabil nach Dateiname.
            let sortedInfos: [LoadedPhotoInfo] = {
                if isPhotosLibrary {
                    return loadedInfos.sorted { a, b in
                        let da = a.captureDate ?? Date.distantPast
                        let db = b.captureDate ?? Date.distantPast
                        if da != db { return da > db }
                        return a.url.lastPathComponent < b.url.lastPathComponent
                    }
                } else {
                    return loadedInfos.sorted { $0.url.lastPathComponent < $1.url.lastPathComponent }
                }
            }()
            
            await MainActor.run {
                func baseKey(for url: URL) -> String {
                    url.isFileURL ? url.standardizedFileURL.path : url.absoluteString
                }
                
                // 1) Load physical files (Masters)
                var loadedPhotos: [PhotoItem] = []
                var photosByKey: [String: PhotoItem] = [:]
                
                for info in sortedInfos {
                    let photo = PhotoItem(
                        url: info.url,
                        rating: info.rating,
                        originalFileName: info.originalFileName,
                        pixelWidth: info.pixelWidth,
                        pixelHeight: info.pixelHeight
                    )
                    photo.iptcMetadata = info.iptc
                    if let edit = info.edit {
                        photo.adjustments = edit.adjustments
                        photo.localMasks = edit.localMasks
                        photo.lensProfileSettings = edit.lensProfileSettings
                        photo.cropRect = edit.cropRect?.cgRect
                        photo.rotation = edit.rotation
                        photo.isMaster = edit.isMaster
                        photo.masterID = edit.masterID.flatMap { UUID(uuidString: $0) }
                        photo.virtualCopyNumber = edit.virtualCopyNumber
                    }
                    loadedPhotos.append(photo)
                    photosByKey[baseKey(for: info.url)] = photo
                }
                
                // 2) Reconstruct Virtual Copies from catalog
                for (key, edit) in editSnapshot {
                    // Virtual Copy entries have a "#UUID" suffix
                    guard key.contains("#"), !edit.isMaster else { continue }
                    
                    let parts = key.split(separator: "#")
                    guard parts.count == 2, let photoIDStr = parts.last, let photoID = UUID(uuidString: String(photoIDStr)) else { continue }
                    
                    let urlKey = String(parts[0])
                    guard let masterPhoto = photosByKey[urlKey] else { continue }
                    
                    // Create virtual copy PhotoItem
                    let virtualCopy = PhotoItem(
                        url: masterPhoto.url,
                        rating: masterPhoto.rating,
                        id: photoID,
                        originalFileName: masterPhoto.originalFileName,
                        pixelWidth: masterPhoto.pixelWidth,
                        pixelHeight: masterPhoto.pixelHeight
                    )
                    virtualCopy.adjustments = edit.adjustments
                    virtualCopy.localMasks = edit.localMasks
                    virtualCopy.lensProfileSettings = edit.lensProfileSettings
                    virtualCopy.cropRect = edit.cropRect?.cgRect
                    virtualCopy.rotation = edit.rotation
                    virtualCopy.isMaster = false
                    virtualCopy.masterID = edit.masterID.flatMap { UUID(uuidString: $0) }
                    virtualCopy.virtualCopyNumber = edit.virtualCopyNumber
                    virtualCopy.iptcMetadata = masterPhoto.iptcMetadata
                    
                    loadedPhotos.append(virtualCopy)
                }
                
                // Sort: nach Capture Date (bei Photos Library), sonst Dateiname. Virtual Copies bleiben direkt beim Master.
                loadedPhotos.sort { a, b in
                    if isPhotosLibrary {
                        let da = a.iptcMetadata?.date ?? Date.distantPast
                        let db = b.iptcMetadata?.date ?? Date.distantPast
                        if da != db { return da > db }
                    }
                    let aURL = a.url.lastPathComponent
                    let bURL = b.url.lastPathComponent
                    if aURL != bURL { return aURL < bURL }
                    return a.virtualCopyNumber < b.virtualCopyNumber
                }
                
                self.photos = loadedPhotos
                self.isLoadingPhotos = false
                self.loadingProgress = 1.0
                
                // Load Quick Collection state
                self.loadQuickCollection()
                
                print("✅ \(loadedPhotos.count) Bilder geladen aus \(folderURL.path)")
                
                // Update filtered photos
                self.updateFilteredPhotos()
                
                if let firstPhoto = self.filteredPhotos.first {
                    self.currentPhotoID = firstPhoto.id
                    self.selectedPhotoIDs = [firstPhoto.id]
                    print("✅ Erstes Foto ausgewählt: \(firstPhoto.fileName)")
                } else {
                    self.currentPhotoID = nil
                    self.selectedPhotoIDs = []
                    print("⚠️ Keine gefilterten Fotos gefunden")
                }
            }
        }
    }

    // MARK: - Non-destructive edit persistence

    private func registerEditPersistenceObservers() {
        NotificationCenter.default.publisher(for: NSNotification.Name("PhotoAdjustmentsChanged"))
            // Hover-Preview/temporäre Vorschau darf NICHT persistiert werden.
            .filter { notification in
                !(notification.userInfo?["isPreview"] as? Bool ?? false)
            }
            .compactMap { $0.userInfo?["photoID"] as? UUID }
            .sink { [weak self] photoID in
                guard let self else { return }
                self.persistEditsDebounced(for: photoID)
            }
            .store(in: &cancellables)
    }

    private var persistTasks: [UUID: Task<Void, Never>] = [:]

    private func persistEditsDebounced(for photoID: UUID) {
        persistTasks[photoID]?.cancel()
        persistTasks[photoID] = Task { @MainActor in
            // debounce: sliders spammen viele Notifications
            try? await Task.sleep(nanoseconds: 500_000_000) // 500ms
            guard let photo = self.photos.first(where: { $0.id == photoID }) else { return }
            let entry = EditCatalogService.EditEntry(
                adjustments: photo.adjustments,
                localMasks: photo.localMasks,
                lensProfileSettings: photo.lensProfileSettings,
                cropRect: photo.cropRect,
                rotation: photo.rotation,
                isMaster: photo.isMaster,
                masterID: photo.masterID,
                virtualCopyNumber: photo.virtualCopyNumber
            )
            // Master: stabil per Dateipfad (kein #UUID), Virtual Copy: per url#uuid
            let keyPhotoID: UUID? = photo.isMaster ? nil : photo.id
            await EditCatalogService.shared.upsertEdit(entry, for: photo.url, photoID: keyPhotoID)
            self.persistTasks[photoID] = nil
        }
    }
    
    // MARK: - History / Undo / Snapshots (Lightroom-like)
    
    private struct EditState: Equatable, Sendable {
        var adjustments: PhotoAdjustments
        var localMasks: [LocalAdjustmentMask]
        var lensProfileSettings: LensProfileSettings
        var cropRect: CGRect?
        var rotation: Double
    }
    
    private let maxUndoDepth: Int = 60
    private var undoStackByKey: [String: [EditState]] = [:]
    private var redoStackByKey: [String: [EditState]] = [:]
    private var inFlightEditStartByKey: [String: EditState] = [:]
    
    func beginEditSession(for photo: PhotoItem) {
        let key = editKey(for: photo)
        if inFlightEditStartByKey[key] == nil {
            inFlightEditStartByKey[key] = captureEditState(photo)
        }
    }
    
    func endEditSession(for photo: PhotoItem) {
        let key = editKey(for: photo)
        guard let start = inFlightEditStartByKey.removeValue(forKey: key) else { return }
        let current = captureEditState(photo)
        guard start != current else { return }
        pushUndo(start, forKey: key)
        redoStackByKey[key] = []
        objectWillChange.send()
    }
    
    /// Für diskrete Aktionen (Auto/Reset/Preset/Paste/Sync): Undo-Punkt vor der Änderung speichern.
    func registerUndoPoint(for photo: PhotoItem) {
        let key = editKey(for: photo)
        pushUndo(captureEditState(photo), forKey: key)
        redoStackByKey[key] = []
        objectWillChange.send()
    }
    
    func undoCurrent() {
        guard let photo = currentPhoto else { return }
        undo(photo: photo)
    }
    
    func redoCurrent() {
        guard let photo = currentPhoto else { return }
        redo(photo: photo)
    }
    
    func canUndo(photo: PhotoItem) -> Bool {
        let key = editKey(for: photo)
        return !(undoStackByKey[key]?.isEmpty ?? true)
    }
    
    func canRedo(photo: PhotoItem) -> Bool {
        let key = editKey(for: photo)
        return !(redoStackByKey[key]?.isEmpty ?? true)
    }
    
    var canUndoCurrent: Bool {
        guard let photo = currentPhoto else { return false }
        return canUndo(photo: photo)
    }
    
    var canRedoCurrent: Bool {
        guard let photo = currentPhoto else { return false }
        return canRedo(photo: photo)
    }
    
    private func undo(photo: PhotoItem) {
        let key = editKey(for: photo)
        guard var undoStack = undoStackByKey[key], let previous = undoStack.popLast() else { return }
        undoStackByKey[key] = undoStack
        
        var redoStack = redoStackByKey[key] ?? []
        redoStack.append(captureEditState(photo))
        redoStackByKey[key] = redoStack
        
        applyEditState(previous, to: photo)
        objectWillChange.send()
    }
    
    private func redo(photo: PhotoItem) {
        let key = editKey(for: photo)
        guard var redoStack = redoStackByKey[key], let next = redoStack.popLast() else { return }
        redoStackByKey[key] = redoStack
        
        var undoStack = undoStackByKey[key] ?? []
        undoStack.append(captureEditState(photo))
        undoStackByKey[key] = trimUndo(undoStack)
        
        applyEditState(next, to: photo)
        objectWillChange.send()
    }
    
    // MARK: Snapshots
    
    func snapshots(for photo: PhotoItem) -> [EditSnapshot] {
        editSnapshotsByKey[editKey(for: photo)] ?? []
    }
    
    func createSnapshot(for photo: PhotoItem, name: String? = nil) {
        let key = editKey(for: photo)
        var list = editSnapshotsByKey[key] ?? []
        let defaultName = name ?? "Snapshot \(list.count + 1)"
        let snapshot = EditSnapshot(
            name: defaultName,
            adjustments: photo.adjustments,
            localMasks: photo.localMasks,
            lensProfileSettings: photo.lensProfileSettings,
            cropRect: photo.cropRect,
            rotation: photo.rotation
        )
        list.insert(snapshot, at: 0)
        editSnapshotsByKey[key] = list
        saveEditSnapshots()
        objectWillChange.send()
    }
    
    func applySnapshot(_ snapshot: EditSnapshot, to photo: PhotoItem) {
        registerUndoPoint(for: photo)
        
        photo.adjustments = snapshot.adjustments
        photo.localMasks = snapshot.localMasks ?? []
        photo.lensProfileSettings = snapshot.lensProfileSettings ?? LensProfileSettings()
        photo.cropRect = snapshot.cropRect?.cgRect
        photo.rotation = snapshot.rotation
        
        triggerReprocess(for: photo)
    }
    
    func deleteSnapshot(_ snapshot: EditSnapshot, for photo: PhotoItem) {
        let key = editKey(for: photo)
        var list = editSnapshotsByKey[key] ?? []
        list.removeAll { $0.id == snapshot.id }
        editSnapshotsByKey[key] = list
        saveEditSnapshots()
        objectWillChange.send()
    }
    
    private func loadEditSnapshots() {
        guard let data = UserDefaults.standard.data(forKey: "editSnapshotsV1"),
              let decoded = try? JSONDecoder().decode([String: [EditSnapshot]].self, from: data) else {
            editSnapshotsByKey = [:]
            return
        }
        editSnapshotsByKey = decoded
    }
    
    private func saveEditSnapshots() {
        guard let encoded = try? JSONEncoder().encode(editSnapshotsByKey) else { return }
        UserDefaults.standard.set(encoded, forKey: "editSnapshotsV1")
    }
    
    // MARK: Helpers
    
    private func editKey(for photo: PhotoItem) -> String {
        let base = photo.url.standardizedFileURL.path
        return photo.isMaster ? base : "\(base)#\(photo.id.uuidString)"
    }
    
    private func captureEditState(_ photo: PhotoItem) -> EditState {
        EditState(
            adjustments: photo.adjustments,
            localMasks: photo.localMasks,
            lensProfileSettings: photo.lensProfileSettings,
            cropRect: photo.cropRect,
            rotation: photo.rotation
        )
    }
    
    private func applyEditState(_ state: EditState, to photo: PhotoItem) {
        photo.adjustments = state.adjustments
        photo.localMasks = state.localMasks
        photo.lensProfileSettings = state.lensProfileSettings
        photo.cropRect = state.cropRect
        photo.rotation = state.rotation
        triggerReprocess(for: photo)
    }
    
    private func pushUndo(_ state: EditState, forKey key: String) {
        var stack = undoStackByKey[key] ?? []
        // Dedup: wenn letzter Eintrag identisch, nicht pushen
        if stack.last != state {
            stack.append(state)
        }
        undoStackByKey[key] = trimUndo(stack)
    }
    
    private func trimUndo(_ stack: [EditState]) -> [EditState] {
        if stack.count <= maxUndoDepth { return stack }
        return Array(stack.suffix(maxUndoDepth))
    }

    @MainActor
    private func requestPhotosLibraryAuthorization() async -> PHAuthorizationStatus {
        await withCheckedContinuation { continuation in
            PHPhotoLibrary.requestAuthorization(for: .readWrite) { status in
                continuation.resume(returning: status)
            }
        }
    }

    @MainActor
    private func showPhotosPermissionAlert() {
        let alert = NSAlert()
        alert.messageText = "Zugriff auf Fotos verweigert"
        alert.informativeText = "WB Foto Manager benötigt Zugriff auf die Fotos‑Mediathek. Bitte in „Systemeinstellungen → Datenschutz & Sicherheit → Fotos“ aktivieren und erneut versuchen."
        alert.addButton(withTitle: "OK")
        alert.alertStyle = .warning
        alert.runModal()
    }
    
    // MARK: - Navigation
    
    func selectPhoto(_ photo: PhotoItem) {
        currentPhotoID = photo.id
        if uiState?.selectionMode == true {
            // Safe multi-select: Click adds to selection, does NOT unselect (prevents accidental "losing" selection).
            selectedPhotoIDs.insert(photo.id)
        } else {
            // Single selection (default)
            selectedPhotoIDs = [photo.id]
        }
    }
    
    /// Wählt alle aktuell sichtbaren/gefilteten Fotos aus (⌘A Workflow).
    /// - Note: Aktiviert automatisch `selectionMode`.
    func selectAllFilteredPhotos() {
        guard !filteredPhotos.isEmpty else { return }
        uiState?.selectionMode = true
        
        selectedPhotoIDs = Set(filteredPhotos.map { $0.id })
        if currentPhotoID == nil {
            currentPhotoID = filteredPhotos.first?.id
        } else if let current = currentPhotoID, !selectedPhotoIDs.contains(current) {
            // Falls Current ausserhalb Filter liegt, setze auf erstes sichtbares Foto.
            currentPhotoID = filteredPhotos.first?.id
        }
    }
    
    func cancelAITagging() {
        aiTaggingTask?.cancel()
        aiTaggingTask = nil
        
        isAITaggingRunning = false
        aiTaggingProgress = 0.0
        aiTaggingProcessedCount = 0
        aiTaggingTotalCount = 0
        aiTaggingCurrentName = ""
    }

    func clearSelectionToCurrent() {
        if let current = currentPhotoID {
            selectedPhotoIDs = [current]
        } else {
            selectedPhotoIDs = []
        }
    }

    func copyAdjustmentsFromCurrent() {
        guard let photo = currentPhoto else { return }
        copiedAdjustments = photo.adjustments
    }

    func pasteAdjustmentsToCurrent() {
        guard let photo = currentPhoto, let copiedAdjustments else { return }
        registerUndoPoint(for: photo)
        photo.adjustments = copiedAdjustments
        triggerReprocess(for: photo)
    }

    func pasteAdjustmentsToSelection() {
        guard let copiedAdjustments else { return }
        let targets = photos.filter { selectedPhotoIDs.contains($0.id) }
        guard !targets.isEmpty else { return }

        for photo in targets {
            registerUndoPoint(for: photo)
            photo.adjustments = copiedAdjustments
            persistEditsForPhoto(photo)
        }

        if let current = currentPhoto {
            triggerReprocess(for: current)
        } else {
            objectWillChange.send()
        }
    }

    func syncFromCurrentToSelection(scope: SyncScope) {
        guard let source = currentPhoto else { return }
        let sourceAdjustments = source.adjustments
        let sourceCrop = source.cropRect
        let sourceRotation = source.rotation

        let targets = photos.filter { selectedPhotoIDs.contains($0.id) && $0.id != source.id }
        guard !targets.isEmpty else { return }

        for photo in targets {
            registerUndoPoint(for: photo)
            var updated = photo.adjustments
            applySyncAdjustments(from: sourceAdjustments, to: &updated, scope: scope)
            photo.adjustments = updated
            if scope.cropAndRotation {
                photo.cropRect = sourceCrop
                photo.rotation = sourceRotation
            }
            persistEditsForPhoto(photo)
        }

        // Ensure current image refresh (and also persist current via existing observer).
        triggerReprocess(for: source)
    }

    private func applySyncAdjustments(from source: PhotoAdjustments, to target: inout PhotoAdjustments, scope: SyncScope) {
        if scope.whiteBalance {
            target.temperature = source.temperature
            target.tint = source.tint
        }
        if scope.exposure {
            target.exposure = source.exposure
        }
        if scope.contrast {
            target.contrast = source.contrast
        }
        if scope.tone {
            target.highlights = source.highlights
            target.shadows = source.shadows
            target.whites = source.whites
            target.blacks = source.blacks
        }
        if scope.presence {
            target.clarity = source.clarity
            target.texture = source.texture
            target.dehaze = source.dehaze
            target.vibrance = source.vibrance
            target.saturation = source.saturation
        }
        if scope.details {
            target.sharpening = source.sharpening
            target.noiseReduction = source.noiseReduction
            target.lensDistortion = source.lensDistortion
            target.vignette = source.vignette
            target.chromaticAberration = source.chromaticAberration
        }
        // ColorAdjustments (hue shifts) - not yet implemented in PhotoAdjustments
    }

    private func triggerReprocess(for photo: PhotoItem) {
        // DetailView observes notification; persistence observers hook into this as well.
        photo.objectWillChange.send()
        objectWillChange.send()
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id]
        )
    }

    private func persistEditsForPhoto(_ photo: PhotoItem) {
        let entry = EditCatalogService.EditEntry(
            adjustments: photo.adjustments,
            localMasks: photo.localMasks,
            lensProfileSettings: photo.lensProfileSettings,
            cropRect: photo.cropRect,
            rotation: photo.rotation,
            isMaster: photo.isMaster,
            masterID: photo.masterID,
            virtualCopyNumber: photo.virtualCopyNumber
        )
        Task {
            // Master: stabil per Dateipfad (kein #UUID), Virtual Copy: per url#uuid
            let keyPhotoID: UUID? = photo.isMaster ? nil : photo.id
            await EditCatalogService.shared.upsertEdit(entry, for: photo.url, photoID: keyPhotoID)
        }
    }
    
    func selectNextPhoto() {
        guard let currentIndex = currentPhotoIndexInFiltered else { return }
        if currentIndex < filteredPhotos.count - 1 {
            selectPhoto(filteredPhotos[currentIndex + 1])
        }
    }
    
    func selectPreviousPhoto() {
        guard let currentIndex = currentPhotoIndexInFiltered else { return }
        if currentIndex > 0 {
            selectPhoto(filteredPhotos[currentIndex - 1])
        }
    }
    
    func selectPhoto(at index: Int) {
        guard index >= 0 && index < filteredPhotos.count else { return }
        selectPhoto(filteredPhotos[index])
    }
    
    // MARK: - Rating & Tags
    
    func setRating(_ rating: Int, for photoID: UUID, autoAdvance: Bool = true) {
        guard let index = photos.firstIndex(where: { $0.id == photoID }) else { return }
        let photo = photos[index]
        photo.rating = rating
        
        // Manually trigger an update for the specific photo and re-filtering
        objectWillChange.send()
        updateFilteredPhotos()
        
        // Photos Library ist read-only: Rating lokal persistieren (sonst ändern wir Dates/Library → Duplikate/„edited zuerst“).
        if isPhotosLibraryContext(photo.url) {
            saveLocalRating(rating, for: photo.url)
        } else {
            Task(priority: .background) {
                try? self.ratingService.writeRating(rating, to: photo.url)
            }
        }
        
        if exportQueueEnabled && rating >= exportQueueMinRating {
            enqueueExport(photo)
        }
        
        // AUTO-ADVANCE: Gehe zum nächsten Bild (KRITISCH für Sportfotografie!)
        if autoAdvance && AppSettings.shared.autoAdvanceAfterRating {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.selectNextPhoto()
            }
        }
    }
    
    // MARK: - Pick/Reject (Lightroom-Style)
    
    func setPickStatus(_ status: PickStatus, for photoID: UUID, autoAdvance: Bool = true) {
        guard let photo = photos.first(where: { $0.id == photoID }) else { return }
        photo.pickStatus = status
        objectWillChange.send()
        updateFilteredPhotos()
        
        // Persist to XMP or sidecar (optional, for now in-memory only)
        // TODO: Save to XMP Rating field (Pick=1, Reject=-1, Unflagged=0)
        
        // AUTO-ADVANCE nach Pick/Reject
        if autoAdvance && AppSettings.shared.autoAdvanceAfterRating {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.selectNextPhoto()
            }
        }
    }
    
    func markAsPick(photoID: UUID) {
        setPickStatus(.pick, for: photoID)
    }
    
    func markAsReject(photoID: UUID) {
        setPickStatus(.reject, for: photoID)
    }
    
    func unflag(photoID: UUID) {
        setPickStatus(.unflagged, for: photoID)
    }
    
    func deleteAllRejects() {
        let rejects = photos.filter { $0.pickStatus == .reject }
        guard !rejects.isEmpty else { return }
        
        // Ask user for confirmation
        let alert = NSAlert()
        alert.messageText = "Alle abgelehnten Bilder löschen?"
        alert.informativeText = "\(rejects.count) Bild(er) werden permanent gelöscht."
        alert.alertStyle = .critical
        alert.addButton(withTitle: "Löschen")
        alert.addButton(withTitle: "Abbrechen")
        
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        
        // Delete from file system
        for photo in rejects {
            try? FileManager.default.trashItem(at: photo.url, resultingItemURL: nil)
        }
        
        // Remove from array
        photos.removeAll { $0.pickStatus == .reject }
        objectWillChange.send()
        updateFilteredPhotos()
    }
    
    // MARK: - Quick Collection (Lightroom-Style)
    
    func toggleQuickCollection(for photoID: UUID) {
        guard let photo = photos.first(where: { $0.id == photoID }) else { return }
        photo.isInQuickCollection.toggle()
        objectWillChange.send()
        updateFilteredPhotos()
        saveQuickCollection()
    }
    
    func clearQuickCollection() {
        for photo in photos {
            photo.isInQuickCollection = false
        }
        objectWillChange.send()
        updateFilteredPhotos()
        saveQuickCollection()
    }
    
    private func saveQuickCollection() {
        let quickCollectionIDs = photos.filter { $0.isInQuickCollection }.map { $0.url.path }
        UserDefaults.standard.set(quickCollectionIDs, forKey: "quickCollectionURLs")
    }
    
    private func loadQuickCollection() {
        guard let savedURLs = UserDefaults.standard.stringArray(forKey: "quickCollectionURLs") else { return }
        let urlSet = Set(savedURLs)
        for photo in photos {
            photo.isInQuickCollection = urlSet.contains(photo.url.path)
        }
    }
    
    // MARK: - Virtual Copies (Lightroom-Style)
    
    func createVirtualCopy(of photoID: UUID) {
        guard let master = photos.first(where: { $0.id == photoID }) else { return }
        
        // Find all existing copies of this master (or master itself if it's a copy)
        let actualMasterID = master.isMaster ? master.id : master.masterID!
        let allCopies = photos.filter {
            ($0.id == actualMasterID) || ($0.masterID == actualMasterID)
        }
        
        // Determine next copy number
        let maxCopyNumber = allCopies.map(\.virtualCopyNumber).max() ?? 0
        let newCopyNumber = maxCopyNumber + 1
        
        // Create virtual copy
        let actualMaster = master.isMaster ? master : photos.first(where: { $0.id == actualMasterID })!
        let virtualCopy = PhotoItem(from: actualMaster, copyNumber: newCopyNumber)
        
        // Mark master if needed
        if actualMaster.virtualCopyNumber == 0, allCopies.count == 1 {
            // First copy created, mark original as "Master"
            actualMaster.virtualCopyNumber = 0
            actualMaster.isMaster = true
        }
        
        // Insert after master/last copy
        if let masterIndex = photos.firstIndex(where: { $0.id == actualMasterID }) {
            let insertIndex = masterIndex + allCopies.count
            photos.insert(virtualCopy, at: min(insertIndex, photos.count))
        } else {
            photos.append(virtualCopy)
        }
        
        // Select new copy
        selectPhoto(virtualCopy)
        
        objectWillChange.send()
        updateFilteredPhotos()
        
        // Persist
        persistEditsForPhoto(virtualCopy)
    }
    
    func deleteVirtualCopy(photoID: UUID) {
        guard let photo = photos.first(where: { $0.id == photoID }), !photo.isMaster else {
            return // Can't delete master
        }
        
        photos.removeAll { $0.id == photoID }
        objectWillChange.send()
        updateFilteredPhotos()
        
        // Remove snapshots for this virtual copy
        editSnapshotsByKey.removeValue(forKey: editKey(for: photo))
        saveEditSnapshots()
        
        // Remove from catalog (Virtual Copy key = url#uuid)
        Task {
            await EditCatalogService.shared.removeEdit(for: photo.url, photoID: photo.id)
        }
    }
    
    func getVirtualCopies(for photoID: UUID) -> [PhotoItem] {
        guard let photo = photos.first(where: { $0.id == photoID }) else { return [] }
        let masterID = photo.isMaster ? photo.id : photo.masterID!
        return photos.filter { ($0.id == masterID) || ($0.masterID == masterID) }.sorted { $0.virtualCopyNumber < $1.virtualCopyNumber }
    }
    
    // ... (rest of the file remains largely the same, but methods like toggleColorTag would also need objectWillChange.send() and updateFilteredPhotos())
    
    func toggleColorTag(_ tag: ColorTag, for photoID: UUID) {
        guard let photo = photos.first(where: { $0.id == photoID }) else { return }
        if photo.colorTags.contains(tag) {
            photo.colorTags.remove(tag)
        } else {
            photo.colorTags.insert(tag)
        }
        objectWillChange.send()
        updateFilteredPhotos()
    }
    
    // MARK: - Export Queue
    
    private var exportQueueIDs: [UUID] = []
    private var exportQueueIDSet: Set<UUID> = []
    private var exportQueueTask: Task<Void, Never>? = nil
    
    /// Fügt ein Foto der Export‑Queue hinzu (falls nicht schon in Queue oder bereits exportiert).
    private func enqueueExport(_ photo: PhotoItem) {
        guard exportQueueEnabled else { return }
        guard photo.rating >= exportQueueMinRating else { return }
        guard !photo.isExported else { return }
        
        if exportQueueIDSet.contains(photo.id) { return }
        exportQueueIDs.append(photo.id)
        exportQueueIDSet.insert(photo.id)
        
        startExportQueueIfNeeded()
    }
    
    func cancelExportQueue() {
        exportQueueTask?.cancel()
        exportQueueTask = nil
        exportQueueIDs.removeAll()
        exportQueueIDSet.removeAll()
        isExportQueueRunning = false
        exportQueueProgress = 0.0
        exportQueueProcessedCount = 0
        exportQueueTotalCount = 0
        exportQueueCurrentName = ""
        objectWillChange.send()
    }
    
    private func startExportQueueIfNeeded() {
        guard exportQueueTask == nil else { return }
        guard exportQueueEnabled else { return }
        let hasItems = !exportQueueIDs.isEmpty
        let initialCount = exportQueueIDs.count
        guard hasItems else { return }
        
        // Preconditions
        guard let preset = exportQueuePreset else {
            showAlert(title: "Export‑Queue", message: "Bitte ein Export‑Preset auswählen.")
            exportQueueIDs.removeAll()
            exportQueueIDSet.removeAll()
            return
        }
        guard let dir = exportQueueOutputDirectory else {
            showAlert(title: "Export‑Queue", message: "Bitte einen Ausgabeordner auswählen.")
            exportQueueIDs.removeAll()
            exportQueueIDSet.removeAll()
            return
        }
        
        isExportQueueRunning = true
        exportQueueTotalCount = initialCount
        exportQueueProcessedCount = 0
        exportQueueProgress = 0.0
        exportQueueCurrentName = ""
        
        let accessGranted = dir.startAccessingSecurityScopedResource()
        
        exportQueueTask = Task { [weak self] in
            defer {
                if accessGranted { dir.stopAccessingSecurityScopedResource() }
            }
            guard let self else { return }
            
            while !Task.isCancelled {
                // Nächstes Element aus Queue holen (async-safe via MainActor)
                let (nextID, remainingCount): (UUID?, Int) = await MainActor.run {
                    let nextID: UUID? = self.exportQueueIDs.isEmpty ? nil : self.exportQueueIDs.removeFirst()
                    if let nextID {
                        self.exportQueueIDSet.remove(nextID)
                    }
                    return (nextID, self.exportQueueIDs.count)
                }
                
                guard let nextID else { break }
                
                guard let photo = await MainActor.run(body: { self.photos.first(where: { $0.id == nextID }) }) else {
                    continue
                }
                
                // Skip, falls Rating wieder runtergesetzt wurde oder schon exportiert
                if !self.exportQueueEnabled || photo.rating < self.exportQueueMinRating || photo.isExported {
                    continue
                }
                
                let processedAtStart = await MainActor.run { self.exportQueueProcessedCount }
                let totalNow = max(1, processedAtStart + remainingCount + 1)
                
                await MainActor.run {
                    self.exportQueueCurrentName = photo.fileName
                    self.exportQueueTotalCount = totalNow
                    self.exportQueueProgress = Double(processedAtStart) / Double(totalNow)
                }
                
                do {
                    let outputURL = self.uniqueOutputURL(for: photo, preset: preset, in: dir)
                    try await ExportService.shared.export(
                        photo: photo,
                        preset: preset,
                        to: outputURL,
                        uploadTargets: self.uploadTargets
                    ) { progress in
                        DispatchQueue.main.async {
                            let processed = self.exportQueueProcessedCount
                            let total = max(1, self.exportQueueTotalCount)
                            let base = Double(processed) / Double(total)
                            let frac = min(1.0, base + (progress / Double(total)))
                            self.exportQueueProgress = frac
                        }
                    }
                    
                    await MainActor.run {
                        photo.isExported = true
                    }
                } catch {
                    // Fail-safe: nicht die ganze Queue abbrechen, nur loggen
                    print("Export‑Queue Fehler für \(photo.fileName): \(error)")
                }
                
                await MainActor.run {
                    self.exportQueueProcessedCount += 1
                    // Total dynamisch: bereits verarbeitet + noch in Queue
                    let remaining = self.exportQueueIDs.count
                    let total = max(1, self.exportQueueProcessedCount + remaining)
                    self.exportQueueTotalCount = total
                    self.exportQueueProgress = Double(self.exportQueueProcessedCount) / Double(total)
                }
            }
            
            await MainActor.run {
                self.exportQueueCurrentName = ""
                self.isExportQueueRunning = false
                self.exportQueueTask = nil
                
                // Reset progress if queue finished (keeps UI clean)
                if !self.exportQueueEnabled {
                    self.exportQueueProgress = 0.0
                    self.exportQueueProcessedCount = 0
                    self.exportQueueTotalCount = 0
                }
            }
        }
    }
    
    private func uniqueOutputURL(for photo: PhotoItem, preset: ExportPreset, in directory: URL) -> URL {
        let fileName = buildFileName(for: photo, preset: preset)
        var candidate = directory.appendingPathComponent(fileName)
        
        let fm = FileManager.default
        if !fm.fileExists(atPath: candidate.path) { return candidate }
        
        let base = (fileName as NSString).deletingPathExtension
        let ext = (fileName as NSString).pathExtension
        var i = 2
        while fm.fileExists(atPath: candidate.path) {
            candidate = directory.appendingPathComponent("\(base)-\(i).\(ext)")
            i += 1
        }
        return candidate
    }
    
    func checkAndExportQueue() {
        // Fallback/Manuell: scanne alle passenden Fotos und enqueu sie.
        let candidates = photos.filter { $0.rating >= exportQueueMinRating }
        for photo in candidates {
            enqueueExport(photo)
        }
    }
    
    // MARK: - Preset Management (Export, Adjustment, etc.)
    
    func loadExportPresets() {
        if let data = UserDefaults.standard.data(forKey: "exportPresets"),
           let decoded = try? JSONDecoder().decode([ExportPreset].self, from: data) {
            exportPresets = decoded
            migrateBuiltinWatermarkDefaultsIfNeeded()
        } else {
            exportPresets = ExportPreset.defaultPresets
            saveExportPresets()
        }
    }
    
    /// Migration: alte Default-Watermark-Grösse (10%) auf neuen Default (6%) umstellen,
    /// aber nur wenn das Preset ansonsten noch exakt dem alten Default entspricht.
    private func migrateBuiltinWatermarkDefaultsIfNeeded() {
        var changed = false
        
        for i in exportPresets.indices {
            guard var wm = exportPresets[i].watermarkSettings else { continue }
            guard isLegacyDefaultWatermark(wm) else { continue }
            wm.size = WatermarkSettings.default.size // 0.06
            exportPresets[i].watermarkSettings = wm
            changed = true
        }
        
        if changed {
            saveExportPresets()
        }
    }
    
    private func isLegacyDefaultWatermark(_ wm: WatermarkSettings) -> Bool {
        // Old default values (before we switched to 6%):
        // - bottom-right, size 0.10, text "© Blaurock Sportpix", textSize 0.03, opacity 0.8
        // Hinweis: Einige Nutzer haben später den Typ (Text/Logo/Both) geändert,
        // aber die Grösse blieb auf 10%. Wir migrieren daher unabhängig vom Typ/Logo,
        // solange die übrigen Default-Werte noch passen.
        let eps = 0.000_1
        let d = WatermarkSettings.default
        
        let wmText = wm.text ?? d.text ?? ""
        let dText = d.text ?? ""
        let wmTextSize = wm.textSize ?? d.textSize ?? 0.0
        let dTextSize = d.textSize ?? 0.0
        
        return wm.position == d.position &&
        abs(wm.size - 0.10) < eps &&
        wmText == dText &&
        abs(wmTextSize - dTextSize) < eps &&
        abs(wm.opacity - d.opacity) < eps
    }
    
    func saveExportPresets() {
        if let encoded = try? JSONEncoder().encode(exportPresets) {
            UserDefaults.standard.set(encoded, forKey: "exportPresets")
        }
    }
    
    // ... etc. for all preset types
    func addExportPreset(_ preset: ExportPreset) {
        exportPresets.append(preset)
        saveExportPresets()
    }
    
    func updateExportPreset(_ preset: ExportPreset) {
        if let index = exportPresets.firstIndex(where: { $0.id == preset.id }) {
            exportPresets[index] = preset
            saveExportPresets()
        }
    }
    
    func deleteExportPreset(_ preset: ExportPreset) {
        exportPresets.removeAll { $0.id == preset.id }
        saveExportPresets()
    }
    func loadAdjustmentPresets() {
        if let data = UserDefaults.standard.data(forKey: "adjustmentPresets"),
           let decoded = try? JSONDecoder().decode([AdjustmentPreset].self, from: data) {
            adjustmentPresets = decoded
            migrateBuiltinAdjustmentPresetsIfNeeded()
        } else {
            // Lade Standard-Presets wenn keine vorhanden
            loadDefaultPresets()
            migrateBuiltinAdjustmentPresetsIfNeeded()
        }
    }

    // MARK: - Built-in Presets (Migration)
    
    private enum BuiltinAdjustmentPresetIDs {
        // Stabiler ID, damit Updates keine Duplikate erzeugen
        static let hallStrongLit: UUID = UUID(uuidString: "5D8C6A8D-6F89-4B0D-AE8D-1A9C8D2A6E3F")!
        static let bwNoirPortrait: UUID = UUID(uuidString: "A9F8D1B0-8B9F-4B7D-9C2E-3AE1C5C9E8D7")!
        static let bwFilmPunch: UUID = UUID(uuidString: "2B34C89A-6E2A-4F2C-9A5B-0A7D2E4B6C11")!
    }
    
    /// Fügt neue, eingebaute Presets zu bestehenden Libraries hinzu (ohne Duplikate).
    private func migrateBuiltinAdjustmentPresetsIfNeeded() {
        var changed = false
        
        let hallAdjustments = PhotoAdjustments(
            exposure: 0.20,       // etwas heller (Indoor/Halle war noch zu dunkel)
            contrast: 1.14,       // knackig, aber nicht "crunchy"
            temperature: -120,    // etwas kühler (Arena/LED)
            tint: 8,              // leichte Magenta-Korrektur gegen Grünstich
            clarity: 0.20,        // crisp
            vibrance: 0.16,       // CIVibrance inputAmount (≈ 16 in LR)
            highlights: -22,      // Highlights schützen (Trikots/LED-Spots)
            shadows: 22,          // Gesichter/Details öffnen (heller)
            whites: -6,           // (Mapping ist grob) daher moderat
            blacks: -5,           // etwas Tiefe, aber nicht zu dunkel
            saturation: 4,        // subtil
            dehaze: 3,            // minimaler Punch
            texture: 12           // Details (Sport)
        )
        
        // B&W – Noir Portrait (dramatischer Schwarz‑Weiß Look, ähnlich "Noir / Regen / hartes Licht")
        // Wichtig: dehaze bleibt 0, weil Dehaze im Pipeline‑Order nach Saturation kommt und sonst wieder Farbe reinbringen könnte.
        let noirAdjustments = PhotoAdjustments(
            exposure: -0.20,
            contrast: 1.40,
            clarity: 0.65,
            highlights: 0,
            shadows: 0,
            whites: 5,
            blacks: 25,
            saturation: -100,
            texture: 28,
            sharpening: 25,
            vignette: 40
        )
        
        // B&W – Film Punch (Import aus XMP: Contrast +40, Highlights -35, Shadows -45, Whites +20, Blacks -55,
        // Texture +35, Clarity +25, Dehaze +12, Sharpening +55, Luminance NR +10, Vignette -18)
        // Hinweis: Tonkurve/Grain/Vignette-Midpoint/Feather werden (noch) nicht abgebildet.
        // Vignette: Lightroom neg. = Abdunkeln; unsere Vignette ist pos. = Abdunkeln → Vorzeichen invertiert.
        let bwFilmPunchAdjustments = PhotoAdjustments(
            exposure: 0.0,
            contrast: 1.40,     // 40 → 1.40
            clarity: 0.25,      // 25 → 0.25
            highlights: -35,
            shadows: -45,
            whites: 20,
            blacks: -55,
            saturation: -100,   // Treatment: BlackAndWhite
            dehaze: 12,
            texture: 35,
            sharpening: 55,
            noiseReduction: 10,
            vignette: 18
        )
        
        // Falls schon vorhanden (stabile ID), bei Bedarf auf neue Defaults migrieren (ohne Duplikate).
        if let idx = adjustmentPresets.firstIndex(where: { $0.id == BuiltinAdjustmentPresetIDs.hallStrongLit }) {
            var updated = adjustmentPresets[idx]
            updated.name = "Halle – stark beleuchtet"
            updated.group = "Sport"
            updated.adjustments = hallAdjustments
            adjustmentPresets[idx] = updated
            changed = true
        }
        
        if !adjustmentPresets.contains(where: { $0.id == BuiltinAdjustmentPresetIDs.hallStrongLit || $0.name == "Halle – stark beleuchtet" }) {
            let preset = AdjustmentPreset(
                id: BuiltinAdjustmentPresetIDs.hallStrongLit,
                name: "Halle – stark beleuchtet",
                group: "Sport",
                adjustments: hallAdjustments
            )
            adjustmentPresets.append(preset)
            changed = true
        }
        
        if let idx = adjustmentPresets.firstIndex(where: { $0.id == BuiltinAdjustmentPresetIDs.bwNoirPortrait }) {
            var updated = adjustmentPresets[idx]
            updated.name = "Noir Portrait"
            updated.group = "B&W"
            updated.adjustments = noirAdjustments
            adjustmentPresets[idx] = updated
            changed = true
        }
        
        if !adjustmentPresets.contains(where: { $0.id == BuiltinAdjustmentPresetIDs.bwNoirPortrait || $0.name == "Noir Portrait" }) {
            let preset = AdjustmentPreset(
                id: BuiltinAdjustmentPresetIDs.bwNoirPortrait,
                name: "Noir Portrait",
                group: "B&W",
                adjustments: noirAdjustments
            )
            adjustmentPresets.append(preset)
            changed = true
        }
        
        if let idx = adjustmentPresets.firstIndex(where: { $0.id == BuiltinAdjustmentPresetIDs.bwFilmPunch }) {
            var updated = adjustmentPresets[idx]
            updated.name = "Film Punch"
            updated.group = "B&W"
            updated.adjustments = bwFilmPunchAdjustments
            adjustmentPresets[idx] = updated
            changed = true
        }
        
        if !adjustmentPresets.contains(where: { $0.id == BuiltinAdjustmentPresetIDs.bwFilmPunch || $0.name == "Film Punch" }) {
            let preset = AdjustmentPreset(
                id: BuiltinAdjustmentPresetIDs.bwFilmPunch,
                name: "Film Punch",
                group: "B&W",
                adjustments: bwFilmPunchAdjustments
            )
            adjustmentPresets.append(preset)
            changed = true
        }
        
        if changed {
            saveAdjustmentPresets()
        }
    }
    
    func saveAdjustmentPresets() {
        if let encoded = try? JSONEncoder().encode(adjustmentPresets) {
            UserDefaults.standard.set(encoded, forKey: "adjustmentPresets")
        }
    }
    
    func addAdjustmentPreset(_ preset: AdjustmentPreset) {
        adjustmentPresets.append(preset)
        if let group = preset.group?.trimmingCharacters(in: .whitespacesAndNewlines),
           !group.isEmpty,
           !presetGroups.contains(group) {
            presetGroups.append(group)
            savePresetGroups()
        }
        saveAdjustmentPresets()
    }
    
    func updateAdjustmentPreset(_ preset: AdjustmentPreset) {
        if let index = adjustmentPresets.firstIndex(where: { $0.id == preset.id }) {
            adjustmentPresets[index] = preset
            if let group = preset.group?.trimmingCharacters(in: .whitespacesAndNewlines),
               !group.isEmpty,
               !presetGroups.contains(group) {
                presetGroups.append(group)
                savePresetGroups()
            }
            saveAdjustmentPresets()
        }
    }
    
    func deleteAdjustmentPreset(_ preset: AdjustmentPreset) {
        adjustmentPresets.removeAll { $0.id == preset.id }
        saveAdjustmentPresets()
    }
    
    // MARK: - Preset Group Management
    
    func loadPresetGroups() {
        if let groups = UserDefaults.standard.stringArray(forKey: "presetGroups") {
            presetGroups = groups
            return
        }
        
        // Default: aus vorhandenen Presets ableiten
        let groupsFromPresets = Set(adjustmentPresets.compactMap { $0.group?.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty })
        presetGroups = groupsFromPresets.sorted()
        savePresetGroups()
    }
    
    func savePresetGroups() {
        UserDefaults.standard.set(presetGroups, forKey: "presetGroups")
    }
    
    func addPresetGroup(_ name: String) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        guard !presetGroups.contains(trimmed) else { return }
        presetGroups.append(trimmed)
        savePresetGroups()
    }
    
    private func loadDefaultPresets() {
        adjustmentPresets = [
            AdjustmentPreset(
                name: "Vivid",
                group: "Farbe",
                adjustments: PhotoAdjustments(
                    exposure: 0.1,
                    contrast: 1.15,
                    clarity: 0.2,
                    vibrance: 0.30,
                    saturation: 25
                )
            ),
            AdjustmentPreset(
                name: "Portrait",
                group: "Portrait",
                adjustments: PhotoAdjustments(
                    exposure: 0.2,
                    contrast: 1.05,
                    temperature: 200,
                    clarity: 0.15,
                    texture: 10
                )
            ),
            AdjustmentPreset(
                name: "Landschaft",
                group: "Stil",
                adjustments: PhotoAdjustments(
                    exposure: 0.1,
                    contrast: 1.2,
                    clarity: 0.3,
                    saturation: 20,
                    dehaze: 15
                )
            ),
            AdjustmentPreset(
                name: "Schwarz-Weiß",
                group: "Stil",
                adjustments: PhotoAdjustments(
                    exposure: 0.1,
                    contrast: 1.3,
                    clarity: 0.25,
                    saturation: -100
                )
            ),
            AdjustmentPreset(
                name: "Warm",
                group: "Farbe",
                adjustments: PhotoAdjustments(
                    temperature: 500,
                    tint: 10,
                    vibrance: 0.20
                )
            ),
            AdjustmentPreset(
                name: "Cool",
                group: "Farbe",
                adjustments: PhotoAdjustments(
                    temperature: -500,
                    tint: -10,
                    vibrance: 0.15
                )
            )
        ]
        saveAdjustmentPresets()
    }
    func loadUploadTargets() {
        if let data = UserDefaults.standard.data(forKey: "uploadTargets"),
           let decoded = try? JSONDecoder().decode([UploadTarget].self, from: data) {
            uploadTargets = decoded
        } else {
            uploadTargets = []
        }
    }
    
    func saveUploadTargets() {
        if let encoded = try? JSONEncoder().encode(uploadTargets) {
            UserDefaults.standard.set(encoded, forKey: "uploadTargets")
        }
    }
    
    func addUploadTarget(_ target: UploadTarget) {
        uploadTargets.append(target)
        saveUploadTargets()
    }
    
    func updateUploadTarget(_ target: UploadTarget) {
        if let index = uploadTargets.firstIndex(where: { $0.id == target.id }) {
            uploadTargets[index] = target
            saveUploadTargets()
        }
    }
    
    func deleteUploadTarget(_ target: UploadTarget) {
        uploadTargets.removeAll { $0.id == target.id }
        saveUploadTargets()
    }
    
    func loadIPTCTemplates() {
        if let data = UserDefaults.standard.data(forKey: "iptcTemplates"),
           let decoded = try? JSONDecoder().decode([IPTCTemplate].self, from: data) {
            iptcTemplates = decoded
        } else {
            iptcTemplates = IPTCTemplate.defaultTemplates
            saveIPTCTemplates()
        }
    }
    
    func saveIPTCTemplates() {
        if let encoded = try? JSONEncoder().encode(iptcTemplates) {
            UserDefaults.standard.set(encoded, forKey: "iptcTemplates")
        }
    }
    
    func addIPTCTemplate(_ template: IPTCTemplate) {
        iptcTemplates.append(template)
        saveIPTCTemplates()
    }
    
    func updateIPTCTemplate(_ template: IPTCTemplate) {
        if let index = iptcTemplates.firstIndex(where: { $0.id == template.id }) {
            iptcTemplates[index] = template
            saveIPTCTemplates()
        }
    }
    
    func deleteIPTCTemplate(_ template: IPTCTemplate) {
        iptcTemplates.removeAll { $0.id == template.id }
        saveIPTCTemplates()
    }
    
    // MARK: - Smart Collections
    
    func loadSmartCollections() {
        if let data = UserDefaults.standard.data(forKey: "smartCollections"),
           let decoded = try? JSONDecoder().decode([SmartCollection].self, from: data) {
            smartCollections = decoded
        } else {
            // Standard Smart Collections
            smartCollections = [
                SmartCollection(name: "Picks", criteria: SmartCollectionCriteria(pickStatus: .pick)),
                SmartCollection(name: "5 Sterne", criteria: SmartCollectionCriteria(minRating: 5, maxRating: 5)),
                SmartCollection(name: "Mit Adjustments", criteria: SmartCollectionCriteria(hasAdjustments: true)),
                SmartCollection(name: "Quick Collection", criteria: SmartCollectionCriteria(isInQuickCollection: true))
            ]
            saveSmartCollections()
        }
    }
    
    func saveSmartCollections() {
        if let encoded = try? JSONEncoder().encode(smartCollections) {
            UserDefaults.standard.set(encoded, forKey: "smartCollections")
        }
    }
    
    func addSmartCollection(_ collection: SmartCollection) {
        smartCollections.append(collection)
        saveSmartCollections()
    }
    
    func updateSmartCollection(_ collection: SmartCollection) {
        if let index = smartCollections.firstIndex(where: { $0.id == collection.id }) {
            smartCollections[index] = collection
            saveSmartCollections()
        }
    }
    
    func deleteSmartCollection(_ collection: SmartCollection) {
        smartCollections.removeAll { $0.id == collection.id }
        saveSmartCollections()
    }
    
    /// Filtert Photos basierend auf Smart Collection Kriterien
    func filterPhotos(by collection: SmartCollection) -> [PhotoItem] {
        return photos.filter { collection.matches($0) }
    }
    
    // MARK: - AI Tagging
    
    /// Generiert AI-Keywords für das aktuelle Foto
    func generateAITagsForCurrent() async {
        guard let photo = currentPhoto else { return }
        await generateAITags(for: photo)
    }
    
    /// Startet AI‑Keywords für das aktuelle Foto mit UI‑Progress State (Toolbar).
    func startAITagsForCurrent() {
        // Restart-Behaviour: falls schon laufend, abbrechen und neu starten.
        if isAITaggingRunning {
            cancelAITagging()
        }
        guard let photo = currentPhoto else { return }
        
        aiTaggingTask?.cancel()
        isAITaggingRunning = true
        aiTaggingProcessedCount = 0
        aiTaggingTotalCount = 1
        aiTaggingProgress = 0.0
        aiTaggingCurrentName = photo.fileName
        
        aiTaggingTask = Task {
            await generateAITags(for: photo)
            if Task.isCancelled { return }
            await MainActor.run {
                self.aiTaggingProcessedCount = 1
                self.aiTaggingProgress = 1.0
                self.isAITaggingRunning = false
                self.aiTaggingCurrentName = ""
            }
        }
    }
    
    /// Generiert AI-Keywords für ein bestimmtes Foto
    func generateAITags(for photo: PhotoItem) async {
        if Task.isCancelled { return }
        let keywords = await AITaggingService.shared.generateKeywords(for: photo)
        if Task.isCancelled { return }
        
        await MainActor.run {
            // Füge Keywords zu IPTC Metadata hinzu
            if photo.iptcMetadata == nil {
                photo.iptcMetadata = IPTCMetadata()
            }
            
            // Kombiniere neue Keywords mit existierenden (keine Duplikate)
            var existingKeywords = Set(photo.iptcMetadata?.keywords ?? [])
            for keyword in keywords {
                existingKeywords.insert(keyword)
            }
            
            photo.iptcMetadata?.keywords = Array(existingKeywords).sorted()
            
            // Persistiere IPTC Metadata
            if let iptc = photo.iptcMetadata, !isPhotosLibraryContext(photo.url) {
                Task {
                    try? IPTCMetadataService.shared.writeMetadata(iptc, to: photo.url)
                }
            }
            
            objectWillChange.send()
        }
    }
    
    /// Batch AI-Tagging für ausgewählte Fotos
    func generateAITagsForSelection(progress: @escaping (Int, Int) -> Void) async {
        let selectedPhotos = photos.filter { selectedPhotoIDs.contains($0.id) }
        guard !selectedPhotos.isEmpty else { return }
        if Task.isCancelled { return }
        
        let results = await AITaggingService.shared.generateKeywordsBatch(for: selectedPhotos, progress: progress)
        if Task.isCancelled { return }
        
        await MainActor.run {
            for photo in selectedPhotos {
                if let keywords = results[photo.id], !keywords.isEmpty {
                    if photo.iptcMetadata == nil {
                        photo.iptcMetadata = IPTCMetadata()
                    }
                    
                    var existingKeywords = Set(photo.iptcMetadata?.keywords ?? [])
                    for keyword in keywords {
                        existingKeywords.insert(keyword)
                    }
                    
                    photo.iptcMetadata?.keywords = Array(existingKeywords).sorted()
                    
                    // Persistiere IPTC Metadata
                    if let iptc = photo.iptcMetadata, !isPhotosLibraryContext(photo.url) {
                        Task {
                            try? IPTCMetadataService.shared.writeMetadata(iptc, to: photo.url)
                        }
                    }
                }
            }
            
            objectWillChange.send()
        }
    }
    
    /// Startet Batch AI‑Keywords für die aktuelle Auswahl mit UI‑Progress State (Toolbar).
    func startAITagsForSelection() {
        // Restart-Behaviour: falls schon laufend, abbrechen und neu starten.
        if isAITaggingRunning {
            cancelAITagging()
        }
        let selectedCount = selectedPhotoIDs.count
        guard selectedCount > 0 else { return }
        
        aiTaggingTask?.cancel()
        isAITaggingRunning = true
        aiTaggingProcessedCount = 0
        aiTaggingTotalCount = selectedCount
        aiTaggingProgress = 0.0
        aiTaggingCurrentName = ""
        
        aiTaggingTask = Task {
            await generateAITagsForSelection { done, total in
                DispatchQueue.main.async {
                    self.aiTaggingProcessedCount = done
                    self.aiTaggingTotalCount = total
                    self.aiTaggingProgress = total > 0 ? Double(done) / Double(total) : 1.0
                }
            }
            await MainActor.run {
                self.isAITaggingRunning = false
                self.aiTaggingCurrentName = ""
            }
        }
    }
}

