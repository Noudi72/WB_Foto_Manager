//
//  UIState.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import Combine
import SwiftUI

class UIState: ObservableObject {
    @Published var viewMode: ViewMode = .detail
    @Published var zoomLevel: Double = 1.0
    @Published var showBeforeAfter: Bool = false
    
    // Watermark Vorschau (nur Anzeige, nicht Export)
    @Published var watermarkPreviewEnabled: Bool = false
    @Published var watermarkPreviewPresetID: UUID? = nil
    
    // Sheets / Modals (zentral, damit Menüs + Topbar zuverlässig funktionieren)
    @Published var activeSheet: SheetRoute? = nil
    
    // Filters
    @Published var ratingFilter: Int? = nil {
        didSet {
            // This is a good place to notify the PhotoStore to re-filter
        }
    }
    
    // Sidebar visibility
    @Published var showLeftSidebar: Bool = true
    @Published var showRightSidebar: Bool = true
}

// MARK: - Modal Routing

extension UIState {
    enum SheetRoute: Identifiable {
        case settings
        case export
        case batchExport
        case uploadSettings
        case exportQueueSettings
        case backupRestore
        
        var id: String {
            switch self {
            case .settings: return "settings"
            case .export: return "export"
            case .batchExport: return "batchExport"
            case .uploadSettings: return "uploadSettings"
            case .exportQueueSettings: return "exportQueueSettings"
            case .backupRestore: return "backupRestore"
            }
        }
    }
}

// We can move the ViewMode enum here as it's purely UI-related.
enum ViewMode {
    case detail
    case grid
}
