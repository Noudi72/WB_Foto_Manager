//
//  ContentView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI

// Diese Datei wird nicht mehr verwendet - RootView ist die Hauptansicht
// Behalten für Kompatibilität
struct ContentView: View {
    var body: some View {
        RootView()
    }
}

#Preview {
    ContentView()
}
