//
//  UploadTarget.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation

/// Upload-Ziel für Exporte
struct UploadTarget: Identifiable, Codable, Hashable {
    let id: UUID
    var name: String
    var type: UploadType
    var isEnabled: Bool
    
    // FTP/SFTP Settings
    var ftpHost: String?
    var ftpPort: Int?
    var ftpUsername: String?
    var ftpPassword: String? // Sollte verschlüsselt gespeichert werden
    var ftpPath: String?
    var ftpUseSSL: Bool
    var ftpPrivateKey: String? // Für SFTP
    
    // S3 Settings
    var s3Bucket: String?
    var s3Region: String?
    var s3AccessKey: String?
    var s3SecretKey: String? // Sollte verschlüsselt gespeichert werden
    var s3Path: String?
    
    // HTTP/API Settings
    var httpURL: String?
    var httpMethod: String? // POST, PUT
    var httpHeaders: [String: String]?
    var httpAuthToken: String? // Sollte verschlüsselt gespeichert werden
    
    // Pictrs Settings
    var pictrsURL: String?
    var pictrsAuthToken: String?
    var pictrsDeleteToken: String?
    
    init(id: UUID = UUID(), name: String, type: UploadType, isEnabled: Bool = true) {
        self.id = id
        self.name = name
        self.type = type
        self.isEnabled = isEnabled
        self.ftpUseSSL = false
    }
}

enum UploadType: String, Codable, Hashable {
    case ftp = "FTP"
    case sftp = "SFTP"
    case s3 = "S3"
    case http = "HTTP/API"
    case pictrs = "Pictrs"
    case local = "Lokal"
}

