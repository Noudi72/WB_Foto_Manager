//
//  IPTCPanel.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit

struct IPTCPanel: View {
    @ObservedObject var store: PhotoStore
    @State private var selectedTemplate: IPTCTemplate?
    @State private var tokenValues: [String: String] = [:]
    @State private var showDraftEditor = false
    @State private var showBatchEditor = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("IPTC-Metadaten")
                .font(DesignSystem.Fonts.semibold(size: 14))
                .foregroundColor(DesignSystem.Colors.text)
            
            // Template Selection
            VStack(alignment: .leading, spacing: 6) {
                Text("Template".uppercased())
                    .font(DesignSystem.Fonts.semibold(size: 10))
                    .foregroundColor(DesignSystem.Colors.text2)
                    .tracking(0.6)
                
                Menu {
                    Button("Kein Template") { selectedTemplate = nil }
                    if !store.iptcTemplates.isEmpty {
                        Divider()
                        ForEach(store.iptcTemplates) { template in
                            Button(template.name) { selectedTemplate = template }
                        }
                    }
                } label: {
                    HStack(spacing: 8) {
                        Text(selectedTemplate?.name ?? "Kein Template")
                            .font(DesignSystem.Fonts.medium(size: 12))
                            .foregroundColor(DesignSystem.Colors.text)
                            .lineLimit(1)
                        
                        Spacer(minLength: 6)
                        
                        Image(systemName: "chevron.down")
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundColor(DesignSystem.Colors.text2)
                    }
                    .padding(.vertical, 7)
                    .padding(.horizontal, 10)
                    .background(DesignSystem.Colors.background4)
                    .overlay(
                        RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                            .stroke(DesignSystem.Colors.border, lineWidth: 1)
                    )
                    .cornerRadius(DesignSystem.CornerRadius.small)
                }
                .buttonStyle(.plain)
            }
            
            if let template = selectedTemplate {
                HStack {
                    Button("Draft Editor öffnen") {
                        showDraftEditor = true
                    }
                    .buttonStyle(LightroomSecondaryButtonStyle())
                    
                    Button("Stapelverarbeitung") {
                        showBatchEditor = true
                    }
                    .buttonStyle(LightroomSecondaryButtonStyle())
                }
            }
            
            // Metadaten anzeigen
            if let photo = store.currentPhoto, let metadata = photo.iptcMetadata {
                IPTCMetadataSummaryView(metadata: metadata)
                    .padding(.top, 4)
            } else if store.currentPhoto != nil {
                Text("Keine IPTC-Daten vorhanden")
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text)
                    .padding(.horizontal, DesignSystem.Spacing.medium)
            }
        }
        .padding(DesignSystem.Spacing.medium)
        .sheet(isPresented: $showDraftEditor) {
            if let template = selectedTemplate {
                IPTCDraftEditorView(template: template, store: store)
            }
        }
        .sheet(isPresented: $showBatchEditor) {
            BatchIPTCEditorView(store: store)
        }
    }
}

struct IPTCMetadataSummaryView: View {
    let metadata: IPTCMetadata
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 10) {
                if let caption = metadata.caption, !caption.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    IPTCRow(label: "Caption", value: caption, multiline: true)
                }
                
                if !metadata.keywords.isEmpty {
                    IPTCRow(label: "Keywords", value: metadata.keywords.joined(separator: ", "), multiline: true)
                }
                
                if let photographer = metadata.photographer, !photographer.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    IPTCRow(label: "Fotograf", value: photographer)
                }
                
                if let copyright = metadata.copyright, !copyright.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    IPTCRow(label: "Copyright", value: copyright)
                }
                
                if let location = metadata.location, !location.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    IPTCRow(label: "Location", value: location)
                }
                
                if let city = metadata.city, !city.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    IPTCRow(label: "City", value: city)
                }
                
                if let country = metadata.country, !country.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    IPTCRow(label: "Country", value: country)
                }
                
                if let event = metadata.event, !event.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    IPTCRow(label: "Event", value: event)
                }
                
                if let venue = metadata.venue, !venue.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                    IPTCRow(label: "Venue", value: venue)
                }
                
                if let date = metadata.date {
                    IPTCRow(label: "Date", value: date.formatted(date: .numeric, time: .omitted))
                }
                
                if !metadata.customFields.isEmpty {
                    Divider().opacity(0.5)
                        .padding(.vertical, 4)
                    
                    Text("Custom Fields")
                        .font(DesignSystem.Fonts.semibold(size: 11))
                        .foregroundColor(DesignSystem.Colors.text)
                        .padding(.top, 4)
                    
                    ForEach(metadata.customFields.keys.sorted(), id: \.self) { key in
                        if let value = metadata.customFields[key], !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                            IPTCRow(label: key, value: value, multiline: true)
                        }
                    }
                }
            }
            .padding(DesignSystem.Spacing.medium)
        }
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
        .overlay(
            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
    }
}

struct IPTCRow: View {
    let label: String
    let value: String?
    var multiline: Bool = false
    
    var body: some View {
        if let value, !value.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            VStack(alignment: .leading, spacing: 4) {
                Text(label.uppercased())
                    .font(DesignSystem.Fonts.semibold(size: 10))
                    .foregroundColor(DesignSystem.Colors.text2)
                    .tracking(0.6)
                
                Text(value)
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text)
                    .lineLimit(multiline ? nil : 1)
                    .fixedSize(horizontal: false, vertical: multiline)
                    .textSelection(.enabled)
            }
        }
    }
}

extension IPTCTemplate {
    static var none: IPTCTemplate? { nil }
}

struct IPTCDraftEditorView: View {
    let template: IPTCTemplate
    @ObservedObject var store: PhotoStore
    @State private var tokenValues: [String: String] = [:]
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        ZStack {
            DesignSystem.Colors.background3
                .ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 12) {
                Text("IPTC Draft Editor")
                    .font(DesignSystem.Fonts.semibold(size: 14))
                    .foregroundColor(DesignSystem.Colors.text)
                    .tracking(0.3)
                
                // Token Input Fields
                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        // Allgemeine Tokens
                        Text("Allgemein".uppercased())
                            .font(DesignSystem.Fonts.semibold(size: 11))
                            .foregroundColor(DesignSystem.Colors.text2)
                            .tracking(0.6)
                            .padding(.top, 2)
                        
                    TokenField(label: "EVENT", value: Binding(
                        get: { tokenValues["{EVENT}"] ?? "" },
                        set: { tokenValues["{EVENT}"] = $0.isEmpty ? nil : $0 }
                    ))
                    TokenField(label: "LOCATION", value: Binding(
                        get: { tokenValues["{LOCATION}"] ?? "" },
                        set: { tokenValues["{LOCATION}"] = $0.isEmpty ? nil : $0 }
                    ))
                    TokenField(label: "VENUE", value: Binding(
                        get: { tokenValues["{VENUE}"] ?? "" },
                        set: { tokenValues["{VENUE}"] = $0.isEmpty ? nil : $0 }
                    ))
                    TokenField(label: "CITY", value: Binding(
                        get: { tokenValues["{CITY}"] ?? "" },
                        set: { tokenValues["{CITY}"] = $0.isEmpty ? nil : $0 }
                    ))
                    TokenField(label: "DESCRIPTION", value: Binding(
                        get: { tokenValues["{DESCRIPTION}"] ?? "" },
                        set: { tokenValues["{DESCRIPTION}"] = $0.isEmpty ? nil : $0 }
                    ))
                    TokenField(label: "PHOTOGRAPHER", value: Binding(
                        get: { tokenValues["{PHOTOGRAPHER}"] ?? "" },
                        set: { tokenValues["{PHOTOGRAPHER}"] = $0.isEmpty ? nil : $0 }
                    ))
                    
                    // Sport-spezifische Tokens
                    Text("Sport".uppercased())
                        .font(DesignSystem.Fonts.semibold(size: 11))
                        .foregroundColor(DesignSystem.Colors.text2)
                        .tracking(0.6)
                        .padding(.top, 10)
                    
                    TokenField(label: "TEAM_A", value: Binding(
                        get: { tokenValues["{TEAM_A}"] ?? "" },
                        set: { tokenValues["{TEAM_A}"] = $0.isEmpty ? nil : $0 }
                    ))
                    TokenField(label: "TEAM_B", value: Binding(
                        get: { tokenValues["{TEAM_B}"] ?? "" },
                        set: { tokenValues["{TEAM_B}"] = $0.isEmpty ? nil : $0 }
                    ))
                    TokenField(label: "LEAGUE", value: Binding(
                        get: { tokenValues["{LEAGUE}"] ?? "" },
                        set: { tokenValues["{LEAGUE}"] = $0.isEmpty ? nil : $0 }
                    ))
                    TokenField(label: "ARENA", value: Binding(
                        get: { tokenValues["{ARENA}"] ?? "" },
                        set: { tokenValues["{ARENA}"] = $0.isEmpty ? nil : $0 }
                    ))
                    TokenField(label: "PLAYER_NAME", value: Binding(
                        get: { tokenValues["{PLAYER_NAME}"] ?? "" },
                        set: { tokenValues["{PLAYER_NAME}"] = $0.isEmpty ? nil : $0 }
                    ))
                    TokenField(label: "PLAYER_NUMBER", value: Binding(
                        get: { tokenValues["{PLAYER_NUMBER}"] ?? "" },
                        set: { tokenValues["{PLAYER_NUMBER}"] = $0.isEmpty ? nil : $0 }
                    ))
                    TokenField(label: "SITUATION", value: Binding(
                        get: { tokenValues["{SITUATION}"] ?? "" },
                        set: { tokenValues["{SITUATION}"] = $0.isEmpty ? nil : $0 }
                    ))
                    }
                    .padding(DesignSystem.Spacing.large)
                }
                .background(DesignSystem.Colors.background4)
                .cornerRadius(DesignSystem.CornerRadius.medium)
                .overlay(
                    RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.medium)
                        .stroke(DesignSystem.Colors.border, lineWidth: 1)
                )
                
                HStack {
                    Button("Abbrechen") { dismiss() }
                        .buttonStyle(LightroomSecondaryButtonStyle())
                    
                    Spacer()
                    
                    Button("Anwenden") { applyMetadata() }
                        .buttonStyle(.borderedProminent)
                }
                .padding(.top, 6)
            }
            .padding(DesignSystem.Spacing.large)
        }
        .lightroomSidebarTheme()
        .frame(width: 680, height: 560)
    }
    
    private func applyMetadata() {
        guard let photo = store.currentPhoto else { return }
        
        let metadata = template.apply(tokenValues: tokenValues, photoDate: photo.iptcMetadata?.date)
        photo.iptcMetadata = metadata
        
        // Speichere Metadaten
        Task {
            do {
                try await Task.detached {
                    try IPTCMetadataService.shared.writeMetadata(metadata, to: photo.url)
                }.value
            } catch {
                print("Error saving metadata: \(error)")
            }
        }
        
        dismiss()
    }
}

struct TokenField: View {
    let label: String
    @Binding var value: String
    
    var body: some View {
        HStack(spacing: 12) {
            Text(label)
                .font(DesignSystem.Fonts.semibold(size: 10))
                .foregroundColor(DesignSystem.Colors.text2)
                .tracking(0.6)
                .lineLimit(1)
                .minimumScaleFactor(0.8)
                .frame(width: 130, alignment: .leading)
            
            TextField("", text: $value)
                .textFieldStyle(.plain)
                .foregroundColor(DesignSystem.Colors.text)
                .padding(.vertical, 7)
                .padding(.horizontal, 10)
                .background(DesignSystem.Colors.background2)
                .cornerRadius(DesignSystem.CornerRadius.small)
                .overlay(
                    RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                        .stroke(DesignSystem.Colors.border, lineWidth: 1)
                )
        }
    }
}

