//
//  FinderLikeSidebar.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit

struct FinderLikeSidebar: View {
    @ObservedObject var store: PhotoStore
    @State private var expandedFolders: Set<UUID> = []
    @State private var rootFolders: [FolderItem] = []
    @State private var cloudLocations: [FolderItem] = []
    @State private var recents: [FolderItem] = []
    
    var body: some View {
        VStack(spacing: 0) {
            // Header mit "Ordner öffnen" Button
            HStack(spacing: DesignSystem.Spacing.small) {
                Text("Ordner")
                    .font(DesignSystem.Fonts.semibold(size: 13))
                    .foregroundColor(DesignSystem.Colors.text)
                Spacer()
                Button(action: openFolder) {
                    Image(systemName: "folder.badge.plus")
                        .font(DesignSystem.Fonts.medium(size: 13))
                        .foregroundColor(DesignSystem.Colors.text2)
                        .frame(width: 24, height: 24)
                        .background(DesignSystem.Colors.background4)
                        .cornerRadius(DesignSystem.CornerRadius.small)
                }
                .buttonStyle(.plain)
                .help("Ordner öffnen...")
            }
            .padding(.horizontal, DesignSystem.Spacing.medium)
            .padding(.vertical, DesignSystem.Spacing.small)
            .background(DesignSystem.Colors.background3)
            .border(width: 1, edges: [.bottom], color: DesignSystem.Colors.border)
            
            // Hierarchische Ordner-Liste (Finder-Stil)
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 0) {
                    // Favoriten (wie im Finder)
                    if !favorites.isEmpty {
                        SectionHeader(title: "Favoriten")
                        ForEach(favorites) { folder in
                            FolderTreeRow(
                                folder: folder,
                                level: 0,
                                isExpanded: expandedFolders.contains(folder.id),
                                store: store,
                                expandedFolders: $expandedFolders,
                                onRemoveFavorite: { url in
                                    removeFromFavorites(url)
                                },
                                onRemoveRecent: nil,
                                onOpenFolder: { url in
                                    addToRecents(url)
                                }
                            )
                        }
                    }

                    // Zuletzt geöffnet (wie Finder "Zuletzt benutzt")
                    if !recents.isEmpty {
                        SectionHeader(title: "Zuletzt geöffnet")
                        ForEach(recents) { folder in
                            FolderTreeRow(
                                folder: folder,
                                level: 0,
                                isExpanded: expandedFolders.contains(folder.id),
                                store: store,
                                expandedFolders: $expandedFolders,
                                onRemoveFavorite: nil,
                                onRemoveRecent: { url in
                                    removeFromRecents(url)
                                },
                                onOpenFolder: { url in
                                    addToRecents(url)
                                }
                            )
                        }
                    }
                    
                    // Orte (wie im Finder)
                    SectionHeader(title: "Orte")
                    
                    // Standard-Ordner
                    ForEach(standardFolders) { folder in
                        FolderTreeRow(
                            folder: folder,
                            level: 0,
                            isExpanded: expandedFolders.contains(folder.id),
                            store: store,
                            expandedFolders: $expandedFolders,
                            onRemoveFavorite: nil,
                            onRemoveRecent: nil,
                            onOpenFolder: { url in
                                addToRecents(url)
                            }
                        )
                    }

                // Cloud-Provider (Finder-ähnlich unter "Orte": iCloud Drive / OneDrive)
                if !cloudLocations.isEmpty {
                    ForEach(cloudLocations) { folder in
                        FolderTreeRow(
                            folder: folder,
                            level: 0,
                            isExpanded: expandedFolders.contains(folder.id),
                            store: store,
                            expandedFolders: $expandedFolders,
                            onRemoveFavorite: nil,
                            onRemoveRecent: nil,
                            onOpenFolder: { url in
                                addToRecents(url)
                            }
                        )
                    }
                }
                    
                    // Home-Ordner (alle Ordner vom MacBook)
                    if !homeFolders.isEmpty {
                        ForEach(homeFolders) { folder in
                            FolderTreeRow(
                                folder: folder,
                                level: 0,
                                isExpanded: expandedFolders.contains(folder.id),
                                store: store,
                                expandedFolders: $expandedFolders,
                                onRemoveFavorite: nil,
                                onRemoveRecent: nil,
                                onOpenFolder: { url in
                                    addToRecents(url)
                                }
                            )
                        }
                    }
                    
                    // Volumes (externe Laufwerke, iCloud, OneDrive, etc.)
                    if !volumes.isEmpty {
                        ForEach(volumes) { folder in
                            FolderTreeRow(
                                folder: folder,
                                level: 0,
                                isExpanded: expandedFolders.contains(folder.id),
                                store: store,
                                expandedFolders: $expandedFolders,
                                onRemoveFavorite: nil,
                                onRemoveRecent: nil,
                                onOpenFolder: { url in
                                    addToRecents(url)
                                }
                            )
                        }
                    }
                }
                .padding(.vertical, 4)
            }
        }
        .background(DesignSystem.Colors.background3)
        // Wichtig: erzwingt ein lesbares Dark-Theme auch dann, wenn macOS im Light-Mode läuft.
        .lightroomSidebarTheme()
        .onAppear {
            loadVolumes()
            loadCloudLocations()
            loadFavorites()
            loadRecents()
            loadHomeFolders()
        }
        .onReceive(NotificationCenter.default.publisher(for: NSNotification.Name("SidebarFoldersUpdated"))) { _ in
            loadFavorites()
            loadRecents()
        }
        .onChange(of: store.currentFolder) { _, newFolder in
            if let url = newFolder {
                addToRecents(url)
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: NSWorkspace.didMountNotification)) { _ in
            loadVolumes()
            loadCloudLocations()
        }
        .onReceive(NotificationCenter.default.publisher(for: NSWorkspace.didUnmountNotification)) { _ in
            loadVolumes()
            loadCloudLocations()
        }
    }
    
    private var standardFolders: [FolderItem] {
        // In der App-Sandbox liefern FileManager.urls(for: ...) oft Container-Pfade (~/Library/Containers/...).
        // Für Finder-ähnliche Navigation wollen wir die echten User-Ordner anzeigen.
        let home = FileManager.default.homeDirectoryForCurrentUser
        return [
            FolderItem(url: home, name: "Home", type: .standard(.home)),
            FolderItem(url: home.appendingPathComponent("Desktop"), name: "Desktop", type: .standard(.desktop)),
            FolderItem(url: home.appendingPathComponent("Documents"), name: "Documents", type: .standard(.documents)),
            FolderItem(url: home.appendingPathComponent("Downloads"), name: "Downloads", type: .standard(.downloads)),
            FolderItem(url: home.appendingPathComponent("Pictures"), name: "Pictures", type: .standard(.pictures))
        ]
    }
    
    @State private var volumes: [FolderItem] = []
    @State private var favorites: [FolderItem] = []
    @State private var homeFolders: [FolderItem] = []
    
    private func openFolder() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = false
        panel.title = "Ordner auswählen"
        panel.prompt = "Öffnen"
        panel.message = "Wählen Sie einen Ordner mit Bildern aus"
        
        // Wichtig: Erlaube Zugriff auf alle Volumes
        panel.directoryURL = nil // Startet im Standard-Verzeichnis
        
        let response = panel.runModal()
        if response == .OK, let url = panel.url {
            // Erstelle Security-Scoped Bookmark für persistente Zugriffe
            saveBookmark(for: url)
            
            store.loadPhotos(from: url)
            addToFavorites(url)
            addToRecents(url)
        }
    }
    
    private func saveBookmark(for url: URL) {
        do {
            let bookmarkData = try url.bookmarkData(
                options: [.withSecurityScope],
                includingResourceValuesForKeys: nil,
                relativeTo: nil
            )
            
            // Speichere Bookmark
            var bookmarks = UserDefaults.standard.dictionary(forKey: "folderBookmarks") ?? [:]
            bookmarks[url.path] = bookmarkData
            UserDefaults.standard.set(bookmarks, forKey: "folderBookmarks")
        } catch {
            print("Fehler beim Speichern des Bookmarks: \(error)")
        }
    }
    
    private func loadVolumes() {
        let fileManager = FileManager.default
        let volumeURLs = fileManager.mountedVolumeURLs(includingResourceValuesForKeys: [.volumeNameKey, .volumeIsRemovableKey], options: []) ?? []
        
        var foundVolumes: [FolderItem] = []
        
        // 1. Lade normale Volumes (externe Laufwerke, etc.)
        for url in volumeURLs {
            guard let resourceValues = try? url.resourceValues(forKeys: [.volumeNameKey, .volumeIsRemovableKey]),
                  let name = resourceValues.volumeName else {
                continue
            }
            
            // FILTERE SIMULATOREN RAUS!
            if name.contains("Simulator") || name.contains("iOS") || name.contains("WatchOS") || name.contains("tvOS") {
                continue
            }

            // Cloud-Provider nicht als "Volume" doppelt anzeigen (die zeigen wir unter "Orte")
            let lower = name.lowercased()
            if lower.contains("onedrive") || lower.contains("icloud") {
                continue
            }
            
            // Zeige ALLE Volumes in /Volumes/ (inkl. OneDrive, externe SSDs, etc.)
            if url.path.contains("/Volumes/") && !url.path.contains("/System/Volumes/") {
                if !name.lowercased().contains("simulator") {
                    let children = loadSubfolders(for: url)
                    foundVolumes.append(FolderItem(url: url, name: name, type: .volume, children: children))
                }
            }
        }
        
        volumes = foundVolumes
    }

    private func loadCloudLocations() {
        let fileManager = FileManager.default
        let homeURL = fileManager.homeDirectoryForCurrentUser
        var found: [FolderItem] = []

        // 1) iCloud Drive (klassischer Pfad) – immer anzeigen (auch wenn Sandbox fileExists blockt)
        let iCloudDriveURL = homeURL.appendingPathComponent("Library/Mobile Documents/com~apple~CloudDocs")
        let iCloudChildren = FileManager.default.isReadableFile(atPath: iCloudDriveURL.path) ? loadSubfolders(for: iCloudDriveURL) : []
        found.append(FolderItem(url: iCloudDriveURL, name: "iCloud Drive", type: .volume, children: iCloudChildren))

        // 2) FileProvider/CloudStorage (OneDrive, iCloud etc.)
        let cloudStorageURL = homeURL.appendingPathComponent("Library/CloudStorage")
        var didFindOneDrive = false
        do {
            let contents = try fileManager.contentsOfDirectory(
                at: cloudStorageURL,
                includingPropertiesForKeys: [.isDirectoryKey],
                options: [.skipsHiddenFiles]
            )

            for url in contents {
                guard let resourceValues = try? url.resourceValues(forKeys: [.isDirectoryKey]),
                      resourceValues.isDirectory == true else {
                    continue
                }

                let rawName = url.lastPathComponent
                let lower = rawName.lowercased()

                if lower.contains("onedrive") || lower.contains("microsoft") {
                    didFindOneDrive = true
                    let children = FileManager.default.isReadableFile(atPath: url.path) ? loadSubfolders(for: url) : []
                    // Wenn mehrere OneDrive-Instanzen existieren (Business/Personal), zeige den Ordnernamen.
                    let display = rawName.lowercased().contains("onedrive") ? rawName : "OneDrive"
                    found.append(FolderItem(url: url, name: display, type: .volume, children: children))
                } else if lower.contains("icloud") {
                    // Nur ergänzen, wenn iCloud nicht bereits über den Standardpfad drin ist
                    if !found.contains(where: { $0.name == "iCloud Drive" }) {
                        let children = FileManager.default.isReadableFile(atPath: url.path) ? loadSubfolders(for: url) : []
                        found.append(FolderItem(url: url, name: "iCloud Drive", type: .volume, children: children))
                    }
                }
            }
        } catch {
            // Wenn die Sandbox den Ordner nicht lesen darf, zeigen wir trotzdem einen sinnvollen OneDrive-Eintrag
            // (der Klick löst dann den Permission-Dialog im richtigen Ordner aus).
            didFindOneDrive = false
        }

        if !didFindOneDrive {
            // Häufigster deutscher OneDrive-Name
            let oneDriveGuess = cloudStorageURL.appendingPathComponent("OneDrive-Persönlich")
            found.append(FolderItem(url: oneDriveGuess, name: "OneDrive", type: .volume, children: []))
        }

        // Stabil sortieren (iCloud zuerst, dann OneDrive/Rest)
        cloudLocations = found.sorted { lhs, rhs in
            if lhs.name == "iCloud Drive" { return true }
            if rhs.name == "iCloud Drive" { return false }
            return lhs.name.localizedCaseInsensitiveCompare(rhs.name) == .orderedAscending
        }
    }
    
    private func loadHomeFolders() {
        let fileManager = FileManager.default
        let home = fileManager.homeDirectoryForCurrentUser
        
        // Lade alle Ordner im Home-Verzeichnis (wie im Finder sichtbar)
        guard let contents = try? fileManager.contentsOfDirectory(
            at: home,
            includingPropertiesForKeys: [.isDirectoryKey, .isHiddenKey],
            options: [.skipsHiddenFiles]
        ) else {
            homeFolders = []
            return
        }
        
        var folders: [FolderItem] = []
        
        for url in contents {
            guard let resourceValues = try? url.resourceValues(forKeys: [.isDirectoryKey, .isHiddenKey]),
                  resourceValues.isDirectory == true,
                  resourceValues.isHidden != true else {
                continue
            }
            
            // Überspringe Standard-Ordner, die bereits oben angezeigt werden
            let name = url.lastPathComponent
            if ["Desktop", "Documents", "Downloads", "Pictures"].contains(name) {
                continue
            }
            
            // Überspringe System-Ordner
            if name.hasPrefix(".") || name == "Library" {
                continue
            }
            
            let children = loadSubfolders(for: url)
            folders.append(FolderItem(url: url, name: name, type: .regular, children: children))
        }
        
        // Sortiere alphabetisch
        homeFolders = folders.sorted { $0.name < $1.name }
    }
    
    private func loadSubfolders(for parentURL: URL) -> [FolderItem] {
        let fileManager = FileManager.default
        guard let enumerator = fileManager.enumerator(
            at: parentURL,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [.skipsHiddenFiles, .skipsSubdirectoryDescendants],
            errorHandler: nil
        ) else {
            return []
        }
        
        var subfolders: [FolderItem] = []
        for case let url as URL in enumerator {
            guard let resourceValues = try? url.resourceValues(forKeys: [.isDirectoryKey]),
                  resourceValues.isDirectory == true else {
                continue
            }
            
            // Lade nur direkte Unterordner (max. 1 Level tief für Performance)
            subfolders.append(FolderItem(url: url, name: url.lastPathComponent, type: .regular))
        }
        
        return subfolders.sorted { $0.name < $1.name }
    }
    
    private func loadFavorites() {
        if let favoritePaths = UserDefaults.standard.stringArray(forKey: "favoriteFolders") {
            favorites = favoritePaths.compactMap { path in
                let url = URL(fileURLWithPath: path)
                guard FileManager.default.fileExists(atPath: path) else { return nil }
                let children = loadSubfolders(for: url)
                return FolderItem(url: url, name: url.lastPathComponent, type: .favorite, children: children)
            }
        }
    }
    
    private func addToFavorites(_ url: URL) {
        // Entferne Duplikate
        favorites.removeAll { $0.url == url }
        
        // Füge am Anfang hinzu
        let children = loadSubfolders(for: url)
        let folder = FolderItem(url: url, name: url.lastPathComponent, type: .favorite, children: children)
        favorites.insert(folder, at: 0)
        
        // Begrenze auf 10
        if favorites.count > 10 {
            favorites = Array(favorites.prefix(10))
        }
        
        // Speichere in UserDefaults
        let paths = favorites.map { $0.url.path }
        UserDefaults.standard.set(paths, forKey: "favoriteFolders")
    }
    
    private func removeFromFavorites(_ url: URL) {
        favorites.removeAll { $0.url == url }
        
        // Speichere in UserDefaults
        let paths = favorites.map { $0.url.path }
        UserDefaults.standard.set(paths, forKey: "favoriteFolders")
    }

    // MARK: - Zuletzt geöffnet (Recents)

    private func loadRecents() {
        guard let recentPaths = UserDefaults.standard.stringArray(forKey: "recentFolders") else {
            recents = []
            return
        }
        recents = recentPaths.map { path in
            let url = URL(fileURLWithPath: path)
            // In der Sandbox kann fileExists/readable false liefern, obwohl der Pfad real existiert.
            // Für "Zuletzt geöffnet" zeigen wir Einträge trotzdem an; beim Klick holen wir Permission nach.
            let children = FileManager.default.isReadableFile(atPath: url.path) ? loadSubfolders(for: url) : []
            return FolderItem(url: url, name: url.lastPathComponent, type: .recent, children: children)
        }
    }

    private func addToRecents(_ url: URL) {
        let standardized = url.standardizedFileURL
        recents.removeAll { $0.url.standardizedFileURL.path == standardized.path }

        let children = FileManager.default.isReadableFile(atPath: standardized.path) ? loadSubfolders(for: standardized) : []
        let item = FolderItem(url: standardized, name: standardized.lastPathComponent, type: .recent, children: children)
        recents.insert(item, at: 0)

        // Begrenze auf 12 (Finder-ähnlich, aber kompakt)
        if recents.count > 12 {
            recents = Array(recents.prefix(12))
        }

        let paths = recents.map { $0.url.path }
        UserDefaults.standard.set(paths, forKey: "recentFolders")
    }

    private func removeFromRecents(_ url: URL) {
        let standardized = url.standardizedFileURL
        recents.removeAll { $0.url.standardizedFileURL.path == standardized.path }
        let paths = recents.map { $0.url.path }
        UserDefaults.standard.set(paths, forKey: "recentFolders")
    }
}

struct SectionHeader: View {
    let title: String
    
    var body: some View {
        Text(title.uppercased())
            .font(DesignSystem.Fonts.semibold(size: 11))
            .foregroundColor(DesignSystem.Colors.text)
            .tracking(0.5)
            .padding(.horizontal, DesignSystem.Spacing.medium)
            .padding(.vertical, DesignSystem.Spacing.small)
    }
}

struct FolderTreeRow: View {
    let folder: FolderItem
    let level: Int
    @State var isExpanded: Bool
    @ObservedObject var store: PhotoStore
    @Binding var expandedFolders: Set<UUID>
    @State private var children: [FolderItem] = []
    @State private var isHovering = false
    var onRemoveFavorite: ((URL) -> Void)? = nil
    var onRemoveRecent: ((URL) -> Void)? = nil
    var onOpenFolder: ((URL) -> Void)? = nil
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Button(action: {
                if !folder.children.isEmpty {
                    isExpanded.toggle()
                    if isExpanded {
                        expandedFolders.insert(folder.id)
                        loadChildrenIfNeeded()
                    } else {
                        expandedFolders.remove(folder.id)
                    }
                } else {
                    // Lade Bilder aus diesem Ordner (Sandbox-safe)
                    if let resolved = resolvedBookmarkURL(for: folder.url) {
                        store.loadPhotos(from: resolved)
                        onOpenFolder?(resolved)
                        return
                    }
                    
                    // Wenn der Pfad direkt lesbar ist (z.B. ohne Sandbox oder für Container-Ordner), lade direkt.
                    if FileManager.default.isReadableFile(atPath: folder.url.path) {
                        store.loadPhotos(from: folder.url)
                        onOpenFolder?(folder.url)
                        return
                    }
                    
                    // Sonst Permission via OpenPanel einholen (User-selected folder access).
                    requestAccessAndLoad(startingAt: folder.url)
                }
            }) {
                HStack(spacing: 4) {
                    // Einrückung
                    ForEach(0..<level, id: \.self) { _ in
                        Rectangle()
                            .fill(Color.clear)
                            .frame(width: 16)
                    }
                    
                    // Expand/Collapse Icon
                    if !folder.children.isEmpty {
                        Image(systemName: isExpanded ? "chevron.down" : "chevron.right")
                            .font(.system(size: 10))
                            .foregroundColor(DesignSystem.Colors.text)
                            .frame(width: 12)
                    } else {
                        Rectangle()
                            .fill(Color.clear)
                            .frame(width: 12)
                    }
                    
                    // Folder Icon
                    Image(systemName: folder.type.icon)
                        .font(DesignSystem.Fonts.regular(size: 14))
                        .foregroundColor(isSelected ? DesignSystem.Colors.accent : DesignSystem.Colors.text)
                        .frame(width: 18)
                    
                    // Folder Name
                    Text(folder.name)
                        .font(DesignSystem.Fonts.regular(size: 13))
                        .foregroundColor(isSelected ? DesignSystem.Colors.text : DesignSystem.Colors.text)
                        .lineLimit(1)
                    
                    Spacer()
                }
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
            }
            .buttonStyle(.plain)
            .background(
                Group {
                    if isSelected {
                        DesignSystem.Colors.accent.opacity(0.15)
                    } else if isHovering {
                        DesignSystem.Colors.background4
                    } else {
                        Color.clear
                    }
                }
            )
            .contentShape(Rectangle())
            .onHover { hovering in
                isHovering = hovering
            }
            .contextMenu {
                if folder.type == .favorite {
                    Button("Aus Favoriten entfernen") {
                        onRemoveFavorite?(folder.url)
                    }
                }
                if folder.type == .recent {
                    Button("Aus „Zuletzt geöffnet“ entfernen") {
                        onRemoveRecent?(folder.url)
                    }
                }
            }
            
            // Unterordner (wenn expanded)
            if isExpanded {
                ForEach(children.isEmpty ? folder.children : children) { child in
                    FolderTreeRow(
                        folder: child,
                        level: level + 1,
                        isExpanded: expandedFolders.contains(child.id),
                        store: store,
                        expandedFolders: $expandedFolders,
                        onRemoveFavorite: onRemoveFavorite,
                        onRemoveRecent: onRemoveRecent,
                        onOpenFolder: onOpenFolder
                    )
                }
            }
        }
    }
    
    private var isSelected: Bool {
        guard let current = store.currentFolder else { return false }
        return current.standardizedFileURL.path == folder.url.standardizedFileURL.path
    }
    
    private func loadChildrenIfNeeded() {
        // Wenn bereits geladen, nichts tun
        if !children.isEmpty {
            return
        }
        
        // Wenn folder.children bereits vorhanden, verwende diese
        if !folder.children.isEmpty {
            children = folder.children
            return
        }
        
        // Wichtig für Swift Concurrency: Werte vor dem Detached-Task capturen,
        // damit wir keine MainActor-isolierten View-Properties im Background lesen müssen.
        let parentURL = folder.url
        
        // Lade Unterordner dynamisch
        Task.detached(priority: .utility) {
            let fileManager = FileManager.default
            
            // Prüfe ob Ordner existiert
            var isDirectory: ObjCBool = false
            guard fileManager.fileExists(atPath: parentURL.path, isDirectory: &isDirectory),
                  isDirectory.boolValue else {
                return
            }
            
            // Lade nur direkte Unterordner (nicht rekursiv)
            guard let contents = try? fileManager.contentsOfDirectory(
                at: parentURL,
                includingPropertiesForKeys: [.isDirectoryKey],
                options: [.skipsHiddenFiles]
            ) else {
                return
            }
            
            var subfolderURLs: [URL] = []
            for url in contents {
                guard let resourceValues = try? url.resourceValues(forKeys: [.isDirectoryKey]),
                      resourceValues.isDirectory == true else {
                    continue
                }
                
                subfolderURLs.append(url)
            }
            
            let sortedURLs = subfolderURLs.sorted { $0.lastPathComponent < $1.lastPathComponent }
            
            await MainActor.run {
                self.children = sortedURLs.map { FolderItem(url: $0, name: $0.lastPathComponent, type: .regular) }
            }
        }
    }
    
    private func resolvedBookmarkURL(for url: URL) -> URL? {
        guard let bookmarks = UserDefaults.standard.dictionary(forKey: "folderBookmarks"),
              let bookmarkData = bookmarks[url.path] as? Data else {
            return nil
        }
        
        var isStale = false
        guard let resolvedURL = try? URL(
            resolvingBookmarkData: bookmarkData,
            options: [.withSecurityScope],
            relativeTo: nil,
            bookmarkDataIsStale: &isStale
        ) else {
            return nil
        }
        
        // Falls stale, speichern wir es beim nächsten erfolgreichen Zugriff neu.
        return resolvedURL
    }
    
    private func saveBookmark(for url: URL) {
        do {
            let bookmarkData = try url.bookmarkData(
                options: [.withSecurityScope],
                includingResourceValuesForKeys: nil,
                relativeTo: nil
            )
            var bookmarks = UserDefaults.standard.dictionary(forKey: "folderBookmarks") ?? [:]
            bookmarks[url.path] = bookmarkData
            UserDefaults.standard.set(bookmarks, forKey: "folderBookmarks")
        } catch {
            print("Fehler beim Speichern des Bookmarks: \(error)")
        }
    }
    
    private func requestAccessAndLoad(startingAt url: URL) {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = false
        panel.prompt = "Zugriff erlauben"
        panel.message = "Damit WB Foto Manager auf diesen Ordner zugreifen kann, bitte den Ordner auswählen."
        
        // Starte im Parent, damit der Ordner leicht auswählbar ist.
        // (Auch wenn Sandbox fileExists blockt, ist der Pfad für den User hilfreich.)
        panel.directoryURL = url.deletingLastPathComponent()
        
        if panel.runModal() == .OK, let selected = panel.url {
            saveBookmark(for: selected)
            store.loadPhotos(from: selected)
            onOpenFolder?(selected)
        }
    }
}

