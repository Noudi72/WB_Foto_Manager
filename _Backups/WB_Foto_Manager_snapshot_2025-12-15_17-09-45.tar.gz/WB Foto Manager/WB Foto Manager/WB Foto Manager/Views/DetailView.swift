//
//  DetailView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI

struct DetailView: View {
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    @State private var image: NSImage?
    @State private var processedImage: NSImage?
    
    var body: some View {
        ZStack { content }
        .onChange(of: store.currentPhotoID) { _, _ in
            loadImage()
        }
        .onChange(of: store.currentPhoto?.cropRect) { _, _ in processImage() }
        .onChange(of: store.currentPhoto?.rotation) { _, _ in processImage() }
        .onChange(of: uiState.watermarkPreviewEnabled) { _, _ in processImage() }
        .onChange(of: uiState.watermarkPreviewPresetID) { _, _ in processImage() }
        .onReceive(NotificationCenter.default.publisher(for: NSNotification.Name("WatermarkSettingsChanged"))) { _ in
            processImage()
        }
        .onAppear(perform: loadImage)
        .onReceive(NotificationCenter.default.publisher(for: NSNotification.Name("PhotoAdjustmentsChanged"))) { notification in
            if let userInfo = notification.userInfo,
               let photoID = userInfo["photoID"] as? UUID,
               photoID == store.currentPhoto?.id {
                processImage()
            } else if notification.object == nil {
                // Fallback: Wenn keine userInfo, prüfe ob es das aktuelle Foto ist
                processImage()
            }
        }
    }
    
    @ViewBuilder
    private var content: some View {
        if let photo = store.currentPhoto {
            if uiState.showBeforeAfter {
                BeforeAfterView(photo: photo, store: store)
            } else {
                PhotoDetailView(photo: photo, store: store, image: processedImage ?? image)
            }
        } else {
            DetailPlaceholderView(
                isLoading: store.isLoadingPhotos,
                progress: store.loadingProgress,
                hasPhotos: !store.photos.isEmpty,
                hasFolder: store.currentFolder != nil
            )
        }
    }
    
    private func loadImage() {
        guard let photo = store.currentPhoto else {
            image = nil
            processedImage = nil
            return
        }
        
        // Reset images first
        image = nil
        processedImage = nil
        
        Task(priority: .userInitiated) {
            // PROGRESSIVE LOADING: Erst Low-Res, dann High-Res
            let (lowRes, highRes) = await SmartImageLoader.shared.loadProgressive(url: photo.url)
            
            // Zeige Low-Res sofort für schnelles Feedback
            if let lowRes = lowRes {
                await MainActor.run {
                    self.image = lowRes
                    if !shouldProcess(photo) {
                        self.processedImage = lowRes
                    }
                }
            }
            
            // Ersetze mit High-Res sobald verfügbar
            if let highRes = highRes {
                await MainActor.run {
                    self.image = highRes
                    if !shouldProcess(photo) {
                        self.processedImage = highRes
                    } else {
                        processImage()
                    }
                }
            }
            
            // PREFETCH nächste Bilder für schnelles Browsing
            if let currentIndex = store.currentPhotoIndexInFiltered {
                let nextPhotos = Array(store.filteredPhotos.dropFirst(currentIndex + 1).prefix(5))
                let nextURLs = nextPhotos.map { $0.url }
                await SmartImageLoader.shared.prefetchNext(urls: nextURLs)
            }
        }
    }
    
    private func processImage() {
        guard let photo = store.currentPhoto, let originalCIImage = photo.loadFullImage() else { return }
        
        // Only re-process if adjustments/crop/rotation OR watermark-preview is active
        guard shouldProcess(photo) else {
            processedImage = image
            return
        }
        
        Task.detached(priority: .userInitiated) {
            await MainActor.run {
                let editEngine = EditEngine.shared
                var processed = originalCIImage
                
                if let adjusted = editEngine.applyAdjustments(to: processed, adjustments: photo.adjustments) {
                    processed = adjusted
                }
                
                processed = editEngine.applyCropAndRotation(
                    to: processed,
                    cropRect: photo.cropRect,
                    rotation: photo.rotation
                )
                
                if let watermark = watermarkSettingsForPreview() {
                    if let watermarked = editEngine.applyWatermark(to: processed, settings: watermark) {
                        processed = watermarked
                    }
                }
                
                Task.detached(priority: .userInitiated) {
                    let rendered = await editEngine.render(processed, size: CGSize(width: 4000, height: 4000))
                    
                    await MainActor.run {
                        self.processedImage = rendered
                    }
                }
            }
        }
    }
    
    private func shouldProcess(_ photo: PhotoItem) -> Bool {
        photo.adjustments.hasAdjustments ||
        photo.cropRect != nil ||
        photo.rotation != 0.0 ||
        (uiState.watermarkPreviewEnabled && watermarkSettingsForPreview() != nil)
    }
    
    private func watermarkSettingsForPreview() -> WatermarkSettings? {
        guard uiState.watermarkPreviewEnabled else { return nil }
        
        if let id = uiState.watermarkPreviewPresetID,
           let preset = store.exportPresets.first(where: { $0.id == id }) {
            return preset.watermarkSettings
        }
        
        return store.exportPresets.first(where: { $0.watermarkSettings != nil })?.watermarkSettings
    }
}

// MARK: - Subviews

struct DetailPlaceholderView: View {
    let isLoading: Bool
    let progress: Double
    let hasPhotos: Bool
    let hasFolder: Bool
    
    var body: some View {
        VStack(spacing: 16) {
            if isLoading {
                VStack(spacing: 12) {
                    ProgressView(value: progress)
                        .frame(width: 300)
                    Text("Lade Bilder... \(Int(progress * 100))%")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            } else {
                Image(systemName: "photo.on.rectangle.angled")
                    .font(.system(size: 56))
                    .foregroundColor(DesignSystem.Colors.text3)
                
                if !hasFolder {
                    Text("Wählen Sie einen Ordner aus, um zu beginnen")
                        .font(DesignSystem.Fonts.semibold(size: 16))
                        .foregroundColor(DesignSystem.Colors.text2)
                } else if !hasPhotos {
                    Text("Keine Bilder in diesem Ordner gefunden")
                        .font(DesignSystem.Fonts.semibold(size: 16))
                        .foregroundColor(DesignSystem.Colors.text2)
                } else {
                    Text("Kein Foto ausgewählt")
                        .font(DesignSystem.Fonts.semibold(size: 16))
                        .foregroundColor(DesignSystem.Colors.text2)
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}


struct PhotoDetailView: View {
    let photo: PhotoItem
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    let image: NSImage?
    
    @State private var zoom: CGFloat = 1.0
    @State private var panOffset: CGSize = .zero
    @State private var lastPanOffset: CGSize = .zero
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                if let img = image {
                    Image(nsImage: img)
                        .resizable()
                        .interpolation(.high)
                        .antialiased(true)
                        .aspectRatio(contentMode: .fit)
                        .scaleEffect(zoom)
                        .offset(x: panOffset.width, y: panOffset.height)
                        .gesture(
                            MagnificationGesture()
                                .onChanged { value in zoom = value }
                                .onEnded { _ in zoom = max(1.0, min(5.0, zoom)) }
                        )
                        .gesture(
                            DragGesture()
                                .onChanged { value in panOffset = CGSize(width: lastPanOffset.width + value.translation.width, height: lastPanOffset.height + value.translation.height) }
                                .onEnded { _ in lastPanOffset = panOffset }
                        )
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    ProgressView().scaleEffect(1.2)
                }
            }
        }
        .background(Color.black)
        .focusable()
        .onKeyPress(.leftArrow) { 
            store.selectPreviousPhoto()
            resetZoom()
            return .handled 
        }
        .onKeyPress(.rightArrow) { 
            store.selectNextPhoto()
            resetZoom()
            return .handled 
        }
        .onKeyPress(.space) { 
            resetZoom()
            return .handled 
        }
        .onKeyPress("1") {
            if let photoID = store.currentPhotoID {
                store.setRating(1, for: photoID)
            }
            return .handled
        }
        .onKeyPress("2") {
            if let photoID = store.currentPhotoID {
                store.setRating(2, for: photoID)
            }
            return .handled
        }
        .onKeyPress("3") {
            if let photoID = store.currentPhotoID {
                store.setRating(3, for: photoID)
            }
            return .handled
        }
        .onKeyPress("4") {
            if let photoID = store.currentPhotoID {
                store.setRating(4, for: photoID)
            }
            return .handled
        }
        .onKeyPress("5") {
            if let photoID = store.currentPhotoID {
                store.setRating(5, for: photoID)
            }
            return .handled
        }
        .onKeyPress("0") {
            if let photoID = store.currentPhotoID {
                store.setRating(0, for: photoID, autoAdvance: false)
            }
            return .handled
        }
        .onKeyPress("y") {
            uiState.showBeforeAfter.toggle()
            return .handled
        }
        .onKeyPress("g") {
            uiState.viewMode = .grid
            return .handled
        }
    }
    
    private func resetZoom() {
        withAnimation(.easeOut(duration: 0.2)) {
            zoom = 1.0
            panOffset = .zero
            lastPanOffset = .zero
        }
    }
}

struct BeforeAfterView: View {
    @ObservedObject var photo: PhotoItem
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    @State private var beforeImage: NSImage?
    @State private var afterImage: NSImage?
    @State private var splitFraction: CGFloat = 0.5
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black
                
                // BEFORE (links)
                if let before = beforeImage {
                    Image(nsImage: before)
                        .resizable()
                        .interpolation(.high)
                        .antialiased(true)
                        .aspectRatio(contentMode: .fit)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    ProgressView().scaleEffect(1.1)
                }
                
                // AFTER (rechts, per Mask)
                if let after = afterImage {
                    Image(nsImage: after)
                        .resizable()
                        .interpolation(.high)
                        .antialiased(true)
                        .aspectRatio(contentMode: .fit)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .mask(
                            Rectangle()
                                .frame(width: geo.size.width * (1.0 - splitFraction))
                                .frame(maxWidth: .infinity, alignment: .trailing)
                        )
                }
                
                // Divider + Handle
                let xPos = geo.size.width * splitFraction
                
                Rectangle()
                    .fill(Color.white.opacity(0.85))
                    .frame(width: 2)
                    .frame(maxHeight: .infinity)
                    .position(x: xPos, y: geo.size.height / 2)
                
                BeforeAfterHandle()
                    .position(x: xPos, y: geo.size.height / 2)
                
                // Labels
                HStack {
                    badge("VORHER")
                    Spacer()
                    badge("NACHHER")
                }
                .padding(10)
                .allowsHitTesting(false)
                
                // Drag target (breiter als die Linie)
                Rectangle()
                    .fill(Color.clear)
                    .frame(width: 44)
                    .frame(maxHeight: .infinity)
                    .position(x: xPos, y: geo.size.height / 2)
                    .contentShape(Rectangle())
                    .gesture(
                        DragGesture(minimumDistance: 0)
                            .onChanged { value in
                                let newFrac = value.location.x / max(1, geo.size.width)
                                splitFraction = min(1.0, max(0.0, newFrac))
                            }
                    )
            }
        }
        .onAppear(perform: loadImages)
        .onChange(of: photo.id) { _, _ in loadImages() }
        .onChange(of: photo.adjustments) { _, _ in loadImages() }
        .onChange(of: photo.cropRect) { _, _ in loadImages() }
        .onChange(of: photo.rotation) { _, _ in loadImages() }
        .focusable()
        .onKeyPress(.leftArrow) {
            store.selectPreviousPhoto()
            return .handled
        }
        .onKeyPress(.rightArrow) {
            store.selectNextPhoto()
            return .handled
        }
        .onKeyPress("1") {
            if let photoID = store.currentPhotoID { store.setRating(1, for: photoID) }
            return .handled
        }
        .onKeyPress("2") {
            if let photoID = store.currentPhotoID { store.setRating(2, for: photoID) }
            return .handled
        }
        .onKeyPress("3") {
            if let photoID = store.currentPhotoID { store.setRating(3, for: photoID) }
            return .handled
        }
        .onKeyPress("4") {
            if let photoID = store.currentPhotoID { store.setRating(4, for: photoID) }
            return .handled
        }
        .onKeyPress("5") {
            if let photoID = store.currentPhotoID { store.setRating(5, for: photoID) }
            return .handled
        }
        .onKeyPress("0") {
            if let photoID = store.currentPhotoID { store.setRating(0, for: photoID, autoAdvance: false) }
            return .handled
        }
        .onKeyPress("y") {
            uiState.showBeforeAfter.toggle()
            return .handled
        }
        .onKeyPress("g") {
            uiState.viewMode = .grid
            return .handled
        }
    }
    
    private func loadImages() {
        beforeImage = nil
        afterImage = nil
        
        // Werte vor dem Background-Task capturen (stabile UI + sauber für Concurrency)
        guard let originalCI = photo.loadFullImage() else { return }
        let cropRect = photo.cropRect
        let rotation = photo.rotation
        let adjustments = photo.adjustments
        
        Task { @MainActor in
            let editEngine = EditEngine.shared
            
            // BEFORE: Original + Crop/Rotation (damit Slider exakt deckungsgleich ist)
            let beforeCI = editEngine.applyCropAndRotation(
                to: originalCI,
                cropRect: cropRect,
                rotation: rotation
            )
            
            // AFTER: Adjustments + Crop/Rotation
            var afterCI = originalCI
            if let adjusted = editEngine.applyAdjustments(to: afterCI, adjustments: adjustments) {
                afterCI = adjusted
            }
            afterCI = editEngine.applyCropAndRotation(
                to: afterCI,
                cropRect: cropRect,
                rotation: rotation
            )
            
            // Optional: Wasserzeichen-Vorschau (nur auf AFTER)
            if uiState.watermarkPreviewEnabled,
               let watermark = watermarkSettingsForPreview() {
                if let watermarked = editEngine.applyWatermark(to: afterCI, settings: watermark) {
                    afterCI = watermarked
                }
            }
            
            let targetSize = CGSize(width: 4000, height: 4000)
            self.beforeImage = editEngine.render(beforeCI, size: targetSize)
            self.afterImage = editEngine.render(afterCI, size: targetSize)
        }
    }
    
    private func watermarkSettingsForPreview() -> WatermarkSettings? {
        guard uiState.watermarkPreviewEnabled else { return nil }
        
        if let id = uiState.watermarkPreviewPresetID,
           let preset = store.exportPresets.first(where: { $0.id == id }) {
            return preset.watermarkSettings
        }
        
        return store.exportPresets.first(where: { $0.watermarkSettings != nil })?.watermarkSettings
    }
    
    private func badge(_ text: String) -> some View {
        Text(text)
            .font(DesignSystem.Fonts.semibold(size: 10))
            .foregroundColor(DesignSystem.Colors.text)
            .tracking(0.6)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(Color.black.opacity(0.55))
            .overlay(
                RoundedRectangle(cornerRadius: 4)
                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
            )
            .cornerRadius(4)
    }
}

struct BeforeAfterHandle: View {
    var body: some View {
        ZStack {
            Circle()
                .fill(Color.black.opacity(0.55))
                .frame(width: 28, height: 28)
                .overlay(
                    Circle()
                        .stroke(Color.white.opacity(0.75), lineWidth: 1)
                )
            
            Image(systemName: "arrow.left.and.right")
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(Color.white.opacity(0.9))
        }
        .shadow(color: .black.opacity(0.35), radius: 6, x: 0, y: 2)
        .allowsHitTesting(false)
    }
}

