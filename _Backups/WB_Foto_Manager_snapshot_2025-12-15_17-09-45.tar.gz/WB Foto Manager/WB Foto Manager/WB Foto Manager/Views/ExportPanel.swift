//
//  ExportPanel.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit
import UniformTypeIdentifiers

struct ExportPanel: View {
    @ObservedObject var store: PhotoStore
    @State private var selectedPreset: ExportPreset?
    @State private var isExporting = false
    @State private var exportProgress: Double = 0.0
    @State private var showPresetManagement = false
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Export")
                    .font(.headline)
                
                Spacer()
                
                Button(action: {
                    showPresetManagement = true
                }) {
                    Image(systemName: "gearshape")
                }
                .help("Presets verwalten")
            }
            
            // Preset Selection
            Picker("Preset", selection: $selectedPreset) {
                Text("Kein Preset").tag(ExportPreset?.none)
                ForEach(store.exportPresets) { preset in
                    Text(preset.name).tag(ExportPreset?.some(preset))
                }
            }
            .pickerStyle(.menu)
            
            if let preset = selectedPreset {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Dimension: \(preset.maxDimension)px")
                    Text("Qualität: \(Int(preset.quality * 100))%")
                    Text("Format: \(preset.format.rawValue)")
                }
                .font(.caption)
                .foregroundColor(.secondary)
            }
            
            if isExporting {
                ProgressView(value: exportProgress)
            }
            
            HStack {
                Button("Abbrechen") {
                    dismiss()
                }
                
                Spacer()
                
                Button("Exportieren") {
                    export()
                }
                .buttonStyle(.borderedProminent)
                .disabled(selectedPreset == nil || isExporting)
            }
        }
        .padding()
        .frame(width: 400)
        .sheet(isPresented: $showPresetManagement) {
            ExportPresetManagementView(store: store)
        }
    }
    
    private func export() {
        guard let preset = selectedPreset,
              let photo = store.currentPhoto else {
            return
        }
        
        isExporting = true
        
        let savePanel = NSSavePanel()
        savePanel.allowedContentTypes = [.jpeg, .png]
        savePanel.nameFieldStringValue = photo.fileName
        
        savePanel.begin { response in
            if response == .OK, let url = savePanel.url {
                Task {
                    do {
                        try await ExportService.shared.export(
                            photo: photo,
                            preset: preset,
                            to: url,
                            uploadTargets: store.uploadTargets
                        ) { progress in
                            DispatchQueue.main.async {
                                self.exportProgress = progress
                            }
                        }
                        
                        DispatchQueue.main.async {
                            self.isExporting = false
                            self.dismiss()
                        }
                    } catch {
                        print("Export error: \(error)")
                        DispatchQueue.main.async {
                            self.isExporting = false
                        }
                    }
                }
            } else {
                isExporting = false
            }
        }
    }
}

extension ExportPreset {
    static var none: ExportPreset? { nil }
}

