//
//  GridView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI

struct GridView: View {
    let photos: [PhotoItem]
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    private let columns = Array(repeating: GridItem(.flexible(), spacing: 2), count: 5)
    
    var body: some View {
        ScrollView {
            LazyVGrid(columns: columns, spacing: 2) {
                ForEach(photos) { photo in
                    GridPhotoCell(photo: photo, store: store, isSelected: store.selectedPhotoIDs.contains(photo.id))
                        .onTapGesture {
                            store.selectPhoto(photo)
                        }
                }
            }
            .padding(2)
        }
        .background(DesignSystem.Colors.background)
        .onKeyPress(.upArrow) {
            if let currentIndex = store.currentPhotoIndexInFiltered {
                let newIndex = currentIndex - columns.count
                if newIndex >= 0 {
                    store.selectPhoto(at: newIndex)
                }
            }
            return .handled
        }
        .onKeyPress(.downArrow) {
            if let currentIndex = store.currentPhotoIndexInFiltered {
                let newIndex = currentIndex + columns.count
                if newIndex < photos.count {
                    store.selectPhoto(at: newIndex)
                }
            }
            return .handled
        }
        .onKeyPress(.leftArrow) {
            if let currentIndex = store.currentPhotoIndexInFiltered {
                let newIndex = currentIndex - 1
                if newIndex >= 0 {
                    store.selectPhoto(at: newIndex)
                }
            }
            return .handled
        }
        .onKeyPress(.rightArrow) {
            if let currentIndex = store.currentPhotoIndexInFiltered {
                let newIndex = currentIndex + 1
                if newIndex < photos.count {
                    store.selectPhoto(at: newIndex)
                }
            }
            return .handled
        }
        .onKeyPress(.space) {
            uiState.viewMode = .detail
            return .handled
        }
        .onKeyPress("e") {
            uiState.viewMode = .detail
            return .handled
        }
        .onKeyPress("1") {
            if let photoID = store.currentPhotoID { store.setRating(1, for: photoID) }
            return .handled
        }
        .onKeyPress("2") {
            if let photoID = store.currentPhotoID { store.setRating(2, for: photoID) }
            return .handled
        }
        .onKeyPress("3") {
            if let photoID = store.currentPhotoID { store.setRating(3, for: photoID) }
            return .handled
        }
        .onKeyPress("4") {
            if let photoID = store.currentPhotoID { store.setRating(4, for: photoID) }
            return .handled
        }
        .onKeyPress("5") {
            if let photoID = store.currentPhotoID { store.setRating(5, for: photoID) }
            return .handled
        }
        .onKeyPress("0") {
            if let photoID = store.currentPhotoID { store.setRating(0, for: photoID, autoAdvance: false) }
            return .handled
        }
        .focusable()
    }
}

struct GridPhotoCell: View {
    let photo: PhotoItem
    @ObservedObject var store: PhotoStore
    let isSelected: Bool
    
    var body: some View {
        ZStack(alignment: .topLeading) {
            AsyncThumbnailView(photo: photo, previewSize: .thumbnail, interpolation: .high)
                .aspectRatio(1.0, contentMode: .fill)
                .clipped()

            // Rating - Kompakter
            if photo.rating > 0 {
                HStack(spacing: 3) {
                    Image(systemName: "star.fill")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor(DesignSystem.Colors.star)
                    Text("\(photo.rating)")
                        .font(.system(size: 10, weight: .bold))
                        .foregroundColor(.white)
                        .monospacedDigit()
                }
                .padding(.horizontal, 6)
                .padding(.vertical, 3)
                .background(Color.black.opacity(0.7))
                .cornerRadius(4)
                .padding(4)
            }
            
            // Selection Indicator - Lightroom Style
            if isSelected {
                Rectangle()
                    .stroke(DesignSystem.Colors.accent, lineWidth: 2)
            }
        }
        .aspectRatio(1.0, contentMode: .fit)
    }
}

