//
//  RootView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit

struct RootView: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @StateObject private var settings = AppSettings.shared
    
    var body: some View {
        HSplitView {
            if uiState.showLeftSidebar || settings.sidebarAlwaysVisible {
                FinderLikeSidebar(store: store)
                    .frame(minWidth: 160, idealWidth: 180, maxWidth: 240)
            }
            
            MainContentView()
            
            if uiState.showRightSidebar {
                AdjustmentsSidebar(store: store)
                    .frame(minWidth: 160, idealWidth: 180, maxWidth: 280)
            }
        }
        .background(DesignSystem.Colors.background)
        .toolbar {
            ToolbarItem(placement: .navigation) {
                Button(action: {
                    // Wenn "immer sichtbar" aktiv ist, soll die Sidebar nicht ausgeblendet werden.
                    if settings.sidebarAlwaysVisible {
                        uiState.showLeftSidebar = true
                    } else {
                        uiState.showLeftSidebar.toggle()
                    }
                }) {
                    Image(systemName: "sidebar.left")
                }
                .disabled(settings.sidebarAlwaysVisible)
                .help(settings.sidebarAlwaysVisible ? "Sidebar ist in den Einstellungen als 'immer sichtbar' aktiviert" : "Sidebar ein-/ausblenden")
            }

            // Titlebar Quick Actions (Workflow wie in Lightroom: wichtige Aktionen ohne Menü)
            ToolbarItemGroup(placement: .automatic) {
                Button(action: openFolderFromTitlebar) {
                    Image(systemName: "folder.badge.plus")
                }
                .help("Ordner öffnen…")

                Menu {
                    Button("Speichern") {
                        if let photo = store.currentPhoto {
                            SaveService.shared.saveOriginal(photo: photo)
                        }
                    }
                    Button("Kopie speichern unter…") {
                        if let photo = store.currentPhoto {
                            SaveService.shared.saveCopyAs(photo: photo)
                        }
                    }
                } label: {
                    Image(systemName: "square.and.arrow.down")
                }
                .help("Speichern")
                .disabled(store.currentPhoto == nil)

                Button(action: { uiState.activeSheet = .export }) {
                    Image(systemName: "square.and.arrow.up")
                }
                .help("Exportieren…")

                Button(action: { uiState.activeSheet = .settings }) {
                    Image(systemName: "gearshape")
                }
                .help("Einstellungen")

                Button(action: { uiState.activeSheet = .batchExport }) {
                    Image(systemName: "tray.and.arrow.up")
                }
                .help("Batch Export")

                Menu {
                    Button("Exportieren…") { uiState.activeSheet = .export }
                    Button("Batch Export…") { uiState.activeSheet = .batchExport }
                    Divider()
                    Button("Upload-Ziele verwalten…") { uiState.activeSheet = .uploadSettings }
                    Button("Export-Queue Einstellungen…") { uiState.activeSheet = .exportQueueSettings }
                    Divider()
                    Button("Backup & Wiederherstellung…") { uiState.activeSheet = .backupRestore }
                } label: {
                    Image(systemName: "ellipsis.circle")
                }
                .help("Weitere Aktionen")
            }
            
            ToolbarItem(placement: .primaryAction) {
                Button(action: { uiState.showRightSidebar.toggle() }) {
                    Image(systemName: "sidebar.right")
                }
            }
        }
        .onAppear {
            store.setup(uiState: uiState)
            // Kein Auto-Load von ~/Pictures: In der Sandbox fehlt ohne User-Interaktion die Permission.
            // Der User soll bewusst einen Ordner über Sidebar / "Ordner öffnen…" auswählen.
            if settings.sidebarAlwaysVisible {
                uiState.showLeftSidebar = true
            }
        }
        .sheet(item: $uiState.activeSheet) { route in
            switch route {
            case .settings:
                SettingsView(store: store)
            case .export:
                ExportPanel(store: store)
            case .batchExport:
                BatchExportView(store: store)
            case .uploadSettings:
                UploadSettingsView(store: store)
            case .exportQueueSettings:
                ExportQueueSettingsView(store: store)
            case .backupRestore:
                BackupRestoreView(store: store)
            }
        }
    }

    // MARK: - Titlebar: Ordner öffnen (gleiches Verhalten wie in Finder-Sidebar)
    private func openFolderFromTitlebar() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = false
        panel.title = "Ordner auswählen"
        panel.prompt = "Öffnen"
        panel.message = "Wählen Sie einen Ordner mit Bildern aus"
        panel.directoryURL = nil

        if panel.runModal() == .OK, let url = panel.url {
            saveBookmark(for: url)
            store.loadPhotos(from: url)
            addPathToUserDefaultsList(key: "favoriteFolders", url: url, limit: 10)
            addPathToUserDefaultsList(key: "recentFolders", url: url, limit: 12)
            NotificationCenter.default.post(name: NSNotification.Name("SidebarFoldersUpdated"), object: nil)
        }
    }

    private func saveBookmark(for url: URL) {
        do {
            let bookmarkData = try url.bookmarkData(
                options: [.withSecurityScope],
                includingResourceValuesForKeys: nil,
                relativeTo: nil
            )
            var bookmarks = UserDefaults.standard.dictionary(forKey: "folderBookmarks") ?? [:]
            bookmarks[url.path] = bookmarkData
            UserDefaults.standard.set(bookmarks, forKey: "folderBookmarks")
        } catch {
            print("Fehler beim Speichern des Bookmarks: \(error)")
        }
    }

    private func addPathToUserDefaultsList(key: String, url: URL, limit: Int) {
        var paths = UserDefaults.standard.stringArray(forKey: key) ?? []
        let standardized = url.standardizedFileURL.path
        paths.removeAll { URL(fileURLWithPath: $0).standardizedFileURL.path == standardized }
        paths.insert(url.path, at: 0)
        if paths.count > limit {
            paths = Array(paths.prefix(limit))
        }
        UserDefaults.standard.set(paths, forKey: key)
    }
}

struct MainContentView: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    var body: some View {
        VStack(spacing: 0) {
            TopTabBar()
            
            ZStack {
                switch uiState.viewMode {
                case .detail:
                    DetailView(store: store)
                case .grid:
                    // Pass the filtered photos to the GridView
                    GridView(photos: store.filteredPhotos, store: store)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            if uiState.viewMode == .detail {
                // Pass the filtered photos to the FilmstripView
                FilmstripView(photos: store.filteredPhotos, store: store)
                    .frame(height: 120)
            }
        }
        .background(DesignSystem.Colors.background)
    }
}

struct TopTabBar: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    var body: some View {
        HStack(spacing: 0) {
            // View Mode Buttons - Kompakt
            ViewModeButtons()
                .padding(.leading, DesignSystem.Spacing.medium)
            
            // Separator
            Rectangle()
                .fill(DesignSystem.Colors.border)
                .frame(width: 1, height: 32)
                .padding(.horizontal, DesignSystem.Spacing.small)
            
            // Rating Filter - Kompakt
            RatingFilterView()
            
            // Ordner / Status (Lightroom-Style)
            FolderStatusView()
                .padding(.leading, DesignSystem.Spacing.small)
            
            Spacer()
            
            // Action Buttons
            ActionButtons()
                .padding(.trailing, DesignSystem.Spacing.medium)
        }
        .frame(height: 48)
        .background(DesignSystem.Colors.background2)
        .overlay(
            Rectangle()
                .frame(height: 1)
                .foregroundColor(DesignSystem.Colors.border),
            alignment: .bottom
        )
    }
}

struct ViewModeButtons: View {
    @EnvironmentObject var uiState: UIState

    var body: some View {
        HStack(spacing: 2) {
            ViewModeButton(imageName: "photo", mode: .detail, currentMode: $uiState.viewMode)
            ViewModeButton(imageName: "square.grid.2x2", mode: .grid, currentMode: $uiState.viewMode)
        }
        .padding(4)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
}

struct ViewModeButton: View {
    let imageName: String
    let mode: ViewMode
    @Binding var currentMode: ViewMode

    var isSelected: Bool {
        currentMode == mode
    }

    var body: some View {
        Button(action: { currentMode = mode }) {
            Image(systemName: imageName)
                .font(DesignSystem.Fonts.medium(size: 14))
                .foregroundColor(isSelected ? Color.white : DesignSystem.Colors.text2)
                .frame(width: 36, height: 32)
                .background(isSelected ? DesignSystem.Colors.accent : Color.clear)
                .cornerRadius(DesignSystem.CornerRadius.small)
        }
        .buttonStyle(.plain)
        .help(mode == .detail ? "Detail-Ansicht" : "Grid-Ansicht")
    }
}

struct RatingFilterView: View {
    @EnvironmentObject var uiState: UIState

    var body: some View {
        HStack(spacing: 4) {
            RatingFilterButton(rating: 0, currentFilter: $uiState.ratingFilter)
            
            Rectangle()
                .fill(DesignSystem.Colors.border2)
                .frame(width: 1, height: 20)
                .padding(.horizontal, 4)
            
            ForEach(1...5, id: \.self) { rating in
                RatingFilterButton(rating: rating, currentFilter: $uiState.ratingFilter)
            }
        }
        .padding(4)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
}

struct RatingFilterButton: View {
    let rating: Int
    @Binding var currentFilter: Int?
    
    var isSelected: Bool {
        currentFilter == (rating == 0 ? nil : rating)
    }

    var body: some View {
        Button(action: {
            currentFilter = (rating == 0 ? nil : rating)
        }) {
            if rating == 0 {
                Text("Alle")
                    .font(DesignSystem.Fonts.medium(size: 11))
                    .foregroundColor(isSelected ? Color.white : DesignSystem.Colors.text3)
                    .frame(width: 44, height: 24)
            } else {
                HStack(spacing: 3) {
                    Image(systemName: "star.fill")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(isSelected ? DesignSystem.Colors.star : DesignSystem.Colors.text3)
                    Text("\(rating)")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(isSelected ? Color.white : DesignSystem.Colors.text3)
                        .monospacedDigit()
                }
                .frame(width: 32, height: 24)
            }
        }
        .buttonStyle(.plain)
        .background(isSelected ? DesignSystem.Colors.background : Color.clear)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
}


struct ActionButtons: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState

    var body: some View {
        HStack(spacing: 6) {
            TopBarIconButton(
                systemName: "rectangle.split.2x1",
                help: "Before/After umschalten",
                isActive: uiState.showBeforeAfter,
                action: { uiState.showBeforeAfter.toggle() }
            )
            
            TopBarIconButton(
                systemName: "wand.and.stars",
                help: "Auto-Verbesserung",
                action: applyAutoEnhancement
            )
            
            TopBarIconButton(
                systemName: "square.and.arrow.up",
                help: "Exportieren",
                action: { uiState.activeSheet = .export }
            )
        }
    }
    
    private func applyAutoEnhancement() {
        guard let photo = store.currentPhoto else { return }
        // Implementation for auto-enhancement
        Task {
            let service = await AutoAdjustmentService.shared
            if let adjustments = await service.analyzeAndAdjust(photo: photo) {
                await MainActor.run {
                    photo.adjustments = adjustments
                    // Trigger DetailView reprocess (wir verlassen uns auf Notification statt auf onChange-Spam)
                    NotificationCenter.default.post(
                        name: NSNotification.Name("PhotoAdjustmentsChanged"),
                        object: nil,
                        userInfo: ["photoID": photo.id]
                    )
                }
            }
        }
    }
    
}

// MARK: - Button Styles & View Modifiers

struct TopBarIconButton: View {
    let systemName: String
    let help: String
    var isActive: Bool = false
    let action: () -> Void
    
    @State private var isHovering = false
    
    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(DesignSystem.Fonts.medium(size: 14))
                .foregroundColor(isActive ? Color.white : DesignSystem.Colors.text)
                .frame(width: 32, height: 32)
                .background(backgroundColor)
                .cornerRadius(DesignSystem.CornerRadius.small)
        }
        .buttonStyle(.plain)
        .help(help)
        .onHover { hovering in
            isHovering = hovering
        }
    }
    
    private var backgroundColor: Color {
        if isActive {
            return DesignSystem.Colors.accent.opacity(0.25)
        }
        if isHovering {
            return DesignSystem.Colors.background4
        }
        return Color.clear
    }
}

struct FolderStatusView: View {
    @EnvironmentObject var store: PhotoStore
    
    var body: some View {
        HStack(spacing: 8) {
            if store.isLoadingPhotos {
                ProgressView()
                    .tint(DesignSystem.Colors.text2)
                    .controlSize(.small)
                    .frame(width: 14, height: 14)
            }
            
            Image(systemName: "folder")
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(DesignSystem.Colors.text3)
            
            Text(folderTitle)
                .font(DesignSystem.Fonts.medium(size: 12))
                .foregroundColor(DesignSystem.Colors.text2)
                .lineLimit(1)
                .truncationMode(.middle)
            
            if totalCount > 0 {
                Text("•")
                    .foregroundColor(DesignSystem.Colors.text4)
                
                Text("\(currentIndex)/\(totalCount)")
                    .font(DesignSystem.Fonts.medium(size: 12))
                    .foregroundColor(DesignSystem.Colors.text3)
                    .monospacedDigit()
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
        .overlay(
            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
        .frame(maxWidth: 520, alignment: .leading)
    }
    
    private var folderTitle: String {
        store.currentFolder?.lastPathComponent ?? "Kein Ordner"
    }
    
    private var totalCount: Int {
        store.filteredPhotos.count
    }
    
    private var currentIndex: Int {
        guard let idx = store.currentPhotoIndexInFiltered else { return 0 }
        return idx + 1
    }
}

struct PrimaryActionButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(DesignSystem.Fonts.medium(size: 12))
            .foregroundColor(DesignSystem.Colors.text)
            .padding(.horizontal, DesignSystem.Spacing.medium)
            .padding(.vertical, DesignSystem.Spacing.small - 2)
            .background(DesignSystem.Colors.accent)
            .cornerRadius(DesignSystem.CornerRadius.small)
            .opacity(configuration.isPressed ? 0.8 : 1.0)
    }
}

struct SecondaryActionButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(DesignSystem.Fonts.medium(size: 12))
            .foregroundColor(DesignSystem.Colors.text)
            .padding(.horizontal, DesignSystem.Spacing.medium)
            .padding(.vertical, DesignSystem.Spacing.small - 2)
            .background(DesignSystem.Colors.background3)
            .cornerRadius(DesignSystem.CornerRadius.small)
            .opacity(configuration.isPressed ? 0.8 : 1.0)
    }
}

extension View {
    func border(width: CGFloat, edges: [Edge], color: Color) -> some View {
        overlay(EdgeBorder(width: width, edges: edges).foregroundColor(color))
    }
}

struct EdgeBorder: Shape {
    var width: CGFloat
    var edges: [Edge]

    func path(in rect: CGRect) -> Path {
        var path = Path()
        for edge in edges {
            var x: CGFloat {
                switch edge {
                case .top, .bottom, .leading: return rect.minX
                case .trailing: return rect.maxX - width
                }
            }

            var y: CGFloat {
                switch edge {
                case .top, .leading, .trailing: return rect.minY
                case .bottom: return rect.maxY - width
                }
            }

            var w: CGFloat {
                switch edge {
                case .top, .bottom: return rect.width
                case .leading, .trailing: return width
                }
            }

            var h: CGFloat {
                switch edge {
                case .top, .bottom: return width
                case .leading, .trailing: return rect.height
                }
            }
            path.addPath(Path(CGRect(x: x, y: y, width: w, height: h)))
        }
        return path
    }
}

