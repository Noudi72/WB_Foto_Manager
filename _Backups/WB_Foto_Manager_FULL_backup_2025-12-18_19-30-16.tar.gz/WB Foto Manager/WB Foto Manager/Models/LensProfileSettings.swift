//
//  LensProfileSettings.swift
//  WB Foto Manager
//
//  Profile-based lens corrections (Lightroom-like)
//

import Foundation

nonisolated enum LensProfileMode: String, Codable, Hashable, CaseIterable, Sendable {
    case auto
    case manual
    
    var title: String {
        switch self {
        case .auto: return "Auto"
        case .manual: return "Manuell"
        }
    }
}

nonisolated struct LensProfileSettings: Codable, Hashable, Sendable {
    /// Enable profile-based corrections (distortion + vignette based on lens profile).
    var enabled: Bool = false
    var mode: LensProfileMode = .auto
    /// Only used when mode == .manual.
    var manualProfileID: String = ""
    /// Amount scaling (0...2). 1.0 = 100%.
    var amount: Double = 1.0
    
    /// Apply profile distortion correction.
    var correctDistortion: Bool = true
    /// Apply profile vignetting correction.
    var correctVignette: Bool = true
    /// Apply chromatic aberration correction (either profile driven or generic).
    var removeChromaticAberration: Bool = true
    
    nonisolated init(
        enabled: Bool = false,
        mode: LensProfileMode = .auto,
        manualProfileID: String = "",
        amount: Double = 1.0,
        correctDistortion: Bool = true,
        correctVignette: Bool = true,
        removeChromaticAberration: Bool = true
    ) {
        self.enabled = enabled
        self.mode = mode
        self.manualProfileID = manualProfileID
        self.amount = amount
        self.correctDistortion = correctDistortion
        self.correctVignette = correctVignette
        self.removeChromaticAberration = removeChromaticAberration
    }
    
    nonisolated var isDefault: Bool {
        enabled == false &&
        mode == .auto &&
        manualProfileID.isEmpty &&
        abs(amount - 1.0) < 0.0001 &&
        correctDistortion == true &&
        correctVignette == true &&
        removeChromaticAberration == true
    }
}


