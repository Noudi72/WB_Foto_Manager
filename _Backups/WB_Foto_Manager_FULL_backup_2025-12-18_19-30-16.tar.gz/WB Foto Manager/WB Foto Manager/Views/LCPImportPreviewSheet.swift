//
//  LCPImportPreviewSheet.swift
//  WB Foto Manager
//
//  Batch import preview for Adobe Lens Correction Profiles (.lcp)
//

import SwiftUI

struct LCPImportPreviewSheet: View {
    let urls: [URL]
    
    @Environment(\.dismiss) private var dismiss
    
    @State private var isLoading: Bool = true
    @State private var rows: [PreviewRow] = []
    @State private var selected: Set<UUID> = []
    @State private var fileErrors: [String] = []
    
    @State private var importInProgress: Bool = false
    @State private var importError: String?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            header
            
            if isLoading {
                HStack(spacing: 10) {
                    ProgressView().controlSize(.small)
                    Text("Analysiere LCP Dateien…")
                        .font(DesignSystem.Fonts.regular(size: 12))
                        .foregroundColor(DesignSystem.Colors.text2)
                }
                .padding(.vertical, 10)
            } else {
                content
            }
            
            footer
        }
        .padding(14)
        .frame(width: 900, height: 600)
        .background(DesignSystem.Colors.background2)
        .lightroomSidebarTheme()
        .task { await loadPreview() }
        .alert("Import fehlgeschlagen", isPresented: Binding(get: { importError != nil }, set: { if !$0 { importError = nil } })) {
            Button("OK") { importError = nil }
        } message: {
            Text(importError ?? "")
        }
    }
    
    private var header: some View {
        HStack(alignment: .firstTextBaseline) {
            VStack(alignment: .leading, spacing: 2) {
                Text("LCP Import – Vorschau")
                    .font(DesignSystem.Fonts.semibold(size: 16))
                    .foregroundColor(DesignSystem.Colors.text)
                Text("\(urls.count) Datei(en) • Wähle die Profile aus, die importiert werden sollen.")
                    .font(DesignSystem.Fonts.regular(size: 11))
                    .foregroundColor(DesignSystem.Colors.text3)
            }
            
            Spacer()
            
            Button("Schließen") { dismiss() }
                .buttonStyle(LightroomSecondaryButtonStyle())
        }
    }
    
    private var content: some View {
        VStack(alignment: .leading, spacing: 10) {
            if !fileErrors.isEmpty {
                GroupBox {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Fehler")
                            .font(DesignSystem.Fonts.semibold(size: 12))
                            .foregroundColor(DesignSystem.Colors.text)
                        ForEach(fileErrors, id: \.self) { err in
                            Text("• \(err)")
                                .font(DesignSystem.Fonts.regular(size: 11))
                                .foregroundColor(DesignSystem.Colors.text2)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                    .padding(8)
                }
                .groupBoxStyle(.automatic)
            }
            
            GroupBox {
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 8) {
                        if rows.isEmpty {
                            Text("Keine Profile gefunden.")
                                .font(DesignSystem.Fonts.regular(size: 12))
                                .foregroundColor(DesignSystem.Colors.text3)
                                .padding(.vertical, 10)
                        } else {
                            ForEach(rows) { row in
                                rowView(row)
                            }
                        }
                    }
                    .padding(10)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .groupBoxStyle(.automatic)
        }
    }
    
    private var footer: some View {
        HStack(spacing: 10) {
            Button("Alle auswählen") { selectAll() }
                .buttonStyle(LightroomSecondaryButtonStyle())
                .disabled(rows.isEmpty || importInProgress)
            
            Button("Alle abwählen") { selected.removeAll() }
                .buttonStyle(LightroomSecondaryButtonStyle())
                .disabled(rows.isEmpty || importInProgress)
            
            Spacer()
            
            if importInProgress {
                HStack(spacing: 10) {
                    ProgressView().controlSize(.small)
                    Text("Importiere…")
                        .font(DesignSystem.Fonts.regular(size: 12))
                        .foregroundColor(DesignSystem.Colors.text2)
                }
            }
            
            Button("Importieren (\(selected.count))") { importSelected() }
                .buttonStyle(.borderedProminent)
                .disabled(selected.isEmpty || importInProgress)
        }
    }
    
    private func rowView(_ row: PreviewRow) -> some View {
        let isOn = selected.contains(row.id)
        
        return HStack(spacing: 10) {
            Toggle(isOn: Binding(
                get: { isOn },
                set: { newValue in
                    setSelected(newValue, for: row)
                }
            )) {
                VStack(alignment: .leading, spacing: 3) {
                    HStack(spacing: 8) {
                        Text(row.profile.name)
                            .font(DesignSystem.Fonts.medium(size: 12))
                            .foregroundColor(DesignSystem.Colors.text)
                            .lineLimit(1)
                        
                        statusBadge(row)
                        
                        Spacer()
                        
                        Text(row.sourceFile)
                            .font(DesignSystem.Fonts.regular(size: 10))
                            .foregroundColor(DesignSystem.Colors.text4)
                            .lineLimit(1)
                    }
                    
                    Text(row.summary)
                        .font(DesignSystem.Fonts.regular(size: 10))
                        .foregroundColor(DesignSystem.Colors.text3)
                        .lineLimit(2)
                    
                    if !row.warnings.isEmpty {
                        Text(row.warnings.joined(separator: " • "))
                            .font(DesignSystem.Fonts.regular(size: 10))
                            .foregroundColor(DesignSystem.Colors.text2)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
            }
            .toggleStyle(.checkbox)
        }
        .padding(10)
        .background(DesignSystem.Colors.background4)
        .overlay(
            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
    
    private func statusBadge(_ row: PreviewRow) -> some View {
        let text: String
        let bg: Color
        
        if row.isDuplicateInBatch {
            text = "Duplikat"
            bg = Color.orange.opacity(0.35)
        } else if let existingName = row.existingProfileName, !existingName.isEmpty {
            text = "Ersetzt"
            bg = Color.blue.opacity(0.35)
        } else {
            text = "Neu"
            bg = Color.green.opacity(0.25)
        }
        
        return Text(text)
            .font(DesignSystem.Fonts.semibold(size: 10))
            .foregroundColor(DesignSystem.Colors.text)
            .padding(.horizontal, 8)
            .padding(.vertical, 3)
            .background(bg)
            .cornerRadius(999)
    }
    
    // MARK: - Load
    
    @MainActor
    private func loadPreview() async {
        isLoading = true
        rows = []
        selected = []
        fileErrors = []
        
        let existing = await LensProfileService.shared.userProfilesSnapshot()
        let existingByKey: [String: LensProfile] = {
            var dict: [String: LensProfile] = [:]
            for p in existing {
                if dict[p.normalizedMatchKey] == nil {
                    dict[p.normalizedMatchKey] = p
                }
            }
            return dict
        }()
        
        var newRows: [PreviewRow] = []
        var errors: [String] = []
        
        for url in urls {
            do {
                let profiles = try await LensProfileService.shared.previewLCP(from: url)
                for p in profiles {
                    let key = p.normalizedMatchKey
                    let existingMatch = existingByKey[key]
                    let warnings = buildWarnings(for: p)
                    newRows.append(
                        PreviewRow(
                            id: UUID(),
                            sourceURL: url,
                            sourceFile: url.lastPathComponent,
                            profile: p,
                            matchKey: key,
                            existingProfileID: existingMatch?.id,
                            existingProfileName: existingMatch?.name,
                            warnings: warnings,
                            isDuplicateInBatch: false
                        )
                    )
                }
            } catch {
                errors.append("\(url.lastPathComponent): \(error.localizedDescription)")
            }
        }
        
        // Mark duplicates within the import set (by matchKey).
        var firstRowIDForKey: [String: UUID] = [:]
        var selectedIDs: Set<UUID> = []
        for idx in newRows.indices {
            let key = newRows[idx].matchKey
            if let first = firstRowIDForKey[key] {
                newRows[idx].isDuplicateInBatch = true
                // default: only the first one selected (prevents accidental overwrite).
                _ = first
            } else {
                firstRowIDForKey[key] = newRows[idx].id
                selectedIDs.insert(newRows[idx].id)
            }
        }
        
        rows = newRows
        selected = selectedIDs
        fileErrors = errors
        isLoading = false
    }
    
    private func buildWarnings(for profile: LensProfile) -> [String] {
        var w: [String] = []
        if profile.lensModelContains.joined().trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            w.append("Match‑Regel: Objektiv fehlt")
        }
        if profile.cameraMakeContains.joined().trimmingCharacters(in: .whitespacesAndNewlines).isEmpty,
           profile.cameraModelContains.joined().trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            w.append("Match‑Regel: Kamera fehlt")
        }
        if profile.correctionPoints.isEmpty {
            w.append("Keine Brennweiten‑Punkte")
        }
        return w
    }
    
    // MARK: - Selection
    
    private func setSelected(_ on: Bool, for row: PreviewRow) {
        if on {
            selected.insert(row.id)
            // Enforce single selection per matchKey to avoid conflicts/overwrites.
            for other in rows where other.matchKey == row.matchKey && other.id != row.id {
                selected.remove(other.id)
            }
        } else {
            selected.remove(row.id)
        }
    }
    
    private func selectAll() {
        // Select at most one per matchKey (first occurrence).
        var ids: Set<UUID> = []
        var seen: Set<String> = []
        for r in rows {
            guard !seen.contains(r.matchKey) else { continue }
            seen.insert(r.matchKey)
            ids.insert(r.id)
        }
        selected = ids
    }
    
    // MARK: - Import
    
    private func importSelected() {
        Task { @MainActor in
            importInProgress = true
            defer { importInProgress = false }
            
            let selectedRows = rows.filter { selected.contains($0.id) }
            guard !selectedRows.isEmpty else { return }
            
            let profilesToSave: [LensProfile] = selectedRows.map { r in
                if let existingID = r.existingProfileID {
                    return r.profile.copy(withID: existingID)
                }
                return r.profile
            }
            
            await LensProfileService.shared.upsertUserProfiles(profilesToSave)
            dismiss()
        }
    }
    
    // MARK: - Row Model
    
    struct PreviewRow: Identifiable {
        let id: UUID
        let sourceURL: URL
        let sourceFile: String
        let profile: LensProfile
        let matchKey: String
        let existingProfileID: String?
        let existingProfileName: String?
        let warnings: [String]
        var isDuplicateInBatch: Bool
        
        var summary: String {
            let lens = profile.lensModelContains.first ?? "—"
            let cam = profile.cameraModelContains.first ?? profile.cameraMakeContains.first ?? "—"
            let points = profile.correctionPoints.isEmpty ? "1×" : "\(profile.correctionPoints.count)×"
            return "Lens: \(lens) • Cam: \(cam) • Points: \(points)"
        }
    }
}


