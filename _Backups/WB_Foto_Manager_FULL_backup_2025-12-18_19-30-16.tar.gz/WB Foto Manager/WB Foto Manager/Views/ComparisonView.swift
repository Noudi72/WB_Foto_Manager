//
//  ComparisonView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit

/// Compare/Culling Mode (Lightroom-like): Hauptfoto + Vergleichs-Strip rechts.
struct CompareModeView: View {
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    @State private var bestShotID: UUID?
    
    private var mainPhoto: PhotoItem? { store.currentPhoto }
    private let burstMaxCount: Int = 12
    private let burstWindowSeconds: TimeInterval = 0.8
    
    /// Selected photos in current order (filteredPhotos preserves sorting).
    private var selectedOrdered: [PhotoItem] {
        store.filteredPhotos.filter { store.selectedPhotoIDs.contains($0.id) }
    }
    
    private func comparisonCandidates(for main: PhotoItem) -> [PhotoItem] {
        let selectedOthers = selectedOrdered.filter { $0.id != main.id }
        if !selectedOthers.isEmpty {
            return Array(selectedOthers.prefix(12))
        }
        
        // Smart Culling: Burst-Group anhand Aufnahmedatum (sehr nützlich bei Sport/Serien).
        let burst = burstGroup(around: main, in: store.filteredPhotos, maxCount: burstMaxCount, windowSeconds: burstWindowSeconds)
        let burstOthers = burst.filter { $0.id != main.id }
        if !burstOthers.isEmpty {
            return Array(burstOthers.prefix(burstMaxCount))
        }
        
        // Fallback: wenn keine Mehrfachauswahl aktiv ist, nimm die nächsten Fotos als "Compare Strip".
        if let idx = store.currentPhotoIndexInFiltered {
            let next = store.filteredPhotos.dropFirst(idx + 1).prefix(12)
            return Array(next)
        }
        return []
    }
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            if let main = mainPhoto {
                let candidates = comparisonCandidates(for: main)
                if candidates.isEmpty {
                    CompareEmptyStateView(
                        canSelectBurst: burstGroup(around: main, in: store.filteredPhotos, maxCount: burstMaxCount, windowSeconds: burstWindowSeconds).count > 1,
                        onSelectBurst: { selectBurst(around: main) }
                    )
                } else {
                    let groupForBestShot = [main] + candidates
                    ComparisonView(
                        mainPhoto: main,
                        comparisonPhotos: candidates,
                        bestShotID: bestShotID,
                        store: store
                    )
                    .task(id: groupForBestShot.map(\.id)) {
                        await updateBestShot(for: groupForBestShot)
                    }
                    .overlay(alignment: .topLeading) {
                        CompareTopOverlay(
                            store: store,
                            bestShotID: bestShotID,
                            groupIDs: groupForBestShot.map(\.id),
                            onSelectBurst: { selectBurst(around: main) }
                        )
                        .padding(10)
                    }
                }
            } else {
                VStack(spacing: 10) {
                    Text("Compare")
                        .font(DesignSystem.Fonts.semibold(size: 18))
                        .foregroundColor(.white)
                    Text("Wähle ein Foto aus, um zu vergleichen.")
                        .font(DesignSystem.Fonts.regular(size: 12))
                        .foregroundColor(.white.opacity(0.75))
                    
                    Button("Zur Grid‑Ansicht") {
                        uiState.viewMode = .grid
                    }
                    .buttonStyle(.borderedProminent)
                }
            }
        }
    }
    
    private func selectBurst(around main: PhotoItem) {
        let burst = burstGroup(around: main, in: store.filteredPhotos, maxCount: burstMaxCount, windowSeconds: burstWindowSeconds)
        guard burst.count > 1 else { return }
        uiState.selectionMode = true
        store.selectedPhotoIDs = Set(burst.map(\.id))
        store.currentPhotoID = main.id
    }
    
    private func updateBestShot(for photos: [PhotoItem]) async {
        // MVP: nur für kleine Gruppen (Burst/Compare Strip)
        guard photos.count >= 2 else {
            await MainActor.run { self.bestShotID = photos.first?.id }
            return
        }
        
        let refs = photos.map { BestShotService.PhotoRef(id: $0.id, url: $0.url) }
        let best = await BestShotService.shared.bestPhotoID(in: refs)
        await MainActor.run { self.bestShotID = best }
    }
}

private struct CompareTopOverlay: View {
    @ObservedObject var store: PhotoStore
    let bestShotID: UUID?
    let groupIDs: [UUID]
    let onSelectBurst: () -> Void
    
    var body: some View {
        HStack(spacing: 8) {
            Button(action: pickBestOnly) {
                Label("BEST als Pick", systemImage: "crown.fill")
                    .font(DesignSystem.Fonts.medium(size: 12))
            }
            .buttonStyle(.borderedProminent)
            .disabled(bestShotID == nil)
            .help("Markiert den Best‑Shot in dieser Serie als Pick (P)")
            
            Menu {
                Button("BEST als Pick, Rest unflag") {
                    applyPickBurst(restStatus: .unflagged)
                }
                
                Button("BEST als Pick, Rest Reject…") {
                    confirmAndRejectRest()
                }
            } label: {
                Label("Burst aufräumen", systemImage: "checkmark.seal")
                    .font(DesignSystem.Fonts.medium(size: 12))
            }
            .menuStyle(.borderlessButton)
            .disabled(bestShotID == nil || groupIDs.count < 2)
            .help("Markiert BEST als Pick und setzt den Rest der Serie auf Unflag oder Reject")
            
            Button(action: onSelectBurst) {
                Label("Burst auswählen", systemImage: "bolt.fill")
                    .font(DesignSystem.Fonts.medium(size: 12))
            }
            .buttonStyle(.bordered)
            .help("Wählt ähnliche Shots rund um das aktuelle Foto (serien/burst) aus")
        }
    }
    
    private func pickBestOnly() {
        guard let id = bestShotID else { return }
        store.setPickStatus(.pick, for: id, autoAdvance: false)
    }
    
    private func applyPickBurst(restStatus: PickStatus) {
        guard let best = bestShotID else { return }
        guard groupIDs.count >= 2 else { return }
        
        store.applyPickBurst(bestID: best, groupIDs: groupIDs, restStatus: restStatus)
    }
    
    private func confirmAndRejectRest() {
        guard let best = bestShotID else { return }
        guard groupIDs.count >= 2 else { return }
        
        let restCount = max(0, groupIDs.count - 1)
        let alert = NSAlert()
        alert.messageText = "Burst aufräumen – Rest als Reject?"
        alert.informativeText = "BEST wird als Pick markiert.\n\(restCount) weiteres Bild(er) werden als Reject markiert.\n\nTipp: Du kannst Rejects später gesammelt löschen."
        alert.alertStyle = .warning
        alert.addButton(withTitle: "Reject setzen")
        alert.addButton(withTitle: "Abbrechen")
        
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        store.applyPickBurst(bestID: best, groupIDs: groupIDs, restStatus: .reject)
    }
}

private struct CompareEmptyStateView: View {
    @EnvironmentObject var uiState: UIState
    let canSelectBurst: Bool
    let onSelectBurst: () -> Void
    
    var body: some View {
        VStack(spacing: 12) {
            Text("Compare / Culling")
                .font(DesignSystem.Fonts.semibold(size: 18))
                .foregroundColor(.white)
            
            Text("Tipp: Aktiviere „Mehrfachauswahl“ und wähle mindestens 2 Fotos aus.\nDann kannst du rechts schnell durch ähnliche Shots klicken.")
                .font(DesignSystem.Fonts.regular(size: 12))
                .foregroundColor(.white.opacity(0.75))
                .multilineTextAlignment(.center)
            
            HStack(spacing: 10) {
                Button("Mehrfachauswahl aktivieren") {
                    uiState.selectionMode = true
                }
                .buttonStyle(.borderedProminent)
                
                if canSelectBurst {
                    Button("Burst auswählen") {
                        onSelectBurst()
                    }
                    .buttonStyle(.bordered)
                }
                
                Button("Zur Grid‑Ansicht") {
                    uiState.viewMode = .grid
                }
                .buttonStyle(.bordered)
            }
        }
        .padding(24)
    }
}

/// Survey Mode (Lightroom-like): mehrere ausgewählte Fotos groß vergleichen.
struct SurveyModeView: View {
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    @State private var bestShotID: UUID?
    
    private var selectedOrdered: [PhotoItem] {
        store.filteredPhotos.filter { store.selectedPhotoIDs.contains($0.id) }
    }
    
    private var columnsCount: Int {
        let n = selectedOrdered.count
        if n <= 1 { return 1 }
        if n == 2 { return 2 }
        if n <= 4 { return 2 }
        if n <= 9 { return 3 }
        return 4
    }
    
    private var grid: [GridItem] {
        Array(repeating: GridItem(.flexible(minimum: 180, maximum: 1000), spacing: 8), count: columnsCount)
    }
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            if selectedOrdered.count <= 1 {
                SurveyEmptyStateView(
                    canSelectBurst: (store.currentPhoto != nil) && burstGroup(around: store.currentPhoto!, in: store.filteredPhotos, maxCount: 12, windowSeconds: 0.8).count > 1,
                    onSelectBurst: {
                        if let main = store.currentPhoto {
                            let burst = burstGroup(around: main, in: store.filteredPhotos, maxCount: 12, windowSeconds: 0.8)
                            guard burst.count > 1 else { return }
                            uiState.selectionMode = true
                            store.selectedPhotoIDs = Set(burst.map(\.id))
                            store.currentPhotoID = main.id
                        }
                    }
                )
            } else {
                ScrollView {
                    LazyVGrid(columns: grid, alignment: .center, spacing: 8) {
                        ForEach(selectedOrdered) { photo in
                            SurveyPhotoCell(
                                photo: photo,
                                store: store,
                                isActive: store.currentPhotoID == photo.id,
                                isBest: bestShotID == photo.id
                            )
                            .aspectRatio(1.5, contentMode: .fit)
                            .contentShape(Rectangle())
                            .onTapGesture {
                                store.selectPhoto(photo)
                            }
                            .contextMenu {
                                Button("In Detail anzeigen") {
                                    store.selectPhoto(photo)
                                    uiState.viewMode = .detail
                                }
                            }
                        }
                    }
                    .padding(10)
                }
                .focusable()
                .task(id: selectedOrdered.map(\.id)) {
                    await updateBestShotForSurvey()
                }
                .overlay(alignment: .topLeading) {
                    SurveyTopOverlay(
                        store: store,
                        bestShotID: bestShotID,
                        groupIDs: selectedOrdered.map(\.id)
                    )
                    .padding(10)
                }
                .onKeyPress(.space) {
                    uiState.viewMode = .detail
                    return .handled
                }
                .onKeyPress("g") {
                    uiState.viewMode = .grid
                    return .handled
                }
            }
        }
    }
    
    private func updateBestShotForSurvey() async {
        // MVP: nur, wenn Auswahl nicht riesig ist (sonst wäre es zu teuer).
        let list = selectedOrdered
        guard list.count >= 2 else {
            await MainActor.run { self.bestShotID = list.first?.id }
            return
        }
        guard list.count <= 24 else {
            await MainActor.run { self.bestShotID = nil }
            return
        }
        
        let refs = list.map { BestShotService.PhotoRef(id: $0.id, url: $0.url) }
        let best = await BestShotService.shared.bestPhotoID(in: refs)
        await MainActor.run { self.bestShotID = best }
    }
}

private struct SurveyEmptyStateView: View {
    @EnvironmentObject var uiState: UIState
    let canSelectBurst: Bool
    let onSelectBurst: () -> Void
    
    var body: some View {
        VStack(spacing: 12) {
            Text("Survey")
                .font(DesignSystem.Fonts.semibold(size: 18))
                .foregroundColor(.white)
            
            Text("Tipp: Aktiviere „Mehrfachauswahl“ und wähle mindestens 2 Fotos aus.\nDann kannst du die Serie groß vergleichen.")
                .font(DesignSystem.Fonts.regular(size: 12))
                .foregroundColor(.white.opacity(0.75))
                .multilineTextAlignment(.center)
            
            HStack(spacing: 10) {
                Button("Mehrfachauswahl aktivieren") { uiState.selectionMode = true }
                    .buttonStyle(.borderedProminent)
                
                if canSelectBurst {
                    Button("Burst auswählen") { onSelectBurst() }
                        .buttonStyle(.bordered)
                }
                
                Button("Zur Grid‑Ansicht") { uiState.viewMode = .grid }
                    .buttonStyle(.bordered)
            }
        }
        .padding(24)
    }
}

private struct SurveyTopOverlay: View {
    @ObservedObject var store: PhotoStore
    let bestShotID: UUID?
    let groupIDs: [UUID]
    
    var body: some View {
        HStack(spacing: 8) {
            Button(action: pickBestOnly) {
                Label("BEST als Pick", systemImage: "crown.fill")
                    .font(DesignSystem.Fonts.medium(size: 12))
            }
            .buttonStyle(.borderedProminent)
            .disabled(bestShotID == nil)
            .help("Markiert den Best‑Shot in dieser Auswahl als Pick (P)")
            
            Menu {
                Button("BEST als Pick, Rest unflag") {
                    applyPickBurst(restStatus: .unflagged)
                }
                
                Button("BEST als Pick, Rest Reject…") {
                    confirmAndRejectRest()
                }
            } label: {
                Label("Auswahl aufräumen", systemImage: "checkmark.seal")
                    .font(DesignSystem.Fonts.medium(size: 12))
            }
            .menuStyle(.borderlessButton)
            .disabled(bestShotID == nil || groupIDs.count < 2)
            .help("Markiert BEST als Pick und setzt den Rest der Auswahl auf Unflag oder Reject")
        }
    }
    
    private func pickBestOnly() {
        guard let id = bestShotID else { return }
        store.setPickStatus(.pick, for: id, autoAdvance: false)
    }
    
    private func applyPickBurst(restStatus: PickStatus) {
        guard let best = bestShotID else { return }
        guard groupIDs.count >= 2 else { return }
        store.applyPickBurst(bestID: best, groupIDs: groupIDs, restStatus: restStatus)
    }
    
    private func confirmAndRejectRest() {
        guard let best = bestShotID else { return }
        guard groupIDs.count >= 2 else { return }
        
        let restCount = max(0, groupIDs.count - 1)
        let alert = NSAlert()
        alert.messageText = "Auswahl aufräumen – Rest als Reject?"
        alert.informativeText = "BEST wird als Pick markiert.\n\(restCount) weiteres Bild(er) werden als Reject markiert.\n\nTipp: Du kannst Rejects später gesammelt löschen."
        alert.alertStyle = .warning
        alert.addButton(withTitle: "Reject setzen")
        alert.addButton(withTitle: "Abbrechen")
        
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        store.applyPickBurst(bestID: best, groupIDs: groupIDs, restStatus: .reject)
    }
}

private struct SurveyPhotoCell: View {
    @ObservedObject var photo: PhotoItem
    @ObservedObject var store: PhotoStore
    let isActive: Bool
    let isBest: Bool
    
    var body: some View {
        ZStack {
            // Medium preview is a sweet spot for fast survey browsing.
            AsyncThumbnailView(photo: photo, previewSize: .medium, interpolation: .high)
                .cornerRadius(8)
            
            PhotoBadgesOverlay(photo: photo, style: .grid)
            
            if isBest {
                BestShotBadge()
                    .padding(10)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            }
            
            if isActive {
                RoundedRectangle(cornerRadius: 10)
                    .stroke(DesignSystem.Colors.accent, lineWidth: 3)
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.white.opacity(0.18), lineWidth: 1)
                    .shadow(color: DesignSystem.Colors.accent.opacity(0.35), radius: 10, x: 0, y: 0)
            } else if store.selectedPhotoIDs.contains(photo.id) {
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.white.opacity(0.10), lineWidth: 1)
            }
        }
    }
}

struct ComparisonView: View {
    let mainPhoto: PhotoItem
    let comparisonPhotos: [PhotoItem]
    let bestShotID: UUID?
    @ObservedObject var store: PhotoStore
    
    var body: some View {
        HStack(spacing: 4) {
            // Hauptfoto (groß, zoom/pan wie in Detail)
            CompareMainPhotoCell(photo: mainPhoto, store: store, isBest: bestShotID == mainPhoto.id)
                .frame(maxWidth: .infinity)
            
            // Vergleichsfotos
            VStack(spacing: 4) {
                ForEach(comparisonPhotos) { photo in
                    PhotoComparisonCell(photo: photo, store: store, isMain: false, isBest: bestShotID == photo.id)
                        .onTapGesture {
                            store.selectPhoto(photo)
                        }
                }
            }
            .frame(width: 200)
        }
        .background(Color.black)
    }
}

// MARK: - Smart Culling helpers

private func burstGroup(
    around main: PhotoItem,
    in list: [PhotoItem],
    maxCount: Int,
    windowSeconds: TimeInterval
) -> [PhotoItem] {
    guard maxCount >= 2 else { return [main] }
    guard let baseDate = main.iptcMetadata?.date else { return [main] }
    
    // Nutze eine Date-sortierte Liste, unabhängig von aktueller UI-Sortierung.
    let sorted = list.sorted { (a, b) in
        let da = a.iptcMetadata?.date ?? Date.distantPast
        let db = b.iptcMetadata?.date ?? Date.distantPast
        if da != db { return da > db }
        return a.fileName < b.fileName
    }
    guard let idx = sorted.firstIndex(where: { $0.id == main.id }) else { return [main] }
    
    func date(_ p: PhotoItem) -> Date? { p.iptcMetadata?.date }
    
    var left = idx
    var right = idx
    
    // Expand left/right by adjacency, stop when time jumps too much.
    while left > 0, (right - left + 1) < maxCount {
        guard let d0 = date(sorted[left]), let dPrev = date(sorted[left - 1]) else { break }
        if abs(dPrev.timeIntervalSince(d0)) <= windowSeconds {
            left -= 1
        } else {
            break
        }
    }
    
    while right < sorted.count - 1, (right - left + 1) < maxCount {
        guard let d0 = date(sorted[right]), let dNext = date(sorted[right + 1]) else { break }
        if abs(dNext.timeIntervalSince(d0)) <= windowSeconds {
            right += 1
        } else {
            break
        }
    }
    
    var group = Array(sorted[left...right])
    
    // If burst is tiny but there are still close photos within window to base date, include them (best-effort).
    if group.count < 2 {
        let extra = sorted.filter { p in
            guard p.id != main.id, let d = p.iptcMetadata?.date else { return false }
            return abs(d.timeIntervalSince(baseDate)) <= windowSeconds
        }
        group = [main] + extra.prefix(max(0, maxCount - 1))
    }
    
    // Ensure main is included.
    if !group.contains(where: { $0.id == main.id }) {
        group.insert(main, at: 0)
    }
    return Array(group.prefix(maxCount))
}

private struct CompareMainPhotoCell: View {
    let photo: PhotoItem
    @ObservedObject var store: PhotoStore
    let isBest: Bool
    @State private var preview: NSImage?
    @State private var loadTask: Task<Void, Never>?
    
    var body: some View {
        ZStack {
            PhotoDetailView(photo: photo, store: store, image: preview)
            
            PhotoBadgesOverlay(photo: photo, style: .grid)
                .padding(10)
            
            if isBest {
                BestShotBadge()
                    .padding(10)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            }
            
            if store.currentPhotoID == photo.id {
                Rectangle()
                    .stroke(Color.accentColor, lineWidth: 3)
                    .padding(2)
            }
        }
        .onAppear { loadPreview(clear: true) }
        .onChange(of: photo.id) { _, _ in loadPreview(clear: true) }
        .onReceive(NotificationCenter.default.publisher(for: .smartImageLoaderDidUpdate)) { note in
            guard let urlStr = note.userInfo?["url"] as? String,
                  let maxDim = note.userInfo?["maxDim"] as? Int else { return }
            guard urlStr == photo.url.absoluteString else { return }
            // Wenn PhotoKit später ein "final" liefert, refreshen wir ohne Flicker.
            guard maxDim == Int(PreviewSize.large.maxDimension) || maxDim == Int(PreviewSize.medium.maxDimension) else { return }
            loadPreview(clear: false)
        }
        .contentShape(Rectangle())
        .onTapGesture {
            store.selectPhoto(photo)
        }
    }
    
    private func loadPreview(clear: Bool) {
        loadTask?.cancel()
        if clear { preview = nil }
        
        let url = photo.url
        loadTask = Task(priority: .userInitiated) {
            // Progressive: erst 2K (schnell), dann 4K (schärfer) – klappt auch für Photo Library (PhotoKit).
            let medium = await SmartImageLoader.shared.loadImage(url: url, previewSize: .medium)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                if self.photo.url == url, let medium {
                    self.preview = medium
                }
            }
            
            let large = await SmartImageLoader.shared.loadImage(url: url, previewSize: .large)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                if self.photo.url == url, let large {
                    self.preview = large
                }
            }
        }
    }
}

struct PhotoComparisonCell: View {
    let photo: PhotoItem
    @ObservedObject var store: PhotoStore
    let isMain: Bool
    let isBest: Bool
    @State private var thumbnail: NSImage?
    @State private var loadTask: Task<Void, Never>?
    
    var body: some View {
        ZStack(alignment: .topTrailing) {
            if let thumb = thumbnail {
                Image(nsImage: thumb)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            } else {
                Rectangle()
                    .fill(Color.gray.opacity(0.2))
                    .overlay(ProgressView())
            }
            
            PhotoBadgesOverlay(photo: photo, style: .grid)
                .padding(6)
            
            if isBest {
                BestShotBadge()
                    .padding(6)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            }
            
            // Selection Indicator
            if store.currentPhotoID == photo.id {
                Rectangle()
                    .stroke(Color.accentColor, lineWidth: isMain ? 4 : 2)
            }
        }
        .frame(maxHeight: isMain ? .infinity : 200)
        .onAppear { loadThumbnail(clear: true) }
        .onChange(of: photo.id) { _, _ in loadThumbnail(clear: true) }
        .onReceive(NotificationCenter.default.publisher(for: .smartImageLoaderDidUpdate)) { note in
            guard let urlStr = note.userInfo?["url"] as? String,
                  let maxDim = note.userInfo?["maxDim"] as? Int else { return }
            guard urlStr == photo.url.absoluteString else { return }
            guard maxDim == Int(PreviewSize.strip.maxDimension) else { return }
            loadThumbnail(clear: false)
        }
    }
    
    private func loadThumbnail(clear: Bool) {
        loadTask?.cancel()
        if clear { thumbnail = nil }
        
        let url = photo.url
        loadTask = Task(priority: .userInitiated) {
            let thumb = await SmartImageLoader.shared.loadImage(url: url, previewSize: .strip)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                if self.photo.url == url {
                    self.thumbnail = thumb
                }
            }
        }
    }
}

private struct BestShotBadge: View {
    var body: some View {
        HStack(spacing: 5) {
            Image(systemName: "crown.fill")
                .font(.system(size: 10, weight: .semibold))
            Text("BEST")
                .font(.system(size: 10, weight: .bold))
                .tracking(0.8)
        }
        .foregroundColor(.white)
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(DesignSystem.Colors.accent.opacity(0.92))
        .clipShape(Capsule())
        .overlay(
            Capsule()
                .stroke(Color.white.opacity(0.10), lineWidth: 1)
        )
        .shadow(color: Color.black.opacity(0.35), radius: 6, x: 0, y: 2)
    }
}

