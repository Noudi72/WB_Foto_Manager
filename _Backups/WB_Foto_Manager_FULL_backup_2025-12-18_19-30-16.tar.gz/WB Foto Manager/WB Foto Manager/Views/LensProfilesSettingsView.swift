//
//  LensProfilesSettingsView.swift
//  WB Foto Manager
//
//  Lens profile database management (built-in + user profiles)
//

import SwiftUI
import AppKit
import UniformTypeIdentifiers

struct LensProfilesSettingsView: View {
    @ObservedObject var store: PhotoStore
    
    @State private var search: String = ""
    @State private var builtIn: [LensProfile] = []
    @State private var user: [LensProfile] = []
    @State private var isLoading: Bool = false
    
    @State private var showEditor: Bool = false
    @State private var editorProfile: LensProfile?
    
    @State private var importError: String?
    
    @State private var showLCPImportPreview: Bool = false
    @State private var lcpImportURLs: [URL] = []
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            header
            
            HStack(spacing: 10) {
                TextField("Suchen (Name / Kamera / Objektiv)…", text: $search)
                    .textFieldStyle(.roundedBorder)
                
                Button("Import JSON…") { importJSON() }
                    .buttonStyle(LightroomSecondaryButtonStyle())
                
                Button("Import LCP…") { importLCP() }
                    .buttonStyle(LightroomSecondaryButtonStyle())
                
                Button("Export JSON…") { exportJSON() }
                    .buttonStyle(LightroomSecondaryButtonStyle())
                    .disabled(user.isEmpty)
                
                Button("Zurücksetzen") { resetUserProfiles() }
                    .buttonStyle(LightroomSecondaryButtonStyle())
                    .disabled(user.isEmpty)
            }
            .padding(.horizontal)
            
            Divider()
            
            HStack(spacing: 12) {
                profilesList
                profileHelp
            }
            .padding(.horizontal)
        }
        .padding(.vertical)
        .onAppear { reload() }
        .onReceive(NotificationCenter.default.publisher(for: .lensProfileDatabaseDidChange)) { _ in
            reload()
        }
        .sheet(isPresented: $showEditor) {
            if let profile = editorProfile {
                LensProfileEditorSheet(
                    store: store,
                    initialProfile: profile,
                    onSave: { updated in
                        Task {
                            await LensProfileService.shared.upsertUserProfile(updated)
                        }
                    }
                )
            }
        }
        .sheet(isPresented: $showLCPImportPreview) {
            LCPImportPreviewSheet(urls: lcpImportURLs)
        }
        .alert("Import fehlgeschlagen", isPresented: Binding(get: { importError != nil }, set: { if !$0 { importError = nil } })) {
            Button("OK") { importError = nil }
        } message: {
            Text(importError ?? "")
        }
    }
    
    // MARK: - Header
    
    private var header: some View {
        HStack(alignment: .firstTextBaseline) {
            VStack(alignment: .leading, spacing: 2) {
                Text("Objektivprofile")
                    .font(DesignSystem.Fonts.semibold(size: 16))
                    .foregroundColor(DesignSystem.Colors.text)
                Text("Auto‑Erkennung über EXIF • Manuell auswählbar in „Optik → Profilkorrekturen“")
                    .font(DesignSystem.Fonts.regular(size: 11))
                    .foregroundColor(DesignSystem.Colors.text3)
            }
            
            Spacer()
            
            Button("Profil aus aktuellem Foto…") { createFromCurrentPhoto() }
                .buttonStyle(LightroomSecondaryButtonStyle())
                .disabled(store.currentPhoto == nil)
                .help("Erstellt ein User‑Profil basierend auf EXIF (Objektivname/Brennweite) des aktuellen Fotos.")
            
            Button("Leeres Profil…") { createEmptyProfile() }
                .buttonStyle(LightroomSecondaryButtonStyle())
        }
        .padding(.horizontal)
    }
    
    // MARK: - List
    
    private var profilesList: some View {
        VStack(alignment: .leading, spacing: 10) {
            if isLoading {
                HStack(spacing: 10) {
                    ProgressView().controlSize(.small)
                    Text("Lade Profil‑Datenbank…")
                        .font(DesignSystem.Fonts.regular(size: 12))
                        .foregroundColor(DesignSystem.Colors.text2)
                }
                .padding(.vertical, 8)
            }
            
            GroupBox {
                VStack(alignment: .leading, spacing: 10) {
                    sectionHeader("Eigene Profile", count: filteredUser.count)
                    if filteredUser.isEmpty {
                        Text("Keine eigenen Profile.")
                            .font(DesignSystem.Fonts.regular(size: 12))
                            .foregroundColor(DesignSystem.Colors.text3)
                            .padding(.vertical, 6)
                    } else {
                        ForEach(filteredUser, id: \.id) { p in
                            profileRow(p, isUser: true)
                        }
                    }
                    
                    Divider().opacity(0.6)
                        .padding(.vertical, 6)
                    
                    sectionHeader("Standard", count: filteredBuiltIn.count)
                    ForEach(filteredBuiltIn, id: \.id) { p in
                        profileRow(p, isUser: false)
                    }
                }
                .padding(10)
            }
            .groupBoxStyle(.automatic)
        }
        .frame(minWidth: 420, maxWidth: 520, alignment: .topLeading)
    }
    
    private func sectionHeader(_ title: String, count: Int) -> some View {
        HStack {
            Text(title)
                .font(DesignSystem.Fonts.semibold(size: 12))
                .foregroundColor(DesignSystem.Colors.text)
            Spacer()
            Text("\(count)")
                .font(DesignSystem.Fonts.regular(size: 11))
                .foregroundColor(DesignSystem.Colors.text3)
                .monospacedDigit()
        }
    }
    
    private func profileRow(_ profile: LensProfile, isUser: Bool) -> some View {
        HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text(profile.name)
                    .font(DesignSystem.Fonts.medium(size: 12))
                    .foregroundColor(DesignSystem.Colors.text)
                    .lineLimit(1)
                
                Text(matchSummary(profile))
                    .font(DesignSystem.Fonts.regular(size: 10))
                    .foregroundColor(DesignSystem.Colors.text3)
                    .lineLimit(2)
            }
            
            Spacer()
            
            if isUser {
                Button("Bearbeiten") {
                    editorProfile = profile
                    showEditor = true
                }
                .buttonStyle(LightroomSecondaryButtonStyle())
                
                Button {
                    deleteProfile(profile)
                } label: {
                    Image(systemName: "trash")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(DesignSystem.Colors.text)
                        .frame(width: 28, height: 24)
                        .background(DesignSystem.Colors.background4)
                        .overlay(
                            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                                .stroke(DesignSystem.Colors.border, lineWidth: 1)
                        )
                        .cornerRadius(DesignSystem.CornerRadius.small)
                }
                .buttonStyle(.plain)
                .help("Löschen")
            } else {
                Text("Read‑only")
                    .font(DesignSystem.Fonts.regular(size: 10))
                    .foregroundColor(DesignSystem.Colors.text4)
            }
        }
        .padding(.vertical, 8)
    }
    
    private func matchSummary(_ p: LensProfile) -> String {
        let lens = p.lensModelContains.first ?? "—"
        let cam = p.cameraModelContains.first ?? p.cameraMakeContains.first ?? "—"
        let points = p.correctionPoints.isEmpty ? "1×" : "\(p.correctionPoints.count)×"
        return "Lens: \(lens) • Cam: \(cam) • Points: \(points)"
    }
    
    private var filteredUser: [LensProfile] {
        filter(user)
    }
    
    private var filteredBuiltIn: [LensProfile] {
        filter(builtIn)
    }
    
    private func filter(_ list: [LensProfile]) -> [LensProfile] {
        let q = search.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !q.isEmpty else { return list.sorted(by: { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }) }
        return list.filter { p in
            p.name.lowercased().contains(q) ||
            p.lensModelContains.joined(separator: " ").lowercased().contains(q) ||
            p.cameraMakeContains.joined(separator: " ").lowercased().contains(q) ||
            p.cameraModelContains.joined(separator: " ").lowercased().contains(q)
        }
        .sorted(by: { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending })
    }
    
    // MARK: - Help panel
    
    private var profileHelp: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Wie das DB‑System arbeitet")
                .font(DesignSystem.Fonts.semibold(size: 12))
                .foregroundColor(DesignSystem.Colors.text)
            
            Text("• Auto wählt das best‑passende Profil anhand der EXIF‑Felder Kamera/Objektiv/Brennweite.\n• Für Zooms kannst du mehrere Punkte pro Brennweite speichern – die App interpoliert automatisch.\n• Eigene Profile werden lokal in „Application Support“ gespeichert und sind 100% non‑destructive.")
                .font(DesignSystem.Fonts.regular(size: 11))
                .foregroundColor(DesignSystem.Colors.text2)
                .fixedSize(horizontal: false, vertical: true)
            
            Divider().opacity(0.6)
            
            Text("Tipp")
                .font(DesignSystem.Fonts.semibold(size: 12))
                .foregroundColor(DesignSystem.Colors.text)
            Text("Für beste Ergebnisse: Erstelle 2–3 Kalibrierpunkte (z.B. 24/50/70mm oder 70/135/200mm) und stelle Verzeichnung/Vignette so ein, dass Linien + Ecken neutral wirken.")
                .font(DesignSystem.Fonts.regular(size: 11))
                .foregroundColor(DesignSystem.Colors.text2)
                .fixedSize(horizontal: false, vertical: true)
            
            Spacer()
        }
        .padding(12)
        .frame(maxWidth: .infinity, alignment: .topLeading)
        .background(DesignSystem.Colors.background4)
        .overlay(
            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
    
    // MARK: - Actions
    
    private func reload() {
        isLoading = true
        Task { @MainActor in
            let user = await LensProfileService.shared.userProfilesSnapshot()
            self.user = user
            self.builtIn = LensProfileCatalog.builtIn
            self.isLoading = false
        }
    }
    
    private func createEmptyProfile() {
        let new = LensProfile(
            id: "user-\(UUID().uuidString)",
            name: "Neues Profil",
            cameraMakeContains: [],
            cameraModelContains: [],
            lensModelContains: [],
            minFocalLengthMM: nil,
            maxFocalLengthMM: nil,
            correctionPoints: [],
            distortion: 0.0,
            distortionScale: 1.0,
            vignette: 0.0,
            chromaticAberration: 0.0
        )
        editorProfile = new
        showEditor = true
    }
    
    private func createFromCurrentPhoto() {
        guard let photo = store.currentPhoto else { return }
        Task { @MainActor in
            let meta = await LensProfileService.shared.lensMeta(for: photo.url)
            let lens = meta?.lensModel ?? "Objektiv"
            let camMake = meta?.cameraMake
            let camModel = meta?.cameraModel
            let fl = meta?.focalLengthMM
            
            // Seed via generic profile by focal length (best effort)
            let seed = pickGenericSeed(focalLength: fl)
            var points: [LensProfileCorrectionPoint] = []
            if let fl {
                points = [
                    LensProfileCorrectionPoint(
                        focalLengthMM: fl,
                        distortion: seed.distortion,
                        distortionScale: seed.scale,
                        vignette: seed.vignette,
                        chromaticAberration: seed.ca
                    )
                ]
            }
            
            let new = LensProfile(
                id: "user-\(UUID().uuidString)",
                name: lens,
                cameraMakeContains: camMake.map { [$0] } ?? [],
                cameraModelContains: camModel.map { [$0] } ?? [],
                lensModelContains: meta?.lensModel.map { [$0] } ?? [],
                minFocalLengthMM: nil,
                maxFocalLengthMM: nil,
                correctionPoints: points,
                distortion: seed.distortion,
                distortionScale: seed.scale,
                vignette: seed.vignette,
                chromaticAberration: seed.ca
            )
            editorProfile = new
            showEditor = true
        }
    }
    
    private func pickGenericSeed(focalLength: Double?) -> (distortion: Double, scale: Double, vignette: Double, ca: Double) {
        guard let fl = focalLength else {
            return (0.12, 1.01, 0.22, 0.22)
        }
        if fl <= 24 { return (0.24, 1.02, 0.35, 0.35) }
        if fl <= 85 { return (0.12, 1.01, 0.22, 0.22) }
        return (0.06, 1.00, 0.14, 0.16)
    }
    
    private func deleteProfile(_ profile: LensProfile) {
        Task {
            await LensProfileService.shared.deleteUserProfile(id: profile.id)
        }
    }
    
    private func resetUserProfiles() {
        let alert = NSAlert()
        alert.messageText = "Eigene Objektivprofile löschen?"
        alert.informativeText = "Alle eigenen Profile werden entfernt. Standard‑Profile bleiben erhalten."
        alert.addButton(withTitle: "Löschen")
        alert.addButton(withTitle: "Abbrechen")
        alert.alertStyle = .warning
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        
        Task {
            await LensProfileService.shared.resetUserProfiles()
        }
    }
    
    private func importJSON() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.json]
        panel.allowsMultipleSelection = false
        panel.canChooseDirectories = false
        panel.title = "Objektivprofile importieren"
        panel.message = "Wähle eine JSON Datei mit Lens Profiles."
        panel.begin { response in
            guard response == .OK, let url = panel.url else { return }
            Task { @MainActor in
                do {
                    try await LensProfileService.shared.importUserProfiles(from: url)
                } catch {
                    importError = error.localizedDescription
                }
            }
        }
    }
    
    private func importLCP() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [UTType(filenameExtension: "lcp") ?? .data]
        panel.allowsMultipleSelection = true
        panel.canChooseDirectories = false
        panel.title = "LCP importieren"
        panel.message = "Wähle eine oder mehrere Adobe Lens Correction Profile Dateien (.lcp)."
        panel.begin { response in
            guard response == .OK else { return }
            let urls = panel.urls
            guard !urls.isEmpty else { return }
            lcpImportURLs = urls
            showLCPImportPreview = true
        }
    }
    
    private func exportJSON() {
        let panel = NSSavePanel()
        panel.allowedContentTypes = [.json]
        panel.nameFieldStringValue = "lens-profiles.json"
        panel.title = "Objektivprofile exportieren"
        panel.begin { response in
            guard response == .OK, let url = panel.url else { return }
            Task { @MainActor in
                do {
                    try await LensProfileService.shared.exportUserProfiles(to: url)
                } catch {
                    importError = error.localizedDescription
                }
            }
        }
    }
}

// MARK: - Editor Sheet

private struct LensProfileEditorSheet: View {
    @ObservedObject var store: PhotoStore
    @Environment(\.dismiss) private var dismiss
    
    @State private var draft: LensProfile
    @State private var currentMeta: LensMeta?
    
    let onSave: (LensProfile) -> Void
    
    init(store: PhotoStore, initialProfile: LensProfile, onSave: @escaping (LensProfile) -> Void) {
        self.store = store
        self._draft = State(initialValue: initialProfile)
        self.onSave = onSave
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Profil bearbeiten")
                        .font(DesignSystem.Fonts.semibold(size: 16))
                        .foregroundColor(DesignSystem.Colors.text)
                    Text("Mehrere Brennweiten‑Punkte = bessere Zoom‑Korrekturen (Interpolation).")
                        .font(DesignSystem.Fonts.regular(size: 11))
                        .foregroundColor(DesignSystem.Colors.text3)
                }
                Spacer()
                Button("Schließen") { dismiss() }
                    .buttonStyle(LightroomSecondaryButtonStyle())
            }
            .padding(.horizontal)
            
            Form {
                Section("Allgemein") {
                    TextField("Name", text: $draft.name)
                }
                
                Section("Match‑Regeln (Auto)") {
                    TextField("Objektiv enthält (Komma‑getrennt)", text: bindingCSV(\.lensModelContains))
                    TextField("Kamera‑Make enthält (Komma‑getrennt)", text: bindingCSV(\.cameraMakeContains))
                    TextField("Kamera‑Model enthält (Komma‑getrennt)", text: bindingCSV(\.cameraModelContains))
                }
                
                Section("Basis‑Korrektur (Fallback)") {
                    SliderRow(title: "Verzeichnung", value: $draft.distortion, range: -0.5...0.5)
                    SliderRow(title: "Scale", value: $draft.distortionScale, range: 0.8...1.2)
                    SliderRow(title: "Vignette", value: $draft.vignette, range: 0.0...1.0)
                    SliderRow(title: "CA", value: $draft.chromaticAberration, range: 0.0...1.0)
                }
                
                Section("Kalibrierpunkte (pro Brennweite)") {
                    if draft.correctionPoints.isEmpty {
                        Text("Keine Punkte – es werden die Basis‑Werte verwendet.")
                            .foregroundColor(.secondary)
                    } else {
                        ForEach(draft.correctionPoints.sorted(by: { $0.focalLengthMM < $1.focalLengthMM })) { point in
                            CalibrationPointEditor(
                                point: bindingPoint(point.id),
                                onDelete: { deletePoint(point.id) }
                            )
                        }
                    }
                    
                    HStack(spacing: 10) {
                        Button("Punkt hinzufügen") { addPoint() }
                            .buttonStyle(LightroomSecondaryButtonStyle())
                        
                        Button("Aus aktuellem Foto hinzufügen") { addPointFromCurrentPhoto() }
                            .buttonStyle(LightroomSecondaryButtonStyle())
                            .disabled(store.currentPhoto == nil)
                        
                        Spacer()
                    }
                }
            }
            .formStyle(.grouped)
            
            HStack {
                Spacer()
                Button("Speichern") {
                    onSave(draft)
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
            }
            .padding(.horizontal)
            .padding(.bottom, 10)
        }
        .frame(width: 760, height: 720)
        .onAppear { loadCurrentMeta() }
        .onChange(of: store.currentPhotoID) { _, _ in loadCurrentMeta() }
    }
    
    // MARK: - Helpers
    
    private func bindingCSV(_ keyPath: WritableKeyPath<LensProfile, [String]>) -> Binding<String> {
        Binding(
            get: {
                draft[keyPath: keyPath].joined(separator: ", ")
            },
            set: { newValue in
                let parts = newValue
                    .split(separator: ",")
                    .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                    .filter { !$0.isEmpty }
                draft[keyPath: keyPath] = parts
            }
        )
    }
    
    private func bindingPoint(_ id: UUID) -> Binding<LensProfileCorrectionPoint> {
        Binding(
            get: {
                draft.correctionPoints.first(where: { $0.id == id }) ?? LensProfileCorrectionPoint(focalLengthMM: 50, distortion: 0.12, distortionScale: 1.01, vignette: 0.22, chromaticAberration: 0.22)
            },
            set: { newValue in
                if let idx = draft.correctionPoints.firstIndex(where: { $0.id == id }) {
                    draft.correctionPoints[idx] = newValue
                }
            }
        )
    }
    
    private func addPoint() {
        let point = LensProfileCorrectionPoint(
            focalLengthMM: currentMeta?.focalLengthMM ?? 50,
            distortion: draft.distortion,
            distortionScale: draft.distortionScale,
            vignette: draft.vignette,
            chromaticAberration: draft.chromaticAberration
        )
        draft.correctionPoints.append(point)
    }
    
    private func addPointFromCurrentPhoto() {
        guard let fl = currentMeta?.focalLengthMM else {
            addPoint()
            return
        }
        let point = LensProfileCorrectionPoint(
            focalLengthMM: fl,
            distortion: draft.distortion,
            distortionScale: draft.distortionScale,
            vignette: draft.vignette,
            chromaticAberration: draft.chromaticAberration
        )
        draft.correctionPoints.append(point)
    }
    
    private func deletePoint(_ id: UUID) {
        draft.correctionPoints.removeAll { $0.id == id }
    }
    
    private func loadCurrentMeta() {
        guard let photo = store.currentPhoto else {
            currentMeta = nil
            return
        }
        Task { @MainActor in
            currentMeta = await LensProfileService.shared.lensMeta(for: photo.url)
        }
    }
}

private struct CalibrationPointEditor: View {
    @Binding var point: LensProfileCorrectionPoint
    let onDelete: () -> Void
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Text("Brennweite")
                    .font(.caption)
                    .foregroundColor(.secondary)
                Spacer()
                TextField("", value: $point.focalLengthMM, format: .number.precision(.fractionLength(0)))
                    .frame(width: 80)
                Text("mm")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                Spacer()
                
                Button(action: onDelete) {
                    Image(systemName: "trash")
                        .foregroundColor(.secondary)
                }
                .buttonStyle(.plain)
                .help("Punkt entfernen")
            }
            
            SliderRow(title: "Verzeichnung", value: $point.distortion, range: -0.5...0.5)
            SliderRow(title: "Scale", value: $point.distortionScale, range: 0.8...1.2)
            SliderRow(title: "Vignette", value: $point.vignette, range: 0.0...1.0)
            SliderRow(title: "CA", value: $point.chromaticAberration, range: 0.0...1.0)
        }
        .padding(.vertical, 8)
    }
}

private struct SliderRow: View {
    let title: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    
    var body: some View {
        HStack(spacing: 10) {
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
                .frame(width: 90, alignment: .leading)
            Slider(value: $value, in: range)
            Text(value.formatted(.number.precision(.fractionLength(2))))
                .font(.caption)
                .foregroundColor(.secondary)
                .monospacedDigit()
                .frame(width: 70, alignment: .trailing)
        }
    }
}


