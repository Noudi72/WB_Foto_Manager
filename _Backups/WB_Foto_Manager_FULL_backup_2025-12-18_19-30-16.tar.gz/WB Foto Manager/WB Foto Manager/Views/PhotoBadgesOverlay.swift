//
//  PhotoBadgesOverlay.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 15.12.2025.
//

import SwiftUI

enum PhotoBadgesStyle {
    case grid
    case filmstrip
}

/// Einheitliche Overlays/Badges für Grid & Filmstrip (Lightroom-inspiriert)
struct PhotoBadgesOverlay: View {
    @ObservedObject var photo: PhotoItem
    let style: PhotoBadgesStyle
    
    var body: some View {
        ZStack {
            topLeft
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            
            topRight
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
            
            bottomLeft
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomLeading)
            
            bottomRight
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing)
        }
        .padding(outerPadding)
        // Wichtig: In manchen Containern (z.B. ScrollView/HStack im Filmstrip) kann ein Overlay sonst
        // „nur so gross wie sein Inhalt“ werden und dadurch nicht zuverlässig in jeder Zelle sichtbar sein.
        // Wir erzwingen deshalb, dass das Overlay immer die volle Zellfläche einnimmt.
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .allowsHitTesting(false)
    }
    
    // MARK: - Regions
    
    private var topLeft: some View {
        HStack(spacing: style == .grid ? 6 : 4) {
            // Lightroom-like: Sterne immer sichtbar (auch 0 = leere Sterne),
            // damit "unrated" nicht wie "Bug/fehlend" wirkt.
            ratingBadge
            
            if !photo.colorTags.isEmpty {
                colorTagsRow
            }
        }
    }
    
    private var topRight: some View {
        Group {
            if photo.pickStatus != .unflagged {
                pickBadge
            }
        }
    }
    
    private var bottomLeft: some View {
        Group {
            if let badge = photo.virtualCopyBadge {
                textBadge(badge, accent: .blue)
            }
        }
    }
    
    private var bottomRight: some View {
        Group {
            if photo.isInQuickCollection {
                Image(systemName: "bookmark.fill")
                    .font(.system(size: style == .grid ? 10 : 9, weight: .semibold))
                    .foregroundColor(.cyan)
                    .padding(style == .grid ? 6 : 5)
                    .background(Color.black.opacity(0.55))
                    .clipShape(RoundedRectangle(cornerRadius: 6))
                    .overlay(
                        RoundedRectangle(cornerRadius: 6)
                            .stroke(Color.white.opacity(0.10), lineWidth: 1)
                    )
            }
        }
    }
    
    // MARK: - Badges
    
    private var ratingBadge: some View {
        let fontSize: CGFloat = (style == .grid ? 10 : 9)
        let inactiveOpacity: Double = (style == .grid ? 0.32 : 0.35)
        
        return HStack(spacing: 1.5) {
            ForEach(1...5, id: \.self) { i in
                Image(systemName: i <= photo.rating ? "star.fill" : "star")
                    .font(.system(size: fontSize, weight: .semibold))
                    .foregroundColor(i <= photo.rating ? DesignSystem.Colors.star : Color.white.opacity(inactiveOpacity))
            }
        }
        .padding(.horizontal, style == .grid ? 7 : 6)
        .padding(.vertical, style == .grid ? 4 : 4)
        .background(Color.black.opacity(style == .grid ? 0.65 : 0.72))
        .clipShape(RoundedRectangle(cornerRadius: 6))
        .overlay(
            RoundedRectangle(cornerRadius: 6)
                .stroke(Color.white.opacity(0.10), lineWidth: 1)
        )
    }
    
    private var pickBadge: some View {
        HStack(spacing: 4) {
            Image(systemName: photo.pickStatus.displayIcon)
                .font(.system(size: style == .grid ? 11 : 10, weight: .semibold))
                .foregroundColor(Color(photo.pickStatus.displayColor))
            
            if style == .grid {
                Text(photo.pickStatus == .pick ? "Pick" : "Reject")
                    .font(.system(size: 10, weight: .medium))
                    .foregroundColor(.white)
                    .padding(.trailing, 1)
            }
        }
        .padding(.horizontal, style == .grid ? 7 : 6)
        .padding(.vertical, style == .grid ? 4 : 3)
        .background(Color.black.opacity(0.65))
        .clipShape(RoundedRectangle(cornerRadius: 6))
        .overlay(
            RoundedRectangle(cornerRadius: 6)
                .stroke(Color.white.opacity(0.10), lineWidth: 1)
        )
    }
    
    private var colorTagsRow: some View {
        HStack(spacing: style == .grid ? 4 : 3) {
            ForEach(Array(photo.colorTags.sorted(by: { $0.rawValue < $1.rawValue })), id: \.self) { tag in
                Circle()
                    .fill(Color(tag.color))
                    .frame(width: style == .grid ? 10 : 8, height: style == .grid ? 10 : 8)
                    .overlay(
                        Circle()
                            .stroke(Color.white.opacity(0.85), lineWidth: 0.5)
                    )
            }
        }
        .padding(.horizontal, style == .grid ? 6 : 5)
        .padding(.vertical, style == .grid ? 4 : 3)
        .background(Color.black.opacity(0.45))
        .clipShape(RoundedRectangle(cornerRadius: 6))
        .overlay(
            RoundedRectangle(cornerRadius: 6)
                .stroke(Color.white.opacity(0.10), lineWidth: 1)
        )
    }
    
    private func textBadge(_ text: String, accent: Color) -> some View {
        Text(text)
            .font(.system(size: style == .grid ? 10 : 9, weight: .semibold))
            .foregroundColor(.white)
            .padding(.horizontal, style == .grid ? 7 : 6)
            .padding(.vertical, style == .grid ? 4 : 3)
            .background(accent.opacity(0.85))
            .clipShape(RoundedRectangle(cornerRadius: 6))
            .overlay(
                RoundedRectangle(cornerRadius: 6)
                    .stroke(Color.white.opacity(0.12), lineWidth: 1)
            )
    }
    
    private var outerPadding: CGFloat {
        style == .grid ? 6 : 4
    }
}


