//
//  SmartCollectionView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 15.12.2025.
//

import SwiftUI

struct SmartCollectionView: View {
    @EnvironmentObject var store: PhotoStore
    @Environment(\.dismiss) private var dismiss
    
    @State private var selectedCollection: SmartCollection?
    @State private var isEditing: Bool = false
    @State private var editingCollection: SmartCollection?
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Text("Smart Collections")
                    .font(DesignSystem.Fonts.semibold(size: 14))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Spacer()
                
                Button("Neu") {
                    let newCollection = SmartCollection(name: "Neue Smart Collection")
                    editingCollection = newCollection
                    isEditing = true
                }
                .buttonStyle(LightroomSecondaryButtonStyle())
            }
            .padding(DesignSystem.Spacing.medium)
            .background(DesignSystem.Colors.background2)
            
            Divider()
            
            // List
            List {
                ForEach(store.smartCollections) { collection in
                    SmartCollectionRow(
                        collection: collection,
                        photoCount: store.filterPhotos(by: collection).count,
                        isSelected: selectedCollection?.id == collection.id
                    )
                    .contentShape(Rectangle())
                    .onTapGesture {
                        selectedCollection = collection
                    }
                    .contextMenu {
                        Button("Bearbeiten") {
                            editingCollection = collection
                            isEditing = true
                        }
                        
                        Button("Löschen") {
                            store.deleteSmartCollection(collection)
                            if selectedCollection?.id == collection.id {
                                selectedCollection = nil
                            }
                        }
                    }
                }
            }
            .listStyle(.plain)
        }
        .background(DesignSystem.Colors.background)
        .lightroomSidebarTheme()
        .sheet(isPresented: $isEditing) {
            if let editing = editingCollection {
                SmartCollectionEditorView(
                    collection: editing,
                    onSave: { updated in
                        if store.smartCollections.contains(where: { $0.id == updated.id }) {
                            store.updateSmartCollection(updated)
                        } else {
                            store.addSmartCollection(updated)
                        }
                        editingCollection = nil
                        isEditing = false
                    },
                    onCancel: {
                        editingCollection = nil
                        isEditing = false
                    }
                )
            }
        }
    }
}

struct SmartCollectionRow: View {
    let collection: SmartCollection
    let photoCount: Int
    let isSelected: Bool
    
    var body: some View {
        HStack {
            Image(systemName: "sparkles")
                .font(.system(size: 12))
                .foregroundColor(DesignSystem.Colors.accent)
            
            VStack(alignment: .leading, spacing: 2) {
                Text(collection.name)
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Text("\(photoCount) Foto(s)")
                    .font(DesignSystem.Fonts.regular(size: 10))
                    .foregroundColor(DesignSystem.Colors.text2)
            }
            
            Spacer()
        }
        .padding(.horizontal, DesignSystem.Spacing.small)
        .padding(.vertical, DesignSystem.Spacing.tiny)
        .background(isSelected ? DesignSystem.Colors.accent.opacity(0.2) : Color.clear)
    }
}

struct SmartCollectionEditorView: View {
    @State var collection: SmartCollection
    let onSave: (SmartCollection) -> Void
    let onCancel: () -> Void
    
    @State private var minRating: Int = 0
    @State private var maxRating: Int = 0
    @State private var hasMinRating: Bool = false
    @State private var hasMaxRating: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: DesignSystem.Spacing.medium) {
            Text("Smart Collection bearbeiten")
                .font(DesignSystem.Fonts.semibold(size: 16))
                .foregroundColor(DesignSystem.Colors.text)
            
            TextField("Name", text: $collection.name)
                .textFieldStyle(.roundedBorder)
            
            GroupBox("Filter-Kriterien") {
                VStack(alignment: .leading, spacing: DesignSystem.Spacing.small) {
                    // Rating
                    HStack {
                        Toggle("Min Rating", isOn: $hasMinRating)
                        if hasMinRating {
                            Picker("", selection: $minRating) {
                                ForEach(1...5, id: \.self) { rating in
                                    Text("\(rating)").tag(rating)
                                }
                            }
                            .frame(width: 60)
                        }
                    }
                    
                    HStack {
                        Toggle("Max Rating", isOn: $hasMaxRating)
                        if hasMaxRating {
                            Picker("", selection: $maxRating) {
                                ForEach(1...5, id: \.self) { rating in
                                    Text("\(rating)").tag(rating)
                                }
                            }
                            .frame(width: 60)
                        }
                    }
                    
                    // Pick Status
                    Picker("Pick Status", selection: Binding(
                        get: { collection.criteria.pickStatus },
                        set: { collection.criteria.pickStatus = $0 }
                    )) {
                        Text("Kein Filter").tag(Optional<PickStatus>(nil))
                        Text("Pick").tag(Optional<PickStatus>(.pick))
                        Text("Reject").tag(Optional<PickStatus>(.reject))
                        Text("Unflagged").tag(Optional<PickStatus>(.unflagged))
                    }
                    
                    // Color Tags
                    Toggle("Hat Color Label", isOn: Binding(
                        get: { collection.criteria.hasColorTag },
                        set: { collection.criteria.hasColorTag = $0 }
                    ))
                    
                    // Quick Collection
                    Picker("Quick Collection", selection: Binding(
                        get: { collection.criteria.isInQuickCollection },
                        set: { collection.criteria.isInQuickCollection = $0 }
                    )) {
                        Text("Kein Filter").tag(Optional<Bool>(nil))
                        Text("In Quick Collection").tag(Optional<Bool>(true))
                        Text("Nicht in Quick Collection").tag(Optional<Bool>(false))
                    }
                    
                    // Adjustments
                    Picker("Adjustments", selection: Binding(
                        get: { collection.criteria.hasAdjustments },
                        set: { collection.criteria.hasAdjustments = $0 }
                    )) {
                        Text("Kein Filter").tag(Optional<Bool>(nil))
                        Text("Mit Adjustments").tag(Optional<Bool>(true))
                        Text("Ohne Adjustments").tag(Optional<Bool>(false))
                    }
                    
                    // Crop
                    Picker("Zuschnitt", selection: Binding(
                        get: { collection.criteria.hasCrop },
                        set: { collection.criteria.hasCrop = $0 }
                    )) {
                        Text("Kein Filter").tag(Optional<Bool>(nil))
                        Text("Mit Zuschnitt").tag(Optional<Bool>(true))
                        Text("Ohne Zuschnitt").tag(Optional<Bool>(false))
                    }
                }
            }
            
            Spacer()
            
            HStack {
                Button("Abbrechen", action: onCancel)
                    .buttonStyle(LightroomSecondaryButtonStyle())
                
                Spacer()
                
                Button("Speichern") {
                    var updated = collection
                    updated.criteria.minRating = hasMinRating ? minRating : nil
                    updated.criteria.maxRating = hasMaxRating ? maxRating : nil
                    onSave(updated)
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding(DesignSystem.Spacing.large)
        .frame(width: 500, height: 600)
        .background(DesignSystem.Colors.background)
        .lightroomSidebarTheme()
        .onAppear {
            if let min = collection.criteria.minRating {
                hasMinRating = true
                minRating = min
            }
            if let max = collection.criteria.maxRating {
                hasMaxRating = true
                maxRating = max
            }
        }
    }
}

