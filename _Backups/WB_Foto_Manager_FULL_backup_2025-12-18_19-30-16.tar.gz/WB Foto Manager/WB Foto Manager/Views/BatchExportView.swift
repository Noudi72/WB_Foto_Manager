//
//  BatchExportView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit
import UniformTypeIdentifiers

struct BatchExportView: View {
    @ObservedObject var store: PhotoStore
    @State private var selectedPreset: ExportPreset?
    @State private var isExporting = false
    @State private var exportProgress: Double = 0.0
    @State private var currentPhotoIndex: Int = 0
    @State private var totalPhotos: Int = 0
    @State private var currentPhotoName: String = ""
    @Environment(\.dismiss) private var dismiss
    
    var photosToExport: [PhotoItem] {
        if store.selectedPhotoIDs.isEmpty {
            return store.filteredPhotos
        } else {
            return store.photos.filter { store.selectedPhotoIDs.contains($0.id) }
        }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Batch Export")
                .font(.headline)
            
            // Preset Selection
            Picker("Preset", selection: $selectedPreset) {
                Text("Kein Preset").tag(ExportPreset?.none)
                ForEach(store.exportPresets) { preset in
                    Text(preset.name).tag(ExportPreset?.some(preset))
                }
            }
            .pickerStyle(.menu)
            .disabled(isExporting)
            
            if let preset = selectedPreset {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Dimension: \(preset.maxDimension)px")
                    Text("Qualität: \(Int(preset.quality * 100))%")
                    Text("Format: \(preset.format.rawValue)")
                    Text("Fotos: \(photosToExport.count)")
                }
                .font(.caption)
                .foregroundColor(.secondary)
            }
            
            if isExporting {
                VStack(alignment: .leading, spacing: 8) {
                    ProgressView(value: exportProgress)
                    
                    HStack {
                        Text("\(currentPhotoIndex) von \(totalPhotos)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        Spacer()
                        
                        Text("\(Int(exportProgress * 100))%")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    if !currentPhotoName.isEmpty {
                        Text("Aktuell: \(currentPhotoName)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
            
            HStack {
                Button("Abbrechen") {
                    if isExporting {
                        // Cancel export
                        isExporting = false
                    } else {
                        dismiss()
                    }
                }
                
                Spacer()
                
                Button(isExporting ? "Abbrechen" : "Exportieren") {
                    if isExporting {
                        isExporting = false
                    } else {
                        export()
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(selectedPreset == nil || isExporting)
            }
        }
        .padding()
        .frame(width: 500)
    }
    
    private func export() {
        guard let preset = selectedPreset else { return }
        
        let photos = photosToExport
        guard !photos.isEmpty else { return }
        
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.prompt = "Exportieren"
        panel.message = "Wählen Sie einen Ordner für den Export"
        
        panel.begin { response in
            if response == .OK, let outputDirectory = panel.url {
                isExporting = true
                totalPhotos = photos.count
                currentPhotoIndex = 0
                exportProgress = 0.0
                
                Task {
                    do {
                        try await ExportService.shared.exportBatch(
                            photos: photos,
                            preset: preset,
                            outputDirectory: outputDirectory,
                            uploadTargets: store.uploadTargets
                        ) { current, total in
                            DispatchQueue.main.async {
                                self.currentPhotoIndex = current
                                self.totalPhotos = total
                                self.exportProgress = Double(current) / Double(total)
                                
                                if current <= photos.count {
                                    self.currentPhotoName = photos[current - 1].fileName
                                }
                            }
                        }
                        
                        DispatchQueue.main.async {
                            self.isExporting = false
                            self.dismiss()
                            
                            // Zeige Erfolgsmeldung
                            let alert = NSAlert()
                            alert.messageText = "Export abgeschlossen"
                            alert.informativeText = "\(photos.count) Fotos wurden erfolgreich exportiert."
                            alert.alertStyle = .informational
                            alert.addButton(withTitle: "OK")
                            alert.runModal()
                        }
                    } catch {
                        print("Batch export error: \(error)")
                        DispatchQueue.main.async {
                            self.isExporting = false
                            
                            let alert = NSAlert()
                            alert.messageText = "Export fehlgeschlagen"
                            alert.informativeText = error.localizedDescription
                            alert.alertStyle = .warning
                            alert.addButton(withTitle: "OK")
                            alert.runModal()
                        }
                    }
                }
            }
        }
    }
}

