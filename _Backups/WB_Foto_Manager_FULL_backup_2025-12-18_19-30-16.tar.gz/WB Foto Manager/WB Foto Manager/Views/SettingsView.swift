//
//  SettingsView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import Combine
import AppKit
import CoreImage

struct SettingsView: View {
    @ObservedObject var store: PhotoStore
    @Environment(\.dismiss) var dismiss
    @State private var selectedTab: SettingsTab = .general
    
    enum SettingsTab: String, CaseIterable {
        case general = "Allgemein"
        case workflow = "Workflow"
        case lensProfiles = "Objektivprofile"
        case performance = "Performance"
        case export = "Export"
        case upload = "Upload"
        case appearance = "Darstellung"
    }
    
    var body: some View {
        NavigationSplitView {
            List(selection: $selectedTab) {
                ForEach(SettingsTab.allCases, id: \.self) { tab in
                    Label(tab.rawValue, systemImage: iconForTab(tab))
                        .tag(tab)
                }
            }
            .frame(minWidth: 200)
        } detail: {
            Group {
                switch selectedTab {
                case .general:
                    GeneralSettingsView(store: store)
                case .workflow:
                    WorkflowSettingsView(store: store)
                case .lensProfiles:
                    LensProfilesSettingsView(store: store)
                case .performance:
                    PerformanceSettingsView(store: store)
                case .export:
                    ExportSettingsView(store: store)
                case .upload:
                    UploadSettingsTabView(store: store)
                case .appearance:
                    AppearanceSettingsView(store: store)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .frame(width: 800, height: 600)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Schließen") {
                    dismiss()
                }
            }
        }
    }
    
    private func iconForTab(_ tab: SettingsTab) -> String {
        switch tab {
        case .general: return "gear"
        case .workflow: return "wand.and.stars"
        case .lensProfiles: return "camera.aperture"
        case .performance: return "speedometer"
        case .export: return "square.and.arrow.up"
        case .upload: return "icloud.and.arrow.up"
        case .appearance: return "paintbrush"
        }
    }
}

struct GeneralSettingsView: View {
    @ObservedObject var store: PhotoStore
    @StateObject private var settings = AppSettings.shared
    
    var body: some View {
        Form {
            Section("Ordner") {
                Toggle("Automatisch letzten Ordner öffnen", isOn: $settings.autoOpenLastFolder)
                Toggle("Unterordner durchsuchen", isOn: $settings.searchSubfolders)
            }
            
            Section("Metadaten") {
                Toggle("Rating in XMP speichern", isOn: $settings.saveRatingInXMP)
                Toggle("IPTC-Metadaten automatisch laden", isOn: $settings.autoLoadIPTC)
            }
            
            Section("Sicherheit") {
                Toggle("Backup vor Überschreiben", isOn: $settings.backupBeforeOverwrite)
            }
        }
        .formStyle(.grouped)
        .padding()
    }
}

struct WorkflowSettingsView: View {
    @ObservedObject var store: PhotoStore
    @StateObject private var settings = AppSettings.shared
    @State private var showStyleProfilePreview: Bool = false
    
    private var stylePresets: [AdjustmentPreset] {
        store.adjustmentPresets.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }
    
    var body: some View {
        Form {
            Section("Workflow-Modus") {
                Picker("Modus", selection: $settings.workflowMode) {
                    Text("Feinanpasser (Presets & manuell)").tag("manual")
                    Text("Automatisierer (Auto + Batch + Quick Export)").tag("automated")
                }
                .help("Steuert, ob die App eher kreatives Feintuning oder maximale Automatisierung in den Vordergrund stellt.")
                
                Toggle("Nach Rating automatisch zum nächsten Bild", isOn: $settings.autoAdvanceAfterRating)
            }
            
            Section("Persönliches Stil‑Profil (Auto + Look)") {
                Toggle("Auto nutzt Stil‑Profil", isOn: $settings.autoUsesStyleProfile)
                    .help("Wenn aktiv, wendet Auto zuerst neutrale Korrektur an und legt danach dein Stil‑Preset als Delta darüber (wie ein persönliches KI‑Profil – aber lokal).")
                
                Picker("Stil‑Preset", selection: $settings.autoStylePresetID) {
                    Text("Keines").tag("")
                    ForEach(stylePresets) { preset in
                        Text(preset.name).tag(preset.id.uuidString)
                    }
                }
                .disabled(!settings.autoUsesStyleProfile)
                .help("Tipp: Erstelle dein Look‑Preset, indem du ein Bild manuell finetunest und als Preset speicherst.")
                
                Button("Stil‑Profil Vorschau…") {
                    showStyleProfilePreview = true
                }
                .disabled(store.currentPhoto == nil)
                .help("Öffnet eine Liste mit Hover‑Vorschau (nur temporär, wird nicht gespeichert).")
            }
        }
        .formStyle(.grouped)
        .padding()
        .sheet(isPresented: $showStyleProfilePreview) {
            StyleProfilePreviewView(store: store)
        }
    }
}

// MARK: - Stil‑Profil Vorschau (Hover Preview) – im Settings‑Workflow

private struct StyleProfilePreviewView: View {
    @ObservedObject var store: PhotoStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var settings = AppSettings.shared
    
    @State private var search: String = ""
    
    // Hover Preview (temporär, wird NICHT persistiert)
    @State private var hoveredPresetID: UUID?
    @State private var temporaryAdjustments: PhotoAdjustments?
    @State private var temporaryPhotoID: UUID?
    @State private var hoverRestoreTask: Task<Void, Never>?
    
    // In-Sheet Preview (damit man den Effekt sieht, auch wenn das Hauptbild hinter dem Sheet verdeckt ist)
    @State private var previewImage: NSImage?
    @State private var isRenderingPreview: Bool = false
    @State private var previewTitle: String = "Aktuelles Bild"
    @State private var previewTask: Task<Void, Never>?
    
    private var presets: [AdjustmentPreset] {
        let all = store.adjustmentPresets
            .sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        
        let q = search.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !q.isEmpty else { return all }
        return all.filter { preset in
            preset.name.lowercased().contains(q) || (preset.group?.lowercased().contains(q) ?? false)
        }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Stil‑Profil Vorschau")
                        .font(DesignSystem.Fonts.semibold(size: 16))
                        .foregroundColor(DesignSystem.Colors.text)
                    Text("Hover = Vorschau • Klick = auswählen")
                        .font(DesignSystem.Fonts.regular(size: 11))
                        .foregroundColor(DesignSystem.Colors.text3)
                }
                Spacer()
                Button("Schließen") { dismiss() }
                    .buttonStyle(LightroomSecondaryButtonStyle())
            }
            
            Toggle("Auto nutzt Stil‑Profil", isOn: $settings.autoUsesStyleProfile)
                .tint(DesignSystem.Colors.accent)
            
            TextField("Suchen (Name / Kategorie)…", text: $search)
                .textFieldStyle(.roundedBorder)
            
            Divider()
            
            HStack(alignment: .top, spacing: 14) {
                // Preset-Liste
                ScrollView {
                    VStack(alignment: .leading, spacing: 8) {
                        StyleProfileRow(
                            title: "Keines",
                            subtitle: "Kein Stil‑Preset",
                            isSelected: settings.autoStylePresetID.isEmpty,
                            isHighlighted: false,
                            onHoverChanged: { hovering in
                                if !hovering { hoveredPresetID = nil }
                            },
                            action: {
                                restorePreviewIfNeeded()
                                settings.autoStylePresetID = ""
                                dismiss()
                            }
                        )
                        
                        if let hall = store.adjustmentPresets.first(where: { $0.name == "Halle – stark beleuchtet" }) {
                            StyleProfileRow(
                                title: hall.name,
                                subtitle: hall.group,
                                isSelected: settings.autoStylePresetID == hall.id.uuidString,
                                isHighlighted: true,
                                onHoverChanged: { hovering in
                                    hoveredPresetID = hovering ? hall.id : nil
                                },
                                action: {
                                    selectPreset(hall)
                                }
                            )
                        }
                        
                        ForEach(presets) { preset in
                            if preset.name == "Halle – stark beleuchtet" { EmptyView() } else {
                                StyleProfileRow(
                                    title: preset.name,
                                    subtitle: preset.group,
                                    isSelected: settings.autoStylePresetID == preset.id.uuidString,
                                    isHighlighted: false,
                                    onHoverChanged: { hovering in
                                        hoveredPresetID = hovering ? preset.id : nil
                                    },
                                    action: {
                                        selectPreset(preset)
                                    }
                                )
                            }
                        }
                    }
                    .padding(.vertical, 4)
                }
                .frame(width: 360)
                
                // Bild-Vorschau
                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("Vorschau")
                            .font(DesignSystem.Fonts.semibold(size: 12))
                            .foregroundColor(DesignSystem.Colors.text)
                        Spacer()
                        if isRenderingPreview {
                            ProgressView()
                                .controlSize(.small)
                                .tint(DesignSystem.Colors.text2)
                        }
                    }
                    
                    ZStack(alignment: .topLeading) {
                        RoundedRectangle(cornerRadius: 10)
                            .fill(DesignSystem.Colors.background4)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
                            )
                        
                        if let img = previewImage {
                            Image(nsImage: img)
                                .resizable()
                                .interpolation(.high)
                                .antialiased(true)
                                .aspectRatio(contentMode: .fit)
                                .frame(maxWidth: .infinity, maxHeight: .infinity)
                                .clipped()
                                .cornerRadius(10)
                        } else {
                            VStack(spacing: 10) {
                                Image(systemName: "photo")
                                    .font(.system(size: 28, weight: .semibold))
                                    .foregroundColor(DesignSystem.Colors.text3)
                                Text(store.currentPhoto == nil ? "Kein Foto ausgewählt" : "Bild wird geladen…")
                                    .font(DesignSystem.Fonts.regular(size: 12))
                                    .foregroundColor(DesignSystem.Colors.text3)
                            }
                        }
                        
                        Text(previewTitle)
                            .font(DesignSystem.Fonts.medium(size: 11))
                            .foregroundColor(DesignSystem.Colors.text)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 6)
                            .background(DesignSystem.Colors.background4.opacity(0.92))
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
                            )
                            .cornerRadius(8)
                            .padding(10)
                    }
                    .frame(maxWidth: .infinity, minHeight: 360, maxHeight: .infinity)
                    
                    if let photo = store.currentPhoto {
                        Text(photo.fileName)
                            .font(DesignSystem.Fonts.regular(size: 11))
                            .foregroundColor(DesignSystem.Colors.text3)
                            .lineLimit(1)
                            .truncationMode(.middle)
                    }
                }
            }
        }
        .padding(16)
        .frame(minWidth: 980, minHeight: 640)
        .background(DesignSystem.Colors.background)
        .lightroomSidebarTheme()
        .onChange(of: hoveredPresetID) { _, newID in
            handleHoverPreviewChange(newID)
        }
        .onChange(of: store.currentPhotoID) { _, _ in
            // Falls während des Sheets das Foto wechselt: Preview-States zurücksetzen,
            // aber NICHT irgendwelche alten Werte auf das neue Foto übertragen.
            hoverRestoreTask?.cancel()
            temporaryAdjustments = nil
            temporaryPhotoID = nil
            hoveredPresetID = nil
            previewTitle = "Aktuelles Bild"
            schedulePreviewRender()
        }
        .onAppear {
            schedulePreviewRender()
        }
        .onDisappear {
            restorePreviewIfNeeded()
            previewTask?.cancel()
            previewTask = nil
        }
    }
    
    private func selectPreset(_ preset: AdjustmentPreset) {
        restorePreviewIfNeeded()
        settings.autoUsesStyleProfile = true
        settings.autoStylePresetID = preset.id.uuidString
        dismiss()
    }
    
    private func handleHoverPreviewChange(_ newID: UUID?) {
        hoverRestoreTask?.cancel()
        guard let photo = store.currentPhoto else { return }
        
        // Hover beginnt / wechselt
        if let id = newID, let preset = store.adjustmentPresets.first(where: { $0.id == id }) {
            if temporaryAdjustments == nil {
                temporaryAdjustments = photo.adjustments
                temporaryPhotoID = photo.id
            }
            
            // Stil-Profil als Delta (wie Auto+Style)
            let base = temporaryAdjustments ?? photo.adjustments
            let delta = preset.adjustments.delta(from: PhotoAdjustments())
            let next = base.applying(delta)
            photo.adjustments = next
            previewTitle = "Vorschau: \(preset.name)"
            triggerImageUpdate(for: photo, isPreview: true)
            schedulePreviewRender()
            return
        }
        
        // Hover endet: mit kleiner Verzögerung zurücksetzen
        let original = temporaryAdjustments
        let originalPhotoID = temporaryPhotoID
        hoverRestoreTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 60_000_000)
            guard hoveredPresetID == nil else { return }
            guard let original,
                  let photo = store.currentPhoto,
                  originalPhotoID == photo.id else {
                temporaryAdjustments = nil
                temporaryPhotoID = nil
                return
            }
            photo.adjustments = original
            temporaryAdjustments = nil
            temporaryPhotoID = nil
            previewTitle = "Aktuelles Bild"
            triggerImageUpdate(for: photo, isPreview: true)
            schedulePreviewRender()
        }
    }
    
    private func restorePreviewIfNeeded() {
        hoverRestoreTask?.cancel()
        guard let original = temporaryAdjustments,
              let originalPhotoID = temporaryPhotoID,
              let photo = store.currentPhoto,
              originalPhotoID == photo.id else {
            temporaryAdjustments = nil
            temporaryPhotoID = nil
            hoveredPresetID = nil
            return
        }
        photo.adjustments = original
        temporaryAdjustments = nil
        temporaryPhotoID = nil
        hoveredPresetID = nil
        previewTitle = "Aktuelles Bild"
        triggerImageUpdate(for: photo, isPreview: true)
        schedulePreviewRender()
    }
    
    private func triggerImageUpdate(for photo: PhotoItem, isPreview: Bool) {
        // Nur Rendering/Preview, nicht persistieren (PhotoStore filtert isPreview raus).
        store.objectWillChange.send()
        photo.objectWillChange.send()
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id, "isPreview": isPreview]
        )
    }
    
    private func schedulePreviewRender() {
        previewTask?.cancel()
        guard let photo = store.currentPhoto else {
            previewImage = nil
            return
        }
        
        // Werte capturen (damit Hover-Wechsel sauber ist)
        let photoID = photo.id
        let adjustments = photo.adjustments
        let cropRect = photo.cropRect
        let rotation = photo.rotation
        
        isRenderingPreview = true
        previewTask = Task { @MainActor in
            // Kurzes Debounce, damit schnelles Hover nicht 20 Renders queued.
            try? await Task.sleep(nanoseconds: 50_000_000)
            guard !Task.isCancelled else { return }
            
            let original: CIImage?
            if let cached = photo.loadFullImage() {
                original = cached
            } else {
                original = await photo.loadFullImageAsync()
            }
            guard !Task.isCancelled else { return }
            guard let original else {
                if store.currentPhoto?.id == photoID {
                    self.previewImage = nil
                    self.isRenderingPreview = false
                }
                return
            }
            
            let engine = EditEngine.shared
            var processed = original
            if let adjusted = engine.applyAdjustments(to: processed, adjustments: adjustments) {
                processed = adjusted
            }
            processed = engine.applyCropAndRotation(to: processed, cropRect: cropRect, rotation: rotation)
            
            let rendered = engine.render(processed, size: CGSize(width: 1600, height: 1600))
            guard store.currentPhoto?.id == photoID else { return }
            self.previewImage = rendered
            self.isRenderingPreview = false
        }
    }
}

private struct StyleProfileRow: View {
    let title: String
    let subtitle: String?
    let isSelected: Bool
    let isHighlighted: Bool
    let onHoverChanged: (Bool) -> Void
    let action: () -> Void
    
    @State private var isHovering = false
    
    var body: some View {
        Button(action: action) {
            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 1) {
                    Text(title)
                        .font(DesignSystem.Fonts.medium(size: 12))
                        .foregroundColor(DesignSystem.Colors.text)
                        .lineLimit(1)
                    
                    if let subtitle, !subtitle.isEmpty {
                        Text(subtitle)
                            .font(DesignSystem.Fonts.regular(size: 10))
                            .foregroundColor(DesignSystem.Colors.text3)
                            .lineLimit(1)
                    }
                }
                
                Spacer()
                
                if isSelected {
                    Image(systemName: "checkmark")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(DesignSystem.Colors.accent)
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(rowBackground)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(isHighlighted ? DesignSystem.Colors.accent.opacity(0.55) : DesignSystem.Colors.border, lineWidth: 1)
            )
            .cornerRadius(10)
        }
        .buttonStyle(.plain)
        .onHover { hovering in
            isHovering = hovering
            onHoverChanged(hovering)
        }
    }
    
    private var rowBackground: Color {
        if isSelected {
            return DesignSystem.Colors.accent.opacity(0.18)
        }
        if isHovering {
            return DesignSystem.Colors.background3
        }
        return DesignSystem.Colors.background4
    }
}

struct PerformanceSettingsView: View {
    @ObservedObject var store: PhotoStore
    @StateObject private var settings = AppSettings.shared
    
    var body: some View {
        Form {
            Section("Vorschau") {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Vorschau-Qualität: \(Int(settings.previewQuality * 100))%")
                        .font(.caption)
                    Slider(value: $settings.previewQuality, in: 0.5...1.0)
                }
                
                Picker("Max. Cache-Größe", selection: $settings.maxCacheSize) {
                    Text("500 Bilder").tag(500)
                    Text("1000 Bilder").tag(1000)
                    Text("2000 Bilder").tag(2000)
                    Text("Unbegrenzt").tag(0)
                }
            }
            
            Section("Rendering") {
                Toggle("Hardware-Beschleunigung", isOn: $settings.hardwareAcceleration)
                Toggle("Progressive Rendering", isOn: $settings.progressiveRendering)
            }
        }
        .formStyle(.grouped)
        .padding()
    }
}

struct ExportSettingsView: View {
    @ObservedObject var store: PhotoStore
    @StateObject private var settings = AppSettings.shared
    @State private var exportFormat: ExportFormat = .jpeg
    
    var body: some View {
        Form {
            Section("Standard-Einstellungen") {
                Picker("Standard-Format", selection: $exportFormat) {
                    Text("JPEG").tag(ExportFormat.jpeg)
                    Text("PNG").tag(ExportFormat.png)
                }
                .onChange(of: exportFormat) { _, newValue in
                    settings.defaultExportFormat = newValue == .jpeg ? "jpeg" : "png"
                }
                .onAppear {
                    exportFormat = settings.defaultExportFormat == "jpeg" ? .jpeg : .png
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Standard-Qualität: \(Int(settings.defaultExportQuality * 100))%")
                        .font(.caption)
                    Slider(value: $settings.defaultExportQuality, in: 0.5...1.0)
                }
            }
            
            Section("Dateinamen") {
                TextField("Vorlage", text: $settings.filenameTemplate)
                    .help("Verfügbare Tokens: {originalname}, {preset}, {date}, {rating}")
            }
        }
        .formStyle(.grouped)
        .padding()
    }
}

struct UploadSettingsTabView: View {
    @ObservedObject var store: PhotoStore
    
    var body: some View {
        VStack {
            Text("Upload-Ziele verwalten")
                .font(.headline)
                .padding()
            
            Button("Upload-Ziele öffnen...") {
                // Öffne UploadSettingsView
            }
            .buttonStyle(.borderedProminent)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct AppearanceSettingsView: View {
    @ObservedObject var store: PhotoStore
    @StateObject private var settings = AppSettings.shared
    
    var body: some View {
        Form {
            Section("Design") {
                Picker("Theme", selection: $settings.theme) {
                    Text("Dunkel").tag("dark")
                    Text("Hell").tag("light")
                    Text("Automatisch").tag("auto")
                }
            }
            
            Section("Sidebar") {
                Toggle("Sidebar immer sichtbar", isOn: $settings.sidebarAlwaysVisible)
                Toggle("Icons in Sidebar", isOn: $settings.showSidebarIcons)
            }
        }
        .formStyle(.grouped)
        .padding()
    }
}

