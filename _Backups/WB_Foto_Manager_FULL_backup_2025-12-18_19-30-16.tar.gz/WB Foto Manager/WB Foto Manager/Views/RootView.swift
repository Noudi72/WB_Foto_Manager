//
//  RootView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit

struct RootView: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @StateObject private var settings = AppSettings.shared
    
    var body: some View {
        HSplitView {
            if uiState.showLeftSidebar || settings.sidebarAlwaysVisible {
                FinderLikeSidebar(store: store)
                    .frame(minWidth: 160, idealWidth: 180, maxWidth: 240)
            }
            
            MainContentView()
            
            if uiState.showRightSidebar {
                AdjustmentsSidebar(store: store)
                    .frame(minWidth: 160, idealWidth: 180, maxWidth: 280)
            }
        }
        .background(DesignSystem.Colors.background)
        .toolbar {
            ToolbarItem(placement: .navigation) {
                Button(action: {
                    // Wenn "immer sichtbar" aktiv ist, soll die Sidebar nicht ausgeblendet werden.
                    if settings.sidebarAlwaysVisible {
                        uiState.showLeftSidebar = true
                    } else {
                        uiState.showLeftSidebar.toggle()
                    }
                }) {
                    Label("Sidebar links", systemImage: "sidebar.left")
                }
                .disabled(settings.sidebarAlwaysVisible)
                .help(settings.sidebarAlwaysVisible ? "Sidebar ist in den Einstellungen als 'immer sichtbar' aktiviert" : "Sidebar ein-/ausblenden")
            }

            // Titlebar Quick Actions (Workflow wie in Lightroom: wichtige Aktionen ohne Menü)
            ToolbarItemGroup(placement: .automatic) {
                Button(action: openFolderFromTitlebar) {
                    Label("Ordner öffnen…", systemImage: "folder.badge.plus")
                }
                .help("Ordner öffnen…")

                Button(action: {
                    uiState.selectionMode.toggle()
                    if !uiState.selectionMode {
                        store.clearSelectionToCurrent()
                    }
                }) {
                    Label(uiState.selectionMode ? "Mehrfachauswahl aktiv" : "Mehrfachauswahl", systemImage: uiState.selectionMode ? "checkmark.circle.fill" : "checkmark.circle")
                }
                .help(uiState.selectionMode ? "Mehrfachauswahl aktiv" : "Mehrfachauswahl")
                .disabled(store.filteredPhotos.isEmpty)

                Menu {
                    Button("Einstellungen kopieren") {
                        store.copyAdjustmentsFromCurrent()
                    }
                    .disabled(store.currentPhoto == nil)

                    Button("Einstellungen einfügen") {
                        store.pasteAdjustmentsToCurrent()
                    }
                    .disabled(store.currentPhoto == nil || store.copiedAdjustments == nil)

                    Button("Einstellungen auf Auswahl einfügen (\(store.selectedPhotoIDs.count))") {
                        store.pasteAdjustmentsToSelection()
                    }
                    .disabled(store.copiedAdjustments == nil || store.selectedPhotoIDs.isEmpty)

                    Divider()

                    Button("Synchronisieren…") {
                        uiState.activeSheet = .syncAdjustments
                    }
                    .disabled(store.selectedPhotoIDs.count <= 1 || store.currentPhoto == nil)

                    Button("Auswahl löschen") {
                        store.clearSelectionToCurrent()
                        uiState.selectionMode = false
                    }
                    .disabled(store.selectedPhotoIDs.count <= 1)
                } label: {
                    Label("Copy/Paste/Sync", systemImage: "doc.on.doc")
                }
                .help("Einstellungen (Copy/Paste/Sync)")
                .disabled(store.currentPhoto == nil && store.copiedAdjustments == nil)

                Menu {
                    Button("Speichern") {
                        if let photo = store.currentPhoto {
                            SaveService.shared.saveOriginal(photo: photo)
                        }
                    }
                    Button("Kopie speichern unter…") {
                        if let photo = store.currentPhoto {
                            SaveService.shared.saveCopyAs(photo: photo)
                        }
                    }
                } label: {
                    Label("Speichern", systemImage: "square.and.arrow.down")
                }
                .help("Speichern")
                .disabled(store.currentPhoto == nil)

                Button(action: { uiState.activeSheet = .export }) {
                    Label("Export", systemImage: "square.and.arrow.up")
                }
                .help("Exportieren…")

                Button(action: {
                    if store.isAITaggingRunning {
                        store.cancelAITagging()
                        return
                    }
                    if store.selectedPhotoIDs.count > 1 {
                        // Multi-select workflow: generiere für alle ausgewählten Fotos.
                        store.startAITagsForSelection()
                    } else {
                        store.startAITagsForCurrent()
                    }
                }) {
                    ZStack {
                        Label("AI Keywords", systemImage: "sparkles")
                        
                        if store.isAITaggingRunning {
                            ProgressView(value: store.aiTaggingProgress)
                                .progressViewStyle(.circular)
                                .tint(DesignSystem.Colors.accent)
                                .scaleEffect(0.75)
                                .frame(width: 20, height: 20)
                                .offset(x: 0, y: 0)
                        }
                    }
                }
                .help(aiKeywordsHelpText)
                .disabled(store.currentPhoto == nil)

                Button(action: { uiState.activeSheet = .settings }) {
                    Label("Einstellungen", systemImage: "gearshape")
                }
                .help("Einstellungen")

                Button(action: { uiState.activeSheet = .batchExport }) {
                    Label("Batch Export", systemImage: "tray.and.arrow.up")
                }
                .help("Batch Export")

                Menu {
                    Button("Exportieren…") { uiState.activeSheet = .export }
                    Button("Batch Export…") { uiState.activeSheet = .batchExport }
                    Divider()
                    Button("Upload-Ziele verwalten…") { uiState.activeSheet = .uploadSettings }
                    Button("Export-Queue Einstellungen…") { uiState.activeSheet = .exportQueueSettings }
                    Divider()
                    Button("Backup & Wiederherstellung…") { uiState.activeSheet = .backupRestore }
                } label: {
                    Label("Mehr", systemImage: "ellipsis.circle")
                }
                .help("Weitere Aktionen")
            }
            
            ToolbarItem(placement: .primaryAction) {
                Button(action: { uiState.showRightSidebar.toggle() }) {
                    Label("Sidebar rechts", systemImage: "sidebar.right")
                }
            }
        }
        .onAppear {
            store.setup(uiState: uiState)
            // Kein Auto-Load von ~/Pictures: In der Sandbox fehlt ohne User-Interaktion die Permission.
            // Der User soll bewusst einen Ordner über Sidebar / "Ordner öffnen…" auswählen.
            if settings.sidebarAlwaysVisible {
                uiState.showLeftSidebar = true
            }
        }
        .sheet(item: $uiState.activeSheet) { route in
            switch route {
            case .settings:
                SettingsView(store: store)
            case .export:
                ExportPanel(store: store)
            case .batchExport:
                BatchExportView(store: store)
            case .uploadSettings:
                UploadSettingsView(store: store)
            case .exportQueueSettings:
                ExportQueueSettingsView(store: store)
            case .backupRestore:
                BackupRestoreView(store: store)
            case .syncAdjustments:
                SyncAdjustmentsView()
            case .surveyView:
                Text("Survey-View (Coming Soon)")
                    .font(.title)
                    .frame(width: 800, height: 600)
            case .smartCollections:
                SmartCollectionView()
                    .environmentObject(store)
            case .shortcutsHelp:
                ShortcutsHelpView()
                    .environmentObject(store)
            }
        }
    }

    private var aiKeywordsHelpText: String {
        if store.isAITaggingRunning {
            let done = store.aiTaggingProcessedCount
            let total = max(1, store.aiTaggingTotalCount)
            return "AI Keywords laufen… \(done)/\(total) • Klick zum Abbrechen"
        }
        if store.selectedPhotoIDs.count > 1 {
            return "AI Keywords für Auswahl generieren (\(store.selectedPhotoIDs.count))"
        }
        return "AI Keywords generieren"
    }

    // MARK: - Titlebar: Ordner öffnen (gleiches Verhalten wie in Finder-Sidebar)
    private func openFolderFromTitlebar() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = false
        panel.title = "Ordner auswählen"
        panel.prompt = "Öffnen"
        panel.message = "Wählen Sie einen Ordner mit Bildern aus"
        panel.directoryURL = nil

        if panel.runModal() == .OK, let url = panel.url {
            saveBookmark(for: url)
            store.loadPhotos(from: url)
            addPathToUserDefaultsList(key: "favoriteFolders", url: url, limit: 10)
            addPathToUserDefaultsList(key: "recentFolders", url: url, limit: 12)
            NotificationCenter.default.post(name: NSNotification.Name("SidebarFoldersUpdated"), object: nil)
        }
    }

    private func saveBookmark(for url: URL) {
        do {
            let bookmarkData = try url.bookmarkData(
                options: [.withSecurityScope],
                includingResourceValuesForKeys: nil,
                relativeTo: nil
            )
            var bookmarks = UserDefaults.standard.dictionary(forKey: "folderBookmarks") ?? [:]
            bookmarks[url.path] = bookmarkData
            UserDefaults.standard.set(bookmarks, forKey: "folderBookmarks")
        } catch {
            print("Fehler beim Speichern des Bookmarks: \(error)")
        }
    }

    private func addPathToUserDefaultsList(key: String, url: URL, limit: Int) {
        var paths = UserDefaults.standard.stringArray(forKey: key) ?? []
        let standardized = url.standardizedFileURL.path
        paths.removeAll { URL(fileURLWithPath: $0).standardizedFileURL.path == standardized }
        paths.insert(url.path, at: 0)
        if paths.count > limit {
            paths = Array(paths.prefix(limit))
        }
        UserDefaults.standard.set(paths, forKey: key)
    }
}

struct MainContentView: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @AppStorage("filmstripHeightV1") private var filmstripHeight: Double = 132
    
    var body: some View {
        VStack(spacing: 0) {
            TopTabBar()
            
            ZStack {
                switch uiState.viewMode {
                case .detail:
                    DetailView(store: store)
                case .grid:
                    // Pass the filtered photos to the GridView
                    GridView(photos: store.filteredPhotos, store: store)
                case .compare:
                    CompareModeView(store: store)
                case .survey:
                    SurveyModeView(store: store)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            
            if uiState.viewMode == .detail {
                FilmstripResizeHandle(height: $filmstripHeight)
                // Pass the filtered photos to the FilmstripView
                FilmstripView(photos: store.filteredPhotos, store: store)
                    .frame(height: filmstripHeight)
            }
        }
        .background(DesignSystem.Colors.background)
    }
}

/// Horizontale "Splitter"-Leiste, um die Filmstrip-Höhe wie in Lightroom/Sidebars per Drag zu ändern.
/// - Note: Height wird in AppStorage persistiert.
struct FilmstripResizeHandle: View {
    @Binding var height: Double
    @State private var startHeight: Double? = nil
    @State private var isHovering: Bool = false
    
    private let minHeight: Double = 92
    private let maxHeight: Double = 320
    
    var body: some View {
        ZStack {
            Rectangle()
                .fill(DesignSystem.Colors.border)
                .frame(height: 1)
            
            RoundedRectangle(cornerRadius: 2)
                .fill(DesignSystem.Colors.text4.opacity(isHovering ? 0.75 : 0.45))
                .frame(width: 44, height: 3)
        }
        .frame(height: 10)
        .background(DesignSystem.Colors.background4)
        .contentShape(Rectangle())
        .onHover { hovering in
            isHovering = hovering
            if hovering {
                NSCursor.resizeUpDown.push()
            } else {
                NSCursor.pop()
            }
        }
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { value in
                    if startHeight == nil { startHeight = height }
                    let base = startHeight ?? height
                    // Drag up => Filmstrip grösser (mehr Höhe)
                    let proposed = base - value.translation.height
                    height = min(maxHeight, max(minHeight, proposed))
                }
                .onEnded { _ in
                    startHeight = nil
                }
        )
        .accessibilityLabel("Filmstreifen Höhe anpassen")
    }
}

struct TopTabBar: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    var body: some View {
        ZStack {
            // Responsive Topbar (kleines Fenster + Sidebar): fällt stufenweise zurück, statt zu "quetschen".
            ViewThatFits(in: .horizontal) {
                topBarFull
                topBarCompact
                topBarMinimal
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .frame(height: 48)
        .background(DesignSystem.Colors.background2)
        .overlay(
            Rectangle()
                .frame(height: 1)
                .foregroundColor(DesignSystem.Colors.border),
            alignment: .bottom
        )
    }
    
    // MARK: - Variants (Responsive)
    
    private var topBarFull: some View {
        HStack(spacing: 0) {
            ViewModeButtons()
                .padding(.leading, DesignSystem.Spacing.medium)
            
            SearchFieldView(maxWidth: 320, minTextFieldWidth: 160)
                .padding(.leading, DesignSystem.Spacing.small)
            
            separator
            
            ratingAndLabelsInline
            
            RatingSortQuickButtons()
                .padding(.trailing, DesignSystem.Spacing.small)
                .help("Schnell sortieren nach Rating")
            
            SortMenuButton()
                .padding(.trailing, DesignSystem.Spacing.small)
            
            FolderStatusView()
                .padding(.leading, DesignSystem.Spacing.small)
            
            Spacer()
            
            ActionButtons()
                .padding(.trailing, DesignSystem.Spacing.medium)
        }
    }
    
    private var topBarCompact: some View {
        HStack(spacing: 0) {
            ViewModeButtons()
                .padding(.leading, DesignSystem.Spacing.small)
            
            SearchFieldView(maxWidth: 220, minTextFieldWidth: 120, placeholder: "Suchen…")
                .padding(.leading, 6)
            
            separator
            
            ratingAndLabelsInline
            
            // RatingSortQuickButtons fällt in Compact weg (ist auch im Sort-Menü verfügbar)
            SortMenuButton()
                .padding(.trailing, 6)
            
            FolderStatusCompactButton()
                .padding(.leading, 6)
            
            Spacer(minLength: 8)
            
            ActionButtons()
                .padding(.trailing, DesignSystem.Spacing.small)
        }
    }
    
    private var topBarMinimal: some View {
        HStack(spacing: 0) {
            ViewModeButtons()
                .padding(.leading, DesignSystem.Spacing.small)
            
            SearchPopoverButton()
                .padding(.leading, 6)
            
            separator
            
            FilterMenuButton()
                .padding(.trailing, 6)
            
            SortMenuButton()
                .padding(.trailing, 6)
            
            FolderStatusCompactButton()
                .padding(.leading, 6)
            
            Spacer(minLength: 8)
            
            ActionButtons()
                .padding(.trailing, DesignSystem.Spacing.small)
        }
    }
    
    private var separator: some View {
        Rectangle()
            .fill(DesignSystem.Colors.border)
            .frame(width: 1, height: 32)
            .padding(.horizontal, 8)
    }
    
    @ViewBuilder
    private var ratingAndLabelsInline: some View {
        if uiState.viewMode == .grid {
            RatingFilterView()
                .padding(.trailing, 6)
                .help("Filter nach Rating (Grid)")
            
            ColorTagFilterView()
                .padding(.trailing, 6)
                .help("Filter nach Farb-Tag (Grid)")
        } else {
            RatingSetView()
                .padding(.trailing, 6)
                .help("Rating für aktuelles Foto setzen (1–5)")
            
            ColorTagSetView()
                .padding(.trailing, 6)
                .help("Farb-Tag für aktuelles Foto setzen (6–9)")
        }
    }
}

struct ViewModeButtons: View {
    @EnvironmentObject var uiState: UIState

    var body: some View {
        HStack(spacing: 2) {
            ViewModeButton(imageName: "photo", mode: .detail, currentMode: $uiState.viewMode)
            ViewModeButton(imageName: "square.grid.2x2", mode: .grid, currentMode: $uiState.viewMode)
            ViewModeButton(imageName: "rectangle.split.2x1", mode: .compare, currentMode: $uiState.viewMode)
            ViewModeButton(imageName: "rectangle.grid.2x2", mode: .survey, currentMode: $uiState.viewMode)
        }
        .padding(4)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
}

struct ViewModeButton: View {
    let imageName: String
    let mode: ViewMode
    @Binding var currentMode: ViewMode

    var isSelected: Bool {
        currentMode == mode
    }

    var body: some View {
        Button(action: { currentMode = mode }) {
            Image(systemName: imageName)
                .font(DesignSystem.Fonts.medium(size: 14))
                .foregroundColor(isSelected ? Color.white : DesignSystem.Colors.text2)
                .frame(width: 36, height: 32)
                .background(isSelected ? DesignSystem.Colors.accent : Color.clear)
                .cornerRadius(DesignSystem.CornerRadius.small)
        }
        .buttonStyle(.plain)
        .help(helpText)
    }
    
    private var helpText: String {
        switch mode {
        case .detail: return "Detail-Ansicht"
        case .grid: return "Grid-Ansicht"
        case .compare: return "Compare / Culling"
        case .survey: return "Survey"
        }
    }
}

struct RatingFilterView: View {
    @EnvironmentObject var uiState: UIState

    var body: some View {
        HStack(spacing: 4) {
            RatingFilterButton(rating: 0, currentFilter: $uiState.ratingFilter)
            
            Rectangle()
                .fill(DesignSystem.Colors.border2)
                .frame(width: 1, height: 20)
                .padding(.horizontal, 4)
            
            ForEach(1...5, id: \.self) { rating in
                RatingFilterButton(rating: rating, currentFilter: $uiState.ratingFilter)
            }
        }
        .padding(4)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
}

/// Rating setzen (für aktuelles Foto) – mouse-friendly.
/// Wichtig: Nicht mit Rating-Filter verwechseln (der ist im Grid).
struct RatingSetView: View {
    @EnvironmentObject var store: PhotoStore
    
    private var currentRating: Int { store.currentPhoto?.rating ?? 0 }
    private var canRate: Bool { store.currentPhotoID != nil }
    
    var body: some View {
        HStack(spacing: 4) {
            Button(action: { setRating(0, autoAdvance: false) }) {
                HStack(spacing: 4) {
                    Text("0")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(currentRating == 0 ? DesignSystem.Colors.text2 : DesignSystem.Colors.text3)
                        .monospacedDigit()
                    Image(systemName: "star")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(currentRating == 0 ? DesignSystem.Colors.text3 : DesignSystem.Colors.text4)
                }
                .frame(width: 34, height: 24)
                .background(DesignSystem.Colors.background3.opacity(currentRating == 0 ? 0.35 : 0.0))
                .cornerRadius(6)
            }
            .buttonStyle(.plain)
            .disabled(!canRate)
            .help("Rating löschen (0)")
            
            Rectangle()
                .fill(DesignSystem.Colors.border2)
                .frame(width: 1, height: 20)
                .padding(.horizontal, 4)
            
            ForEach(1...5, id: \.self) { r in
                Button(action: { setRating(r) }) {
                    Image(systemName: (currentRating >= r) ? "star.fill" : "star")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor((currentRating >= r) ? DesignSystem.Colors.star : DesignSystem.Colors.text3)
                        .frame(width: 24, height: 24)
                }
                .buttonStyle(.plain)
                .disabled(!canRate)
                .help("\(r) Stern\(r == 1 ? "" : "e")")
            }
        }
        .padding(4)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
    
    private func setRating(_ rating: Int, autoAdvance: Bool = true) {
        guard let id = store.currentPhotoID else { return }
        store.setRating(rating, for: id, autoAdvance: autoAdvance)
    }
}

/// Farb-Tags filtern (Grid) – Lightroom-like.
struct ColorTagFilterView: View {
    @EnvironmentObject var uiState: UIState
    
    private let tags: [ColorTag] = [.red, .yellow, .green, .blue]
    
    var body: some View {
        HStack(spacing: 4) {
            Button(action: { uiState.colorTagFilter = nil }) {
                Text("Alle")
                    .font(DesignSystem.Fonts.medium(size: 11))
                    .foregroundColor(uiState.colorTagFilter == nil ? Color.white : DesignSystem.Colors.text3)
                    .frame(width: 44, height: 24)
                    .background(uiState.colorTagFilter == nil ? DesignSystem.Colors.background : Color.clear)
                    .cornerRadius(6)
            }
            .buttonStyle(.plain)
            
            Rectangle()
                .fill(DesignSystem.Colors.border2)
                .frame(width: 1, height: 20)
                .padding(.horizontal, 4)
            
            ForEach(tags, id: \.self) { tag in
                Button(action: {
                    uiState.colorTagFilter = (uiState.colorTagFilter == tag) ? nil : tag
                }) {
                    Circle()
                        .fill(Color(tag.color).opacity(uiState.colorTagFilter == tag ? 1.0 : 0.35))
                        .frame(width: 12, height: 12)
                        .overlay(
                            Circle()
                                .stroke(Color.white.opacity(0.70), lineWidth: 0.5)
                        )
                        .frame(width: 24, height: 24)
                        .background(uiState.colorTagFilter == tag ? DesignSystem.Colors.background : Color.clear)
                        .cornerRadius(6)
                }
                .buttonStyle(.plain)
                .help(tag.displayName)
            }
        }
        .padding(4)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
}

/// Farb-Tags setzen (aktuelles Foto) – mouse-friendly, zusätzlich zu 6–9.
struct ColorTagSetView: View {
    @EnvironmentObject var store: PhotoStore
    
    private let tags: [ColorTag] = [.red, .yellow, .green, .blue]
    private var current: Set<ColorTag> { store.currentPhoto?.colorTags ?? [] }
    private var canTag: Bool { store.currentPhotoID != nil }
    
    var body: some View {
        HStack(spacing: 4) {
            ForEach(tags, id: \.self) { tag in
                Button(action: { toggle(tag) }) {
                    Circle()
                        .fill(Color(tag.color).opacity(current.contains(tag) ? 1.0 : 0.25))
                        .frame(width: 12, height: 12)
                        .overlay(
                            Circle()
                                .stroke(Color.white.opacity(current.contains(tag) ? 0.85 : 0.45), lineWidth: 0.6)
                        )
                        .frame(width: 24, height: 24)
                        .background(current.contains(tag) ? DesignSystem.Colors.background3.opacity(0.35) : Color.clear)
                        .cornerRadius(6)
                }
                .buttonStyle(.plain)
                .disabled(!canTag)
                .help("\(tag.displayName) (\(tagKeyboardHint(tag)))")
            }
        }
        .padding(4)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
    
    private func toggle(_ tag: ColorTag) {
        guard let id = store.currentPhotoID else { return }
        store.toggleColorTag(tag, for: id)
    }
    
    private func tagKeyboardHint(_ tag: ColorTag) -> String {
        switch tag {
        case .red: return "6"
        case .yellow: return "7"
        case .green: return "8"
        case .blue: return "9"
        default: return ""
        }
    }
}

/// Ein-Klick Sortierung nach Rating (hoch→tief / tief→hoch).
/// Toggle: Wenn bereits aktiv, geht's zurück auf Aufnahmedatum (neueste).
struct RatingSortQuickButtons: View {
    @EnvironmentObject var uiState: UIState
    
    private var isDesc: Bool { uiState.sortMode == .ratingDesc }
    private var isAsc: Bool { uiState.sortMode == .ratingAsc }
    
    var body: some View {
        HStack(spacing: 2) {
            sortButton(
                title: "★↓",
                isActive: isDesc,
                onTap: { toggle(.ratingDesc) }
            )
            sortButton(
                title: "★↑",
                isActive: isAsc,
                onTap: { toggle(.ratingAsc) }
            )
        }
        .padding(4)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
    
    private func toggle(_ mode: PhotoSortMode) {
        if uiState.sortMode == mode {
            uiState.sortMode = .captureDateDesc
        } else {
            uiState.sortMode = mode
        }
    }
    
    private func sortButton(title: String, isActive: Bool, onTap: @escaping () -> Void) -> some View {
        Button(action: onTap) {
            Text(title)
                .font(.system(size: 11, weight: .bold))
                .foregroundColor(isActive ? Color.white : DesignSystem.Colors.text3)
                .frame(width: 34, height: 24)
                .background(isActive ? DesignSystem.Colors.accent.opacity(0.28) : DesignSystem.Colors.background3)
                .cornerRadius(6)
                .overlay(
                    RoundedRectangle(cornerRadius: 6)
                        .stroke(isActive ? DesignSystem.Colors.accent.opacity(0.55) : DesignSystem.Colors.border, lineWidth: 1)
                )
        }
        .buttonStyle(.plain)
    }
}

struct SortMenuButton: View {
    @EnvironmentObject var uiState: UIState
    @State private var isHovering = false
    
    var body: some View {
        Menu {
            Picker("Sortierung", selection: $uiState.sortMode) {
                ForEach(PhotoSortMode.allCases, id: \.self) { mode in
                    Text(mode.title).tag(mode)
                }
            }
        } label: {
            HStack(spacing: 4) {
                Image(systemName: iconName)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Image(systemName: "chevron.down")
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text3)
            }
            .frame(width: 44, height: 32)
            .background(backgroundColor)
            .cornerRadius(DesignSystem.CornerRadius.small)
            .overlay(
                RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
            )
        }
        .menuStyle(.borderlessButton)
        .help("Sortieren: \(uiState.sortMode.title)")
        .onHover { hovering in
            isHovering = hovering
        }
    }
    
    private var backgroundColor: Color {
        // Etwas heller als #1A1A1A, damit es auf der Topbar nicht wie ein "schwarzer Block" wirkt.
        if isHovering { return DesignSystem.Colors.background4 }
        return DesignSystem.Colors.background3
    }
    
    private var iconName: String {
        switch uiState.sortMode {
        case .captureDateDesc, .captureDateAsc:
            return "clock"
        case .fileNameAsc:
            return "textformat.abc"
        case .ratingDesc, .ratingAsc:
            return "star"
        }
    }
}

struct SearchFieldView: View {
    @EnvironmentObject var uiState: UIState
    @FocusState private var isFocused: Bool
    
    var maxWidth: CGFloat = 320
    var minTextFieldWidth: CGFloat = 120
    var placeholder: String = "Suchen (Dateiname, Caption, Keywords)"
    
    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(DesignSystem.Colors.text3)
            
            TextField(placeholder, text: $uiState.searchQuery)
                .textFieldStyle(.plain)
                .font(DesignSystem.Fonts.medium(size: 12))
                .foregroundColor(DesignSystem.Colors.text2)
                .focused($isFocused)
                .frame(minWidth: minTextFieldWidth)
            
            if !uiState.searchQuery.isEmpty {
                Button {
                    uiState.searchQuery = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(DesignSystem.Colors.text3)
                }
                .buttonStyle(.plain)
                .help("Suche löschen")
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
        .overlay(
            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
        .frame(maxWidth: maxWidth)
        .onChange(of: uiState.focusSearchField) { _, focus in
            guard focus else { return }
            isFocused = true
            DispatchQueue.main.async {
                uiState.focusSearchField = false
            }
        }
    }
}

struct RatingFilterButton: View {
    let rating: Int
    @Binding var currentFilter: Int?
    
    var isSelected: Bool {
        currentFilter == (rating == 0 ? nil : rating)
    }

    var body: some View {
        Button(action: {
            currentFilter = (rating == 0 ? nil : rating)
        }) {
            if rating == 0 {
                Text("Alle")
                    .font(DesignSystem.Fonts.medium(size: 11))
                    .foregroundColor(isSelected ? Color.white : DesignSystem.Colors.text3)
                    .frame(width: 44, height: 24)
            } else {
                HStack(spacing: 3) {
                    Image(systemName: "star.fill")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(isSelected ? DesignSystem.Colors.star : DesignSystem.Colors.text3)
                    Text("\(rating)")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(isSelected ? Color.white : DesignSystem.Colors.text3)
                        .monospacedDigit()
                }
                .frame(width: 32, height: 24)
            }
        }
        .buttonStyle(.plain)
        .background(isSelected ? DesignSystem.Colors.background : Color.clear)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
}


struct ActionButtons: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @StateObject private var settings = AppSettings.shared

    var body: some View {
        HStack(spacing: 6) {
            TopBarIconButton(
                systemName: "arrow.uturn.left",
                help: "Undo (⌘Z)",
                action: { store.undoCurrent() }
            )
            .disabled(!store.canUndoCurrent)
            
            TopBarIconButton(
                systemName: "arrow.uturn.right",
                help: "Redo (⇧⌘Z)",
                action: { store.redoCurrent() }
            )
            .disabled(!store.canRedoCurrent)
            
            TopBarIconButton(
                systemName: "rectangle.split.2x1",
                help: "Before/After umschalten",
                isActive: uiState.showBeforeAfter,
                action: { uiState.showBeforeAfter.toggle() }
            )
            
            AutoMenuButton(
                help: settings.autoUsesStyleProfile ? "Auto (+ Stil‑Profil)" : "Auto‑Verbesserung",
                applyAutoCurrent: applyAutoEnhancement
            )

            QuickExportMenuButton()
        }
    }
    
    private func applyAutoEnhancement() {
        guard let photo = store.currentPhoto else { return }
        Task {
            if let adjustments = await store.buildAutoAdjustments(for: photo) {
                await MainActor.run {
                    store.registerUndoPoint(for: photo)
                    photo.adjustments = adjustments
                    // Trigger DetailView reprocess (wir verlassen uns auf Notification statt auf onChange-Spam)
                    NotificationCenter.default.post(
                        name: NSNotification.Name("PhotoAdjustmentsChanged"),
                        object: nil,
                        userInfo: ["photoID": photo.id]
                    )
                }
            }
        }
    }
    
}

private struct AutoMenuButton: View {
    @EnvironmentObject var store: PhotoStore
    @StateObject private var settings = AppSettings.shared
    @State private var isHovering = false
    
    let help: String
    let applyAutoCurrent: () -> Void
    
    var body: some View {
        Menu {
            Section("Auto") {
                Button(settings.autoUsesStyleProfile ? "Auto (+ Stil‑Profil) – aktuelles Foto" : "Auto – aktuelles Foto") {
                    applyAutoCurrent()
                }
                .disabled(store.currentPhoto == nil || store.isBatchAutoRunning)
                
                Button("Auto auf Auswahl anwenden (\(store.selectedPhotoIDs.count))") {
                    store.applyAutoToSelection()
                }
                .disabled(store.selectedPhotoIDs.isEmpty || store.isBatchAutoRunning)
                
                if store.isBatchAutoRunning {
                    Divider()
                    Button("Abbrechen") {
                        store.cancelBatchAuto()
                    }
                }
            }
            
            Divider()
            
            Toggle("Auto nutzt Stil‑Profil", isOn: $settings.autoUsesStyleProfile)
        } label: {
            ZStack {
                Image(systemName: "wand.and.stars")
                    .font(DesignSystem.Fonts.medium(size: 14))
                    .foregroundColor(DesignSystem.Colors.text)
                    .frame(width: 32, height: 32)
                    .background(backgroundColor)
                    .overlay(
                        RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                            .stroke(DesignSystem.Colors.border, lineWidth: 1)
                    )
                    .cornerRadius(DesignSystem.CornerRadius.small)
                
                if store.isBatchAutoRunning {
                    ProgressView(value: store.batchAutoProgress)
                        .progressViewStyle(.circular)
                        .tint(DesignSystem.Colors.accent)
                        .scaleEffect(0.75)
                        .frame(width: 20, height: 20)
                }
            }
        }
        .menuStyle(.borderlessButton)
        .help(autoHelpText)
        .onHover { hovering in
            isHovering = hovering
        }
    }
    
    private var backgroundColor: Color {
        if isHovering { return DesignSystem.Colors.background4 }
        return DesignSystem.Colors.background3
    }
    
    private var autoHelpText: String {
        if store.isBatchAutoRunning {
            let done = store.batchAutoProcessedCount
            let total = max(1, store.batchAutoTotalCount)
            let name = store.batchAutoCurrentName.isEmpty ? "" : " • \(store.batchAutoCurrentName)"
            return "Auto läuft… \(done)/\(total)\(name)"
        }
        return help
    }
}

private struct QuickExportMenuButton: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @State private var isHovering = false
    
    var body: some View {
        Menu {
            Section("Quick Export") {
                Button("Quick Export (aktuelles Foto)") {
                    store.quickExportCurrent()
                }
                .disabled(store.currentPhoto == nil)
                
                Button("Quick Export (Auswahl)") {
                    store.quickExportSelection()
                }
                .disabled(store.selectedPhotoIDs.isEmpty)
                
                Divider()
                
                Menu("Preset") {
                    Button("Keines") { store.setQuickExportPreset(nil) }
                    Divider()
                    ForEach(store.exportPresets) { preset in
                        Button(preset.name) { store.setQuickExportPreset(preset) }
                    }
                }
                
                Button("Zielordner wählen…") {
                    store.chooseQuickExportDirectory()
                }
            }
            
            Divider()
            
            Button("Exportieren…") {
                uiState.activeSheet = .export
            }
            Button("Batch Export…") {
                uiState.activeSheet = .batchExport
            }
        } label: {
            ZStack {
                // Button
                Image(systemName: "square.and.arrow.up")
                    .font(DesignSystem.Fonts.medium(size: 14))
                    .foregroundColor(DesignSystem.Colors.text)
                    .frame(width: 32, height: 32)
                    .background(backgroundColor)
                    .overlay(
                        RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                            .stroke(DesignSystem.Colors.border, lineWidth: 1)
                    )
                    .cornerRadius(DesignSystem.CornerRadius.small)
                
                // Progress overlay
                if store.isQuickExporting {
                    ProgressView(value: store.quickExportProgress)
                        .progressViewStyle(.circular)
                        .tint(DesignSystem.Colors.accent)
                        .scaleEffect(0.75)
                        .frame(width: 20, height: 20)
                } else if store.isExportQueueRunning {
                    ProgressView(value: store.exportQueueProgress)
                        .progressViewStyle(.circular)
                        .tint(DesignSystem.Colors.accent)
                        .scaleEffect(0.75)
                        .frame(width: 20, height: 20)
                }
                
                // Export‑Queue enabled indicator
                if store.exportQueueEnabled {
                    Circle()
                        .fill(DesignSystem.Colors.accent)
                        .frame(width: 7, height: 7)
                        .offset(x: 11, y: -11)
                }
            }
        }
        .menuStyle(.borderlessButton)
        .help(quickExportHelpText)
        .onHover { hovering in
            isHovering = hovering
        }
    }
    
    private var backgroundColor: Color {
        if isHovering { return DesignSystem.Colors.background4 }
        return DesignSystem.Colors.background3
    }
    
    private var quickExportHelpText: String {
        if store.isQuickExporting {
            return "Quick Export läuft…"
        }
        if store.isExportQueueRunning {
            let done = store.exportQueueProcessedCount
            let total = max(1, store.exportQueueTotalCount)
            let name = store.exportQueueCurrentName.isEmpty ? "" : " • \(store.exportQueueCurrentName)"
            return "Export‑Queue läuft… \(done)/\(total)\(name)"
        }
        return "Quick Export / Export…"
    }
}

// MARK: - Button Styles & View Modifiers

struct TopBarIconButton: View {
    let systemName: String
    let help: String
    var isActive: Bool = false
    let action: () -> Void
    
    @State private var isHovering = false
    
    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(DesignSystem.Fonts.medium(size: 14))
                .foregroundColor(isActive ? Color.white : DesignSystem.Colors.text)
                .frame(width: 32, height: 32)
                .background(backgroundColor)
                .overlay(
                    RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                        .stroke(DesignSystem.Colors.border, lineWidth: 1)
                )
                .cornerRadius(DesignSystem.CornerRadius.small)
        }
        .buttonStyle(.plain)
        .help(help)
        .onHover { hovering in
            isHovering = hovering
        }
    }
    
    private var backgroundColor: Color {
        if isActive {
            return DesignSystem.Colors.accent.opacity(0.25)
        }
        if isHovering {
            return DesignSystem.Colors.background4
        }
        // Standard: leicht abgesetzt, damit Buttons auf der Topbar gut sichtbar sind (ohne wie "schwarze Klötze" zu wirken).
        return DesignSystem.Colors.background3
    }
}

struct FolderStatusView: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    var body: some View {
        HStack(spacing: 8) {
            if store.isLoadingPhotos {
                ProgressView()
                    .tint(DesignSystem.Colors.text2)
                    .controlSize(.small)
                    .frame(width: 14, height: 14)
            }
            
            Image(systemName: "folder")
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(DesignSystem.Colors.text3)
            
            Text(folderTitle)
                .font(DesignSystem.Fonts.medium(size: 12))
                .foregroundColor(DesignSystem.Colors.text2)
                .lineLimit(1)
                .truncationMode(.middle)
            
            if totalCount > 0 {
                Text("•")
                    .foregroundColor(DesignSystem.Colors.text4)
                
                Text("\(currentIndex)/\(totalCount)")
                    .font(DesignSystem.Fonts.medium(size: 12))
                    .foregroundColor(DesignSystem.Colors.text3)
                    .monospacedDigit()
            }
            
            if hasActiveFilters {
                Text("•")
                    .foregroundColor(DesignSystem.Colors.text4)
                
                ActiveFilterChipsInline()
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
        .overlay(
            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
        .frame(maxWidth: 720, alignment: .leading)
    }
    
    private var folderTitle: String {
        store.currentFolder?.lastPathComponent ?? "Kein Ordner"
    }
    
    private var totalCount: Int {
        store.filteredPhotos.count
    }
    
    private var currentIndex: Int {
        guard let idx = store.currentPhotoIndexInFiltered else { return 0 }
        return idx + 1
    }
    
    private var hasActiveFilters: Bool {
        uiState.activeSmartCollectionID != nil ||
        !uiState.searchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
        uiState.ratingFilter != nil ||
        uiState.pickStatusFilter != nil ||
        uiState.colorTagFilter != nil ||
        uiState.showQuickCollectionOnly
    }
}

struct ActiveFilterChipsInline: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    var body: some View {
        HStack(spacing: 6) {
            if let smartID = uiState.activeSmartCollectionID,
               let collection = store.smartCollections.first(where: { $0.id == smartID }) {
                FilterChip(title: collection.name, systemImage: "sparkles") {
                    uiState.activeSmartCollectionID = nil
                }
            }
            
            let q = uiState.searchQuery.trimmingCharacters(in: .whitespacesAndNewlines)
            if !q.isEmpty {
                FilterChip(title: "Suche: \(q)", systemImage: "magnifyingglass") {
                    uiState.searchQuery = ""
                }
            }
            
            if let rating = uiState.ratingFilter {
                FilterChip(title: "★ \(rating)", systemImage: "star.fill") {
                    uiState.ratingFilter = nil
                }
            }
            
            if let pick = uiState.pickStatusFilter {
                FilterChip(
                    title: pick == .pick ? "Pick" : "Reject",
                    systemImage: pick == .pick ? "flag.fill" : "xmark.circle.fill"
                ) {
                    uiState.pickStatusFilter = nil
                }
            }
            
            if let tag = uiState.colorTagFilter {
                FilterChip(
                    title: "Label: \(tag.displayName)",
                    dotColor: Color(tag.color)
                ) {
                    uiState.colorTagFilter = nil
                }
            }
            
            if uiState.showQuickCollectionOnly {
                FilterChip(title: "Quick Collection", systemImage: "bookmark.fill") {
                    uiState.showQuickCollectionOnly = false
                }
            }
        }
        .lineLimit(1)
    }
}

struct FilterChip: View {
    let title: String
    var systemImage: String? = nil
    var dotColor: Color? = nil
    let onClear: () -> Void
    
    var body: some View {
        HStack(spacing: 6) {
            if let systemImage {
                Image(systemName: systemImage)
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text2)
            }
            
            if let dotColor {
                Circle()
                    .fill(dotColor)
                    .frame(width: 8, height: 8)
                    .overlay(
                        Circle().stroke(Color.white.opacity(0.75), lineWidth: 0.5)
                    )
            }
            
            Text(title)
                .font(DesignSystem.Fonts.medium(size: 11))
                .foregroundColor(DesignSystem.Colors.text2)
                .lineLimit(1)
            
            Button(action: onClear) {
                Image(systemName: "xmark")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundColor(DesignSystem.Colors.text3)
                    .padding(2)
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(DesignSystem.Colors.background3.opacity(0.65))
        .clipShape(RoundedRectangle(cornerRadius: 6))
        .overlay(
            RoundedRectangle(cornerRadius: 6)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
    }
}

// MARK: - Topbar Compact Helpers

/// Kompakte Suche (Popover), wenn die Topbar wenig Platz hat.
struct SearchPopoverButton: View {
    @EnvironmentObject var uiState: UIState
    @State private var show: Bool = false
    @State private var isHovering: Bool = false
    
    var body: some View {
        Button {
            show.toggle()
            DispatchQueue.main.async {
                uiState.focusSearchField = true
            }
        } label: {
            Image(systemName: "magnifyingglass")
                .font(DesignSystem.Fonts.medium(size: 14))
                .foregroundColor(DesignSystem.Colors.text)
                .frame(width: 32, height: 32)
                .background(isHovering ? DesignSystem.Colors.background4 : DesignSystem.Colors.background3)
                .cornerRadius(DesignSystem.CornerRadius.small)
                .overlay(
                    RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                        .stroke(DesignSystem.Colors.border, lineWidth: 1)
                )
        }
        .buttonStyle(.plain)
        .help("Suchen (⌘F)")
        .onHover { hovering in
            isHovering = hovering
        }
        .popover(isPresented: $show, arrowEdge: .top) {
            VStack(alignment: .leading, spacing: 10) {
                Text("Suche")
                    .font(DesignSystem.Fonts.semibold(size: 13))
                    .foregroundColor(DesignSystem.Colors.text2)
                
                SearchFieldView(maxWidth: 420, minTextFieldWidth: 240)
            }
            .padding(12)
            .frame(width: 460)
            .background(DesignSystem.Colors.background2)
            .onAppear {
                DispatchQueue.main.async {
                    uiState.focusSearchField = true
                }
            }
        }
    }
}

/// Kompakter Ordner/Status Button (Popover mit Details).
struct FolderStatusCompactButton: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @State private var show: Bool = false
    @State private var isHovering: Bool = false
    
    var body: some View {
        Button {
            show.toggle()
        } label: {
            HStack(spacing: 6) {
                if store.isLoadingPhotos {
                    ProgressView()
                        .tint(DesignSystem.Colors.text2)
                        .controlSize(.small)
                        .frame(width: 14, height: 14)
                }
                
                Image(systemName: "folder")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text3)
                
                if totalCount > 0 {
                    Text("\(currentIndex)/\(totalCount)")
                        .font(DesignSystem.Fonts.medium(size: 12))
                        .foregroundColor(DesignSystem.Colors.text2)
                        .monospacedDigit()
                } else {
                    Text("—")
                        .font(DesignSystem.Fonts.medium(size: 12))
                        .foregroundColor(DesignSystem.Colors.text3)
                }
                
                if hasActiveFilters {
                    Image(systemName: "line.3.horizontal.decrease.circle.fill")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(DesignSystem.Colors.accent)
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(isHovering ? DesignSystem.Colors.background4 : DesignSystem.Colors.background3)
            .cornerRadius(DesignSystem.CornerRadius.small)
            .overlay(
                RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .help("Ordner/Status anzeigen")
        .onHover { hovering in
            isHovering = hovering
        }
        .popover(isPresented: $show, arrowEdge: .top) {
            VStack(alignment: .leading, spacing: 10) {
                Text("Status")
                    .font(DesignSystem.Fonts.semibold(size: 13))
                    .foregroundColor(DesignSystem.Colors.text2)
                
                FolderStatusView()
            }
            .padding(12)
            .frame(width: 520)
            .background(DesignSystem.Colors.background2)
        }
    }
    
    private var totalCount: Int {
        store.filteredPhotos.count
    }
    
    private var currentIndex: Int {
        guard let idx = store.currentPhotoIndexInFiltered else { return 0 }
        return idx + 1
    }
    
    private var hasActiveFilters: Bool {
        uiState.activeSmartCollectionID != nil ||
        !uiState.searchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
        uiState.ratingFilter != nil ||
        uiState.pickStatusFilter != nil ||
        uiState.colorTagFilter != nil ||
        uiState.showQuickCollectionOnly
    }
}

/// Alles was viel Platz braucht (Rating/Labels/Sort) als Menü, für sehr kleine Fenster.
struct FilterMenuButton: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @State private var isHovering: Bool = false
    
    private let tags: [ColorTag] = [.red, .yellow, .green, .blue]
    
    var body: some View {
        Menu {
            if uiState.viewMode == .grid {
                Section("Rating‑Filter") {
                    Button("Alle") { uiState.ratingFilter = nil }
                    Divider()
                    ForEach(1...5, id: \.self) { r in
                        Button("\(r) Stern\(r == 1 ? "" : "e")") { uiState.ratingFilter = r }
                    }
                }
                
                Section("Farb‑Label‑Filter") {
                    Button("Alle") { uiState.colorTagFilter = nil }
                    Divider()
                    ForEach(tags, id: \.self) { tag in
                        Button(tag.displayName) { uiState.colorTagFilter = tag }
                    }
                }
            } else {
                Section("Rating setzen") {
                    Button("0 (löschen)") {
                        if let id = store.currentPhotoID {
                            store.setRating(0, for: id, autoAdvance: false)
                        }
                    }
                    Divider()
                    ForEach(1...5, id: \.self) { r in
                        Button("\(r) Stern\(r == 1 ? "" : "e")") {
                            if let id = store.currentPhotoID {
                                store.setRating(r, for: id)
                            }
                        }
                    }
                }
                
                Section("Farb‑Label") {
                    ForEach(tags, id: \.self) { tag in
                        Button(tag.displayName) {
                            if let id = store.currentPhotoID {
                                store.toggleColorTag(tag, for: id)
                            }
                        }
                    }
                }
            }
            
            Divider()
            
            Section("Sortieren") {
                Button("Aufnahmedatum ↓") { uiState.sortMode = .captureDateDesc }
                Button("Aufnahmedatum ↑") { uiState.sortMode = .captureDateAsc }
                Button("Dateiname ↑") { uiState.sortMode = .fileNameAsc }
                Divider()
                Button("Rating ↓") { uiState.sortMode = .ratingDesc }
                Button("Rating ↑") { uiState.sortMode = .ratingAsc }
            }
        } label: {
            HStack(spacing: 6) {
                Image(systemName: "slider.horizontal.3")
                    .font(DesignSystem.Fonts.medium(size: 14))
                    .foregroundColor(DesignSystem.Colors.text)
                Image(systemName: "chevron.down")
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text3)
            }
            .frame(width: 44, height: 32)
            .background(isHovering ? DesignSystem.Colors.background4 : DesignSystem.Colors.background3)
            .cornerRadius(DesignSystem.CornerRadius.small)
            .overlay(
                RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
            )
        }
        .menuStyle(.borderlessButton)
        .help("Filter & Sort (kompakt)")
        .onHover { hovering in
            isHovering = hovering
        }
    }
}

struct PrimaryActionButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(DesignSystem.Fonts.medium(size: 12))
            .foregroundColor(DesignSystem.Colors.text)
            .padding(.horizontal, DesignSystem.Spacing.medium)
            .padding(.vertical, DesignSystem.Spacing.small - 2)
            .background(DesignSystem.Colors.accent)
            .cornerRadius(DesignSystem.CornerRadius.small)
            .opacity(configuration.isPressed ? 0.8 : 1.0)
    }
}

struct SecondaryActionButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(DesignSystem.Fonts.medium(size: 12))
            .foregroundColor(DesignSystem.Colors.text)
            .padding(.horizontal, DesignSystem.Spacing.medium)
            .padding(.vertical, DesignSystem.Spacing.small - 2)
            .background(DesignSystem.Colors.background3)
            .cornerRadius(DesignSystem.CornerRadius.small)
            .opacity(configuration.isPressed ? 0.8 : 1.0)
    }
}

extension View {
    func border(width: CGFloat, edges: [Edge], color: Color) -> some View {
        overlay(EdgeBorder(width: width, edges: edges).foregroundColor(color))
    }
}

struct EdgeBorder: Shape {
    var width: CGFloat
    var edges: [Edge]

    func path(in rect: CGRect) -> Path {
        var path = Path()
        for edge in edges {
            var x: CGFloat {
                switch edge {
                case .top, .bottom, .leading: return rect.minX
                case .trailing: return rect.maxX - width
                }
            }

            var y: CGFloat {
                switch edge {
                case .top, .leading, .trailing: return rect.minY
                case .bottom: return rect.maxY - width
                }
            }

            var w: CGFloat {
                switch edge {
                case .top, .bottom: return rect.width
                case .leading, .trailing: return width
                }
            }

            var h: CGFloat {
                switch edge {
                case .top, .bottom: return width
                case .leading, .trailing: return rect.height
                }
            }
            path.addPath(Path(CGRect(x: x, y: y, width: w, height: h)))
        }
        return path
    }
}

