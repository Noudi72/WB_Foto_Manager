//
//  MaskingPanel.swift
//  WB Foto Manager
//
//  Lightroom-like local adjustments (Masking)
//

import SwiftUI
import CoreImage
import Vision

struct MaskingPanel: View {
    @ObservedObject var store: PhotoStore
    
    var body: some View {
        if let photo = store.currentPhoto {
            MaskingPanelContent(photo: photo, store: store)
        } else {
            Text("Kein Foto ausgewählt")
                .font(DesignSystem.Fonts.regular(size: 12))
                .foregroundColor(DesignSystem.Colors.text3)
                .padding(DesignSystem.Spacing.medium)
        }
    }
}

private struct MaskingPanelContent: View {
    @ObservedObject var photo: PhotoItem
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    @State private var isAutoMasking: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            header
            
            if photo.localMasks.isEmpty {
                emptyState
            } else {
                masksList
                Divider().opacity(0.6)
                activeMaskEditor
            }
        }
        .padding(.vertical, 8)
        .onAppear {
            ensureActiveMask()
        }
        .onChange(of: photo.id) { _, _ in
            ensureActiveMask()
        }
        .onChange(of: photo.localMasks) { _, _ in
            ensureActiveMask()
        }
    }
    
    // MARK: - Header
    
    private var header: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                Text("Masken")
                    .font(DesignSystem.Fonts.semibold(size: 14))
                    .foregroundColor(DesignSystem.Colors.text)
                    .lineLimit(1)
                
                Spacer()
                
                Toggle("Overlay", isOn: $uiState.showMaskOverlay)
                    .toggleStyle(.switch)
                    .controlSize(.small)
                    .labelsHidden()
                    .help("Masken-Overlay im Bild anzeigen")
                
                Menu {
                    Button {
                        addAutoSubjectMask()
                    } label: {
                        Label("Motiv (AI)", systemImage: "person.crop.square")
                    }
                    .disabled(isAutoMasking)
                    
                    Button {
                        addAutoSkyMask()
                    } label: {
                        Label("Himmel (AI)", systemImage: "cloud.sun")
                    }
                    .disabled(isAutoMasking)
                } label: {
                    Image(systemName: "sparkles")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(isAutoMasking ? DesignSystem.Colors.text4 : DesignSystem.Colors.text)
                        .frame(width: 28, height: 24)
                        .background(DesignSystem.Colors.background4)
                        .overlay(
                            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                                .stroke(DesignSystem.Colors.border, lineWidth: 1)
                        )
                        .cornerRadius(DesignSystem.CornerRadius.small)
                }
                .help("AI Masken (Motiv/Himmel)")
                
                Menu {
                    Button {
                        addMask(.linear)
                    } label: {
                        Label("Linear", systemImage: LocalMaskKind.linear.systemImage)
                    }
                    
                    Button {
                        addMask(.radial)
                    } label: {
                        Label("Radial", systemImage: LocalMaskKind.radial.systemImage)
                    }
                    
                    Divider()
                    
                    Button {} label: {
                        Label("Pinsel (kommt bald)", systemImage: LocalMaskKind.brush.systemImage)
                    }
                    .disabled(true)
                } label: {
                    Image(systemName: "plus")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(DesignSystem.Colors.text)
                        .frame(width: 28, height: 24)
                        .background(DesignSystem.Colors.background4)
                        .overlay(
                            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                                .stroke(DesignSystem.Colors.border, lineWidth: 1)
                        )
                        .cornerRadius(DesignSystem.CornerRadius.small)
                }
                .help("Maske hinzufügen")
                
                Button {
                    deleteActiveMask()
                } label: {
                    Image(systemName: "trash")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(canDelete ? DesignSystem.Colors.text : DesignSystem.Colors.text4)
                        .frame(width: 28, height: 24)
                        .background(DesignSystem.Colors.background4)
                        .overlay(
                            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                                .stroke(DesignSystem.Colors.border, lineWidth: 1)
                        )
                        .cornerRadius(DesignSystem.CornerRadius.small)
                }
                .buttonStyle(.plain)
                .disabled(!canDelete)
                .help("Aktive Maske löschen")
            }
            
            Text("Tipp: Ziehe die Griffe direkt im Bild, um Linear/Radial zu positionieren.")
                .font(DesignSystem.Fonts.regular(size: 11))
                .foregroundColor(DesignSystem.Colors.text3)
                .lineLimit(2)
        }
        .padding(.horizontal, DesignSystem.Spacing.medium)
    }
    
    private var canDelete: Bool {
        uiState.activeMaskID != nil && !photo.localMasks.isEmpty
    }
    
    // MARK: - Empty
    
    private var emptyState: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Noch keine Masken.")
                .font(DesignSystem.Fonts.medium(size: 12))
                .foregroundColor(DesignSystem.Colors.text)
            
            Text("Erstelle eine Maske, um lokale Anpassungen wie in Lightroom zu machen.")
                .font(DesignSystem.Fonts.regular(size: 11))
                .foregroundColor(DesignSystem.Colors.text3)
            
            HStack(spacing: 10) {
                Button("Linear hinzufügen") { addMask(.linear) }
                    .buttonStyle(LightroomSecondaryButtonStyle())
                Button("Radial hinzufügen") { addMask(.radial) }
                    .buttonStyle(LightroomSecondaryButtonStyle())
            }
            
            HStack(spacing: 10) {
                Button("Motiv (AI)") { addAutoSubjectMask() }
                    .buttonStyle(LightroomSecondaryButtonStyle())
                    .disabled(isAutoMasking)
                Button("Himmel (AI)") { addAutoSkyMask() }
                    .buttonStyle(LightroomSecondaryButtonStyle())
                    .disabled(isAutoMasking)
            }
        }
        .padding(.horizontal, DesignSystem.Spacing.medium)
        .padding(.top, 8)
    }
    
    // MARK: - List
    
    private var masksList: some View {
        VStack(alignment: .leading, spacing: 8) {
            ForEach(photo.localMasks) { mask in
                MaskRow(
                    mask: mask,
                    isSelected: uiState.activeMaskID == mask.id,
                    isEnabled: maskBoolBinding(mask.id, \.isEnabled, defaultValue: true),
                    onSelect: { uiState.activeMaskID = mask.id }
                )
            }
        }
        .padding(.horizontal, DesignSystem.Spacing.medium)
    }
    
    // MARK: - Editor
    
    @ViewBuilder
    private var activeMaskEditor: some View {
        if let activeID = uiState.activeMaskID,
           let active = photo.localMasks.first(where: { $0.id == activeID }) {
            VStack(alignment: .leading, spacing: 14) {
            // Basic settings
            VStack(alignment: .leading, spacing: 10) {
                TextField("Name", text: maskStringBinding(active.id, \.name, defaultValue: active.name))
                    .textFieldStyle(.roundedBorder)
                
                HStack(spacing: 10) {
                    Toggle("Invertieren", isOn: maskBoolBinding(active.id, \.inverted, defaultValue: false))
                        .toggleStyle(.switch)
                        .controlSize(.small)
                        .tint(DesignSystem.Colors.accent)
                    
                    Spacer()
                    
                    Text(active.kind.title)
                        .font(DesignSystem.Fonts.regular(size: 11))
                        .foregroundColor(DesignSystem.Colors.text3)
                        .lineLimit(1)
                }
            }
            .padding(.horizontal, DesignSystem.Spacing.medium)
            
            AdjustmentSection(title: "Maske") {
                AdjustmentSlider(
                    title: "Stärke",
                    value: maskDoubleBinding(active.id, \.opacity, defaultValue: 1.0),
                    range: 0.0...1.0,
                    unit: nil,
                    defaultValue: 1.0,
                    photo: photo
                )
                
                AdjustmentSlider(
                    title: "Weiche Kante",
                    value: maskDoubleBinding(active.id, \.feather, defaultValue: 0.35),
                    range: 0.0...1.0,
                    unit: nil,
                    defaultValue: 0.35,
                    photo: photo
                )
            }
            
            AdjustmentSection(title: "Licht") {
                AdjustmentSlider(title: "Belichtung", value: adjustmentBinding(active.id, \.exposure), range: -2.0...2.0, unit: "EV", defaultValue: 0.0, photo: photo)
                AdjustmentSlider(title: "Kontrast", value: adjustmentBinding(active.id, \.contrast, defaultValue: 1.0), range: 0.5...1.8, unit: "x", defaultValue: 1.0, photo: photo)
                AdjustmentSlider(title: "Highlights", value: adjustmentBinding(active.id, \.highlights), range: -100...100, unit: "", defaultValue: 0.0, photo: photo)
                AdjustmentSlider(title: "Shadows", value: adjustmentBinding(active.id, \.shadows), range: -100...100, unit: "", defaultValue: 0.0, photo: photo)
                AdjustmentSlider(title: "Whites", value: adjustmentBinding(active.id, \.whites), range: -100...100, unit: "", defaultValue: 0.0, photo: photo)
                AdjustmentSlider(title: "Blacks", value: adjustmentBinding(active.id, \.blacks), range: -100...100, unit: "", defaultValue: 0.0, photo: photo)
            }
            
            AdjustmentSection(title: "Farbe") {
                AdjustmentSlider(title: "Temperatur", value: adjustmentBinding(active.id, \.temperature), range: -3000...3000, unit: "K", defaultValue: 0.0, photo: photo)
                AdjustmentSlider(title: "Tint", value: adjustmentBinding(active.id, \.tint), range: -80...80, unit: "", defaultValue: 0.0, photo: photo)
                AdjustmentSlider(title: "Vibrance", value: adjustmentBinding(active.id, \.vibrance), range: -0.6...1.0, unit: "", defaultValue: 0.0, photo: photo)
                AdjustmentSlider(title: "Saturation", value: adjustmentBinding(active.id, \.saturation), range: -100...100, unit: "", defaultValue: 0.0, photo: photo)
            }
            
            AdjustmentSection(title: "Effekte") {
                AdjustmentSlider(title: "Klarheit", value: adjustmentBinding(active.id, \.clarity), range: 0.0...1.0, unit: "", defaultValue: 0.0, photo: photo)
                AdjustmentSlider(title: "Texture", value: adjustmentBinding(active.id, \.texture), range: -100...100, unit: "", defaultValue: 0.0, photo: photo)
                AdjustmentSlider(title: "Dehaze", value: adjustmentBinding(active.id, \.dehaze), range: -100...100, unit: "", defaultValue: 0.0, photo: photo)
            }
            }
        } else {
            Text("Wähle eine Maske aus.")
                .font(DesignSystem.Fonts.regular(size: 12))
                .foregroundColor(DesignSystem.Colors.text3)
                .padding(.horizontal, DesignSystem.Spacing.medium)
        }
    }
    
    // MARK: - Actions
    
    private func ensureActiveMask() {
        if let id = uiState.activeMaskID, photo.localMasks.contains(where: { $0.id == id }) {
            return
        }
        uiState.activeMaskID = photo.localMasks.first?.id
    }
    
    private func addMask(_ kind: LocalMaskKind) {
        store.registerUndoPoint(for: photo)
        var list = photo.localMasks
        let new = LocalAdjustmentMask.makeDefault(kind: kind)
        list.append(new)
        photo.localMasks = list
        uiState.activeMaskID = new.id
        
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id]
        )
    }
    
    private func addAutoSubjectMask() {
        guard !isAutoMasking else { return }
        isAutoMasking = true
        
        Task(priority: .userInitiated) {
            let ciImage: CIImage? = await {
                if let cached = await MainActor.run(body: { photo.loadFullImage() }) {
                    return cached
                }
                return await photo.loadFullImageAsync()
            }()
            
            let extent = ciImage?.extent ?? .zero
            let subjectRect = await Task.detached(priority: .userInitiated) { () -> CGRect? in
                guard let ciImage, extent.width > 1, extent.height > 1 else { return nil }
                return Self.detectLargestFaceRect(in: ciImage)
            }.value
            
            await MainActor.run {
                defer { isAutoMasking = false }
                
                store.registerUndoPoint(for: photo)
                
                var list = photo.localMasks
                var new = LocalAdjustmentMask.makeDefault(kind: .radial, name: "Motiv (AI)")
                new.feather = 0.55
                
                if let rect = subjectRect, extent.width > 1, extent.height > 1 {
                    // rect ist in Image-Koordinaten (origin bottom-left). NormalizedPoint ist top-left.
                    let cx = rect.midX / extent.width
                    let cyFromTop = 1.0 - (rect.midY / extent.height)
                    let radius = min(0.90, max(0.12, max(rect.width, rect.height) / min(extent.width, extent.height) * 0.75))
                    new.radial = RadialMask(center: NormalizedPoint(x: cx, y: cyFromTop), radius: radius)
                } else {
                    // Fallback: zentriert
                    new.radial = RadialMask(center: .center, radius: 0.32)
                }
                
                list.append(new)
                photo.localMasks = list
                uiState.activeMaskID = new.id
                
                NotificationCenter.default.post(
                    name: NSNotification.Name("PhotoAdjustmentsChanged"),
                    object: nil,
                    userInfo: ["photoID": photo.id]
                )
            }
        }
    }
    
    private func addAutoSkyMask() {
        guard !isAutoMasking else { return }
        isAutoMasking = true
        
        // MVP: Sky als linearer Verlauf von oben nach unten (User kann im Bild feinjustieren).
        Task { @MainActor in
            defer { isAutoMasking = false }
            store.registerUndoPoint(for: photo)
            
            var list = photo.localMasks
            var new = LocalAdjustmentMask.makeDefault(kind: .linear, name: "Himmel (AI)")
            new.feather = 0.65
            new.linear = LinearMask(
                start: NormalizedPoint(x: 0.5, y: 0.03),
                end: NormalizedPoint(x: 0.5, y: 0.48)
            )
            
            list.append(new)
            photo.localMasks = list
            uiState.activeMaskID = new.id
            
            NotificationCenter.default.post(
                name: NSNotification.Name("PhotoAdjustmentsChanged"),
                object: nil,
                userInfo: ["photoID": photo.id]
            )
        }
    }
    
    private nonisolated static func detectLargestFaceRect(in image: CIImage) -> CGRect? {
        let extent = image.extent
        guard let cgImage = CIContext(options: [.useSoftwareRenderer: false]).createCGImage(image, from: extent) else {
            return nil
        }
        
        let request = VNDetectFaceRectanglesRequest()
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        try? handler.perform([request])
        guard let faces = request.results, !faces.isEmpty else { return nil }
        
        // Union of faces (mehrere Personen)
        let imageSize = extent.size
        var unionRect: CGRect = .null
        for face in faces {
            let rect = VNImageRectForNormalizedRect(
                face.boundingBox,
                Int(imageSize.width),
                Int(imageSize.height)
            )
            unionRect = unionRect.union(rect)
        }
        
        // Padding, damit es eher "Motiv" als nur Gesicht ist
        let padding: CGFloat = 0.55
        let padded = CGRect(
            x: max(0, unionRect.origin.x - unionRect.width * padding),
            y: max(0, unionRect.origin.y - unionRect.height * padding),
            width: min(imageSize.width - unionRect.origin.x, unionRect.width * (1 + 2 * padding)),
            height: min(imageSize.height - unionRect.origin.y, unionRect.height * (1 + 2 * padding))
        )
        
        return padded
    }
    
    private func deleteActiveMask() {
        guard let id = uiState.activeMaskID else { return }
        guard let idx = photo.localMasks.firstIndex(where: { $0.id == id }) else { return }
        store.registerUndoPoint(for: photo)
        var list = photo.localMasks
        list.remove(at: idx)
        photo.localMasks = list
        uiState.activeMaskID = list.first?.id
        
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id]
        )
    }
    
    // MARK: - Bindings
    
    private func maskBoolBinding(_ maskID: UUID, _ keyPath: WritableKeyPath<LocalAdjustmentMask, Bool>, defaultValue: Bool) -> Binding<Bool> {
        Binding(
            get: { photo.localMasks.first(where: { $0.id == maskID })?[keyPath: keyPath] ?? defaultValue },
            set: { newValue in
                guard let idx = photo.localMasks.firstIndex(where: { $0.id == maskID }) else { return }
                var list = photo.localMasks
                var mask = list[idx]
                mask[keyPath: keyPath] = newValue
                list[idx] = mask
                photo.localMasks = list
                NotificationCenter.default.post(
                    name: NSNotification.Name("PhotoAdjustmentsChanged"),
                    object: nil,
                    userInfo: ["photoID": photo.id]
                )
            }
        )
    }
    
    private func maskDoubleBinding(_ maskID: UUID, _ keyPath: WritableKeyPath<LocalAdjustmentMask, Double>, defaultValue: Double) -> Binding<Double> {
        Binding(
            get: { photo.localMasks.first(where: { $0.id == maskID })?[keyPath: keyPath] ?? defaultValue },
            set: { newValue in
                guard let idx = photo.localMasks.firstIndex(where: { $0.id == maskID }) else { return }
                var list = photo.localMasks
                var mask = list[idx]
                mask[keyPath: keyPath] = newValue
                list[idx] = mask
                photo.localMasks = list
                NotificationCenter.default.post(
                    name: NSNotification.Name("PhotoAdjustmentsChanged"),
                    object: nil,
                    userInfo: ["photoID": photo.id]
                )
            }
        )
    }
    
    private func maskStringBinding(_ maskID: UUID, _ keyPath: WritableKeyPath<LocalAdjustmentMask, String>, defaultValue: String) -> Binding<String> {
        Binding(
            get: { photo.localMasks.first(where: { $0.id == maskID })?[keyPath: keyPath] ?? defaultValue },
            set: { newValue in
                guard let idx = photo.localMasks.firstIndex(where: { $0.id == maskID }) else { return }
                var list = photo.localMasks
                var mask = list[idx]
                mask[keyPath: keyPath] = newValue
                list[idx] = mask
                photo.localMasks = list
            }
        )
    }
    
    private func adjustmentBinding(_ maskID: UUID, _ keyPath: WritableKeyPath<PhotoAdjustments, Double>, defaultValue: Double = 0.0) -> Binding<Double> {
        Binding(
            get: {
                photo.localMasks.first(where: { $0.id == maskID })?.adjustments[keyPath: keyPath] ?? defaultValue
            },
            set: { newValue in
                guard let idx = photo.localMasks.firstIndex(where: { $0.id == maskID }) else { return }
                var list = photo.localMasks
                var mask = list[idx]
                var adj = mask.adjustments
                adj[keyPath: keyPath] = newValue
                mask.adjustments = adj
                list[idx] = mask
                photo.localMasks = list
            }
        )
    }
}

private struct MaskRow: View {
    let mask: LocalAdjustmentMask
    let isSelected: Bool
    @Binding var isEnabled: Bool
    let onSelect: () -> Void
    
    @State private var hovering = false
    
    var body: some View {
        Button(action: onSelect) {
            HStack(spacing: 10) {
                Image(systemName: mask.kind.systemImage)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text)
                    .frame(width: 18)
                
                VStack(alignment: .leading, spacing: 1) {
                    Text(mask.name.isEmpty ? "Maske" : mask.name)
                        .font(DesignSystem.Fonts.medium(size: 12))
                        .foregroundColor(DesignSystem.Colors.text)
                        .lineLimit(1)
                    
                    Text(mask.kind.title)
                        .font(DesignSystem.Fonts.regular(size: 10))
                        .foregroundColor(DesignSystem.Colors.text3)
                        .lineLimit(1)
                }
                
                Spacer()
                
                Toggle("", isOn: $isEnabled)
                    .toggleStyle(.switch)
                    .controlSize(.mini)
                    .labelsHidden()
                    .tint(DesignSystem.Colors.accent)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 10)
            .background(background)
            .overlay(
                RoundedRectangle(cornerRadius: 10)
                    .stroke(isSelected ? DesignSystem.Colors.accent.opacity(0.55) : DesignSystem.Colors.border, lineWidth: 1)
            )
            .cornerRadius(10)
        }
        .buttonStyle(.plain)
        .onHover { hovering in
            self.hovering = hovering
        }
    }
    
    private var background: Color {
        if isSelected { return DesignSystem.Colors.accent.opacity(0.16) }
        if hovering { return DesignSystem.Colors.background3 }
        return DesignSystem.Colors.background4
    }
}


