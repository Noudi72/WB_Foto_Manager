//
//  ExportService.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import CoreImage

/// Service für Export-Funktionalität
class ExportService {
    static let shared = ExportService()
    private let editEngine = EditEngine.shared
    
    private init() {}
    
    /// Exportiert ein Foto mit einem Preset
    func export(photo: PhotoItem, preset: ExportPreset, to outputURL: URL, uploadTargets: [UploadTarget] = [], progress: ((Double) -> Void)? = nil) async throws {
        progress?(0.1)
        
        // Lade Originalbild
        let resolvedImage: CIImage
        if let cached = photo.loadFullImage() {
            resolvedImage = cached
        } else if let loaded = await photo.loadFullImageAsync() {
            resolvedImage = loaded
        } else {
            throw NSError(domain: "ExportService", code: 1, userInfo: [NSLocalizedDescriptionKey: "Could not load image"])
        }
        
        progress?(0.3)
        
        // Wende Adjustments an
        var processedImage = resolvedImage
        if photo.adjustments.hasAdjustments {
            if let adjusted = editEngine.applyAdjustments(to: processedImage, adjustments: photo.adjustments) {
                processedImage = adjusted
            }
        }
        
        // Lens Profile Corrections (Lightroom-like)
        let lensSettings = photo.lensProfileSettings
        let lensMeta = await LensProfileService.shared.lensMeta(for: photo.url)
        let resolvedLensProfile = await LensProfileService.shared.resolveProfile(for: photo.url, settings: lensSettings)
        processedImage = editEngine.applyLensProfileCorrections(
            to: processedImage,
            settings: lensSettings,
            profile: resolvedLensProfile,
            meta: lensMeta
        )
        
        progress?(0.5)
        
        // Wende Crop und Rotation an
        processedImage = editEngine.applyCropAndRotation(
            to: processedImage,
            cropRect: photo.cropRect,
            rotation: photo.rotation
        )
        
        // Lokale Masken (Masking)
        if let masked = editEngine.applyLocalMasks(to: processedImage, masks: photo.localMasks) {
            processedImage = masked
        }
        
        progress?(0.6)
        
        // Wende Wasserzeichen an
        if let watermark = preset.watermarkSettings {
            if let watermarked = editEngine.applyWatermark(to: processedImage, settings: watermark) {
                processedImage = watermarked
            }
        }
        
        progress?(0.8)
        
        // Rendere zu Data
        guard let imageData = editEngine.renderToData(
            processedImage,
            format: preset.format,
            quality: preset.quality,
            maxDimension: preset.maxDimension
        ) else {
            throw NSError(domain: "ExportService", code: 2, userInfo: [NSLocalizedDescriptionKey: "Could not render image"])
        }
        
        progress?(0.9)
        
        // Schreibe Datei
        try imageData.write(to: outputURL)
        
        // Kopiere Metadaten wenn vorhanden
        if let metadata = photo.iptcMetadata {
            try? IPTCMetadataService.shared.writeMetadata(metadata, to: outputURL)
        }
        
        progress?(0.95)
        
        // Upload zu konfigurierten Zielen
        if !preset.uploadTargets.isEmpty && !uploadTargets.isEmpty {
            let targetsToUpload = uploadTargets.filter { target in
                preset.uploadTargets.contains(target.id.uuidString) && target.isEnabled
            }
            
            for target in targetsToUpload {
                do {
                    try await UploadService.shared.upload(
                        fileURL: outputURL,
                        to: target
                    ) { uploadProgress in
                        // Kombiniere Export- und Upload-Progress
                        let totalProgress = 0.95 + (uploadProgress * 0.05)
                        DispatchQueue.main.async {
                            progress?(totalProgress)
                        }
                    }
                } catch {
                    print("Upload error for target \(target.name): \(error)")
                    // Upload-Fehler werden geloggt, aber Export wird nicht abgebrochen
                }
            }
        }
        
        progress?(1.0)
    }
    
    /// Exportiert mehrere Fotos
    func exportBatch(photos: [PhotoItem], preset: ExportPreset, outputDirectory: URL, uploadTargets: [UploadTarget] = [], progress: ((Int, Int) -> Void)? = nil) async throws {
        let fileManager = FileManager.default
        try fileManager.createDirectory(at: outputDirectory, withIntermediateDirectories: true)
        
        for (index, photo) in photos.enumerated() {
            let fileName = photo.fileName
            let baseName = (fileName as NSString).deletingPathExtension
            let fileExtension = preset.format.fileExtension
            let outputURL = outputDirectory.appendingPathComponent("\(baseName).\(fileExtension)")
            
            try await export(photo: photo, preset: preset, to: outputURL, uploadTargets: uploadTargets) { _ in
                // Progress wird pro Foto aktualisiert
            }
            
            // Aktualisiere Batch-Progress nach jedem Foto
            progress?(index + 1, photos.count)
        }
    }
}

