//
//  EditCatalogService.swift
//  WB Foto Manager
//
//  Non-destructive edit persistence ("catalog") per photo.
//  Stores adjustments/crop/rotation without touching the original file.
//

import Foundation
import CoreGraphics

actor EditCatalogService {
    static let shared = EditCatalogService()

    struct CodableRect: Codable, Hashable, Sendable {
        var x: Double
        var y: Double
        var width: Double
        var height: Double

        init(_ rect: CGRect) {
            self.x = rect.origin.x
            self.y = rect.origin.y
            self.width = rect.size.width
            self.height = rect.size.height
        }

        var cgRect: CGRect {
            CGRect(x: x, y: y, width: width, height: height)
        }
    }

    struct EditEntry: Codable, Hashable, Sendable {
        var version: Int = 3
        var updatedAt: Date = Date()

        var adjustments: PhotoAdjustments
        var localMasks: [LocalAdjustmentMask] = []
        var lensProfileSettings: LensProfileSettings = LensProfileSettings()
        var cropRect: CodableRect?
        var rotation: Double
        
        // Virtual Copy Metadata
        var isMaster: Bool = true
        var masterID: String? = nil // UUID string of master
        var virtualCopyNumber: Int = 0

        init(adjustments: PhotoAdjustments, localMasks: [LocalAdjustmentMask] = [], lensProfileSettings: LensProfileSettings = LensProfileSettings(), cropRect: CGRect?, rotation: Double, isMaster: Bool = true, masterID: UUID? = nil, virtualCopyNumber: Int = 0) {
            self.adjustments = adjustments
            self.localMasks = localMasks
            self.lensProfileSettings = lensProfileSettings
            self.cropRect = cropRect.map { CodableRect($0) }
            self.rotation = rotation
            self.isMaster = isMaster
            self.masterID = masterID?.uuidString
            self.virtualCopyNumber = virtualCopyNumber
            self.updatedAt = Date()
        }

        var isDefault: Bool {
            let defaults = PhotoAdjustments()
            let cropIsDefault = (cropRect == nil)
            let rotationIsDefault = abs(rotation) < 0.0001
            return adjustments == defaults && localMasks.isEmpty && lensProfileSettings.isDefault && cropIsDefault && rotationIsDefault
        }
        
        // MARK: - Codable (rückwärtskompatibel bei neuen Feldern)
        
        private enum CodingKeys: String, CodingKey {
            case version
            case updatedAt
            case adjustments
            case localMasks
            case lensProfileSettings
            case cropRect
            case rotation
            case isMaster
            case masterID
            case virtualCopyNumber
        }
        
        init(from decoder: Decoder) throws {
            let c = try decoder.container(keyedBy: CodingKeys.self)
            
            version = try c.decodeIfPresent(Int.self, forKey: .version) ?? 1
            updatedAt = try c.decodeIfPresent(Date.self, forKey: .updatedAt) ?? Date()
            
            adjustments = try c.decodeIfPresent(PhotoAdjustments.self, forKey: .adjustments) ?? PhotoAdjustments()
            localMasks = try c.decodeIfPresent([LocalAdjustmentMask].self, forKey: .localMasks) ?? []
            lensProfileSettings = try c.decodeIfPresent(LensProfileSettings.self, forKey: .lensProfileSettings) ?? LensProfileSettings()
            
            cropRect = try c.decodeIfPresent(CodableRect.self, forKey: .cropRect)
            rotation = try c.decodeIfPresent(Double.self, forKey: .rotation) ?? 0.0
            
            isMaster = try c.decodeIfPresent(Bool.self, forKey: .isMaster) ?? true
            masterID = try c.decodeIfPresent(String.self, forKey: .masterID)
            virtualCopyNumber = try c.decodeIfPresent(Int.self, forKey: .virtualCopyNumber) ?? 0
        }
        
        func encode(to encoder: Encoder) throws {
            var c = encoder.container(keyedBy: CodingKeys.self)
            try c.encode(version, forKey: .version)
            try c.encode(updatedAt, forKey: .updatedAt)
            try c.encode(adjustments, forKey: .adjustments)
            try c.encode(localMasks, forKey: .localMasks)
            try c.encode(lensProfileSettings, forKey: .lensProfileSettings)
            try c.encode(cropRect, forKey: .cropRect)
            try c.encode(rotation, forKey: .rotation)
            try c.encode(isMaster, forKey: .isMaster)
            try c.encode(masterID, forKey: .masterID)
            try c.encode(virtualCopyNumber, forKey: .virtualCopyNumber)
        }
    }

    private struct PersistedCatalog: Codable, Sendable {
        var version: Int = 1
        var updatedAt: Date = Date()
        var edits: [String: EditEntry] = [:]
    }

    private var editsByPath: [String: EditEntry] = [:]
    private var loadTask: Task<Void, Never>?
    private var saveTask: Task<Void, Never>?

    private init() {
        // lazy load on first access
    }

    func snapshot() async -> [String: EditEntry] {
        await ensureLoaded()
        return editsByPath
    }

    func loadEdit(for url: URL, photoID: UUID? = nil) async -> EditEntry? {
        await ensureLoaded()
        return editsByPath[key(for: url, photoID: photoID)]
    }

    func upsertEdit(_ entry: EditEntry, for url: URL, photoID: UUID? = nil) async {
        await ensureLoaded()
        let k = key(for: url, photoID: photoID)
        if entry.isDefault {
            editsByPath.removeValue(forKey: k)
        } else {
            var copy = entry
            copy.updatedAt = Date()
            editsByPath[k] = copy
        }
        scheduleSave()
    }

    func removeEdit(for url: URL, photoID: UUID? = nil) async {
        await ensureLoaded()
        editsByPath.removeValue(forKey: key(for: url, photoID: photoID))
        scheduleSave()
    }

    // MARK: - Private

    private func key(for url: URL, photoID: UUID? = nil) -> String {
        let baseKey: String = {
            if url.isFileURL {
                return url.standardizedFileURL.path
            }
            // Für nicht-file URLs (z.B. phasset://...) absoluteString als stabilen Schlüssel verwenden.
            return url.absoluteString
        }()
        if let id = photoID {
            return "\(baseKey)#\(id.uuidString)"
        }
        return baseKey
    }

    private func ensureLoaded() async {
        if loadTask != nil { return }
        loadTask = Task { [weak self] in
            guard let self else { return }
            await self.loadFromDisk()
        }
        await loadTask?.value
    }

    private func scheduleSave() {
        saveTask?.cancel()
        saveTask = Task { [weak self] in
            guard let self else { return }
            try? await Task.sleep(nanoseconds: 450_000_000) // 450ms debounce
            await self.saveToDisk()
        }
    }

    private func catalogURL() -> URL? {
        guard let appSupport = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
            return nil
        }
        let folder = appSupport.appendingPathComponent("WB Foto Manager", isDirectory: true)
        return folder.appendingPathComponent("edit-catalog.json", isDirectory: false)
    }

    private func loadFromDisk() async {
        guard let url = catalogURL() else { return }
        do {
            let data = try Data(contentsOf: url)
            let decoded = try JSONDecoder().decode(PersistedCatalog.self, from: data)
            editsByPath = decoded.edits
        } catch {
            // No file yet or decode failed – start fresh
            editsByPath = [:]
        }
    }

    private func saveToDisk() async {
        guard let url = catalogURL() else { return }
        do {
            let folder = url.deletingLastPathComponent()
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)

            var payload = PersistedCatalog()
            payload.updatedAt = Date()
            payload.edits = editsByPath

            let enc = JSONEncoder()
            enc.outputFormatting = [] // keep file small
            let data = try enc.encode(payload)
            try data.write(to: url, options: [.atomic])
        } catch {
            // Best effort; ignore (no UI spam)
            // print("EditCatalog save failed: \(error)")
        }
    }
}


