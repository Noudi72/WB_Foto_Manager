//
//  SmartImageLoader.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//  High-Performance Image Loading for Sports Photography
//

import Foundation
import AppKit
import ImageIO
import Combine
import Photos

extension Notification.Name {
    static let smartImageLoaderDidUpdate = Notification.Name("SmartImageLoaderDidUpdate")
}

@MainActor
class SmartImageLoader: ObservableObject {
    @Published private(set) var isLoading = false
    static let shared = SmartImageLoader()
    
    private var cache = NSCache<NSString, NSImage>()
    /// In-flight loads müssen nach *URL + Zielgröße* unterschieden werden.
    /// Sonst blockiert ein Low-Res Load den High-Res Load (Progressive Loading liefert dann nur Low-Res zurück).
    private var loadingTasks: [String: Task<NSImage?, Never>] = [:]
    private var prefetchQueue: [URL] = []
    
    // Settings for sports photography - OPTIMIERT
    private let prefetchCount: Int = 5      // Nächste 5 Bilder prefetchen
    
    private init() {
        cache.countLimit = 50 // Max 50 High-Res Bilder im Cache (ca. 2GB)
        cache.totalCostLimit = 2_000_000_000 // 2GB
    }
    
    /// Lädt ein Bild mit höchster Priorität (für aktuelle Ansicht)
    func loadImage(url: URL, highRes: Bool = true) async -> NSImage? {
        let previewSize: PreviewSize = highRes ? .fullRes : .medium
        return await loadImage(url: url, previewSize: previewSize)
    }
    
    /// Lädt ein Bild für eine konkrete Preview-Größe (Thumbnail/Medium/FullRes).
    func loadImage(url: URL, previewSize: PreviewSize) async -> NSImage? {
        let cacheKey = cacheKey(for: url, previewSize: previewSize)
        let cacheKeyNSString = cacheKey as NSString
        
        // Check cache first
        if let cached = cache.object(forKey: cacheKeyNSString) {
            return cached
        }
        
        // Check if already loading
        if let existingTask = loadingTasks[cacheKey] {
            return await existingTask.value
        }
        
        // Start new loading task
        let task = Task(priority: .userInitiated) { () -> NSImage? in
            let size = previewSize.maxDimension
            // Wichtig: Für High-Res Preview niemals das eingebettete Thumbnail verwenden,
            // sonst wirkt die Vorschau "unscharf" bis ein Slider (CoreImage-Render) getriggert wird.
            let alwaysFromFullImage = (previewSize == .fullRes)
            let wantsSquareThumb = (previewSize == .thumbnail)
            let image = await self.loadFromDisk(
                url: url,
                maxSize: size,
                alwaysFromFullImage: alwaysFromFullImage,
                wantsSquareThumbnail: wantsSquareThumb
            )
            
            // Cache the result
            if let image = image {
                await MainActor.run {
                    self.cache.setObject(image, forKey: cacheKeyNSString, cost: Int(size * size * 4))
                }
            }
            
            return image
        }
        
        loadingTasks[cacheKey] = task
        let result = await task.value
        loadingTasks.removeValue(forKey: cacheKey)
        
        return result
    }
    
    /// Progressive Loading: Lädt erst Low-Res, dann High-Res
    func loadProgressive(url: URL) async -> (lowRes: NSImage?, highRes: NSImage?) {
        async let lowRes = loadImage(url: url, previewSize: .medium)
        async let highRes = loadImage(url: url, previewSize: .fullRes)
        
        return await (lowRes, highRes)
    }
    
    /// Prefetch nächste Bilder im Hintergrund
    func prefetchNext(urls: [URL]) {
        prefetchQueue = urls
        
        Task(priority: .background) {
            for url in urls.prefix(prefetchCount) {
                // Lade Medium-Res für schnelles Browsing in der Detailansicht
                _ = await loadImage(url: url, previewSize: .medium)
            }
        }
    }
    
    /// Prefetch Thumbnails (für Filmstrip/Grid), damit weniger "Spinner" sichtbar sind.
    func prefetchThumbnails(urls: [URL], count: Int = 24) {
        Task(priority: .background) {
            for url in urls.prefix(count) {
                _ = await loadImage(url: url, previewSize: .thumbnail)
            }
        }
    }
    
    /// Clear Cache (z.B. beim Ordnerwechsel)
    func clearCache() {
        cache.removeAllObjects()
        loadingTasks.values.forEach { $0.cancel() }
        loadingTasks.removeAll()
    }
    
    // MARK: - Private Helpers
    
    private func cacheKey(for url: URL, previewSize: PreviewSize) -> String {
        "\(url.absoluteString)-\(Int(previewSize.maxDimension))"
    }
    
    private func loadFromDisk(url: URL, maxSize: CGFloat, alwaysFromFullImage: Bool, wantsSquareThumbnail: Bool) async -> NSImage? {
        if let assetID = PHAssetURL.localIdentifier(from: url) {
            return await loadFromPhotoKit(
                assetLocalIdentifier: assetID,
                maxSize: maxSize,
                highQuality: alwaysFromFullImage,
                wantsSquareThumbnail: wantsSquareThumbnail
            )
        }
        
        return await Task.detached(priority: .userInitiated) {
            // Check file exists
            guard FileManager.default.fileExists(atPath: url.path) else {
                print("⚠️ Datei nicht gefunden: \(url.path)")
                return nil
            }
            
            // Create image source
            guard let imageSource = CGImageSourceCreateWithURL(url as CFURL, nil) else {
                print("⚠️ Konnte ImageSource nicht erstellen: \(url.path)")
                return nil
            }
            
            // Optimierte Optionen für beste Performance/Qualität
            // - Low-Res: darf Embedded Thumbnail nutzen (schnell)
            // - High-Res: IMMER aus Full Image generieren (maximale Schärfe)
            // Für Square-Thumbnails (Grid/Filmstrip) etwas grösser rendern,
            // damit Portraits beim aspectFill nicht hochskaliert werden müssen (sonst wirkt es weich).
            let effectiveMaxSize = wantsSquareThumbnail ? (maxSize * 1.5) : maxSize
            var options: [CFString: Any] = [
                kCGImageSourceThumbnailMaxPixelSize: effectiveMaxSize,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceShouldCache: true,
                kCGImageSourceShouldAllowFloat: true
            ]
            
            if alwaysFromFullImage {
                options[kCGImageSourceCreateThumbnailFromImageAlways] = true
                options[kCGImageSourceShouldCacheImmediately] = true
            } else {
                options[kCGImageSourceCreateThumbnailFromImageIfAbsent] = true
            }
            
            guard let cgImage = CGImageSourceCreateThumbnailAtIndex(imageSource, 0, options as CFDictionary) else {
                print("⚠️ Konnte Thumbnail nicht erstellen: \(url.path)")
                return nil
            }
            
            let image = NSImage(cgImage: cgImage, size: CGSize(width: cgImage.width, height: cgImage.height))
            return image
        }.value
    }
    
    private func loadFromPhotoKit(assetLocalIdentifier: String, maxSize: CGFloat, highQuality: Bool, wantsSquareThumbnail: Bool) async -> NSImage? {
        let fetched = PHAsset.fetchAssets(withLocalIdentifiers: [assetLocalIdentifier], options: nil)
        guard let asset = fetched.firstObject else { return nil }
        
        let options = PHImageRequestOptions()
        options.isNetworkAccessAllowed = true
        options.version = .current
        
        // Strategie:
        // - FullRes/HighQuality: auf finales Bild warten (degraded ignorieren)
        // - Thumbnails: sofort etwas anzeigen (auch degraded) und später automatisch updaten, sobald final verfügbar ist.
        let waitForFinalBeforeReturn = highQuality
        options.deliveryMode = highQuality ? .highQualityFormat : .opportunistic
        options.resizeMode = highQuality ? .exact : .fast
        options.isSynchronous = false
        
        let effectiveMaxSize = wantsSquareThumbnail ? (maxSize * 1.5) : maxSize
        let targetSize = CGSize(width: effectiveMaxSize, height: effectiveMaxSize)
        let contentMode: PHImageContentMode = wantsSquareThumbnail ? .aspectFill : .aspectFit
        
        return await withCheckedContinuation { continuation in
            var didResume = false
            var bestDegraded: NSImage?
            
            let requestID = PHImageManager.default().requestImage(
                for: asset,
                targetSize: targetSize,
                contentMode: contentMode,
                options: options
            ) { image, info in
                DispatchQueue.main.async {
                    let cancelled = (info?[PHImageCancelledKey] as? Bool) ?? false
                    let degraded = (info?[PHImageResultIsDegradedKey] as? Bool) ?? false
                    
                    if cancelled {
                        if !didResume {
                            didResume = true
                            continuation.resume(returning: bestDegraded)
                        }
                        return
                    }
                    
                    guard let img = image else { return }
                    
                    if degraded {
                        bestDegraded = img
                        // Thumbnails: sofort anzeigen, später upgraden wenn final kommt.
                        if !waitForFinalBeforeReturn, !didResume {
                            didResume = true
                            continuation.resume(returning: img)
                        }
                        return
                    }
                    
                    // Finales Bild
                    if !didResume {
                        didResume = true
                        continuation.resume(returning: img)
                    } else if !waitForFinalBeforeReturn {
                        // Wir haben bereits degraded zurückgegeben → Cache upgraden und View refreshen.
                        let url = PHAssetURL.url(forLocalIdentifier: assetLocalIdentifier)
                        let key = "\(url.absoluteString)-\(Int(maxSize))"
                        self.cache.setObject(img, forKey: key as NSString, cost: Int(effectiveMaxSize * effectiveMaxSize * 4))
                        NotificationCenter.default.post(
                            name: .smartImageLoaderDidUpdate,
                            object: nil,
                            userInfo: ["url": url.absoluteString, "maxDim": Int(maxSize)]
                        )
                    }
                    return
                }
            }
            
            // Safety: falls PhotoKit nur ein degraded liefert (z.B. iCloud langsam), nach kurzer Zeit trotzdem etwas anzeigen.
            Task { @MainActor in
                let timeoutNs: UInt64 = waitForFinalBeforeReturn ? 8_000_000_000 : 1_200_000_000
                try? await Task.sleep(nanoseconds: timeoutNs)
                guard !didResume else { return }
                // Nicht hängen: spätestens hier zurückgeben (degraded falls vorhanden, sonst nil).
                didResume = true
                continuation.resume(returning: bestDegraded)
                // Request NICHT canceln – wenn später final kommt, aktualisieren wir Cache + senden Notification.
                _ = requestID
            }
        }
    }
}

