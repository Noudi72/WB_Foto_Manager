//
//  BestShotService.swift
//  WB Foto Manager
//
//  Smart Culling MVP: Best-Shot Scoring (sharpness + face prominence)
//

import Foundation
import AppKit
import CoreImage
import Vision

/// Lightweight scorer for "best shot" ranking inside bursts/selections.
/// Uses a fast sharpness metric (edge energy) plus optional face prominence.
actor BestShotService {
    static let shared = BestShotService()
    
    private var scoreCache: [UUID: Double] = [:]
    
    /// For stability/performance we use a software context on a small working image.
    private let ciContext = CIContext(options: [
        .useSoftwareRenderer: true,
        .cacheIntermediates: false,
        .workingColorSpace: NSNull(),
        .outputColorSpace: NSNull()
    ])
    
    private init() {}
    
    struct PhotoRef: Sendable, Hashable {
        let id: UUID
        let url: URL
    }
    
    func clearCache() {
        scoreCache.removeAll(keepingCapacity: true)
    }
    
    func bestPhotoID(in photos: [PhotoRef]) async -> UUID? {
        guard photos.count >= 2 else { return photos.first?.id }
        if Task.isCancelled { return nil }
        
        var bestID: UUID?
        var bestScore: Double = -Double.greatestFiniteMagnitude
        
        // Evaluate sequentially (actor isolation); cached scores make this cheap after first run.
        for p in photos {
            if Task.isCancelled { return nil }
            let s = await score(for: p)
            if s > bestScore {
                bestScore = s
                bestID = p.id
            }
        }
        
        return bestID
    }
    
    func score(for photo: PhotoRef) async -> Double {
        if let cached = scoreCache[photo.id] {
            return cached
        }
        if Task.isCancelled { return 0 }
        
        // Load a preview image (PhotoKit needs .medium to avoid square-crop; files can use .thumbnail for speed).
        let isPhotoKit = PHAssetURL.localIdentifier(from: photo.url) != nil
        let previewSize: PreviewSize = isPhotoKit ? .medium : .thumbnail
        guard let nsImage = await SmartImageLoader.shared.loadImage(url: photo.url, previewSize: previewSize) else {
            scoreCache[photo.id] = 0
            return 0
        }
        
        // Convert to CGImage on MainActor (AppKit safety).
        let cg: CGImage? = await MainActor.run {
            nsImage.cgImage(forProposedRect: nil, context: nil, hints: nil)
        }
        guard let cgImage = cg else {
            scoreCache[photo.id] = 0
            return 0
        }
        
        // Compute components.
        let sharp = sharpnessScore(cgImage: cgImage)
        let face = faceProminenceScore(cgImage: cgImage)
        
        // Combine (MVP): sharpness dominates; faces give a small boost for people/portraits.
        // Typical ranges: sharp ~0.01..0.20, face area ~0.00..0.20 (normalized).
        let combined = sharp + (face * 0.18)
        
        scoreCache[photo.id] = combined
        return combined
    }
    
    // MARK: - Metrics
    
    private func sharpnessScore(cgImage: CGImage) -> Double {
        // Downsample for speed & consistency.
        let ci = CIImage(cgImage: cgImage)
        let extent = ci.extent.integral
        guard extent.width > 1, extent.height > 1 else { return 0 }
        
        let maxDim: CGFloat = 512
        let longest = max(extent.width, extent.height)
        let scale = max(0.01, min(1.0, maxDim / longest))
        
        let scaled = ci
            .transformed(by: CGAffineTransform(scaleX: scale, y: scale))
            .cropped(to: CGRect(origin: .zero, size: CGSize(width: extent.width * scale, height: extent.height * scale)).integral)
        
        // Edge energy (CIEdges gives positive edges; CIAreaAverage gives a stable scalar).
        let gray = scaled.applyingFilter("CIColorControls", parameters: [
            kCIInputSaturationKey: 0.0
        ])
        let edges = gray.applyingFilter("CIEdges", parameters: [
            kCIInputIntensityKey: 1.0
        ])
        let avg = edges.applyingFilter("CIAreaAverage", parameters: [
            kCIInputExtentKey: CIVector(cgRect: edges.extent)
        ])
        
        var pixel = [UInt8](repeating: 0, count: 4)
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        pixel.withUnsafeMutableBytes { ptr in
            guard let base = ptr.baseAddress else { return }
            ciContext.render(
                avg,
                toBitmap: base,
                rowBytes: 4,
                bounds: CGRect(x: 0, y: 0, width: 1, height: 1),
                format: .RGBA8,
                colorSpace: colorSpace
            )
        }
        
        let r = Double(pixel[0]) / 255.0
        let g = Double(pixel[1]) / 255.0
        let b = Double(pixel[2]) / 255.0
        return (r + g + b) / 3.0
    }
    
    private func faceProminenceScore(cgImage: CGImage) -> Double {
        let request = VNDetectFaceRectanglesRequest()
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        try? handler.perform([request])
        
        guard let faces = request.results, !faces.isEmpty else { return 0 }
        // Use the largest face area as a simple prominence measure (0..1).
        let maxArea = faces
            .map { Double($0.boundingBox.width * $0.boundingBox.height) }
            .max() ?? 0
        return max(0, min(1, maxArea))
    }
}


