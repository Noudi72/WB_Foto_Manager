//
//  RatingPersistenceService.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import ImageIO

/// Service für Rating-Persistenz in Bild-Metadaten
final class RatingPersistenceService: @unchecked Sendable {
    nonisolated static let shared = RatingPersistenceService()
    
    private init() {}
    
    /// Lädt Rating aus Bild-Metadaten
    nonisolated func loadRating(from url: URL) -> Int {
        // PhotoKit / nicht-file URLs: Rating kommt in der App aus lokaler Persistenz.
        guard url.isFileURL else { return 0 }
        
        // 1) Embedded Metadaten (JPEG/HEIC/TIFF/PNG …) – best effort
        if let embedded = loadEmbeddedRating(from: url) {
            return clampRating(embedded)
        }
        
        // 2) RAW-Workflows (Lightroom/Camera Raw): Rating liegt sehr oft im Sidecar-XMP (IMG_1234.XMP)
        if let sidecar = loadSidecarXMPRating(for: url) {
            return clampRating(sidecar)
        }
        
        return 0
    }
    
    // MARK: - Helpers (Read)
    
    private nonisolated func clampRating(_ value: Int) -> Int {
        max(0, min(5, value))
    }
    
    private nonisolated func parseRatingValue(_ any: Any?) -> Int? {
        guard let any else { return nil }
        if let i = any as? Int { return i }
        if let d = any as? Double { return Int(d.rounded()) }
        if let s = any as? String {
            let trimmed = s.trimmingCharacters(in: .whitespacesAndNewlines)
            if let i = Int(trimmed) { return i }
            if let d = Double(trimmed) { return Int(d.rounded()) }
        }
        return nil
    }
    
    private nonisolated func loadEmbeddedRating(from url: URL) -> Int? {
        guard let imageSource = CGImageSourceCreateWithURL(url as CFURL, nil),
              let metadata = CGImageSourceCopyPropertiesAtIndex(imageSource, 0, nil) as? [String: Any] else {
            return nil
        }
        
        // 0) XMP (korrekter Weg über CGImageMetadata – liefert z.B. Lightroom/Camera Raw Ratings)
        if let meta = CGImageSourceCopyMetadataAtIndex(imageSource, 0, nil) {
            if let s = CGImageMetadataCopyStringValueWithPath(meta, nil, "xmp:Rating" as CFString) {
                if let r = parseRatingValue(s as String) { return r }
            }
        }
        
        // 1) Top-level (manche Tools schreiben hier)
        if let r = parseRatingValue(metadata["Rating" as String]) { return r }
        if let r = parseRatingValue(metadata["xmp:Rating" as String]) { return r }
        
        // 2) IPTC Star Rating (kommt häufig bei JPEGs vor)
        if let iptcDict = metadata[kCGImagePropertyIPTCDictionary as String] as? [String: Any] {
            if let r = parseRatingValue(iptcDict["StarRating" as String]) { return r }
            if let r = parseRatingValue(iptcDict["Rating" as String]) { return r }
        }
        
        return nil
    }
    
    private nonisolated func loadSidecarXMPRating(for url: URL) -> Int? {
        // Nur sinnvoll bei RAW/ähnlichen Workflows – sonst wäre das in grossen Ordnern zu teuer.
        let ext = url.pathExtension.lowercased()
        let rawExts: Set<String> = [
            "dng","cr2","cr3","nef","orf","arw","raf","rw2","pef","srw","3fr","mef","mos","r3d","x3f"
        ]
        guard rawExts.contains(ext) else { return nil }
        
        let base = url.deletingPathExtension()
        let candidates: [URL] = [
            base.appendingPathExtension("xmp"),
            base.appendingPathExtension("XMP")
        ]
        
        for xmpURL in candidates {
            guard FileManager.default.fileExists(atPath: xmpURL.path) else { continue }
            
            // XMP ist XML/Text – wir versuchen UTF-8, sonst Latin1.
            if let xml = try? String(contentsOf: xmpURL, encoding: .utf8) {
                if let r = parseRatingFromXMP(xml) { return r }
            } else if let data = try? Data(contentsOf: xmpURL),
                      let xml = String(data: data, encoding: .isoLatin1) {
                if let r = parseRatingFromXMP(xml) { return r }
            }
        }
        
        return nil
    }
    
    private nonisolated func parseRatingFromXMP(_ xml: String) -> Int? {
        // Lightroom/Camera Raw nutzen typischerweise xmp:Rating="3" oder <xmp:Rating>3</xmp:Rating>
        let patterns: [String] = [
            #"xmp:Rating\s*=\s*["']\s*(-?\d+(?:\.\d+)?)\s*["']"#,
            #"<xmp:Rating>\s*(-?\d+(?:\.\d+)?)\s*</xmp:Rating>"#
        ]
        
        for pattern in patterns {
            guard let re = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive]) else { continue }
            let range = NSRange(xml.startIndex..<xml.endIndex, in: xml)
            if let match = re.firstMatch(in: xml, options: [], range: range),
               match.numberOfRanges >= 2,
               let rRange = Range(match.range(at: 1), in: xml) {
                let raw = String(xml[rRange]).trimmingCharacters(in: .whitespacesAndNewlines)
                if let i = Int(raw) { return i }
                if let d = Double(raw) { return Int(d.rounded()) }
            }
        }
        return nil
    }
    
    /// Schreibt Rating in Bild-Metadaten
    nonisolated func writeRating(_ rating: Int, to url: URL) throws {
        guard let imageSource = CGImageSourceCreateWithURL(url as CFURL, nil),
              let image = CGImageSourceCreateImageAtIndex(imageSource, 0, nil),
              let uti = CGImageSourceGetType(imageSource) else {
            throw NSError(domain: "RatingPersistenceService", code: 1, userInfo: [NSLocalizedDescriptionKey: "Could not read image"])
        }
        
        let mutableData = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(mutableData, uti, 1, nil) else {
            throw NSError(domain: "RatingPersistenceService", code: 2, userInfo: [NSLocalizedDescriptionKey: "Could not create image destination"])
        }
        
        // Lade bestehende Metadaten
        var metadata = CGImageSourceCopyPropertiesAtIndex(imageSource, 0, nil) as? [String: Any] ?? [:]
        
        // Setze Rating in verschiedenen Formaten für Kompatibilität
        metadata["Rating" as String] = rating
        metadata["xmp:Rating" as String] = rating
        
        // IPTC Star Rating
        var iptcDict: [String: Any] = metadata[kCGImagePropertyIPTCDictionary as String] as? [String: Any] ?? [:]
        iptcDict["StarRating" as String] = rating
        metadata[kCGImagePropertyIPTCDictionary as String] = iptcDict
        
        // Schreibe Bild mit Metadaten
        CGImageDestinationAddImage(destination, image, metadata as CFDictionary)
        guard CGImageDestinationFinalize(destination) else {
            throw NSError(domain: "RatingPersistenceService", code: 3, userInfo: [NSLocalizedDescriptionKey: "Could not finalize image"])
        }
        
        // Atomare Operation
        let tempURL = url.appendingPathExtension("tmp")
        try mutableData.write(to: tempURL)
        try FileManager.default.replaceItem(at: url, withItemAt: tempURL, backupItemName: nil, options: [], resultingItemURL: nil)
    }
}

