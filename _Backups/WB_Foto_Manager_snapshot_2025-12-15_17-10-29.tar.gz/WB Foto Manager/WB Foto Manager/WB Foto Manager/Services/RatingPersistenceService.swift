//
//  RatingPersistenceService.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import ImageIO

/// Service für Rating-Persistenz in Bild-Metadaten
final class RatingPersistenceService: @unchecked Sendable {
    nonisolated static let shared = RatingPersistenceService()
    
    private init() {}
    
    /// Lädt Rating aus Bild-Metadaten
    nonisolated func loadRating(from url: URL) -> Int {
        guard let imageSource = CGImageSourceCreateWithURL(url as CFURL, nil),
              let metadata = CGImageSourceCopyPropertiesAtIndex(imageSource, 0, nil) as? [String: Any] else {
            return 0
        }
        
        // XMP Rating - verwende EXIF Rating als Fallback
        // Rating wird normalerweise in einem speziellen XMP-Feld gespeichert
        // Für Kompatibilität prüfen wir verschiedene Felder
        if let rating = metadata["Rating" as String] as? Int {
            return rating
        }
        if let rating = metadata["xmp:Rating" as String] as? Int {
            return rating
        }
        
        // IPTC Star Rating
        if let iptcDict = metadata[kCGImagePropertyIPTCDictionary as String] as? [String: Any],
           let rating = iptcDict["StarRating" as String] as? Int {
            return rating
        }
        
        return 0
    }
    
    /// Schreibt Rating in Bild-Metadaten
    nonisolated func writeRating(_ rating: Int, to url: URL) throws {
        guard let imageSource = CGImageSourceCreateWithURL(url as CFURL, nil),
              let image = CGImageSourceCreateImageAtIndex(imageSource, 0, nil),
              let uti = CGImageSourceGetType(imageSource) else {
            throw NSError(domain: "RatingPersistenceService", code: 1, userInfo: [NSLocalizedDescriptionKey: "Could not read image"])
        }
        
        let mutableData = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(mutableData, uti, 1, nil) else {
            throw NSError(domain: "RatingPersistenceService", code: 2, userInfo: [NSLocalizedDescriptionKey: "Could not create image destination"])
        }
        
        // Lade bestehende Metadaten
        var metadata = CGImageSourceCopyPropertiesAtIndex(imageSource, 0, nil) as? [String: Any] ?? [:]
        
        // Setze Rating in verschiedenen Formaten für Kompatibilität
        metadata["Rating" as String] = rating
        metadata["xmp:Rating" as String] = rating
        
        // IPTC Star Rating
        var iptcDict: [String: Any] = metadata[kCGImagePropertyIPTCDictionary as String] as? [String: Any] ?? [:]
        iptcDict["StarRating" as String] = rating
        metadata[kCGImagePropertyIPTCDictionary as String] = iptcDict
        
        // Schreibe Bild mit Metadaten
        CGImageDestinationAddImage(destination, image, metadata as CFDictionary)
        guard CGImageDestinationFinalize(destination) else {
            throw NSError(domain: "RatingPersistenceService", code: 3, userInfo: [NSLocalizedDescriptionKey: "Could not finalize image"])
        }
        
        // Atomare Operation
        let tempURL = url.appendingPathExtension("tmp")
        try mutableData.write(to: tempURL)
        try FileManager.default.replaceItem(at: url, withItemAt: tempURL, backupItemName: nil, options: [], resultingItemURL: nil)
    }
}

