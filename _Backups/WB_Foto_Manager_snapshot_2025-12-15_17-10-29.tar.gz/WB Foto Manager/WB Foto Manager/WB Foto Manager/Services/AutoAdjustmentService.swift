//
//  AutoAdjustmentService.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import CoreImage

/// AI-basierte Auto-Adjustments
class AutoAdjustmentService {
    static let shared = AutoAdjustmentService()
    
    private init() {}
    
    /// Analysiert ein PhotoItem und gibt optimale Adjustments zurück
    func analyzeAndAdjust(photo: PhotoItem) async -> PhotoAdjustments? {
        guard let image = photo.loadFullImage() else { return nil }
        return analyzeAndAdjust(image: image)
    }
    
    /// Analysiert ein Bild und gibt optimale Adjustments zurück
    func analyzeAndAdjust(image: CIImage) -> PhotoAdjustments {
        // Einfache Heuristik-basierte Auto-Adjustments
        // In einer echten Implementierung könnte hier ML/AI verwendet werden
        
        var adjustments = PhotoAdjustments()
        
        // Analysiere Histogramm für Exposure
        if let histogram = analyzeHistogram(image: image) {
            // Auto Exposure basierend auf Histogramm
            let mean = histogram.mean
            if mean < 0.3 {
                adjustments.exposure = 0.5 // Aufhellen
            } else if mean > 0.7 {
                adjustments.exposure = -0.3 // Abdunkeln
            }
            
            // Auto Contrast
            let contrast = histogram.stdDev
            if contrast < 0.2 {
                adjustments.contrast = 1.2 // Mehr Kontrast
            }
        }
        
        // Auto White Balance (vereinfacht)
        if let colorBalance = analyzeColorBalance(image: image) {
            adjustments.temperature = colorBalance.temperature
            adjustments.tint = colorBalance.tint
        }
        
        return adjustments
    }
    
    private func analyzeHistogram(image: CIImage) -> (mean: Double, stdDev: Double)? {
        // Vereinfachte Histogramm-Analyse
        let extent = image.extent
        let context = CIContext()
        
        // Erstelle ein kleines Sample für schnelle Analyse
        let sampleSize = CGSize(width: 100, height: 100)
        let sampleRect = CGRect(
            x: extent.midX - sampleSize.width / 2,
            y: extent.midY - sampleSize.height / 2,
            width: sampleSize.width,
            height: sampleSize.height
        )
        
        guard let cgImage = context.createCGImage(image, from: sampleRect) else {
            return nil
        }
        
        // Analysiere Pixel-Daten
        let width = cgImage.width
        let height = cgImage.height
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let bytesPerPixel = 4
        let bytesPerRow = bytesPerPixel * width
        let bitsPerComponent = 8
        
        var pixelData = [UInt8](repeating: 0, count: width * height * bytesPerPixel)
        guard let context2 = CGContext(
            data: &pixelData,
            width: width,
            height: height,
            bitsPerComponent: bitsPerComponent,
            bytesPerRow: bytesPerRow,
            space: colorSpace,
            bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue
        ) else {
            return nil
        }
        
        context2.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
        
        // Berechne Durchschnitt und Standardabweichung
        var sum: Double = 0
        var sumSquared: Double = 0
        let count = Double(width * height)
        
        for i in stride(from: 0, to: pixelData.count, by: bytesPerPixel) {
            let r = Double(pixelData[i]) / 255.0
            let g = Double(pixelData[i + 1]) / 255.0
            let b = Double(pixelData[i + 2]) / 255.0
            let luminance = 0.299 * r + 0.587 * g + 0.114 * b
            sum += luminance
            sumSquared += luminance * luminance
        }
        
        let mean = sum / count
        let variance = (sumSquared / count) - (mean * mean)
        let stdDev = sqrt(variance)
        
        return (mean: mean, stdDev: stdDev)
    }
    
    private func analyzeColorBalance(image: CIImage) -> (temperature: Double, tint: Double)? {
        // Vereinfachte Farbanalyse - analysiere dominante Farben
        let extent = image.extent
        let context = CIContext()
        
        let sampleSize = CGSize(width: 100, height: 100)
        let sampleRect = CGRect(
            x: extent.midX - sampleSize.width / 2,
            y: extent.midY - sampleSize.height / 2,
            width: sampleSize.width,
            height: sampleSize.height
        )
        
        guard let cgImage = context.createCGImage(image, from: sampleRect) else {
            return nil
        }
        
        // Analysiere Farbtemperatur (vereinfacht)
        // In einer echten Implementierung würde hier eine detaillierte Farbanalyse durchgeführt
        var avgR: Double = 0
        var avgB: Double = 0
        let width = cgImage.width
        let height = cgImage.height
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        let bytesPerPixel = 4
        let bytesPerRow = bytesPerPixel * width
        
        var pixelData = [UInt8](repeating: 0, count: width * height * bytesPerPixel)
        guard let context2 = CGContext(
            data: &pixelData,
            width: width,
            height: height,
            bitsPerComponent: 8,
            bytesPerRow: bytesPerRow,
            space: colorSpace,
            bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue
        ) else {
            return nil
        }
        
        context2.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))
        
        let count = Double(width * height)
        for i in stride(from: 0, to: pixelData.count, by: bytesPerPixel) {
            avgR += Double(pixelData[i]) / count
            avgB += Double(pixelData[i + 2]) / count
        }
        
        // Schätze Temperatur basierend auf R/B-Verhältnis
        let ratio = avgR / max(avgB, 1.0)
        let temperature: Double
        if ratio > 1.1 {
            temperature = -500 // Kühler (mehr Blau)
        } else if ratio < 0.9 {
            temperature = 500 // Wärmer (mehr Rot)
        } else {
            temperature = 0
        }
        
        return (temperature: temperature, tint: 0)
    }
}

