//
//  PersistentPreviewCache.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import AppKit

enum PreviewSize {
    case thumbnail  // 512px - bessere Grid-Qualität
    case medium     // 2048px - hochwertige Vorschau (2K)
    case large      // 3840px - hohe Qualität (4K)
    case fullRes    // 5120px - maximale Qualität (5K)
    
    var size: CGSize {
        switch self {
        case .thumbnail:
            return CGSize(width: 512, height: 512)
        case .medium:
            return CGSize(width: 2048, height: 2048)
        case .large:
            return CGSize(width: 3840, height: 3840)
        case .fullRes:
            return CGSize(width: 5120, height: 5120)
        }
    }
    
    var maxDimension: CGFloat {
        switch self {
        case .thumbnail: return 512
        case .medium: return 2048
        case .large: return 3840
        case .fullRes: return 5120
        }
    }
}

@MainActor
class PersistentPreviewCache {
    static let shared = PersistentPreviewCache()
    
    private let cache = NSCache<NSString, NSImage>()
    
    private init() {
        cache.countLimit = 100
        cache.totalCostLimit = 1024 * 1024 * 500 // 500 MB
    }
    
    func image(for url: URL, size: PreviewSize) -> NSImage? {
        let key = cacheKey(for: url, size: size)
        return cache.object(forKey: key as NSString)
    }
    
    func setImage(_ image: NSImage, for url: URL, size: PreviewSize) {
        let key = cacheKey(for: url, size: size)
        let cost = Int(image.size.width * image.size.height * 4)
        cache.setObject(image, forKey: key as NSString, cost: cost)
        }
    
    private func cacheKey(for url: URL, size: PreviewSize) -> String {
        return "\(url.path)-\(size.maxDimension)"
    }
    
    func clearCache() {
        cache.removeAllObjects()
    }
}
