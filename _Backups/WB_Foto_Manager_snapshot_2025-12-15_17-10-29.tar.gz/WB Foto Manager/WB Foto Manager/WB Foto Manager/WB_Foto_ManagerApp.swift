//
//  WB_Foto_ManagerApp.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit
import UniformTypeIdentifiers

@main
struct WB_Foto_ManagerApp: App {
    @StateObject private var store = PhotoStore()
    @StateObject private var uiState = UIState()
    
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .environmentObject(uiState)
                .frame(minWidth: 1200, minHeight: 800)
        }
        .defaultSize(width: 1400, height: 900)
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("Ordner öffnen...") {
                    openFolder()
                }
                .keyboardShortcut("o", modifiers: .command)
                
                Divider()
                
                Button("Nächstes Foto") {
                    store.selectNextPhoto()
                }
                .keyboardShortcut(.rightArrow, modifiers: [])
                
                Button("Vorheriges Foto") {
                    store.selectPreviousPhoto()
                }
                .keyboardShortcut(.leftArrow, modifiers: [])
            }

            // File > Save / Save As (normal macOS Workflow)
            CommandGroup(replacing: .saveItem) {
                Button("Speichern") {
                    if let photo = store.currentPhoto {
                        SaveService.shared.saveOriginal(photo: photo)
                    }
                }
                .keyboardShortcut("s", modifiers: .command)

                Button("Kopie speichern unter…") {
                    if let photo = store.currentPhoto {
                        SaveService.shared.saveCopyAs(photo: photo)
                    }
                }
                .keyboardShortcut("s", modifiers: [.command, .shift])
            }
            
            CommandGroup(after: .toolbar) {
                // Rating
                Button("1 Stern") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(1, for: photoID)
                    }
                }
                .keyboardShortcut("1", modifiers: [])
                
                Button("2 Sterne") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(2, for: photoID)
                    }
                }
                .keyboardShortcut("2", modifiers: [])
                
                Button("3 Sterne") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(3, for: photoID)
                    }
                }
                .keyboardShortcut("3", modifiers: [])
                
                Button("4 Sterne") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(4, for: photoID)
                    }
                }
                .keyboardShortcut("4", modifiers: [])
                
                Button("5 Sterne") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(5, for: photoID)
                    }
                }
                .keyboardShortcut("5", modifiers: [])
                
                Button("Rating löschen") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(0, for: photoID)
                    }
                }
                .keyboardShortcut("0", modifiers: [])
                
                Divider()
                
                // Export
                Button("Exportieren...") {
                    uiState.activeSheet = .export
                }
                .keyboardShortcut("e", modifiers: [.command, .shift])
                
                Button("Batch Export...") {
                    uiState.activeSheet = .batchExport
                }
                .keyboardShortcut("b", modifiers: [.command, .shift])
                
                Divider()
                
                Button("Sidebar links ein/aus") {
                    if AppSettings.shared.sidebarAlwaysVisible {
                        uiState.showLeftSidebar = true
                    } else {
                        uiState.showLeftSidebar.toggle()
                    }
                }
                .keyboardShortcut("\\", modifiers: [.command])
                
                Button("Sidebar rechts ein/aus") {
                    uiState.showRightSidebar.toggle()
                }
                .keyboardShortcut("\\", modifiers: [.command, .option])
            }
            
            CommandGroup(replacing: .textEditing) {
                // Bildbearbeitung
                Button("Adjustments zurücksetzen") {
                    resetAdjustments()
                }
                .keyboardShortcut("r", modifiers: [.command, .option])
                
                Divider()
                
                // View Mode
                Button("Detail-Ansicht") {
                    uiState.viewMode = .detail
                }
                .keyboardShortcut("1", modifiers: [.command, .control])
                
                Button("Grid-Ansicht") {
                    uiState.viewMode = .grid
                }
                .keyboardShortcut("2", modifiers: [.command, .control])
                
                Divider()
                
                // Before/After
                Button("Before/After umschalten") {
                    uiState.showBeforeAfter.toggle()
                }
                .keyboardShortcut("b", modifiers: [.command, .option])
                
                Divider()
                
                // Zoom
                Button("Zoom zurücksetzen") {
                    uiState.zoomLevel = 1.0
                }
                .keyboardShortcut("0", modifiers: [.command, .option])
                
                Button("Zoom vergrößern") {
                    uiState.zoomLevel = min(5.0, uiState.zoomLevel + 0.5)
                }
                .keyboardShortcut("=", modifiers: [.command, .option])
                
                Button("Zoom verkleinern") {
                    uiState.zoomLevel = max(0.5, uiState.zoomLevel - 0.5)
                }
                .keyboardShortcut("-", modifiers: [.command, .option])
            }
            
            CommandGroup(after: .appSettings) {
                Button("Einstellungen...") {
                    uiState.activeSheet = .settings
                }
                .keyboardShortcut(",", modifiers: .command)
                
                Divider()
                
                Button("Upload-Ziele verwalten...") {
                    uiState.activeSheet = .uploadSettings
                }
                
                Divider()
                
                Button("Batch Export...") {
                    uiState.activeSheet = .batchExport
                }
                .keyboardShortcut("b", modifiers: [.command, .shift])
                
                Button("Export-Queue Einstellungen...") {
                    uiState.activeSheet = .exportQueueSettings
                }
                
                Button("Backup & Wiederherstellung...") {
                    uiState.activeSheet = .backupRestore
                }
            }
        }
    }
    
    private func openFolder() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        
        panel.begin { response in
            if response == .OK, let url = panel.url {
                store.loadPhotos(from: url)
            }
        }
    }
    
    private func resetAdjustments() {
        guard let photo = store.currentPhoto else { return }
        photo.adjustments.reset()
    }
}
