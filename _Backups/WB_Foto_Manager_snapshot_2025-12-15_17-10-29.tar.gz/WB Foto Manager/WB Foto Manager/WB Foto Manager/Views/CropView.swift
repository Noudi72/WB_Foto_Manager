//
//  CropView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit
import CoreImage
import Combine

struct CropView: View {
    let photo: PhotoItem
    @ObservedObject var store: PhotoStore
    @State private var cropRect: CGRect
    @State private var selectedAspectRatio: CropAspectRatio
    @State private var imageSize: CGSize = .zero
    @State private var displayImage: NSImage?
    @State private var imageScale: CGFloat = 1.0
    @State private var imageOffset: CGSize = .zero
    @Environment(\.dismiss) private var dismiss
    
    // Crop-Handles
    @State private var isDragging: Bool = false
    @State private var dragHandle: CropHandle?
    @State private var dragStartPoint: CGPoint = .zero
    @State private var dragStartCropRect: CGRect = .zero
    
    enum CropHandle {
        case topLeft, topRight, bottomLeft, bottomRight
    }
    
    init(photo: PhotoItem, store: PhotoStore) {
        self.photo = photo
        self.store = store
        // Initialisiere mit bestehendem Crop oder Standard
        if let existingCrop = photo.cropRect {
            _cropRect = State(initialValue: existingCrop)
        } else {
            // Wird in onAppear mit tatsächlicher Bildgröße initialisiert
            _cropRect = State(initialValue: CGRect(x: 0, y: 0, width: 1000, height: 1000))
        }
        _selectedAspectRatio = State(initialValue: CropAspectRatio.commonRatios.first!)
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Toolbar
            HStack {
                // Aspect Ratio Picker
                Picker("Seitenverhältnis", selection: $selectedAspectRatio) {
                    ForEach(CropAspectRatio.commonRatios) { ratio in
                        Text(ratio.name).tag(ratio)
                    }
                }
                .pickerStyle(.menu)
                .frame(width: 150)
                .onChange(of: selectedAspectRatio) { _ in
                    applyAspectRatio()
                }
                
                Spacer()
                
                // Rotation
                HStack {
                    Button(action: { rotate(-90) }) {
                        Image(systemName: "rotate.left")
                    }
                    .help("90° links drehen")
                    
                    Text("\(Int(photo.rotation))°")
                        .frame(width: 50)
                    
                    Button(action: { rotate(90) }) {
                        Image(systemName: "rotate.right")
                    }
                    .help("90° rechts drehen")
                }
                
                Spacer()
                
                Button("Reset") {
                    resetCrop()
                }
                
                Button("Abbrechen") {
                    dismiss()
                }
                
                Button("Anwenden") {
                    applyCrop()
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
            .background(DesignSystem.Colors.background2)
            
            // Crop Canvas
            GeometryReader { geometry in
                ZStack {
                    // Hintergrund
                    Color.black
                    
                    // Bild
                    if let img = displayImage {
                        Image(nsImage: img)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .scaleEffect(imageScale)
                            .offset(imageOffset)
                            .gesture(
                                MagnificationGesture()
                                    .onChanged { value in
                                        imageScale = value
                                    }
                            )
                            .gesture(
                                DragGesture()
                                    .onChanged { value in
                                        if dragHandle == nil {
                                            imageOffset = value.translation
                                        }
                                    }
                            )
                    } else {
                        ProgressView()
                    }
                    
                    // Crop Overlay
                    CropOverlay(
                        cropRect: $cropRect,
                        imageSize: imageSize,
                        containerSize: geometry.size,
                        isDragging: $isDragging,
                        dragHandle: $dragHandle,
                        dragStartPoint: $dragStartPoint,
                        dragStartCropRect: $dragStartCropRect,
                        aspectRatio: selectedAspectRatio.ratio
                    )
                }
            }
        }
        .frame(width: 1000, height: 700)
        .onAppear {
            loadImage()
        }
    }
    
    private func loadImage() {
        guard let originalImage = photo.loadFullImage() else { return }
        
        // Wende bestehende Adjustments an
        let editEngine = EditEngine.shared
        var processed = originalImage
        
        if photo.adjustments.hasAdjustments {
            if let adjusted = editEngine.applyAdjustments(to: processed, adjustments: photo.adjustments) {
                processed = adjusted
            }
        }
        
        // Rendere zu NSImage
        let extent = processed.extent
        imageSize = extent.size
        
        // Initialisiere cropRect (UI-Koordinaten: Ursprung oben-links)
        if let existingCIcrop = photo.cropRect {
            cropRect = convertFromCICropRect(existingCIcrop, imageSize: imageSize)
            constrainCropToImage()
        } else {
            cropRect = CGRect(origin: .zero, size: imageSize)
        }
        
        DispatchQueue.main.async {
            self.displayImage = editEngine.render(processed)
        }
    }
    
    private func applyAspectRatio() {
        guard let ratio = selectedAspectRatio.ratio else {
            return // Frei - keine Einschränkung
        }
        
        let currentWidth = cropRect.width
        let currentHeight = cropRect.height
        let currentCenter = CGPoint(
            x: cropRect.midX,
            y: cropRect.midY
        )
        
        // Berechne neue Größe basierend auf Seitenverhältnis
        var newWidth = currentWidth
        var newHeight = currentWidth / ratio
        
        // Wenn Höhe größer wird, passe Breite an
        if newHeight > currentHeight {
            newHeight = currentHeight
            newWidth = currentHeight * ratio
        }
        
        // Setze neue Crop-Rect mit gleichem Zentrum
        cropRect = CGRect(
            x: currentCenter.x - newWidth / 2,
            y: currentCenter.y - newHeight / 2,
            width: newWidth,
            height: newHeight
        )
        
        // Stelle sicher, dass Crop innerhalb Bildgrenzen bleibt
        constrainCropToImage()
    }
    
    private func constrainCropToImage() {
        let minX: CGFloat = 0
        let minY: CGFloat = 0
        let maxX = imageSize.width
        let maxY = imageSize.height
        
        var newRect = cropRect
        
        // Begrenze auf Bildgrenzen
        if newRect.minX < minX {
            newRect.origin.x = minX
        }
        if newRect.minY < minY {
            newRect.origin.y = minY
        }
        if newRect.maxX > maxX {
            newRect.origin.x = maxX - newRect.width
        }
        if newRect.maxY > maxY {
            newRect.origin.y = maxY - newRect.height
        }
        
        // Stelle sicher, dass Mindestgröße eingehalten wird
        if newRect.width < 50 {
            newRect.size.width = 50
        }
        if newRect.height < 50 {
            newRect.size.height = 50
        }
        
        cropRect = newRect
    }
    
    private func rotate(_ degrees: Double) {
        photo.rotation += degrees
        // Normalisiere auf -180 bis 180
        while photo.rotation > 180 {
            photo.rotation -= 360
        }
        while photo.rotation < -180 {
            photo.rotation += 360
        }
    }
    
    private func resetCrop() {
        cropRect = CGRect(origin: .zero, size: imageSize)
        photo.rotation = 0.0
        selectedAspectRatio = CropAspectRatio.commonRatios.first!
        imageScale = 1.0
        imageOffset = .zero
    }
    
    private func applyCrop() {
        // Speichere im CI-Koordinatensystem (Ursprung unten-links)
        let ciCropRect = convertToCICropRect(cropRect, imageSize: imageSize)
        photo.cropRect = ciCropRect
        
        // Trigger Re-Render im DetailView (PhotoItem wird nicht direkt observed)
        photo.objectWillChange.send()
        store.objectWillChange.send()
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id]
        )
        dismiss()
    }
    
    private func convertToCICropRect(_ viewRect: CGRect, imageSize: CGSize) -> CGRect {
        // viewRect: y=0 ist oben
        // CI rect: y=0 ist unten
        let ciY = imageSize.height - viewRect.origin.y - viewRect.height
        return CGRect(x: viewRect.origin.x, y: ciY, width: viewRect.width, height: viewRect.height)
    }
    
    private func convertFromCICropRect(_ ciRect: CGRect, imageSize: CGSize) -> CGRect {
        // Invertiere Y wieder zurück für UI
        let viewY = imageSize.height - ciRect.origin.y - ciRect.height
        return CGRect(x: ciRect.origin.x, y: viewY, width: ciRect.width, height: ciRect.height)
    }
}

struct CropOverlay: View {
    @Binding var cropRect: CGRect
    let imageSize: CGSize
    let containerSize: CGSize
    @Binding var isDragging: Bool
    @Binding var dragHandle: CropView.CropHandle?
    @Binding var dragStartPoint: CGPoint
    @Binding var dragStartCropRect: CGRect
    let aspectRatio: Double?
    
    // Berechne Skalierung und Offset für die Anzeige
    private var displayScale: CGFloat {
        let imageAspect = imageSize.width / imageSize.height
        let containerAspect = containerSize.width / containerSize.height
        
        let scale: CGFloat
        if imageAspect > containerAspect {
            scale = containerSize.width / imageSize.width
        } else {
            scale = containerSize.height / imageSize.height
        }
        return scale
    }
    
    private var displayOffset: CGSize {
        let scaledSize = CGSize(
            width: imageSize.width * displayScale,
            height: imageSize.height * displayScale
        )
        return CGSize(
            width: (containerSize.width - scaledSize.width) / 2,
            height: (containerSize.height - scaledSize.height) / 2
        )
    }
    
    private var displayCropRect: CGRect {
        CGRect(
            x: cropRect.origin.x * displayScale + displayOffset.width,
            y: cropRect.origin.y * displayScale + displayOffset.height,
            width: cropRect.width * displayScale,
            height: cropRect.height * displayScale
        )
    }
    
    var body: some View {
        ZStack {
            // Dunkler Overlay außerhalb des Crop-Bereichs
            Rectangle()
                .fill(Color.black.opacity(0.5))
                .mask(
                    GeometryReader { geometry in
                        ZStack {
                            Rectangle()
                            Rectangle()
                                .frame(
                                    width: displayCropRect.width,
                                    height: displayCropRect.height
                                )
                                .position(
                                    x: displayCropRect.midX,
                                    y: displayCropRect.midY
                                )
                                .blendMode(.destinationOut)
                        }
                    }
                )
            
            // Crop-Rahmen
            Rectangle()
                .stroke(Color.white, lineWidth: 2)
                .frame(
                    width: displayCropRect.width,
                    height: displayCropRect.height
                )
                .position(
                    x: displayCropRect.midX,
                    y: displayCropRect.midY
                )
            
            // Handles an den Ecken
            CropHandleView(
                position: .topLeft,
                cropRect: displayCropRect,
                onDrag: { delta in
                    handleDrag(handle: .topLeft, delta: delta)
                }
            )
            
            CropHandleView(
                position: .topRight,
                cropRect: displayCropRect,
                onDrag: { delta in
                    handleDrag(handle: .topRight, delta: delta)
                }
            )
            
            CropHandleView(
                position: .bottomLeft,
                cropRect: displayCropRect,
                onDrag: { delta in
                    handleDrag(handle: .bottomLeft, delta: delta)
                }
            )
            
            CropHandleView(
                position: .bottomRight,
                cropRect: displayCropRect,
                onDrag: { delta in
                    handleDrag(handle: .bottomRight, delta: delta)
                }
            )
        }
    }
    
    private func handleDrag(handle: CropView.CropHandle, delta: CGSize) {
        var newRect = cropRect
        let scaleDelta = CGSize(
            width: delta.width / displayScale,
            height: delta.height / displayScale
        )
        
        switch handle {
        case .topLeft:
            newRect.origin.x += scaleDelta.width
            newRect.origin.y += scaleDelta.height
            newRect.size.width -= scaleDelta.width
            newRect.size.height -= scaleDelta.height
            
        case .topRight:
            newRect.origin.y += scaleDelta.height
            newRect.size.width += scaleDelta.width
            newRect.size.height -= scaleDelta.height
            
        case .bottomLeft:
            newRect.origin.x += scaleDelta.width
            newRect.size.width -= scaleDelta.width
            newRect.size.height += scaleDelta.height
            
        case .bottomRight:
            newRect.size.width += scaleDelta.width
            newRect.size.height += scaleDelta.height
        }
        
        // Wende Seitenverhältnis an wenn gesetzt
        if let ratio = aspectRatio {
            let currentRatio = newRect.width / newRect.height
            if abs(currentRatio - ratio) > 0.01 {
                // Passe an Seitenverhältnis an
                let center = CGPoint(x: newRect.midX, y: newRect.midY)
                let newWidth = newRect.height * ratio
                newRect = CGRect(
                    x: center.x - newWidth / 2,
                    y: newRect.origin.y,
                    width: newWidth,
                    height: newRect.height
                )
            }
        }
        
        // Begrenze auf Bildgrenzen
        newRect.origin.x = max(0, min(newRect.origin.x, imageSize.width - newRect.width))
        newRect.origin.y = max(0, min(newRect.origin.y, imageSize.height - newRect.height))
        newRect.size.width = min(newRect.size.width, imageSize.width - newRect.origin.x)
        newRect.size.height = min(newRect.size.height, imageSize.height - newRect.origin.y)
        
        // Mindestgröße
        if newRect.width >= 50 && newRect.height >= 50 {
            cropRect = newRect
        }
    }
}

struct CropHandleView: View {
    let position: CropView.CropHandle
    let cropRect: CGRect
    let onDrag: (CGSize) -> Void
    
    @State private var isDragging = false
    @State private var dragStart: CGPoint = .zero
    @State private var lastTranslation: CGSize = .zero
    
    private var handlePosition: CGPoint {
        switch position {
        case .topLeft:
            return CGPoint(x: cropRect.minX, y: cropRect.minY)
        case .topRight:
            return CGPoint(x: cropRect.maxX, y: cropRect.minY)
        case .bottomLeft:
            return CGPoint(x: cropRect.minX, y: cropRect.maxY)
        case .bottomRight:
            return CGPoint(x: cropRect.maxX, y: cropRect.maxY)
        }
    }
    
    var body: some View {
        Circle()
            .fill(Color.white)
            .frame(width: 20, height: 20)
            .overlay(
                Circle()
                    .stroke(Color.accentColor, lineWidth: 2)
            )
            .position(handlePosition)
            .onHover { hovering in
                if hovering {
                    NSCursor.crosshair.push()
                } else {
                    NSCursor.pop()
                }
            }
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        if !isDragging {
                            isDragging = true
                            dragStart = value.location
                            lastTranslation = .zero
                        }
                        // Wichtig: value.translation ist seit Drag-Start kumulativ.
                        // Für sauberes, kontrollierbares Ziehen brauchen wir *inkrementelle* Deltas.
                        let incremental = CGSize(
                            width: value.translation.width - lastTranslation.width,
                            height: value.translation.height - lastTranslation.height
                        )
                        lastTranslation = value.translation
                        onDrag(incremental)
                    }
                    .onEnded { _ in
                        isDragging = false
                        lastTranslation = .zero
                    }
            )
    }
}

extension View {
    func cursor(_ cursor: NSCursor) -> some View {
        self.onHover { inside in
            if inside {
                cursor.push()
            } else {
                NSCursor.pop()
            }
        }
    }
}
