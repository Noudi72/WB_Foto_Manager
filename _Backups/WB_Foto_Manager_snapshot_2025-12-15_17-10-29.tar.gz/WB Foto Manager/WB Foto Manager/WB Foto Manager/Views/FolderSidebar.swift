//
//  FolderSidebar.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit

struct FolderSidebar: View {
    @ObservedObject var store: PhotoStore
    @State private var folders: [FolderItem] = []
    @State private var favorites: [FolderItem] = []
    @State private var recentFolders: [FolderItem] = []
    @State private var volumes: [FolderItem] = []
    
    var body: some View {
        VStack(spacing: 0) {
            // Header mit "Ordner öffnen" Button
            HStack {
                Text("Ordner")
                    .font(.headline)
                    .foregroundColor(.primary)
                Spacer()
                Button(action: openFolder) {
                    Image(systemName: "folder.badge.plus")
                        .font(.system(size: 14))
                }
                .buttonStyle(.plain)
                .help("Ordner öffnen...")
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(Color(red: 0.13, green: 0.13, blue: 0.14))
            
            // Ordner-Liste
            List {
                // Standard-Ordner
                Section("Standard") {
                    ForEach(standardFolders) { folder in
                        FolderRow(folder: folder, store: store)
                    }
                }
                
                // Volumes (externe Laufwerke)
                if !volumes.isEmpty {
                    Section("Laufwerke") {
                        ForEach(volumes) { folder in
                            FolderRow(folder: folder, store: store)
                        }
                    }
                }
                
                // Favoriten
                if !favorites.isEmpty {
                    Section("Favoriten") {
                        ForEach(favorites) { folder in
                            FolderRow(folder: folder, store: store)
                        }
                    }
                }
                
                // Zuletzt geöffnet
                if !recentFolders.isEmpty {
                    Section("Zuletzt geöffnet") {
                        ForEach(recentFolders) { folder in
                            FolderRow(folder: folder, store: store)
                        }
                    }
                }
            }
            .listStyle(.sidebar)
        }
        .background(Color(red: 0.15, green: 0.15, blue: 0.16)) // #262629
        .onAppear {
            loadFolders()
            loadVolumes()
        }
        .onReceive(NotificationCenter.default.publisher(for: NSWorkspace.didMountNotification)) { _ in
            loadVolumes()
        }
        .onReceive(NotificationCenter.default.publisher(for: NSWorkspace.didUnmountNotification)) { _ in
            loadVolumes()
        }
    }
    
    private func openFolder() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = false
        panel.title = "Ordner auswählen"
        panel.prompt = "Öffnen"
        panel.message = "Wählen Sie einen Ordner mit Bildern aus"
        
        // Erlaube Zugriff auf alle Volumes (inkl. externe Laufwerke)
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        
        panel.begin { response in
            if response == .OK, let url = panel.url {
                store.loadPhotos(from: url)
                addToRecentFolders(url)
            }
        }
    }
    
    private func loadVolumes() {
        let fileManager = FileManager.default
        let volumeURLs = fileManager.mountedVolumeURLs(includingResourceValuesForKeys: [.volumeNameKey, .volumeIsRemovableKey], options: []) ?? []
        
        volumes = volumeURLs.compactMap { url in
            guard let resourceValues = try? url.resourceValues(forKeys: [.volumeNameKey, .volumeIsRemovableKey]),
                  let name = resourceValues.volumeName else {
                return nil
            }
            
            // Zeige nur externe/entfernbare Laufwerke
            if resourceValues.volumeIsRemovable == true {
                return FolderItem(url: url, name: name, type: .volume)
            }
            
            // Zeige auch Netzwerk-Volumes (OneDrive, etc.)
            if url.path.contains("/Volumes/") && !url.path.contains("/System/Volumes/") {
                return FolderItem(url: url, name: name, type: .volume)
            }
            
            return nil
        }
    }
    
    private func addToRecentFolders(_ url: URL) {
        // Entferne Duplikate
        recentFolders.removeAll { $0.url == url }
        
        // Füge am Anfang hinzu
        let folder = FolderItem(url: url, name: url.lastPathComponent, type: .recent)
        recentFolders.insert(folder, at: 0)
        
        // Begrenze auf 10
        if recentFolders.count > 10 {
            recentFolders = Array(recentFolders.prefix(10))
        }
        
        // Speichere in UserDefaults
        saveRecentFolders()
    }
    
    private func saveRecentFolders() {
        let urls = recentFolders.map { $0.url }
        UserDefaults.standard.set(urls.map { $0.path }, forKey: "recentFolders")
    }
    
    private var standardFolders: [FolderItem] {
        // In der App-Sandbox liefern FileManager.urls(for: ...) oft Container-Pfade.
        // Für echte Finder-Pfade nutzen wir den Home-Pfad.
        let home = FileManager.default.homeDirectoryForCurrentUser
        return [
            FolderItem(url: home, name: "Home", type: .standard(.home)),
            FolderItem(url: home.appendingPathComponent("Desktop"), name: "Desktop", type: .standard(.desktop)),
            FolderItem(url: home.appendingPathComponent("Documents"), name: "Documents", type: .standard(.documents)),
            FolderItem(url: home.appendingPathComponent("Downloads"), name: "Downloads", type: .standard(.downloads)),
            FolderItem(url: home.appendingPathComponent("Pictures"), name: "Pictures", type: .standard(.pictures))
        ]
    }
    
    private func loadFolders() {
        // Lade Favoriten aus UserDefaults
        if let favoritePaths = UserDefaults.standard.stringArray(forKey: "favoriteFolders") {
            favorites = favoritePaths.compactMap { path in
                let url = URL(fileURLWithPath: path)
                guard FileManager.default.fileExists(atPath: path) else { return nil }
                return FolderItem(url: url, name: url.lastPathComponent, type: .favorite)
            }
        }
        
        // Lade Recent Folders aus UserDefaults
        if let recentPaths = UserDefaults.standard.stringArray(forKey: "recentFolders") {
            recentFolders = recentPaths.compactMap { path in
                let url = URL(fileURLWithPath: path)
                guard FileManager.default.fileExists(atPath: path) else { return nil }
                return FolderItem(url: url, name: url.lastPathComponent, type: .recent)
            }
        }
    }
}

struct FolderRow: View {
    let folder: FolderItem
    @ObservedObject var store: PhotoStore
    
    var body: some View {
        Button(action: {
            store.loadPhotos(from: folder.url)
        }) {
            HStack {
                Image(systemName: folder.type.icon)
                    .foregroundColor(.secondary)
                    .frame(width: 16)
                Text(folder.name)
                    .foregroundColor(store.currentFolder == folder.url ? .accentColor : .primary)
                Spacer()
            }
        }
        .buttonStyle(.plain)
        .background(store.currentFolder == folder.url ? Color.accentColor.opacity(0.2) : Color.clear)
    }
}

