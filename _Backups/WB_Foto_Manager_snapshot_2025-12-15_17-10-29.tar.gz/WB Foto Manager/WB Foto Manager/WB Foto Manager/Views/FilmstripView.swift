//
//  FilmstripView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI

struct FilmstripView: View {
    let photos: [PhotoItem]
    @ObservedObject var store: PhotoStore
    
    var body: some View {
        ScrollViewReader { proxy in
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 4) {
                    ForEach(photos) { photo in
                        FilmstripPhotoCell(
                            photo: photo,
                            store: store,
                            isSelected: store.currentPhotoID == photo.id
                        )
                        .id(photo.id)
                        .onTapGesture {
                            store.selectPhoto(photo)
                        }
                    }
                }
                .padding(.horizontal, 4)
            }
            .background(DesignSystem.Colors.background4)
            .overlay(
                Rectangle()
                    .fill(DesignSystem.Colors.border)
                    .frame(height: 1),
                alignment: .top
            )
            .onChange(of: store.currentPhotoID) { newID in
                if let id = newID {
                    withAnimation {
                        proxy.scrollTo(id, anchor: .center)
                    }
                }
            }
        }
    }
}

struct FilmstripPhotoCell: View {
    let photo: PhotoItem
    @ObservedObject var store: PhotoStore
    let isSelected: Bool
    
    var body: some View {
        ZStack(alignment: .bottom) {
            AsyncThumbnailView(photo: photo, previewSize: .thumbnail, interpolation: .medium)

            if photo.rating > 0 {
                HStack(spacing: 3) {
                    Image(systemName: "star.fill")
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundColor(DesignSystem.Colors.star)
                    Text("\(photo.rating)")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(.white)
                        .monospacedDigit()
                }
                .padding(.horizontal, 6)
                .padding(.vertical, 3)
                .background(Color.black.opacity(0.6))
                .cornerRadius(4)
                .padding(4)
            }
            
            if isSelected {
                Rectangle()
                    .stroke(DesignSystem.Colors.accent, lineWidth: 3)
            }
        }
        .frame(width: 100, height: 100)
        .cornerRadius(4)
    }
}

