//
//  BackupRestoreView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit
import UniformTypeIdentifiers

struct BackupRestoreView: View {
    @ObservedObject var store: PhotoStore
    @State private var isBackingUp = false
    @State private var isRestoring = false
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Backup & Wiederherstellung")
                .font(.headline)
            
            Text("Sichern Sie Ihre Einstellungen, Presets und Templates")
                .font(.caption)
                .foregroundColor(.secondary)
            
            Divider()
            
            // Backup Section
            VStack(alignment: .leading, spacing: 12) {
                Text("Backup erstellen")
                    .font(.subheadline)
                
                Text("Folgende Daten werden gesichert:")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                VStack(alignment: .leading, spacing: 4) {
                    BackupItem(name: "Export Presets", count: store.exportPresets.count)
                    BackupItem(name: "Adjustment Presets", count: store.adjustmentPresets.count)
                    BackupItem(name: "IPTC Templates", count: store.iptcTemplates.count)
                    BackupItem(name: "Upload Targets", count: store.uploadTargets.count)
                }
                .padding()
                .background(Color(red: 0.13, green: 0.13, blue: 0.14))
                .cornerRadius(8)
                
                Button("Backup erstellen...") {
                    createBackup()
                }
                .buttonStyle(.borderedProminent)
                .disabled(isBackingUp || isRestoring)
            }
            
            Divider()
            
            // Restore Section
            VStack(alignment: .leading, spacing: 12) {
                Text("Wiederherstellen")
                    .font(.subheadline)
                
                Text("Warnung: Beim Wiederherstellen werden alle aktuellen Einstellungen überschrieben!")
                    .font(.caption)
                    .foregroundColor(.orange)
                
                Button("Aus Backup wiederherstellen...") {
                    restoreBackup()
                }
                .buttonStyle(LightroomSecondaryButtonStyle())
                .disabled(isBackingUp || isRestoring)
            }
            
            if isBackingUp {
                HStack {
                    ProgressView()
                    Text("Backup wird erstellt...")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            if isRestoring {
                HStack {
                    ProgressView()
                    Text("Wiederherstellung läuft...")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Spacer()
            
            Button("Fertig") {
                dismiss()
            }
            .buttonStyle(.borderedProminent)
            .frame(maxWidth: .infinity)
        }
        .padding()
        .frame(width: 500, height: 500)
    }
    
    private func createBackup() {
        let savePanel = NSSavePanel()
        savePanel.allowedContentTypes = [.json]
        savePanel.nameFieldStringValue = "WB_Foto_Manager_Backup_\(Date().timeIntervalSince1970).json"
        savePanel.prompt = "Sichern"
        
        if savePanel.runModal() == .OK, let url = savePanel.url {
            isBackingUp = true
            
            Task {
                do {
                    let backup = BackupData(
                        exportPresets: store.exportPresets,
                        adjustmentPresets: store.adjustmentPresets,
                        iptcTemplates: store.iptcTemplates,
                        uploadTargets: store.uploadTargets,
                        exportQueueEnabled: store.exportQueueEnabled,
                        exportQueueMinRating: store.exportQueueMinRating
                    )
                    
                    let encoder = JSONEncoder()
                    encoder.outputFormatting = .prettyPrinted
                    let data = try encoder.encode(backup)
                    
                    try data.write(to: url)
                    
                    DispatchQueue.main.async {
                        self.isBackingUp = false
                        
                        let alert = NSAlert()
                        alert.messageText = "Backup erfolgreich"
                        alert.informativeText = "Backup wurde erstellt: \(url.lastPathComponent)"
                        alert.alertStyle = .informational
                        alert.runModal()
                    }
                } catch {
                    print("Backup error: \(error)")
                    DispatchQueue.main.async {
                        self.isBackingUp = false
                        
                        let alert = NSAlert()
                        alert.messageText = "Backup fehlgeschlagen"
                        alert.informativeText = error.localizedDescription
                        alert.alertStyle = .warning
                        alert.runModal()
                    }
                }
            }
        }
    }
    
    private func restoreBackup() {
        let alert = NSAlert()
        alert.messageText = "Backup wiederherstellen?"
        alert.informativeText = "Alle aktuellen Einstellungen, Presets und Templates werden überschrieben. Diese Aktion kann nicht rückgängig gemacht werden."
        alert.alertStyle = .warning
        alert.addButton(withTitle: "Wiederherstellen")
        alert.addButton(withTitle: "Abbrechen")
        
        if alert.runModal() != .alertFirstButtonReturn {
            return
        }
        
        let openPanel = NSOpenPanel()
        openPanel.allowedContentTypes = [.json]
        openPanel.allowsMultipleSelection = false
        openPanel.canChooseFiles = true
        openPanel.canChooseDirectories = false
        
        if openPanel.runModal() == .OK, let url = openPanel.url {
            isRestoring = true
            
            Task {
                do {
                    let data = try Data(contentsOf: url)
                    let decoder = JSONDecoder()
                    let backup = try decoder.decode(BackupData.self, from: data)
                    
                    DispatchQueue.main.async {
                        store.exportPresets = backup.exportPresets
                        store.adjustmentPresets = backup.adjustmentPresets
                        store.iptcTemplates = backup.iptcTemplates
                        store.uploadTargets = backup.uploadTargets
                        store.exportQueueEnabled = backup.exportQueueEnabled
                        store.exportQueueMinRating = backup.exportQueueMinRating
                        
                        // Speichere alle Daten
                        store.saveExportPresets()
                        store.saveAdjustmentPresets()
                        store.saveIPTCTemplates()
                        store.saveUploadTargets()
                        
                        self.isRestoring = false
                        
                        let successAlert = NSAlert()
                        successAlert.messageText = "Wiederherstellung erfolgreich"
                        successAlert.informativeText = "Alle Einstellungen wurden wiederhergestellt."
                        successAlert.alertStyle = .informational
                        successAlert.runModal()
                    }
                } catch {
                    print("Restore error: \(error)")
                    DispatchQueue.main.async {
                        self.isRestoring = false
                        
                        let alert = NSAlert()
                        alert.messageText = "Wiederherstellung fehlgeschlagen"
                        alert.informativeText = error.localizedDescription
                        alert.alertStyle = .warning
                        alert.runModal()
                    }
                }
            }
        }
    }
}

struct BackupItem: View {
    let name: String
    let count: Int
    
    var body: some View {
        HStack {
            Text(name)
            Spacer()
            Text("\(count)")
                .foregroundColor(.secondary)
        }
        .font(.caption)
    }
}

struct BackupData: Codable {
    let exportPresets: [ExportPreset]
    let adjustmentPresets: [AdjustmentPreset]
    let iptcTemplates: [IPTCTemplate]
    let uploadTargets: [UploadTarget]
    let exportQueueEnabled: Bool
    let exportQueueMinRating: Int
}

