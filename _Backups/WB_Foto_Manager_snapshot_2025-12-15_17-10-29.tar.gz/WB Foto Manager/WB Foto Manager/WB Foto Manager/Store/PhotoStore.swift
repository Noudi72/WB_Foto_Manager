//
//  PhotoStore.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import SwiftUI
import Combine

/// Zentraler State Manager für die App
class PhotoStore: ObservableObject {
    // MARK: - Published Properties
    
    @Published var photos: [PhotoItem] = []
    @Published var filteredPhotos: [PhotoItem] = []
    
    @Published var selectedPhotoIDs: Set<UUID> = []
    @Published var currentPhotoID: UUID?
    @Published var currentFolder: URL?
    
    @Published var exportPresets: [ExportPreset] = []
    @Published var adjustmentPresets: [AdjustmentPreset] = []
    /// User-definierte Preset-Kategorien (Reihenfolge wird persistiert).
    @Published var presetGroups: [String] = []
    @Published var uploadTargets: [UploadTarget] = []
    @Published var iptcTemplates: [IPTCTemplate] = []
    
    // Export Queue Settings
    @Published var exportQueueEnabled: Bool = false
    @Published var exportQueueMinRating: Int = 4
    @Published var exportQueuePreset: ExportPreset?
    @Published var exportQueueOutputDirectory: URL?
    @Published var isExportQueueRunning: Bool = false
    
    // MARK: - Computed Properties
    
    var currentPhoto: PhotoItem? {
        guard let id = currentPhotoID else { return nil }
        // Search in the main photos array, not the filtered one.
        return photos.first { $0.id == id }
    }
    
    var currentPhotoIndexInFiltered: Int? {
        guard let currentID = currentPhotoID else { return nil }
        return filteredPhotos.firstIndex { $0.id == currentID }
    }
    
    // MARK: - Services & State
    
    private let ratingService = RatingPersistenceService.shared
    private let metadataService = IPTCMetadataService.shared
    private var uiState: UIState?
    private var cancellables = Set<AnyCancellable>()
    
    // MARK: - Security-Scoped Folder Access
    
    private var currentFolderAccessURL: URL?
    private var isAccessingCurrentFolder: Bool = false
    
    private struct LoadedPhotoInfo: Sendable {
        let url: URL
        let rating: Int
        let iptc: IPTCMetadata?
    }
    
    // MARK: - Initialization
    
    init() {
        // Lade alle Presets beim Start
        loadExportPresets()
        loadAdjustmentPresets() // Lädt Standard-Presets wenn keine vorhanden
        loadPresetGroups()
        loadUploadTargets()
        loadIPTCTemplates()
    }
    
    deinit {
        stopAccessingCurrentFolderIfNeeded()
    }
    
    private func stopAccessingCurrentFolderIfNeeded() {
        if isAccessingCurrentFolder, let url = currentFolderAccessURL {
            url.stopAccessingSecurityScopedResource()
        }
        isAccessingCurrentFolder = false
        currentFolderAccessURL = nil
    }
    
    func setup(uiState: UIState) {
        self.uiState = uiState
        
        // Listen for filter changes from UIState
        uiState.$ratingFilter
            .debounce(for: .milliseconds(100), scheduler: RunLoop.main)
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)

        // Also update when the base photos array changes
        $photos
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Filtering
    
    private func updateFilteredPhotos() {
        guard let uiState = uiState else {
            self.filteredPhotos = self.photos
            return
        }
        
        var newFilteredPhotos = photos
        
        // Rating Filter
        if let rating = uiState.ratingFilter {
            newFilteredPhotos = newFilteredPhotos.filter { $0.rating == rating }
        }
        self.filteredPhotos = newFilteredPhotos
    }
    
    // MARK: - Folder Management
    
    @Published var isLoadingPhotos: Bool = false
    @Published var loadingProgress: Double = 0.0
    
    func loadPhotos(from folderURL: URL) {
        // Prüfe ob Ordner existiert und zugänglich ist
        let fileManager = FileManager.default
        var isDirectory: ObjCBool = false
        
        guard fileManager.fileExists(atPath: folderURL.path, isDirectory: &isDirectory),
              isDirectory.boolValue else {
            print("Ordner existiert nicht oder ist nicht zugänglich: \(folderURL.path)")
            return
        }
        
        // Wenn wir den Ordner wechseln: alte Security-Scope schließen & Caches leeren.
        // Wichtig: startAccessingSecurityScopedResource() ist referenzgezählt — bei erneutem Laden desselben Ordners
        // dürfen wir nicht blind erneut starten, sonst "leaken" wir die Referenzen.
        let isSameFolderAndAlreadyAccessing = (currentFolderAccessURL?.path == folderURL.path && isAccessingCurrentFolder)
        if !isSameFolderAndAlreadyAccessing {
            stopAccessingCurrentFolderIfNeeded()
            Task { @MainActor in
                SmartImageLoader.shared.clearCache()
            }
            
            // Security-Scoped Resource: während der Nutzung des Ordners offen halten
            currentFolderAccessURL = folderURL
            isAccessingCurrentFolder = folderURL.startAccessingSecurityScopedResource()
        }
        
        currentFolder = folderURL
        isLoadingPhotos = true
        loadingProgress = 0.0
        photos = [] // Leere zuerst für sofortiges UI-Update
        
        Task.detached(priority: .userInitiated) {
            let fileManager = FileManager.default
            let imageExtensions: Set<String> = [
                "jpg", "jpeg", "png", "heic", "heif", "tiff", "tif",
                "raw", "cr2", "nef", "orf", "sr2", "arw", "dng",
                "raf", "rw2", "pef", "srw", "3fr", "mef", "mos",
                "ari", "bay", "crw", "cap", "data", "dcs", "dcr",
                "drf", "eip", "erf", "fff", "iiq", "k25", "kdc",
                "mdc", "mrw", "nrw", "obm", "ptx", "pxn", "r3d",
                "raw", "rwl", "rwz", "sr2", "srf", "srw", "x3f"
            ]
            
            var allFiles: [URL] = []
            
            // Lade zuerst direkte Dateien im Ordner (nicht rekursiv)
            do {
                let contents = try fileManager.contentsOfDirectory(
                    at: folderURL,
                    includingPropertiesForKeys: [.isRegularFileKey, .contentTypeKey],
                    options: [.skipsHiddenFiles]
                )
                
                for fileURL in contents {
                    guard let resourceValues = try? fileURL.resourceValues(forKeys: [.isRegularFileKey]),
                          resourceValues.isRegularFile == true else {
                        continue
                    }
                    
                    let ext = fileURL.pathExtension.lowercased()
                    if imageExtensions.contains(ext) {
                        allFiles.append(fileURL)
                    }
                }
            } catch {
                print("⚠️ Fehler beim Laden des Ordners: \(error.localizedDescription)")
            }
            
            print("📸 Gefundene Bilder: \(allFiles.count) in \(folderURL.path)")
            
            let totalFiles = allFiles.count
            var loadedInfos: [LoadedPhotoInfo] = []
            loadedInfos.reserveCapacity(totalFiles)
            
            // Services lokal (keine MainActor-Abhängigkeiten über `self` im Background)
            let ratingService = RatingPersistenceService.shared
            let metadataService = IPTCMetadataService.shared
            
            // Lade Metadaten in Batches für bessere Performance
            for (index, fileURL) in allFiles.enumerated() {
                let rating = ratingService.loadRating(from: fileURL)
                let iptc = metadataService.loadMetadata(from: fileURL)
                loadedInfos.append(LoadedPhotoInfo(url: fileURL, rating: rating, iptc: iptc))
                
                // Update Progress alle 10 Dateien oder am Ende
                if index % 10 == 0 || index == totalFiles - 1 {
                    let progress = totalFiles > 0 ? Double(index + 1) / Double(totalFiles) : 1.0
                    DispatchQueue.main.async {
                        self.loadingProgress = progress
                    }
                }
            }
            
            // Sortiere nach Dateiname
            let sortedInfos = loadedInfos.sorted { $0.url.lastPathComponent < $1.url.lastPathComponent }
            
            await MainActor.run {
                let loadedPhotos: [PhotoItem] = sortedInfos.map { info in
                    let photo = PhotoItem(url: info.url, rating: info.rating)
                    photo.iptcMetadata = info.iptc
                    return photo
                }
                
                self.photos = loadedPhotos
                self.isLoadingPhotos = false
                self.loadingProgress = 1.0
                
                print("✅ \(loadedPhotos.count) Bilder geladen aus \(folderURL.path)")
                
                // Update filtered photos
                self.updateFilteredPhotos()
                
                if let firstPhoto = self.filteredPhotos.first {
                    self.currentPhotoID = firstPhoto.id
                    self.selectedPhotoIDs = [firstPhoto.id]
                    print("✅ Erstes Foto ausgewählt: \(firstPhoto.fileName)")
                } else {
                    self.currentPhotoID = nil
                    self.selectedPhotoIDs = []
                    print("⚠️ Keine gefilterten Fotos gefunden")
                }
            }
        }
    }
    
    // MARK: - Navigation
    
    func selectPhoto(_ photo: PhotoItem) {
        currentPhotoID = photo.id
        if !selectedPhotoIDs.contains(photo.id) {
            selectedPhotoIDs.insert(photo.id)
        }
    }
    
    func selectNextPhoto() {
        guard let currentIndex = currentPhotoIndexInFiltered else { return }
        if currentIndex < filteredPhotos.count - 1 {
            selectPhoto(filteredPhotos[currentIndex + 1])
        }
    }
    
    func selectPreviousPhoto() {
        guard let currentIndex = currentPhotoIndexInFiltered else { return }
        if currentIndex > 0 {
            selectPhoto(filteredPhotos[currentIndex - 1])
        }
    }
    
    func selectPhoto(at index: Int) {
        guard index >= 0 && index < filteredPhotos.count else { return }
        selectPhoto(filteredPhotos[index])
    }
    
    // MARK: - Rating & Tags
    
    func setRating(_ rating: Int, for photoID: UUID, autoAdvance: Bool = true) {
        guard let index = photos.firstIndex(where: { $0.id == photoID }) else { return }
        let photo = photos[index]
        photo.rating = rating
        
        // Manually trigger an update for the specific photo and re-filtering
        objectWillChange.send()
        updateFilteredPhotos()
        
        Task(priority: .background) {
            try? await self.ratingService.writeRating(rating, to: photo.url)
        }
        
        if exportQueueEnabled && rating >= exportQueueMinRating {
            checkAndExportQueue()
        }
        
        // AUTO-ADVANCE: Gehe zum nächsten Bild (KRITISCH für Sportfotografie!)
        if autoAdvance && AppSettings.shared.autoAdvanceAfterRating {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.selectNextPhoto()
            }
        }
    }
    
    // ... (rest of the file remains largely the same, but methods like toggleColorTag would also need objectWillChange.send() and updateFilteredPhotos())
    
    func toggleColorTag(_ tag: ColorTag, for photoID: UUID) {
        guard let photo = photos.first(where: { $0.id == photoID }) else { return }
        if photo.colorTags.contains(tag) {
            photo.colorTags.remove(tag)
        } else {
            photo.colorTags.insert(tag)
        }
        objectWillChange.send()
    }
    
    // MARK: - Export Queue
    
    func checkAndExportQueue() {
        // ... implementation ...
    }
    
    // MARK: - Preset Management (Export, Adjustment, etc.)
    
    func loadExportPresets() {
        if let data = UserDefaults.standard.data(forKey: "exportPresets"),
           let decoded = try? JSONDecoder().decode([ExportPreset].self, from: data) {
            exportPresets = decoded
        } else {
            exportPresets = ExportPreset.defaultPresets
            saveExportPresets()
        }
    }
    
    func saveExportPresets() {
        if let encoded = try? JSONEncoder().encode(exportPresets) {
            UserDefaults.standard.set(encoded, forKey: "exportPresets")
        }
    }
    
    // ... etc. for all preset types
    func addExportPreset(_ preset: ExportPreset) {
        exportPresets.append(preset)
        saveExportPresets()
    }
    
    func updateExportPreset(_ preset: ExportPreset) {
        if let index = exportPresets.firstIndex(where: { $0.id == preset.id }) {
            exportPresets[index] = preset
            saveExportPresets()
        }
    }
    
    func deleteExportPreset(_ preset: ExportPreset) {
        exportPresets.removeAll { $0.id == preset.id }
        saveExportPresets()
    }
    func loadAdjustmentPresets() {
        if let data = UserDefaults.standard.data(forKey: "adjustmentPresets"),
           let decoded = try? JSONDecoder().decode([AdjustmentPreset].self, from: data) {
            adjustmentPresets = decoded
        } else {
            // Lade Standard-Presets wenn keine vorhanden
            loadDefaultPresets()
        }
    }
    
    func saveAdjustmentPresets() {
        if let encoded = try? JSONEncoder().encode(adjustmentPresets) {
            UserDefaults.standard.set(encoded, forKey: "adjustmentPresets")
        }
    }
    
    func addAdjustmentPreset(_ preset: AdjustmentPreset) {
        adjustmentPresets.append(preset)
        if let group = preset.group?.trimmingCharacters(in: .whitespacesAndNewlines),
           !group.isEmpty,
           !presetGroups.contains(group) {
            presetGroups.append(group)
            savePresetGroups()
        }
        saveAdjustmentPresets()
    }
    
    func updateAdjustmentPreset(_ preset: AdjustmentPreset) {
        if let index = adjustmentPresets.firstIndex(where: { $0.id == preset.id }) {
            adjustmentPresets[index] = preset
            if let group = preset.group?.trimmingCharacters(in: .whitespacesAndNewlines),
               !group.isEmpty,
               !presetGroups.contains(group) {
                presetGroups.append(group)
                savePresetGroups()
            }
            saveAdjustmentPresets()
        }
    }
    
    func deleteAdjustmentPreset(_ preset: AdjustmentPreset) {
        adjustmentPresets.removeAll { $0.id == preset.id }
        saveAdjustmentPresets()
    }
    
    // MARK: - Preset Group Management
    
    func loadPresetGroups() {
        if let groups = UserDefaults.standard.stringArray(forKey: "presetGroups") {
            presetGroups = groups
            return
        }
        
        // Default: aus vorhandenen Presets ableiten
        let groupsFromPresets = Set(adjustmentPresets.compactMap { $0.group?.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty })
        presetGroups = groupsFromPresets.sorted()
        savePresetGroups()
    }
    
    func savePresetGroups() {
        UserDefaults.standard.set(presetGroups, forKey: "presetGroups")
    }
    
    func addPresetGroup(_ name: String) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        guard !presetGroups.contains(trimmed) else { return }
        presetGroups.append(trimmed)
        savePresetGroups()
    }
    
    private func loadDefaultPresets() {
        adjustmentPresets = [
            AdjustmentPreset(
                name: "Vivid",
                group: "Farbe",
                adjustments: PhotoAdjustments(
                    exposure: 0.1,
                    contrast: 1.15,
                    clarity: 0.2,
                    vibrance: 30,
                    saturation: 25
                )
            ),
            AdjustmentPreset(
                name: "Portrait",
                group: "Portrait",
                adjustments: PhotoAdjustments(
                    exposure: 0.2,
                    contrast: 1.05,
                    temperature: 200,
                    clarity: 0.15,
                    texture: 10
                )
            ),
            AdjustmentPreset(
                name: "Landschaft",
                group: "Stil",
                adjustments: PhotoAdjustments(
                    exposure: 0.1,
                    contrast: 1.2,
                    clarity: 0.3,
                    saturation: 20,
                    dehaze: 15
                )
            ),
            AdjustmentPreset(
                name: "Schwarz-Weiß",
                group: "Stil",
                adjustments: PhotoAdjustments(
                    exposure: 0.1,
                    contrast: 1.3,
                    clarity: 0.25,
                    saturation: -100
                )
            ),
            AdjustmentPreset(
                name: "Warm",
                group: "Farbe",
                adjustments: PhotoAdjustments(
                    temperature: 500,
                    tint: 10,
                    vibrance: 20
                )
            ),
            AdjustmentPreset(
                name: "Cool",
                group: "Farbe",
                adjustments: PhotoAdjustments(
                    temperature: -500,
                    tint: -10,
                    vibrance: 15
                )
            )
        ]
        saveAdjustmentPresets()
    }
    func loadUploadTargets() {
        if let data = UserDefaults.standard.data(forKey: "uploadTargets"),
           let decoded = try? JSONDecoder().decode([UploadTarget].self, from: data) {
            uploadTargets = decoded
        } else {
            uploadTargets = []
        }
    }
    
    func saveUploadTargets() {
        if let encoded = try? JSONEncoder().encode(uploadTargets) {
            UserDefaults.standard.set(encoded, forKey: "uploadTargets")
        }
    }
    
    func addUploadTarget(_ target: UploadTarget) {
        uploadTargets.append(target)
        saveUploadTargets()
    }
    
    func updateUploadTarget(_ target: UploadTarget) {
        if let index = uploadTargets.firstIndex(where: { $0.id == target.id }) {
            uploadTargets[index] = target
            saveUploadTargets()
        }
    }
    
    func deleteUploadTarget(_ target: UploadTarget) {
        uploadTargets.removeAll { $0.id == target.id }
        saveUploadTargets()
    }
    
    func loadIPTCTemplates() {
        if let data = UserDefaults.standard.data(forKey: "iptcTemplates"),
           let decoded = try? JSONDecoder().decode([IPTCTemplate].self, from: data) {
            iptcTemplates = decoded
        } else {
            iptcTemplates = IPTCTemplate.defaultTemplates
            saveIPTCTemplates()
        }
    }
    
    func saveIPTCTemplates() {
        if let encoded = try? JSONEncoder().encode(iptcTemplates) {
            UserDefaults.standard.set(encoded, forKey: "iptcTemplates")
        }
    }
    
    func addIPTCTemplate(_ template: IPTCTemplate) {
        iptcTemplates.append(template)
        saveIPTCTemplates()
    }
    
    func updateIPTCTemplate(_ template: IPTCTemplate) {
        if let index = iptcTemplates.firstIndex(where: { $0.id == template.id }) {
            iptcTemplates[index] = template
            saveIPTCTemplates()
        }
    }
    
    func deleteIPTCTemplate(_ template: IPTCTemplate) {
        iptcTemplates.removeAll { $0.id == template.id }
        saveIPTCTemplates()
    }
}

