//
//  PhotoItem.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import AppKit
import CoreImage
import Combine

/// Repräsentiert ein einzelnes Foto mit allen Metadaten und Bearbeitungsparametern
class PhotoItem: ObservableObject, Identifiable, Hashable {
    let id: UUID
    let url: URL
    @Published var rating: Int = 0 // 0-5, 0 = kein Rating
    @Published var colorTags: Set<ColorTag> = []
    @Published var textTags: Set<String> = []
    @Published var adjustments: PhotoAdjustments
    @Published var cropRect: CGRect?
    @Published var rotation: Double = 0.0
    @Published var iptcMetadata: IPTCMetadata?
    @Published var isExported: Bool = false
    
    // Cache for full-resolution image used in editing
    private var _fullImage: CIImage?
    
    init(url: URL, rating: Int = 0) {
        self.id = UUID()
        self.url = url
        self.rating = rating
        self.adjustments = PhotoAdjustments()
    }
    
    var fileName: String {
        url.lastPathComponent
    }
    
    var fileSize: Int64 {
        (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? Int64) ?? 0
    }
    
    // MARK: - Hashable & Equatable
    
    static func == (lhs: PhotoItem, rhs: PhotoItem) -> Bool {
        lhs.id == rhs.id
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    // MARK: - Image Loading (Using Global Cache)
    
    /// Loads a thumbnail of a specific size, utilizing the global cache.
    nonisolated func loadThumbnail(size: CGSize) async -> NSImage? {
        // Prüfe ob Datei existiert
        guard FileManager.default.fileExists(atPath: url.path) else {
            print("⚠️ Datei existiert nicht: \(url.path)")
            return nil
        }
        
        // Cache-Zugriff auf Main Actor
        let cacheKeyString = "\(url.absoluteString)-\(size.width)x\(size.height)"
        
        // Check cache first
        let cachedImage = await MainActor.run {
            ThumbnailCache.shared.get(forKey: cacheKeyString as NSString)
        }
        if let cached = cachedImage {
            return cached
        }
        
        // If not in cache, generate it - auf Background Thread
        let fileURL = self.url
        let cacheKeyStringCopy = cacheKeyString
        return await Task.detached(priority: .userInitiated) {
            guard let imageSource = CGImageSourceCreateWithURL(fileURL as CFURL, nil) else {
                print("⚠️ Konnte ImageSource nicht erstellen für: \(fileURL.path)")
                return nil
            }
            
            // Für bessere Qualität: Verwende größere Max-Pixel-Size und bessere Optionen
            let maxSize = max(size.width, size.height)
            let options: [CFString: Any] = [
                kCGImageSourceThumbnailMaxPixelSize: maxSize * 1.5, // Etwas größer für bessere Qualität
                kCGImageSourceCreateThumbnailFromImageIfAbsent: true,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceShouldCache: true,
                kCGImageSourceShouldAllowFloat: true
            ]
            
            guard let cgImage = CGImageSourceCreateThumbnailAtIndex(imageSource, 0, options as CFDictionary) else {
                print("⚠️ Konnte Thumbnail nicht erstellen für: \(fileURL.path)")
                return nil
            }
            
            // Erstelle hochwertiges NSImage
            let thumbnail = NSImage(cgImage: cgImage, size: size)
            thumbnail.cacheMode = .never // Verhindere automatisches Caching für bessere Qualität
            
            // Store in cache for next time
            await MainActor.run {
                ThumbnailCache.shared.set(thumbnail, forKey: cacheKeyStringCopy as NSString)
            }
            
            return thumbnail
        }.value
    }
    
    /// Loads the full-resolution image for editing.
    func loadFullImage() -> CIImage? {
        if let cached = _fullImage {
            return cached
        }
        
        guard let image = CIImage(contentsOf: url, options: [
            .applyOrientationProperty: true,
            .cacheImmediately: false // Lazy loading
        ]) else {
            return nil
        }
        
        _fullImage = image
        return image
    }
    
    /// Clears the cached full-resolution image.
    func clearFullImageCache() {
        _fullImage = nil
    }
}

// MARK: - Color Tags

enum ColorTag: String, CaseIterable, Codable {
    case red = "red"
    case orange = "orange"
    case yellow = "yellow"
    case green = "green"
    case blue = "blue"
    case purple = "purple"
    case pink = "pink"
    case gray = "gray"
    
    var color: NSColor {
        switch self {
        case .red: return .systemRed
        case .orange: return .systemOrange
        case .yellow: return .systemYellow
        case .green: return .systemGreen
        case .blue: return .systemBlue
        case .purple: return .systemPurple
        case .pink: return .systemPink
        case .gray: return .systemGray
        }
    }
}

// MARK: - IPTC Metadata

struct IPTCMetadata: Codable, Sendable {
    var caption: String?
    var keywords: [String]
    var photographer: String?
    var copyright: String?
    var location: String?
    var city: String?
    var country: String?
    var event: String?
    var venue: String?
    var date: Date?
    var customFields: [String: String]
    
    init(caption: String? = nil, keywords: [String] = [], photographer: String? = nil, copyright: String? = nil, location: String? = nil, city: String? = nil, country: String? = nil, event: String? = nil, venue: String? = nil, date: Date? = nil, customFields: [String: String] = [:]) {
        self.caption = caption
        self.keywords = keywords
        self.photographer = photographer
        self.copyright = copyright
        self.location = location
        self.city = city
        self.country = country
        self.event = event
        self.venue = venue
        self.date = date
        self.customFields = customFields
    }
}

