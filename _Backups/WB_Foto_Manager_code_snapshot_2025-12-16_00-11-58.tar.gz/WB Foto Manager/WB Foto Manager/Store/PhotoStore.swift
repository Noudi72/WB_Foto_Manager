//
//  PhotoStore.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import SwiftUI
import Combine
import AppKit
import Photos

/// Zentraler State Manager für die App
class PhotoStore: ObservableObject {
    // MARK: - Published Properties
    
    @Published var photos: [PhotoItem] = []
    @Published var filteredPhotos: [PhotoItem] = []
    
    @Published var selectedPhotoIDs: Set<UUID> = []
    @Published var currentPhotoID: UUID?
    @Published var currentFolder: URL?
    
    @Published var exportPresets: [ExportPreset] = []
    @Published var adjustmentPresets: [AdjustmentPreset] = []
    /// User-definierte Preset-Kategorien (Reihenfolge wird persistiert).
    @Published var presetGroups: [String] = []
    @Published var uploadTargets: [UploadTarget] = []
    @Published var iptcTemplates: [IPTCTemplate] = []
    @Published var smartCollections: [SmartCollection] = []
    
    // MARK: - History / Snapshots (Lightroom-like)
    @Published var editSnapshotsByKey: [String: [EditSnapshot]] = [:]

    // MARK: - Copy/Paste & Sync (Lightroom-like)

    @Published var copiedAdjustments: PhotoAdjustments? = nil
    
    // Export Queue Settings
    @Published var exportQueueEnabled: Bool = false
    @Published var exportQueueMinRating: Int = 4
    @Published var exportQueuePreset: ExportPreset?
    @Published var exportQueueOutputDirectory: URL?
    @Published var isExportQueueRunning: Bool = false
    
    // MARK: - Quick Export (1‑Klick Export)
    @Published var quickExportPresetID: UUID? = nil
    @Published var quickExportDirectory: URL? = nil
    @Published var isQuickExporting: Bool = false
    @Published var quickExportProgress: Double = 0.0
    
    // MARK: - Computed Properties
    
    var currentPhoto: PhotoItem? {
        guard let id = currentPhotoID else { return nil }
        // Search in the main photos array, not the filtered one.
        return photos.first { $0.id == id }
    }
    
    var currentPhotoIndexInFiltered: Int? {
        guard let currentID = currentPhotoID else { return nil }
        return filteredPhotos.firstIndex { $0.id == currentID }
    }
    
    // MARK: - Services & State
    
    private let ratingService = RatingPersistenceService.shared
    private let metadataService = IPTCMetadataService.shared
    var uiState: UIState?
    private var cancellables = Set<AnyCancellable>()
    
    // MARK: - Security-Scoped Folder Access
    
    private var currentFolderAccessURL: URL?
    private var isAccessingCurrentFolder: Bool = false
    
    private struct LoadedPhotoInfo: Sendable {
        let url: URL
        let rating: Int
        let iptc: IPTCMetadata?
        let edit: EditCatalogService.EditEntry?
    }
    
    // MARK: - Initialization
    
    init() {
        // Lade alle Presets beim Start
        loadExportPresets()
        loadAdjustmentPresets() // Lädt Standard-Presets wenn keine vorhanden
        loadPresetGroups()
        loadUploadTargets()
        loadIPTCTemplates()
        loadSmartCollections()
        loadEditSnapshots()
        loadQuickExportSettings()

        // Persist edits (non-destructive) whenever UI signals a reprocess.
        registerEditPersistenceObservers()
    }
    
    deinit {
        stopAccessingCurrentFolderIfNeeded()
    }
    
    private func stopAccessingCurrentFolderIfNeeded() {
        if isAccessingCurrentFolder, let url = currentFolderAccessURL {
            url.stopAccessingSecurityScopedResource()
        }
        isAccessingCurrentFolder = false
        currentFolderAccessURL = nil
    }
    
    func setup(uiState: UIState) {
        self.uiState = uiState
        
        // Listen for filter changes from UIState
        uiState.$ratingFilter
            .debounce(for: .milliseconds(100), scheduler: RunLoop.main)
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)
        
        uiState.$pickStatusFilter
            .debounce(for: .milliseconds(100), scheduler: RunLoop.main)
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)
        
        uiState.$searchQuery
            .debounce(for: .milliseconds(150), scheduler: RunLoop.main)
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)

        // Also update when the base photos array changes
        $photos
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)

        // Quick Collection filter
        uiState.$showQuickCollectionOnly
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)

        // Color Tag filter
        uiState.$colorTagFilter
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)
        
        // Smart Collection filter
        uiState.$activeSmartCollectionID
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)

        // Selection mode: when disabled, keep a single active selection (safer for beginners).
        uiState.$selectionMode
            .sink { [weak self] enabled in
                guard let self else { return }
                guard !enabled else { return }
                if let current = self.currentPhotoID {
                    self.selectedPhotoIDs = [current]
                }
            }
            .store(in: &cancellables)
    }
    
    // MARK: - Filtering
    
    private func updateFilteredPhotos() {
        guard let uiState = uiState else {
            self.filteredPhotos = self.photos
            return
        }
        
        var newFilteredPhotos = photos
        
        // Smart Collection Filter (zuerst, damit Kriterien wie "hasAdjustments" etc. funktionieren)
        if let activeID = uiState.activeSmartCollectionID,
           let collection = smartCollections.first(where: { $0.id == activeID }) {
            newFilteredPhotos = newFilteredPhotos.filter { collection.matches($0) }
        }
        
        // Textsuche (Dateiname, Caption, Keywords)
        let q = uiState.searchQuery.trimmingCharacters(in: .whitespacesAndNewlines)
        if !q.isEmpty {
            newFilteredPhotos = newFilteredPhotos.filter { matchesSearch($0, query: q) }
        }
        
        // Rating Filter
        if let rating = uiState.ratingFilter {
            newFilteredPhotos = newFilteredPhotos.filter { $0.rating == rating }
        }
        
        // Pick Status Filter
        if let pickStatus = uiState.pickStatusFilter {
            newFilteredPhotos = newFilteredPhotos.filter { $0.pickStatus == pickStatus }
        }
        
        // Quick Collection Filter
        if uiState.showQuickCollectionOnly {
            newFilteredPhotos = newFilteredPhotos.filter { $0.isInQuickCollection }
        }
        
        // Color Tag Filter
        if let colorTag = uiState.colorTagFilter {
            newFilteredPhotos = newFilteredPhotos.filter { $0.colorTags.contains(colorTag) }
        }
        
        self.filteredPhotos = newFilteredPhotos
    }
    
    private func matchesSearch(_ photo: PhotoItem, query: String) -> Bool {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return true }
        
        // AND-Search über Tokens
        let tokens = trimmed
            .lowercased()
            .split(whereSeparator: { $0.isWhitespace })
            .map(String.init)
            .filter { !$0.isEmpty }
        
        if tokens.isEmpty { return true }
        
        let fileName = photo.fileName.lowercased()
        let caption = (photo.iptcMetadata?.caption ?? "").lowercased()
        let keywords = (photo.iptcMetadata?.keywords ?? []).joined(separator: " ").lowercased()
        let tags = photo.textTags.joined(separator: " ").lowercased()
        
        let haystack = "\(fileName) \(caption) \(keywords) \(tags)"
        return tokens.allSatisfy { haystack.contains($0) }
    }
    
    // MARK: - Folder Management
    
    @Published var isLoadingPhotos: Bool = false
    @Published var loadingProgress: Double = 0.0
    
    func loadPhotos(from folderURL: URL) {
        // Fotos-Mediathek ist durch macOS Privacy geschützt. Wir triggern explizit die Photos-Permission,
        // damit das Einlesen nicht stillschweigend leer bleibt.
        let isPhotosLibraryFolder = folderURL.pathExtension.lowercased() == "photoslibrary"
        if isPhotosLibraryFolder {
            let current = PHPhotoLibrary.authorizationStatus(for: .readWrite)
            if current == .notDetermined {
                isLoadingPhotos = true
                loadingProgress = 0.0
                Task { @MainActor in
                    let status = await requestPhotosLibraryAuthorization()
                    if status == .authorized || status == .limited {
                        self.loadPhotos(from: folderURL)
                    } else {
                        self.isLoadingPhotos = false
                        self.loadingProgress = 0.0
                        self.photos = []
                        self.currentPhotoID = nil
                        self.selectedPhotoIDs = []
                        self.updateFilteredPhotos()
                        self.showPhotosPermissionAlert()
                    }
                }
                return
            }
            if !(current == .authorized || current == .limited) {
                showPhotosPermissionAlert()
                return
            }
        }

        // Prüfe ob Ordner existiert und zugänglich ist
        let fileManager = FileManager.default
        var isDirectory: ObjCBool = false
        
        guard fileManager.fileExists(atPath: folderURL.path, isDirectory: &isDirectory),
              isDirectory.boolValue else {
            print("Ordner existiert nicht oder ist nicht zugänglich: \(folderURL.path)")
            return
        }
        
        // Wenn wir den Ordner wechseln: alte Security-Scope schließen & Caches leeren.
        // Wichtig: startAccessingSecurityScopedResource() ist referenzgezählt — bei erneutem Laden desselben Ordners
        // dürfen wir nicht blind erneut starten, sonst "leaken" wir die Referenzen.
        let isSameFolderAndAlreadyAccessing = (currentFolderAccessURL?.path == folderURL.path && isAccessingCurrentFolder)
        if !isSameFolderAndAlreadyAccessing {
            stopAccessingCurrentFolderIfNeeded()
            Task { @MainActor in
                SmartImageLoader.shared.clearCache()
            }
            
            // Security-Scoped Resource: während der Nutzung des Ordners offen halten
            currentFolderAccessURL = folderURL
            isAccessingCurrentFolder = folderURL.startAccessingSecurityScopedResource()
        }
        
        currentFolder = folderURL
        isLoadingPhotos = true
        loadingProgress = 0.0
        photos = [] // Leere zuerst für sofortiges UI-Update

        // Settings/Flags einmal capturen (für Concurrency/Sandbox)
        let shouldSearchSubfolders = AppSettings.shared.searchSubfolders
        let isPhotosLibrary = folderURL.pathExtension.lowercased() == "photoslibrary"
        let scanCandidates: [URL] = {
            guard isPhotosLibrary else { return [folderURL] }
            // Photos.app Library ist ein Package. Die Originale liegen üblicherweise unter "originals" (neu) oder "Masters" (alt).
            // Wichtig: fileExists kann in Sandbox/Permissions false liefern. Daher probieren wir mehrere Kandidaten.
            return [
                folderURL.appendingPathComponent("resources"),
                folderURL.appendingPathComponent("originals"),
                folderURL.appendingPathComponent("Masters"),
                folderURL
            ]
        }()
        
        Task.detached(priority: .userInitiated) {
            let fileManager = FileManager.default
            let imageExtensions: Set<String> = [
                "jpg", "jpeg", "png", "heic", "heif", "tiff", "tif",
                "raw", "cr2", "nef", "orf", "sr2", "arw", "dng",
                "raf", "rw2", "pef", "srw", "3fr", "mef", "mos",
                "ari", "bay", "crw", "cap", "data", "dcs", "dcr",
                "drf", "eip", "erf", "fff", "iiq", "k25", "kdc",
                "mdc", "mrw", "nrw", "obm", "ptx", "pxn", "r3d",
                "raw", "rwl", "rwz", "sr2", "srf", "srw", "x3f"
            ]
            
            var allFiles: [URL] = []

            // Unterordner optional durchsuchen (Einstellung) + Photos-Library immer rekursiv
            let recursiveScan = shouldSearchSubfolders || isPhotosLibrary
            if recursiveScan {
                let keys: [URLResourceKey] = [.isRegularFileKey, .isDirectoryKey, .isPackageKey]
                var collected = Set<URL>()
                var didFindPreferred = false

                for (idx, base) in scanCandidates.enumerated() {
                    // Wenn wir in Originals/Masters schon etwas gefunden haben, sparen wir uns den (sehr grossen) Fallback-Scan auf Package-Root.
                    if isPhotosLibrary, idx == scanCandidates.count - 1, didFindPreferred {
                        break
                    }

                    guard let enumerator = fileManager.enumerator(
                        at: base,
                        includingPropertiesForKeys: keys,
                        options: [.skipsHiddenFiles],
                        errorHandler: nil
                    ) else {
                        continue
                    }

                    for case let url as URL in enumerator {
                        guard let values = try? url.resourceValues(forKeys: Set(keys)) else { continue }

                        if values.isDirectory == true {
                            // In normalen Ordnern Packages überspringen (z.B. *.app, *.photoslibrary)
                            if !isPhotosLibrary, values.isPackage == true {
                                enumerator.skipDescendants()
                            }
                            continue
                        }

                        guard values.isRegularFile == true else { continue }
                        let ext = url.pathExtension.lowercased()
                        if imageExtensions.contains(ext) {
                            collected.insert(url)
                        }
                    }

                    if isPhotosLibrary {
                        let last = base.lastPathComponent.lowercased()
                        if (last == "resources" || last == "originals" || last == "masters"), !collected.isEmpty {
                            didFindPreferred = true
                        }
                    }
                }

                allFiles = Array(collected)
            } else {
                // Nur direkte Dateien im Ordner (nicht rekursiv)
                do {
                    let contents = try fileManager.contentsOfDirectory(
                        at: folderURL,
                        includingPropertiesForKeys: [.isRegularFileKey, .contentTypeKey],
                        options: [.skipsHiddenFiles]
                    )
                    
                    for fileURL in contents {
                        guard let resourceValues = try? fileURL.resourceValues(forKeys: [.isRegularFileKey]),
                              resourceValues.isRegularFile == true else {
                            continue
                        }
                        
                        let ext = fileURL.pathExtension.lowercased()
                        if imageExtensions.contains(ext) {
                            allFiles.append(fileURL)
                        }
                    }
                } catch {
                    print("⚠️ Fehler beim Laden des Ordners: \(error.localizedDescription)")
                }
            }

            // Dedupe + stabil sortieren
            allFiles = Array(Set(allFiles)).sorted { $0.lastPathComponent < $1.lastPathComponent }

            if isPhotosLibrary {
                print("📸 Photos Library Scan: \(allFiles.count) Dateien (Kandidaten: \(scanCandidates.map { $0.lastPathComponent }.joined(separator: ", ")))")
            } else {
                print("📸 Gefundene Bilder: \(allFiles.count) in \(folderURL.path)")
            }
            
            let totalFiles = allFiles.count
            var loadedInfos: [LoadedPhotoInfo] = []
            loadedInfos.reserveCapacity(totalFiles)
            
            // Services lokal (keine MainActor-Abhängigkeiten über `self` im Background)
            let ratingService = RatingPersistenceService.shared
            let metadataService = IPTCMetadataService.shared
            let editSnapshot = await EditCatalogService.shared.snapshot()
            
            // Lade Metadaten in Batches für bessere Performance
            for (index, fileURL) in allFiles.enumerated() {
                let rating = ratingService.loadRating(from: fileURL)
                let iptc = metadataService.loadMetadata(from: fileURL)
                let edit = editSnapshot[fileURL.standardizedFileURL.path]
                loadedInfos.append(LoadedPhotoInfo(url: fileURL, rating: rating, iptc: iptc, edit: edit))
                
                // Update Progress alle 10 Dateien oder am Ende
                if index % 10 == 0 || index == totalFiles - 1 {
                    let progress = totalFiles > 0 ? Double(index + 1) / Double(totalFiles) : 1.0
                    DispatchQueue.main.async {
                        self.loadingProgress = progress
                    }
                }
            }
            
            // Sortiere nach Dateiname (stabil, passend zur UI)
            let sortedInfos = loadedInfos.sorted { $0.url.lastPathComponent < $1.url.lastPathComponent }
            
            await MainActor.run {
                // 1) Load physical files (Masters)
                var loadedPhotos: [PhotoItem] = []
                var photosByURL: [String: PhotoItem] = [:]
                
                for info in sortedInfos {
                    let photo = PhotoItem(url: info.url, rating: info.rating)
                    photo.iptcMetadata = info.iptc
                    if let edit = info.edit {
                        photo.adjustments = edit.adjustments
                        photo.cropRect = edit.cropRect?.cgRect
                        photo.rotation = edit.rotation
                        photo.isMaster = edit.isMaster
                        photo.masterID = edit.masterID.flatMap { UUID(uuidString: $0) }
                        photo.virtualCopyNumber = edit.virtualCopyNumber
                    }
                    loadedPhotos.append(photo)
                    photosByURL[info.url.standardizedFileURL.path] = photo
                }
                
                // 2) Reconstruct Virtual Copies from catalog
                for (key, edit) in editSnapshot {
                    // Virtual Copy entries have a "#UUID" suffix
                    guard key.contains("#"), !edit.isMaster else { continue }
                    
                    let parts = key.split(separator: "#")
                    guard parts.count == 2, let photoIDStr = parts.last, let photoID = UUID(uuidString: String(photoIDStr)) else { continue }
                    
                    let urlPath = String(parts[0])
                    guard let masterPhoto = photosByURL[urlPath] else { continue }
                    
                    // Create virtual copy PhotoItem
                    let virtualCopy = PhotoItem(url: masterPhoto.url, rating: masterPhoto.rating, id: photoID)
                    virtualCopy.adjustments = edit.adjustments
                    virtualCopy.cropRect = edit.cropRect?.cgRect
                    virtualCopy.rotation = edit.rotation
                    virtualCopy.isMaster = false
                    virtualCopy.masterID = edit.masterID.flatMap { UUID(uuidString: $0) }
                    virtualCopy.virtualCopyNumber = edit.virtualCopyNumber
                    virtualCopy.iptcMetadata = masterPhoto.iptcMetadata
                    
                    loadedPhotos.append(virtualCopy)
                }
                
                // Sort: Masters first, then their copies
                loadedPhotos.sort { a, b in
                    let aURL = a.url.lastPathComponent
                    let bURL = b.url.lastPathComponent
                    if aURL != bURL { return aURL < bURL }
                    return a.virtualCopyNumber < b.virtualCopyNumber
                }
                
                self.photos = loadedPhotos
                self.isLoadingPhotos = false
                self.loadingProgress = 1.0
                
                // Load Quick Collection state
                self.loadQuickCollection()
                
                print("✅ \(loadedPhotos.count) Bilder geladen aus \(folderURL.path)")
                
                // Update filtered photos
                self.updateFilteredPhotos()
                
                if let firstPhoto = self.filteredPhotos.first {
                    self.currentPhotoID = firstPhoto.id
                    self.selectedPhotoIDs = [firstPhoto.id]
                    print("✅ Erstes Foto ausgewählt: \(firstPhoto.fileName)")
                } else {
                    self.currentPhotoID = nil
                    self.selectedPhotoIDs = []
                    print("⚠️ Keine gefilterten Fotos gefunden")
                }
            }
        }
    }

    // MARK: - Non-destructive edit persistence

    private func registerEditPersistenceObservers() {
        NotificationCenter.default.publisher(for: NSNotification.Name("PhotoAdjustmentsChanged"))
            .compactMap { $0.userInfo?["photoID"] as? UUID }
            .sink { [weak self] photoID in
                guard let self else { return }
                self.persistEditsDebounced(for: photoID)
            }
            .store(in: &cancellables)
    }

    private var persistTasks: [UUID: Task<Void, Never>] = [:]

    private func persistEditsDebounced(for photoID: UUID) {
        persistTasks[photoID]?.cancel()
        persistTasks[photoID] = Task { @MainActor in
            // debounce: sliders spammen viele Notifications
            try? await Task.sleep(nanoseconds: 500_000_000) // 500ms
            guard let photo = self.photos.first(where: { $0.id == photoID }) else { return }
            let entry = EditCatalogService.EditEntry(
                adjustments: photo.adjustments,
                cropRect: photo.cropRect,
                rotation: photo.rotation,
                isMaster: photo.isMaster,
                masterID: photo.masterID,
                virtualCopyNumber: photo.virtualCopyNumber
            )
            // Master: stabil per Dateipfad (kein #UUID), Virtual Copy: per url#uuid
            let keyPhotoID: UUID? = photo.isMaster ? nil : photo.id
            await EditCatalogService.shared.upsertEdit(entry, for: photo.url, photoID: keyPhotoID)
            self.persistTasks[photoID] = nil
        }
    }
    
    // MARK: - History / Undo / Snapshots (Lightroom-like)
    
    private struct EditState: Equatable, Sendable {
        var adjustments: PhotoAdjustments
        var cropRect: CGRect?
        var rotation: Double
    }
    
    private let maxUndoDepth: Int = 60
    private var undoStackByKey: [String: [EditState]] = [:]
    private var redoStackByKey: [String: [EditState]] = [:]
    private var inFlightEditStartByKey: [String: EditState] = [:]
    
    func beginEditSession(for photo: PhotoItem) {
        let key = editKey(for: photo)
        if inFlightEditStartByKey[key] == nil {
            inFlightEditStartByKey[key] = captureEditState(photo)
        }
    }
    
    func endEditSession(for photo: PhotoItem) {
        let key = editKey(for: photo)
        guard let start = inFlightEditStartByKey.removeValue(forKey: key) else { return }
        let current = captureEditState(photo)
        guard start != current else { return }
        pushUndo(start, forKey: key)
        redoStackByKey[key] = []
        objectWillChange.send()
    }
    
    /// Für diskrete Aktionen (Auto/Reset/Preset/Paste/Sync): Undo-Punkt vor der Änderung speichern.
    func registerUndoPoint(for photo: PhotoItem) {
        let key = editKey(for: photo)
        pushUndo(captureEditState(photo), forKey: key)
        redoStackByKey[key] = []
        objectWillChange.send()
    }
    
    func undoCurrent() {
        guard let photo = currentPhoto else { return }
        undo(photo: photo)
    }
    
    func redoCurrent() {
        guard let photo = currentPhoto else { return }
        redo(photo: photo)
    }
    
    func canUndo(photo: PhotoItem) -> Bool {
        let key = editKey(for: photo)
        return !(undoStackByKey[key]?.isEmpty ?? true)
    }
    
    func canRedo(photo: PhotoItem) -> Bool {
        let key = editKey(for: photo)
        return !(redoStackByKey[key]?.isEmpty ?? true)
    }
    
    var canUndoCurrent: Bool {
        guard let photo = currentPhoto else { return false }
        return canUndo(photo: photo)
    }
    
    var canRedoCurrent: Bool {
        guard let photo = currentPhoto else { return false }
        return canRedo(photo: photo)
    }
    
    private func undo(photo: PhotoItem) {
        let key = editKey(for: photo)
        guard var undoStack = undoStackByKey[key], let previous = undoStack.popLast() else { return }
        undoStackByKey[key] = undoStack
        
        var redoStack = redoStackByKey[key] ?? []
        redoStack.append(captureEditState(photo))
        redoStackByKey[key] = redoStack
        
        applyEditState(previous, to: photo)
        objectWillChange.send()
    }
    
    private func redo(photo: PhotoItem) {
        let key = editKey(for: photo)
        guard var redoStack = redoStackByKey[key], let next = redoStack.popLast() else { return }
        redoStackByKey[key] = redoStack
        
        var undoStack = undoStackByKey[key] ?? []
        undoStack.append(captureEditState(photo))
        undoStackByKey[key] = trimUndo(undoStack)
        
        applyEditState(next, to: photo)
        objectWillChange.send()
    }
    
    // MARK: Snapshots
    
    func snapshots(for photo: PhotoItem) -> [EditSnapshot] {
        editSnapshotsByKey[editKey(for: photo)] ?? []
    }
    
    func createSnapshot(for photo: PhotoItem, name: String? = nil) {
        let key = editKey(for: photo)
        var list = editSnapshotsByKey[key] ?? []
        let defaultName = name ?? "Snapshot \(list.count + 1)"
        let snapshot = EditSnapshot(
            name: defaultName,
            adjustments: photo.adjustments,
            cropRect: photo.cropRect,
            rotation: photo.rotation
        )
        list.insert(snapshot, at: 0)
        editSnapshotsByKey[key] = list
        saveEditSnapshots()
        objectWillChange.send()
    }
    
    func applySnapshot(_ snapshot: EditSnapshot, to photo: PhotoItem) {
        registerUndoPoint(for: photo)
        
        photo.adjustments = snapshot.adjustments
        photo.cropRect = snapshot.cropRect?.cgRect
        photo.rotation = snapshot.rotation
        
        triggerReprocess(for: photo)
    }
    
    func deleteSnapshot(_ snapshot: EditSnapshot, for photo: PhotoItem) {
        let key = editKey(for: photo)
        var list = editSnapshotsByKey[key] ?? []
        list.removeAll { $0.id == snapshot.id }
        editSnapshotsByKey[key] = list
        saveEditSnapshots()
        objectWillChange.send()
    }
    
    private func loadEditSnapshots() {
        guard let data = UserDefaults.standard.data(forKey: "editSnapshotsV1"),
              let decoded = try? JSONDecoder().decode([String: [EditSnapshot]].self, from: data) else {
            editSnapshotsByKey = [:]
            return
        }
        editSnapshotsByKey = decoded
    }
    
    private func saveEditSnapshots() {
        guard let encoded = try? JSONEncoder().encode(editSnapshotsByKey) else { return }
        UserDefaults.standard.set(encoded, forKey: "editSnapshotsV1")
    }
    
    // MARK: Helpers
    
    private func editKey(for photo: PhotoItem) -> String {
        let base = photo.url.standardizedFileURL.path
        return photo.isMaster ? base : "\(base)#\(photo.id.uuidString)"
    }
    
    private func captureEditState(_ photo: PhotoItem) -> EditState {
        EditState(adjustments: photo.adjustments, cropRect: photo.cropRect, rotation: photo.rotation)
    }
    
    private func applyEditState(_ state: EditState, to photo: PhotoItem) {
        photo.adjustments = state.adjustments
        photo.cropRect = state.cropRect
        photo.rotation = state.rotation
        triggerReprocess(for: photo)
    }
    
    private func pushUndo(_ state: EditState, forKey key: String) {
        var stack = undoStackByKey[key] ?? []
        // Dedup: wenn letzter Eintrag identisch, nicht pushen
        if stack.last != state {
            stack.append(state)
        }
        undoStackByKey[key] = trimUndo(stack)
    }
    
    private func trimUndo(_ stack: [EditState]) -> [EditState] {
        if stack.count <= maxUndoDepth { return stack }
        return Array(stack.suffix(maxUndoDepth))
    }

    @MainActor
    private func requestPhotosLibraryAuthorization() async -> PHAuthorizationStatus {
        await withCheckedContinuation { continuation in
            PHPhotoLibrary.requestAuthorization(for: .readWrite) { status in
                continuation.resume(returning: status)
            }
        }
    }

    @MainActor
    private func showPhotosPermissionAlert() {
        let alert = NSAlert()
        alert.messageText = "Zugriff auf Fotos verweigert"
        alert.informativeText = "WB Foto Manager benötigt Zugriff auf die Fotos‑Mediathek. Bitte in „Systemeinstellungen → Datenschutz & Sicherheit → Fotos“ aktivieren und erneut versuchen."
        alert.addButton(withTitle: "OK")
        alert.alertStyle = .warning
        alert.runModal()
    }
    
    // MARK: - Navigation
    
    func selectPhoto(_ photo: PhotoItem) {
        currentPhotoID = photo.id
        if uiState?.selectionMode == true {
            // Safe multi-select: Click adds to selection, does NOT unselect (prevents accidental "losing" selection).
            selectedPhotoIDs.insert(photo.id)
        } else {
            // Single selection (default)
            selectedPhotoIDs = [photo.id]
        }
    }

    func clearSelectionToCurrent() {
        if let current = currentPhotoID {
            selectedPhotoIDs = [current]
        } else {
            selectedPhotoIDs = []
        }
    }

    func copyAdjustmentsFromCurrent() {
        guard let photo = currentPhoto else { return }
        copiedAdjustments = photo.adjustments
    }

    func pasteAdjustmentsToCurrent() {
        guard let photo = currentPhoto, let copiedAdjustments else { return }
        registerUndoPoint(for: photo)
        photo.adjustments = copiedAdjustments
        triggerReprocess(for: photo)
    }

    func pasteAdjustmentsToSelection() {
        guard let copiedAdjustments else { return }
        let targets = photos.filter { selectedPhotoIDs.contains($0.id) }
        guard !targets.isEmpty else { return }

        for photo in targets {
            registerUndoPoint(for: photo)
            photo.adjustments = copiedAdjustments
            persistEditsForPhoto(photo)
        }

        if let current = currentPhoto {
            triggerReprocess(for: current)
        } else {
            objectWillChange.send()
        }
    }

    func syncFromCurrentToSelection(scope: SyncScope) {
        guard let source = currentPhoto else { return }
        let sourceAdjustments = source.adjustments
        let sourceCrop = source.cropRect
        let sourceRotation = source.rotation

        let targets = photos.filter { selectedPhotoIDs.contains($0.id) && $0.id != source.id }
        guard !targets.isEmpty else { return }

        for photo in targets {
            registerUndoPoint(for: photo)
            var updated = photo.adjustments
            applySyncAdjustments(from: sourceAdjustments, to: &updated, scope: scope)
            photo.adjustments = updated
            if scope.cropAndRotation {
                photo.cropRect = sourceCrop
                photo.rotation = sourceRotation
            }
            persistEditsForPhoto(photo)
        }

        // Ensure current image refresh (and also persist current via existing observer).
        triggerReprocess(for: source)
    }

    private func applySyncAdjustments(from source: PhotoAdjustments, to target: inout PhotoAdjustments, scope: SyncScope) {
        if scope.whiteBalance {
            target.temperature = source.temperature
            target.tint = source.tint
        }
        if scope.exposure {
            target.exposure = source.exposure
        }
        if scope.contrast {
            target.contrast = source.contrast
        }
        if scope.tone {
            target.highlights = source.highlights
            target.shadows = source.shadows
            target.whites = source.whites
            target.blacks = source.blacks
        }
        if scope.presence {
            target.clarity = source.clarity
            target.texture = source.texture
            target.dehaze = source.dehaze
            target.vibrance = source.vibrance
            target.saturation = source.saturation
        }
        // Details (sharpness, noise) - not yet implemented in PhotoAdjustments
        // ColorAdjustments (hue shifts) - not yet implemented in PhotoAdjustments
    }

    private func triggerReprocess(for photo: PhotoItem) {
        // DetailView observes notification; persistence observers hook into this as well.
        photo.objectWillChange.send()
        objectWillChange.send()
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id]
        )
    }

    private func persistEditsForPhoto(_ photo: PhotoItem) {
        let entry = EditCatalogService.EditEntry(
            adjustments: photo.adjustments,
            cropRect: photo.cropRect,
            rotation: photo.rotation,
            isMaster: photo.isMaster,
            masterID: photo.masterID,
            virtualCopyNumber: photo.virtualCopyNumber
        )
        Task {
            // Master: stabil per Dateipfad (kein #UUID), Virtual Copy: per url#uuid
            let keyPhotoID: UUID? = photo.isMaster ? nil : photo.id
            await EditCatalogService.shared.upsertEdit(entry, for: photo.url, photoID: keyPhotoID)
        }
    }
    
    func selectNextPhoto() {
        guard let currentIndex = currentPhotoIndexInFiltered else { return }
        if currentIndex < filteredPhotos.count - 1 {
            selectPhoto(filteredPhotos[currentIndex + 1])
        }
    }
    
    func selectPreviousPhoto() {
        guard let currentIndex = currentPhotoIndexInFiltered else { return }
        if currentIndex > 0 {
            selectPhoto(filteredPhotos[currentIndex - 1])
        }
    }
    
    func selectPhoto(at index: Int) {
        guard index >= 0 && index < filteredPhotos.count else { return }
        selectPhoto(filteredPhotos[index])
    }
    
    // MARK: - Rating & Tags
    
    func setRating(_ rating: Int, for photoID: UUID, autoAdvance: Bool = true) {
        guard let index = photos.firstIndex(where: { $0.id == photoID }) else { return }
        let photo = photos[index]
        photo.rating = rating
        
        // Manually trigger an update for the specific photo and re-filtering
        objectWillChange.send()
        updateFilteredPhotos()
        
        Task(priority: .background) {
            try? await self.ratingService.writeRating(rating, to: photo.url)
        }
        
        if exportQueueEnabled && rating >= exportQueueMinRating {
            checkAndExportQueue()
        }
        
        // AUTO-ADVANCE: Gehe zum nächsten Bild (KRITISCH für Sportfotografie!)
        if autoAdvance && AppSettings.shared.autoAdvanceAfterRating {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.selectNextPhoto()
            }
        }
    }
    
    // MARK: - Pick/Reject (Lightroom-Style)
    
    func setPickStatus(_ status: PickStatus, for photoID: UUID, autoAdvance: Bool = true) {
        guard let photo = photos.first(where: { $0.id == photoID }) else { return }
        photo.pickStatus = status
        objectWillChange.send()
        updateFilteredPhotos()
        
        // Persist to XMP or sidecar (optional, for now in-memory only)
        // TODO: Save to XMP Rating field (Pick=1, Reject=-1, Unflagged=0)
        
        // AUTO-ADVANCE nach Pick/Reject
        if autoAdvance && AppSettings.shared.autoAdvanceAfterRating {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.selectNextPhoto()
            }
        }
    }
    
    func markAsPick(photoID: UUID) {
        setPickStatus(.pick, for: photoID)
    }
    
    func markAsReject(photoID: UUID) {
        setPickStatus(.reject, for: photoID)
    }
    
    func unflag(photoID: UUID) {
        setPickStatus(.unflagged, for: photoID)
    }
    
    func deleteAllRejects() {
        let rejects = photos.filter { $0.pickStatus == .reject }
        guard !rejects.isEmpty else { return }
        
        // Ask user for confirmation
        let alert = NSAlert()
        alert.messageText = "Alle abgelehnten Bilder löschen?"
        alert.informativeText = "\(rejects.count) Bild(er) werden permanent gelöscht."
        alert.alertStyle = .critical
        alert.addButton(withTitle: "Löschen")
        alert.addButton(withTitle: "Abbrechen")
        
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        
        // Delete from file system
        for photo in rejects {
            try? FileManager.default.trashItem(at: photo.url, resultingItemURL: nil)
        }
        
        // Remove from array
        photos.removeAll { $0.pickStatus == .reject }
        objectWillChange.send()
        updateFilteredPhotos()
    }
    
    // MARK: - Quick Collection (Lightroom-Style)
    
    func toggleQuickCollection(for photoID: UUID) {
        guard let photo = photos.first(where: { $0.id == photoID }) else { return }
        photo.isInQuickCollection.toggle()
        objectWillChange.send()
        updateFilteredPhotos()
        saveQuickCollection()
    }
    
    func clearQuickCollection() {
        for photo in photos {
            photo.isInQuickCollection = false
        }
        objectWillChange.send()
        updateFilteredPhotos()
        saveQuickCollection()
    }
    
    private func saveQuickCollection() {
        let quickCollectionIDs = photos.filter { $0.isInQuickCollection }.map { $0.url.path }
        UserDefaults.standard.set(quickCollectionIDs, forKey: "quickCollectionURLs")
    }
    
    private func loadQuickCollection() {
        guard let savedURLs = UserDefaults.standard.stringArray(forKey: "quickCollectionURLs") else { return }
        let urlSet = Set(savedURLs)
        for photo in photos {
            photo.isInQuickCollection = urlSet.contains(photo.url.path)
        }
    }
    
    // MARK: - Virtual Copies (Lightroom-Style)
    
    func createVirtualCopy(of photoID: UUID) {
        guard let master = photos.first(where: { $0.id == photoID }) else { return }
        
        // Find all existing copies of this master (or master itself if it's a copy)
        let actualMasterID = master.isMaster ? master.id : master.masterID!
        let allCopies = photos.filter {
            ($0.id == actualMasterID) || ($0.masterID == actualMasterID)
        }
        
        // Determine next copy number
        let maxCopyNumber = allCopies.map(\.virtualCopyNumber).max() ?? 0
        let newCopyNumber = maxCopyNumber + 1
        
        // Create virtual copy
        let actualMaster = master.isMaster ? master : photos.first(where: { $0.id == actualMasterID })!
        let virtualCopy = PhotoItem(from: actualMaster, copyNumber: newCopyNumber)
        
        // Mark master if needed
        if actualMaster.virtualCopyNumber == 0, allCopies.count == 1 {
            // First copy created, mark original as "Master"
            actualMaster.virtualCopyNumber = 0
            actualMaster.isMaster = true
        }
        
        // Insert after master/last copy
        if let masterIndex = photos.firstIndex(where: { $0.id == actualMasterID }) {
            let insertIndex = masterIndex + allCopies.count
            photos.insert(virtualCopy, at: min(insertIndex, photos.count))
        } else {
            photos.append(virtualCopy)
        }
        
        // Select new copy
        selectPhoto(virtualCopy)
        
        objectWillChange.send()
        updateFilteredPhotos()
        
        // Persist
        persistEditsForPhoto(virtualCopy)
    }
    
    func deleteVirtualCopy(photoID: UUID) {
        guard let photo = photos.first(where: { $0.id == photoID }), !photo.isMaster else {
            return // Can't delete master
        }
        
        photos.removeAll { $0.id == photoID }
        objectWillChange.send()
        updateFilteredPhotos()
        
        // Remove snapshots for this virtual copy
        editSnapshotsByKey.removeValue(forKey: editKey(for: photo))
        saveEditSnapshots()
        
        // Remove from catalog (Virtual Copy key = url#uuid)
        Task {
            await EditCatalogService.shared.removeEdit(for: photo.url, photoID: photo.id)
        }
    }
    
    func getVirtualCopies(for photoID: UUID) -> [PhotoItem] {
        guard let photo = photos.first(where: { $0.id == photoID }) else { return [] }
        let masterID = photo.isMaster ? photo.id : photo.masterID!
        return photos.filter { ($0.id == masterID) || ($0.masterID == masterID) }.sorted { $0.virtualCopyNumber < $1.virtualCopyNumber }
    }
    
    // ... (rest of the file remains largely the same, but methods like toggleColorTag would also need objectWillChange.send() and updateFilteredPhotos())
    
    func toggleColorTag(_ tag: ColorTag, for photoID: UUID) {
        guard let photo = photos.first(where: { $0.id == photoID }) else { return }
        if photo.colorTags.contains(tag) {
            photo.colorTags.remove(tag)
        } else {
            photo.colorTags.insert(tag)
        }
        objectWillChange.send()
        updateFilteredPhotos()
    }
    
    // MARK: - Export Queue
    
    func checkAndExportQueue() {
        // ... implementation ...
    }
    
    // MARK: - Preset Management (Export, Adjustment, etc.)
    
    func loadExportPresets() {
        if let data = UserDefaults.standard.data(forKey: "exportPresets"),
           let decoded = try? JSONDecoder().decode([ExportPreset].self, from: data) {
            exportPresets = decoded
        } else {
            exportPresets = ExportPreset.defaultPresets
            saveExportPresets()
        }
    }
    
    func saveExportPresets() {
        if let encoded = try? JSONEncoder().encode(exportPresets) {
            UserDefaults.standard.set(encoded, forKey: "exportPresets")
        }
    }
    
    // ... etc. for all preset types
    func addExportPreset(_ preset: ExportPreset) {
        exportPresets.append(preset)
        saveExportPresets()
    }
    
    func updateExportPreset(_ preset: ExportPreset) {
        if let index = exportPresets.firstIndex(where: { $0.id == preset.id }) {
            exportPresets[index] = preset
            saveExportPresets()
        }
    }
    
    func deleteExportPreset(_ preset: ExportPreset) {
        exportPresets.removeAll { $0.id == preset.id }
        saveExportPresets()
    }
    func loadAdjustmentPresets() {
        if let data = UserDefaults.standard.data(forKey: "adjustmentPresets"),
           let decoded = try? JSONDecoder().decode([AdjustmentPreset].self, from: data) {
            adjustmentPresets = decoded
        } else {
            // Lade Standard-Presets wenn keine vorhanden
            loadDefaultPresets()
        }
    }
    
    func saveAdjustmentPresets() {
        if let encoded = try? JSONEncoder().encode(adjustmentPresets) {
            UserDefaults.standard.set(encoded, forKey: "adjustmentPresets")
        }
    }
    
    func addAdjustmentPreset(_ preset: AdjustmentPreset) {
        adjustmentPresets.append(preset)
        if let group = preset.group?.trimmingCharacters(in: .whitespacesAndNewlines),
           !group.isEmpty,
           !presetGroups.contains(group) {
            presetGroups.append(group)
            savePresetGroups()
        }
        saveAdjustmentPresets()
    }
    
    func updateAdjustmentPreset(_ preset: AdjustmentPreset) {
        if let index = adjustmentPresets.firstIndex(where: { $0.id == preset.id }) {
            adjustmentPresets[index] = preset
            if let group = preset.group?.trimmingCharacters(in: .whitespacesAndNewlines),
               !group.isEmpty,
               !presetGroups.contains(group) {
                presetGroups.append(group)
                savePresetGroups()
            }
            saveAdjustmentPresets()
        }
    }
    
    func deleteAdjustmentPreset(_ preset: AdjustmentPreset) {
        adjustmentPresets.removeAll { $0.id == preset.id }
        saveAdjustmentPresets()
    }
    
    // MARK: - Preset Group Management
    
    func loadPresetGroups() {
        if let groups = UserDefaults.standard.stringArray(forKey: "presetGroups") {
            presetGroups = groups
            return
        }
        
        // Default: aus vorhandenen Presets ableiten
        let groupsFromPresets = Set(adjustmentPresets.compactMap { $0.group?.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty })
        presetGroups = groupsFromPresets.sorted()
        savePresetGroups()
    }
    
    func savePresetGroups() {
        UserDefaults.standard.set(presetGroups, forKey: "presetGroups")
    }
    
    func addPresetGroup(_ name: String) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        guard !presetGroups.contains(trimmed) else { return }
        presetGroups.append(trimmed)
        savePresetGroups()
    }
    
    private func loadDefaultPresets() {
        adjustmentPresets = [
            AdjustmentPreset(
                name: "Vivid",
                group: "Farbe",
                adjustments: PhotoAdjustments(
                    exposure: 0.1,
                    contrast: 1.15,
                    clarity: 0.2,
                    vibrance: 30,
                    saturation: 25
                )
            ),
            AdjustmentPreset(
                name: "Portrait",
                group: "Portrait",
                adjustments: PhotoAdjustments(
                    exposure: 0.2,
                    contrast: 1.05,
                    temperature: 200,
                    clarity: 0.15,
                    texture: 10
                )
            ),
            AdjustmentPreset(
                name: "Landschaft",
                group: "Stil",
                adjustments: PhotoAdjustments(
                    exposure: 0.1,
                    contrast: 1.2,
                    clarity: 0.3,
                    saturation: 20,
                    dehaze: 15
                )
            ),
            AdjustmentPreset(
                name: "Schwarz-Weiß",
                group: "Stil",
                adjustments: PhotoAdjustments(
                    exposure: 0.1,
                    contrast: 1.3,
                    clarity: 0.25,
                    saturation: -100
                )
            ),
            AdjustmentPreset(
                name: "Warm",
                group: "Farbe",
                adjustments: PhotoAdjustments(
                    temperature: 500,
                    tint: 10,
                    vibrance: 20
                )
            ),
            AdjustmentPreset(
                name: "Cool",
                group: "Farbe",
                adjustments: PhotoAdjustments(
                    temperature: -500,
                    tint: -10,
                    vibrance: 15
                )
            )
        ]
        saveAdjustmentPresets()
    }
    func loadUploadTargets() {
        if let data = UserDefaults.standard.data(forKey: "uploadTargets"),
           let decoded = try? JSONDecoder().decode([UploadTarget].self, from: data) {
            uploadTargets = decoded
        } else {
            uploadTargets = []
        }
    }
    
    func saveUploadTargets() {
        if let encoded = try? JSONEncoder().encode(uploadTargets) {
            UserDefaults.standard.set(encoded, forKey: "uploadTargets")
        }
    }
    
    func addUploadTarget(_ target: UploadTarget) {
        uploadTargets.append(target)
        saveUploadTargets()
    }
    
    func updateUploadTarget(_ target: UploadTarget) {
        if let index = uploadTargets.firstIndex(where: { $0.id == target.id }) {
            uploadTargets[index] = target
            saveUploadTargets()
        }
    }
    
    func deleteUploadTarget(_ target: UploadTarget) {
        uploadTargets.removeAll { $0.id == target.id }
        saveUploadTargets()
    }
    
    func loadIPTCTemplates() {
        if let data = UserDefaults.standard.data(forKey: "iptcTemplates"),
           let decoded = try? JSONDecoder().decode([IPTCTemplate].self, from: data) {
            iptcTemplates = decoded
        } else {
            iptcTemplates = IPTCTemplate.defaultTemplates
            saveIPTCTemplates()
        }
    }
    
    func saveIPTCTemplates() {
        if let encoded = try? JSONEncoder().encode(iptcTemplates) {
            UserDefaults.standard.set(encoded, forKey: "iptcTemplates")
        }
    }
    
    func addIPTCTemplate(_ template: IPTCTemplate) {
        iptcTemplates.append(template)
        saveIPTCTemplates()
    }
    
    func updateIPTCTemplate(_ template: IPTCTemplate) {
        if let index = iptcTemplates.firstIndex(where: { $0.id == template.id }) {
            iptcTemplates[index] = template
            saveIPTCTemplates()
        }
    }
    
    func deleteIPTCTemplate(_ template: IPTCTemplate) {
        iptcTemplates.removeAll { $0.id == template.id }
        saveIPTCTemplates()
    }
    
    // MARK: - Smart Collections
    
    func loadSmartCollections() {
        if let data = UserDefaults.standard.data(forKey: "smartCollections"),
           let decoded = try? JSONDecoder().decode([SmartCollection].self, from: data) {
            smartCollections = decoded
        } else {
            // Standard Smart Collections
            smartCollections = [
                SmartCollection(name: "Picks", criteria: SmartCollectionCriteria(pickStatus: .pick)),
                SmartCollection(name: "5 Sterne", criteria: SmartCollectionCriteria(minRating: 5, maxRating: 5)),
                SmartCollection(name: "Mit Adjustments", criteria: SmartCollectionCriteria(hasAdjustments: true)),
                SmartCollection(name: "Quick Collection", criteria: SmartCollectionCriteria(isInQuickCollection: true))
            ]
            saveSmartCollections()
        }
    }
    
    func saveSmartCollections() {
        if let encoded = try? JSONEncoder().encode(smartCollections) {
            UserDefaults.standard.set(encoded, forKey: "smartCollections")
        }
    }
    
    func addSmartCollection(_ collection: SmartCollection) {
        smartCollections.append(collection)
        saveSmartCollections()
    }
    
    func updateSmartCollection(_ collection: SmartCollection) {
        if let index = smartCollections.firstIndex(where: { $0.id == collection.id }) {
            smartCollections[index] = collection
            saveSmartCollections()
        }
    }
    
    func deleteSmartCollection(_ collection: SmartCollection) {
        smartCollections.removeAll { $0.id == collection.id }
        saveSmartCollections()
    }
    
    /// Filtert Photos basierend auf Smart Collection Kriterien
    func filterPhotos(by collection: SmartCollection) -> [PhotoItem] {
        return photos.filter { collection.matches($0) }
    }
    
    // MARK: - AI Tagging
    
    /// Generiert AI-Keywords für das aktuelle Foto
    func generateAITagsForCurrent() async {
        guard let photo = currentPhoto else { return }
        await generateAITags(for: photo)
    }
    
    /// Generiert AI-Keywords für ein bestimmtes Foto
    func generateAITags(for photo: PhotoItem) async {
        let keywords = await AITaggingService.shared.generateKeywords(for: photo)
        
        await MainActor.run {
            // Füge Keywords zu IPTC Metadata hinzu
            if photo.iptcMetadata == nil {
                photo.iptcMetadata = IPTCMetadata()
            }
            
            // Kombiniere neue Keywords mit existierenden (keine Duplikate)
            var existingKeywords = Set(photo.iptcMetadata?.keywords ?? [])
            for keyword in keywords {
                existingKeywords.insert(keyword)
            }
            
            photo.iptcMetadata?.keywords = Array(existingKeywords).sorted()
            
            // Persistiere IPTC Metadata
            if let iptc = photo.iptcMetadata {
                Task {
                    try? IPTCMetadataService.shared.writeMetadata(iptc, to: photo.url)
                }
            }
            
            objectWillChange.send()
        }
    }
    
    /// Batch AI-Tagging für ausgewählte Fotos
    func generateAITagsForSelection(progress: @escaping (Int, Int) -> Void) async {
        let selectedPhotos = photos.filter { selectedPhotoIDs.contains($0.id) }
        guard !selectedPhotos.isEmpty else { return }
        
        let results = await AITaggingService.shared.generateKeywordsBatch(for: selectedPhotos, progress: progress)
        
        await MainActor.run {
            for photo in selectedPhotos {
                if let keywords = results[photo.id], !keywords.isEmpty {
                    if photo.iptcMetadata == nil {
                        photo.iptcMetadata = IPTCMetadata()
                    }
                    
                    var existingKeywords = Set(photo.iptcMetadata?.keywords ?? [])
                    for keyword in keywords {
                        existingKeywords.insert(keyword)
                    }
                    
                    photo.iptcMetadata?.keywords = Array(existingKeywords).sorted()
                    
                    // Persistiere IPTC Metadata
                    if let iptc = photo.iptcMetadata {
                        Task {
                            try? IPTCMetadataService.shared.writeMetadata(iptc, to: photo.url)
                        }
                    }
                }
            }
            
            objectWillChange.send()
        }
    }
}

