//
//  AppSettings.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import SwiftUI
import Combine

class AppSettings: ObservableObject {
    static let shared = AppSettings()
    
    private init() {
        // Load from UserDefaults
        autoOpenLastFolder = UserDefaults.standard.bool(forKey: "autoOpenLastFolder")
        searchSubfolders = UserDefaults.standard.object(forKey: "searchSubfolders") as? Bool ?? true
        saveRatingInXMP = UserDefaults.standard.object(forKey: "saveRatingInXMP") as? Bool ?? true
        autoLoadIPTC = UserDefaults.standard.object(forKey: "autoLoadIPTC") as? Bool ?? true
        backupBeforeOverwrite = UserDefaults.standard.object(forKey: "backupBeforeOverwrite") as? Bool ?? true
        previewQuality = UserDefaults.standard.object(forKey: "previewQuality") as? Double ?? 0.8
        maxCacheSize = UserDefaults.standard.object(forKey: "maxCacheSize") as? Int ?? 1000
        hardwareAcceleration = UserDefaults.standard.object(forKey: "hardwareAcceleration") as? Bool ?? true
        progressiveRendering = UserDefaults.standard.object(forKey: "progressiveRendering") as? Bool ?? true
        defaultExportFormat = UserDefaults.standard.string(forKey: "defaultExportFormat") ?? "jpeg"
        defaultExportQuality = UserDefaults.standard.object(forKey: "defaultExportQuality") as? Double ?? 0.85
        filenameTemplate = UserDefaults.standard.string(forKey: "filenameTemplate") ?? "{originalname}_{preset}"
        theme = UserDefaults.standard.string(forKey: "theme") ?? "dark"
        sidebarAlwaysVisible = UserDefaults.standard.bool(forKey: "sidebarAlwaysVisible")
        showSidebarIcons = UserDefaults.standard.object(forKey: "showSidebarIcons") as? Bool ?? true
        autoAdvanceAfterRating = UserDefaults.standard.object(forKey: "autoAdvanceAfterRating") as? Bool ?? true
    }
    
    // General Settings
    @Published var autoOpenLastFolder: Bool = false {
        didSet { UserDefaults.standard.set(autoOpenLastFolder, forKey: "autoOpenLastFolder") }
    }
    @Published var searchSubfolders: Bool = true {
        didSet { UserDefaults.standard.set(searchSubfolders, forKey: "searchSubfolders") }
    }
    @Published var saveRatingInXMP: Bool = true {
        didSet { UserDefaults.standard.set(saveRatingInXMP, forKey: "saveRatingInXMP") }
    }
    @Published var autoLoadIPTC: Bool = true {
        didSet { UserDefaults.standard.set(autoLoadIPTC, forKey: "autoLoadIPTC") }
    }
    @Published var backupBeforeOverwrite: Bool = true {
        didSet { UserDefaults.standard.set(backupBeforeOverwrite, forKey: "backupBeforeOverwrite") }
    }
    
    // Performance Settings
    @Published var previewQuality: Double = 0.8 {
        didSet { UserDefaults.standard.set(previewQuality, forKey: "previewQuality") }
    }
    @Published var maxCacheSize: Int = 1000 {
        didSet { UserDefaults.standard.set(maxCacheSize, forKey: "maxCacheSize") }
    }
    @Published var hardwareAcceleration: Bool = true {
        didSet { UserDefaults.standard.set(hardwareAcceleration, forKey: "hardwareAcceleration") }
    }
    @Published var progressiveRendering: Bool = true {
        didSet { UserDefaults.standard.set(progressiveRendering, forKey: "progressiveRendering") }
    }
    
    // Export Settings
    @Published var defaultExportFormat: String = "jpeg" {
        didSet { UserDefaults.standard.set(defaultExportFormat, forKey: "defaultExportFormat") }
    }
    @Published var defaultExportQuality: Double = 0.85 {
        didSet { UserDefaults.standard.set(defaultExportQuality, forKey: "defaultExportQuality") }
    }
    @Published var filenameTemplate: String = "{originalname}_{preset}" {
        didSet { UserDefaults.standard.set(filenameTemplate, forKey: "filenameTemplate") }
    }
    
    // Appearance Settings
    @Published var theme: String = "dark" {
        didSet { UserDefaults.standard.set(theme, forKey: "theme") }
    }
    @Published var sidebarAlwaysVisible: Bool = false {
        didSet { UserDefaults.standard.set(sidebarAlwaysVisible, forKey: "sidebarAlwaysVisible") }
    }
    @Published var showSidebarIcons: Bool = true {
        didSet { UserDefaults.standard.set(showSidebarIcons, forKey: "showSidebarIcons") }
    }
    
    // Workflow Settings
    @Published var autoAdvanceAfterRating: Bool = true {
        didSet { UserDefaults.standard.set(autoAdvanceAfterRating, forKey: "autoAdvanceAfterRating") }
    }
}
