//
//  AdjustmentPreset.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation

/// Preset für Bildbearbeitungs-Adjustments
struct AdjustmentPreset: Identifiable, Codable, Hashable {
    let id: UUID
    var name: String
    var group: String?
    var adjustments: PhotoAdjustments
    
    init(id: UUID = UUID(), name: String, group: String? = nil, adjustments: PhotoAdjustments = PhotoAdjustments()) {
        self.id = id
        self.name = name
        self.group = group
        self.adjustments = adjustments
    }
    
    static var defaultPresets: [AdjustmentPreset] {
        [
            AdjustmentPreset(
                name: "Vivid",
                group: "Farbe",
                adjustments: PhotoAdjustments(
                    exposure: 0.0,
                    contrast: 1.1,
                    temperature: 0.0,
                    tint: 0.0,
                    clarity: 0.2,
                    vibrance: 0.3,
                    highlights: 0.0,
                    shadows: 0.0,
                    whites: 0.0,
                    blacks: 0.0,
                    saturation: 0.0,
                    dehaze: 0.0,
                    texture: 0.0
                )
            ),
            AdjustmentPreset(
                name: "Dramatic",
                group: "Stil",
                adjustments: PhotoAdjustments(
                    exposure: -0.2,
                    contrast: 1.3,
                    temperature: 0.0,
                    tint: 0.0,
                    clarity: 0.4,
                    vibrance: 0.2,
                    highlights: -20,
                    shadows: 30,
                    whites: 0.0,
                    blacks: -10,
                    saturation: 0.0,
                    dehaze: 0.0,
                    texture: 0.0
                )
            ),
            AdjustmentPreset(
                name: "Soft",
                group: "Stil",
                adjustments: PhotoAdjustments(
                    exposure: 0.1,
                    contrast: 0.9,
                    temperature: 0.0,
                    tint: 0.0,
                    clarity: -0.1,
                    vibrance: 0.1,
                    highlights: 10,
                    shadows: 10,
                    whites: 0.0,
                    blacks: 0.0,
                    saturation: -0.1,
                    dehaze: 0.0,
                    texture: 0.0
                )
            )
        ]
    }
}

