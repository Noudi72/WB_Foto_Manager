//
//  SettingsView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI

struct SettingsView: View {
    @ObservedObject var store: PhotoStore
    @Environment(\.dismiss) var dismiss
    @State private var selectedTab: SettingsTab = .general
    
    enum SettingsTab: String, CaseIterable {
        case general = "Allgemein"
        case performance = "Performance"
        case export = "Export"
        case upload = "Upload"
        case appearance = "Darstellung"
    }
    
    var body: some View {
        NavigationSplitView {
            List(selection: $selectedTab) {
                ForEach(SettingsTab.allCases, id: \.self) { tab in
                    Label(tab.rawValue, systemImage: iconForTab(tab))
                        .tag(tab)
                }
            }
            .frame(minWidth: 200)
        } detail: {
            Group {
                switch selectedTab {
                case .general:
                    GeneralSettingsView(store: store)
                case .performance:
                    PerformanceSettingsView(store: store)
                case .export:
                    ExportSettingsView(store: store)
                case .upload:
                    UploadSettingsTabView(store: store)
                case .appearance:
                    AppearanceSettingsView(store: store)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
        .frame(width: 800, height: 600)
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Schließen") {
                    dismiss()
                }
            }
        }
    }
    
    private func iconForTab(_ tab: SettingsTab) -> String {
        switch tab {
        case .general: return "gear"
        case .performance: return "speedometer"
        case .export: return "square.and.arrow.up"
        case .upload: return "icloud.and.arrow.up"
        case .appearance: return "paintbrush"
        }
    }
}

struct GeneralSettingsView: View {
    @ObservedObject var store: PhotoStore
    @StateObject private var settings = AppSettings.shared
    
    var body: some View {
        Form {
            Section("Ordner") {
                Toggle("Automatisch letzten Ordner öffnen", isOn: $settings.autoOpenLastFolder)
                Toggle("Unterordner durchsuchen", isOn: $settings.searchSubfolders)
            }
            
            Section("Metadaten") {
                Toggle("Rating in XMP speichern", isOn: $settings.saveRatingInXMP)
                Toggle("IPTC-Metadaten automatisch laden", isOn: $settings.autoLoadIPTC)
            }
            
            Section("Sicherheit") {
                Toggle("Backup vor Überschreiben", isOn: $settings.backupBeforeOverwrite)
            }
        }
        .formStyle(.grouped)
        .padding()
    }
}

struct PerformanceSettingsView: View {
    @ObservedObject var store: PhotoStore
    @StateObject private var settings = AppSettings.shared
    
    var body: some View {
        Form {
            Section("Vorschau") {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Vorschau-Qualität: \(Int(settings.previewQuality * 100))%")
                        .font(.caption)
                    Slider(value: $settings.previewQuality, in: 0.5...1.0)
                }
                
                Picker("Max. Cache-Größe", selection: $settings.maxCacheSize) {
                    Text("500 Bilder").tag(500)
                    Text("1000 Bilder").tag(1000)
                    Text("2000 Bilder").tag(2000)
                    Text("Unbegrenzt").tag(0)
                }
            }
            
            Section("Rendering") {
                Toggle("Hardware-Beschleunigung", isOn: $settings.hardwareAcceleration)
                Toggle("Progressive Rendering", isOn: $settings.progressiveRendering)
            }
        }
        .formStyle(.grouped)
        .padding()
    }
}

struct ExportSettingsView: View {
    @ObservedObject var store: PhotoStore
    @StateObject private var settings = AppSettings.shared
    @State private var exportFormat: ExportFormat = .jpeg
    
    var body: some View {
        Form {
            Section("Standard-Einstellungen") {
                Picker("Standard-Format", selection: $exportFormat) {
                    Text("JPEG").tag(ExportFormat.jpeg)
                    Text("PNG").tag(ExportFormat.png)
                }
                .onChange(of: exportFormat) { _, newValue in
                    settings.defaultExportFormat = newValue == .jpeg ? "jpeg" : "png"
                }
                .onAppear {
                    exportFormat = settings.defaultExportFormat == "jpeg" ? .jpeg : .png
                }
                
                VStack(alignment: .leading, spacing: 8) {
                    Text("Standard-Qualität: \(Int(settings.defaultExportQuality * 100))%")
                        .font(.caption)
                    Slider(value: $settings.defaultExportQuality, in: 0.5...1.0)
                }
            }
            
            Section("Dateinamen") {
                TextField("Vorlage", text: $settings.filenameTemplate)
                    .help("Verfügbare Tokens: {originalname}, {preset}, {date}, {rating}")
            }
        }
        .formStyle(.grouped)
        .padding()
    }
}

struct UploadSettingsTabView: View {
    @ObservedObject var store: PhotoStore
    
    var body: some View {
        VStack {
            Text("Upload-Ziele verwalten")
                .font(.headline)
                .padding()
            
            Button("Upload-Ziele öffnen...") {
                // Öffne UploadSettingsView
            }
            .buttonStyle(.borderedProminent)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

struct AppearanceSettingsView: View {
    @ObservedObject var store: PhotoStore
    @StateObject private var settings = AppSettings.shared
    
    var body: some View {
        Form {
            Section("Design") {
                Picker("Theme", selection: $settings.theme) {
                    Text("Dunkel").tag("dark")
                    Text("Hell").tag("light")
                    Text("Automatisch").tag("auto")
                }
            }
            
            Section("Sidebar") {
                Toggle("Sidebar immer sichtbar", isOn: $settings.sidebarAlwaysVisible)
                Toggle("Icons in Sidebar", isOn: $settings.showSidebarIcons)
            }
        }
        .formStyle(.grouped)
        .padding()
    }
}

