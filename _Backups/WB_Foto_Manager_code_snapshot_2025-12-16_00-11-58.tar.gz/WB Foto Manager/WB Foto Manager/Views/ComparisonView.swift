//
//  ComparisonView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI

struct ComparisonView: View {
    let mainPhoto: PhotoItem
    let comparisonPhotos: [PhotoItem]
    @ObservedObject var store: PhotoStore
    
    var body: some View {
        HStack(spacing: 4) {
            // Hauptfoto (größer)
            VStack {
                PhotoComparisonCell(photo: mainPhoto, store: store, isMain: true)
            }
            .frame(maxWidth: .infinity)
            
            // Vergleichsfotos
            VStack(spacing: 4) {
                ForEach(comparisonPhotos) { photo in
                    PhotoComparisonCell(photo: photo, store: store, isMain: false)
                        .onTapGesture {
                            store.selectPhoto(photo)
                        }
                }
            }
            .frame(width: 200)
        }
        .background(Color.black)
    }
}

struct PhotoComparisonCell: View {
    let photo: PhotoItem
    @ObservedObject var store: PhotoStore
    let isMain: Bool
    @State private var thumbnail: NSImage?
    
    var body: some View {
        ZStack(alignment: .topTrailing) {
            if let thumb = thumbnail {
                Image(nsImage: thumb)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            } else {
                Rectangle()
                    .fill(Color.gray.opacity(0.2))
                    .overlay(ProgressView())
            }
            
            // Rating
            if photo.rating > 0 {
                HStack(spacing: 2) {
                    ForEach(0..<photo.rating, id: \.self) { _ in
                        Image(systemName: "star.fill")
                            .font(.caption2)
                            .foregroundColor(.yellow)
                    }
                }
                .padding(4)
                .background(Color.black.opacity(0.6))
                .cornerRadius(4)
            }
            
            // Selection Indicator
            if store.currentPhotoID == photo.id {
                Rectangle()
                    .stroke(Color.accentColor, lineWidth: isMain ? 4 : 2)
            }
        }
        .frame(maxHeight: isMain ? .infinity : 200)
        .onAppear {
            loadThumbnail()
        }
    }
    
    private func loadThumbnail() {
        Task(priority: .userInitiated) {
            let size = isMain ? CGSize(width: 1000, height: 1000) : CGSize(width: 200, height: 200)
            let thumb = await photo.loadThumbnail(size: size)
            await MainActor.run {
                self.thumbnail = thumb
            }
        }
    }
}

