//
//  FilmstripView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI

struct FilmstripView: View {
    let photos: [PhotoItem]
    @ObservedObject var store: PhotoStore
    
    var body: some View {
        ScrollViewReader { proxy in
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 4) {
                    ForEach(photos) { photo in
                        FilmstripPhotoCell(
                            photo: photo,
                            store: store,
                            isSelected: store.currentPhotoID == photo.id
                        )
                        .id(photo.id)
                        .onTapGesture {
                            store.selectPhoto(photo)
                        }
                    }
                }
                .padding(.horizontal, 4)
            }
            .background(DesignSystem.Colors.background4)
            .overlay(
                Rectangle()
                    .fill(DesignSystem.Colors.border)
                    .frame(height: 1),
                alignment: .top
            )
            .onChange(of: store.currentPhotoID) { newID in
                if let id = newID {
                    withAnimation {
                        proxy.scrollTo(id, anchor: .center)
                    }
                }
            }
        }
    }
}

struct FilmstripPhotoCell: View {
    @ObservedObject var photo: PhotoItem
    @ObservedObject var store: PhotoStore
    let isSelected: Bool
    
    var body: some View {
        ZStack {
            AsyncThumbnailView(photo: photo, previewSize: .thumbnail, interpolation: .medium)
                .cornerRadius(4)
            
            PhotoBadgesOverlay(photo: photo, style: .filmstrip)
            
            if isSelected {
                Rectangle()
                    .stroke(DesignSystem.Colors.accent, lineWidth: 3)
            }
        }
        .frame(width: 100, height: 100)
        .cornerRadius(4)
    }
}
