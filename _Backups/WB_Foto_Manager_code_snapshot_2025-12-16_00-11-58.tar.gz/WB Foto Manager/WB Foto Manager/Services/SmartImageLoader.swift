//
//  SmartImageLoader.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//  High-Performance Image Loading for Sports Photography
//

import Foundation
import AppKit
import ImageIO
import Combine

@MainActor
class SmartImageLoader: ObservableObject {
    @Published private(set) var isLoading = false
    static let shared = SmartImageLoader()
    
    private var cache = NSCache<NSString, NSImage>()
    /// In-flight loads müssen nach *URL + Zielgröße* unterschieden werden.
    /// Sonst blockiert ein Low-Res Load den High-Res Load (Progressive Loading liefert dann nur Low-Res zurück).
    private var loadingTasks: [String: Task<NSImage?, Never>] = [:]
    private var prefetchQueue: [URL] = []
    
    // Settings for sports photography - OPTIMIERT
    private let prefetchCount: Int = 5      // Nächste 5 Bilder prefetchen
    
    private init() {
        cache.countLimit = 50 // Max 50 High-Res Bilder im Cache (ca. 2GB)
        cache.totalCostLimit = 2_000_000_000 // 2GB
    }
    
    /// Lädt ein Bild mit höchster Priorität (für aktuelle Ansicht)
    func loadImage(url: URL, highRes: Bool = true) async -> NSImage? {
        let previewSize: PreviewSize = highRes ? .fullRes : .medium
        return await loadImage(url: url, previewSize: previewSize)
    }
    
    /// Lädt ein Bild für eine konkrete Preview-Größe (Thumbnail/Medium/FullRes).
    func loadImage(url: URL, previewSize: PreviewSize) async -> NSImage? {
        let cacheKey = cacheKey(for: url, previewSize: previewSize)
        let cacheKeyNSString = cacheKey as NSString
        
        // Check cache first
        if let cached = cache.object(forKey: cacheKeyNSString) {
            return cached
        }
        
        // Check if already loading
        if let existingTask = loadingTasks[cacheKey] {
            return await existingTask.value
        }
        
        // Start new loading task
        let task = Task(priority: .userInitiated) { () -> NSImage? in
            let size = previewSize.maxDimension
            // Wichtig: Für High-Res Preview niemals das eingebettete Thumbnail verwenden,
            // sonst wirkt die Vorschau "unscharf" bis ein Slider (CoreImage-Render) getriggert wird.
            let alwaysFromFullImage = (previewSize == .fullRes)
            let image = await self.loadFromDisk(url: url, maxSize: size, alwaysFromFullImage: alwaysFromFullImage)
            
            // Cache the result
            if let image = image {
                await MainActor.run {
                    self.cache.setObject(image, forKey: cacheKeyNSString, cost: Int(size * size * 4))
                }
            }
            
            return image
        }
        
        loadingTasks[cacheKey] = task
        let result = await task.value
        loadingTasks.removeValue(forKey: cacheKey)
        
        return result
    }
    
    /// Progressive Loading: Lädt erst Low-Res, dann High-Res
    func loadProgressive(url: URL) async -> (lowRes: NSImage?, highRes: NSImage?) {
        async let lowRes = loadImage(url: url, previewSize: .medium)
        async let highRes = loadImage(url: url, previewSize: .fullRes)
        
        return await (lowRes, highRes)
    }
    
    /// Prefetch nächste Bilder im Hintergrund
    func prefetchNext(urls: [URL]) {
        prefetchQueue = urls
        
        Task(priority: .background) {
            for url in urls.prefix(prefetchCount) {
                // Lade Medium-Res für schnelles Browsing in der Detailansicht
                _ = await loadImage(url: url, previewSize: .medium)
            }
        }
    }
    
    /// Clear Cache (z.B. beim Ordnerwechsel)
    func clearCache() {
        cache.removeAllObjects()
        loadingTasks.values.forEach { $0.cancel() }
        loadingTasks.removeAll()
    }
    
    // MARK: - Private Helpers
    
    private func cacheKey(for url: URL, previewSize: PreviewSize) -> String {
        "\(url.path)-\(Int(previewSize.maxDimension))"
    }
    
    private func loadFromDisk(url: URL, maxSize: CGFloat, alwaysFromFullImage: Bool) async -> NSImage? {
        return await Task.detached(priority: .userInitiated) {
            // Check file exists
            guard FileManager.default.fileExists(atPath: url.path) else {
                print("⚠️ Datei nicht gefunden: \(url.path)")
                return nil
            }
            
            // Create image source
            guard let imageSource = CGImageSourceCreateWithURL(url as CFURL, nil) else {
                print("⚠️ Konnte ImageSource nicht erstellen: \(url.path)")
                return nil
            }
            
            // Optimierte Optionen für beste Performance/Qualität
            // - Low-Res: darf Embedded Thumbnail nutzen (schnell)
            // - High-Res: IMMER aus Full Image generieren (maximale Schärfe)
            var options: [CFString: Any] = [
                kCGImageSourceThumbnailMaxPixelSize: maxSize,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceShouldCache: true,
                kCGImageSourceShouldAllowFloat: true
            ]
            
            if alwaysFromFullImage {
                options[kCGImageSourceCreateThumbnailFromImageAlways] = true
                options[kCGImageSourceShouldCacheImmediately] = true
            } else {
                options[kCGImageSourceCreateThumbnailFromImageIfAbsent] = true
            }
            
            guard let cgImage = CGImageSourceCreateThumbnailAtIndex(imageSource, 0, options as CFDictionary) else {
                print("⚠️ Konnte Thumbnail nicht erstellen: \(url.path)")
                return nil
            }
            
            let image = NSImage(cgImage: cgImage, size: CGSize(width: cgImage.width, height: cgImage.height))
            return image
        }.value
    }
}

