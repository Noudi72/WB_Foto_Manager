//
//  AITaggingService.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 15.12.2025.
//

import Foundation
import CoreImage
import Vision
import AppKit

/// AI-basierter Service für automatische Keyword-Generierung via Vision Framework
final class AITaggingService {
    static let shared = AITaggingService()
    
    private init() {}
    
    /// Analysiert ein Bild und generiert automatische Keywords
    func generateKeywords(for photo: PhotoItem) async -> [String] {
        guard let image = photo.loadFullImage() else { return [] }
        
        return await Task.detached(priority: .userInitiated) { [weak self] in
            guard let self else { return [] }
            return self.generateKeywords(from: image)
        }.value
    }
    
    /// Analysiert ein CIImage und gibt relevante Keywords zurück
    private func generateKeywords(from image: CIImage) -> [String] {
        let extent = image.extent
        guard extent.width > 0, extent.height > 0 else { return [] }
        
        // Convert CIImage → CGImage for Vision
        let context = CIContext(options: [.useSoftwareRenderer: false])
        guard let cgImage = context.createCGImage(image, from: extent) else {
            return []
        }
        
        var keywords: Set<String> = []
        let semaphore = DispatchSemaphore(value: 0)
        
        // 1) Scene Classification (Hauptquelle für Keywords)
        let classifyRequest = VNClassifyImageRequest { request, error in
            defer { semaphore.signal() }
            guard error == nil, let results = request.results as? [VNClassificationObservation] else { return }
            
            // Top-Klassifikationen mit hoher Confidence als Keywords verwenden
            for observation in results.prefix(10) {
                let confidence = observation.confidence
                let identifier = observation.identifier
                
                // Nur Keywords mit ausreichender Confidence (mindestens 0.3)
                if confidence >= 0.3 {
                    // Identifier kann mehrere Wörter enthalten, z.B. "outdoor scene, nature"
                    let words = identifier.components(separatedBy: CharacterSet(charactersIn: ", "))
                        .map { $0.trimmingCharacters(in: .whitespaces) }
                        .filter { !$0.isEmpty && $0.count > 2 }
                    
                    for word in words {
                        // Übersetze englische Begriffe ins Deutsche (einfache Mapping)
                        let germanWord = self.translateToGerman(word)
                        keywords.insert(germanWord)
                    }
                }
            }
        }
        
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        try? handler.perform([classifyRequest])
        semaphore.wait()
        
        // 2) Text Detection (falls Text im Bild vorhanden)
        let textRequest = VNDetectTextRectanglesRequest { request, error in
            defer { semaphore.signal() }
            guard error == nil, let results = request.results as? [VNTextObservation] else { return }
            
            // Wenn Text erkannt wird, füge "Text" als Keyword hinzu
            if !results.isEmpty {
                keywords.insert("Text")
            }
        }
        
        textRequest.reportCharacterBoxes = false // Nur Text-Regionen, nicht einzelne Zeichen
        try? handler.perform([textRequest])
        semaphore.wait()
        
        // 3) Face Detection (falls Gesichter vorhanden)
        let faceRequest = VNDetectFaceRectanglesRequest { request, error in
            defer { semaphore.signal() }
            guard error == nil, let results = request.results as? [VNFaceObservation] else { return }
            
            if !results.isEmpty {
                keywords.insert("Portrait")
                keywords.insert("Person")
                if results.count > 1 {
                    keywords.insert("Gruppe")
                }
            }
        }
        
        try? handler.perform([faceRequest])
        semaphore.wait()
        
        // Sortiere Keywords alphabetisch und gib als Array zurück
        return Array(keywords).sorted()
    }
    
    /// Einfache Übersetzung englischer Vision-Keywords ins Deutsche
    private func translateToGerman(_ english: String) -> String {
        let translations: [String: String] = [
            "outdoor": "Draußen",
            "indoor": "Drinnen",
            "nature": "Natur",
            "landscape": "Landschaft",
            "mountain": "Berg",
            "beach": "Strand",
            "ocean": "Ozean",
            "water": "Wasser",
            "sky": "Himmel",
            "cloud": "Wolke",
            "sunset": "Sonnenuntergang",
            "sunrise": "Sonnenaufgang",
            "night": "Nacht",
            "day": "Tag",
            "building": "Gebäude",
            "architecture": "Architektur",
            "city": "Stadt",
            "street": "Straße",
            "vehicle": "Fahrzeug",
            "car": "Auto",
            "food": "Essen",
            "meal": "Mahlzeit",
            "restaurant": "Restaurant",
            "animal": "Tier",
            "dog": "Hund",
            "cat": "Katze",
            "bird": "Vogel",
            "flower": "Blume",
            "tree": "Baum",
            "forest": "Wald",
            "grass": "Gras",
            "snow": "Schnee",
            "winter": "Winter",
            "summer": "Sommer",
            "spring": "Frühling",
            "autumn": "Herbst",
            "portrait": "Portrait",
            "person": "Person",
            "people": "Personen",
            "group": "Gruppe",
            "sport": "Sport",
            "music": "Musik",
            "art": "Kunst",
            "text": "Text",
            "document": "Dokument"
        ]
        
        let lowercased = english.lowercased()
        
        // Direkte Übersetzung
        if let translation = translations[lowercased] {
            return translation
        }
        
        // Fallback: Capitalize first letter
        return english.prefix(1).uppercased() + english.dropFirst().lowercased()
    }
    
    /// Batch-Tagging für mehrere Fotos
    func generateKeywordsBatch(for photos: [PhotoItem], progress: @escaping (Int, Int) -> Void) async -> [UUID: [String]] {
        var results: [UUID: [String]] = [:]
        let total = photos.count
        
        for (index, photo) in photos.enumerated() {
            let keywords = await generateKeywords(for: photo)
            results[photo.id] = keywords
            progress(index + 1, total)
        }
        
        return results
    }
}

