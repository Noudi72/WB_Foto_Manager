//
//  EditCatalogService.swift
//  WB Foto Manager
//
//  Non-destructive edit persistence ("catalog") per photo.
//  Stores adjustments/crop/rotation without touching the original file.
//

import Foundation
import CoreGraphics

actor EditCatalogService {
    static let shared = EditCatalogService()

    struct CodableRect: Codable, Hashable, Sendable {
        var x: Double
        var y: Double
        var width: Double
        var height: Double

        init(_ rect: CGRect) {
            self.x = rect.origin.x
            self.y = rect.origin.y
            self.width = rect.size.width
            self.height = rect.size.height
        }

        var cgRect: CGRect {
            CGRect(x: x, y: y, width: width, height: height)
        }
    }

    struct EditEntry: Codable, Hashable, Sendable {
        var version: Int = 1
        var updatedAt: Date = Date()

        var adjustments: PhotoAdjustments
        var cropRect: CodableRect?
        var rotation: Double
        
        // Virtual Copy Metadata
        var isMaster: Bool = true
        var masterID: String? = nil // UUID string of master
        var virtualCopyNumber: Int = 0

        init(adjustments: PhotoAdjustments, cropRect: CGRect?, rotation: Double, isMaster: Bool = true, masterID: UUID? = nil, virtualCopyNumber: Int = 0) {
            self.adjustments = adjustments
            self.cropRect = cropRect.map { CodableRect($0) }
            self.rotation = rotation
            self.isMaster = isMaster
            self.masterID = masterID?.uuidString
            self.virtualCopyNumber = virtualCopyNumber
            self.updatedAt = Date()
        }

        var isDefault: Bool {
            let defaults = PhotoAdjustments()
            let cropIsDefault = (cropRect == nil)
            let rotationIsDefault = abs(rotation) < 0.0001
            return adjustments == defaults && cropIsDefault && rotationIsDefault
        }
    }

    private struct PersistedCatalog: Codable, Sendable {
        var version: Int = 1
        var updatedAt: Date = Date()
        var edits: [String: EditEntry] = [:]
    }

    private var editsByPath: [String: EditEntry] = [:]
    private var loadTask: Task<Void, Never>?
    private var saveTask: Task<Void, Never>?

    private init() {
        // lazy load on first access
    }

    func snapshot() async -> [String: EditEntry] {
        await ensureLoaded()
        return editsByPath
    }

    func loadEdit(for url: URL, photoID: UUID? = nil) async -> EditEntry? {
        await ensureLoaded()
        return editsByPath[key(for: url, photoID: photoID)]
    }

    func upsertEdit(_ entry: EditEntry, for url: URL, photoID: UUID? = nil) async {
        await ensureLoaded()
        let k = key(for: url, photoID: photoID)
        if entry.isDefault {
            editsByPath.removeValue(forKey: k)
        } else {
            var copy = entry
            copy.updatedAt = Date()
            editsByPath[k] = copy
        }
        scheduleSave()
    }

    func removeEdit(for url: URL, photoID: UUID? = nil) async {
        await ensureLoaded()
        editsByPath.removeValue(forKey: key(for: url, photoID: photoID))
        scheduleSave()
    }

    // MARK: - Private

    private func key(for url: URL, photoID: UUID? = nil) -> String {
        let basePath = url.standardizedFileURL.path
        if let id = photoID {
            return "\(basePath)#\(id.uuidString)"
        }
        return basePath
    }

    private func ensureLoaded() async {
        if loadTask != nil { return }
        loadTask = Task { [weak self] in
            guard let self else { return }
            await self.loadFromDisk()
        }
        await loadTask?.value
    }

    private func scheduleSave() {
        saveTask?.cancel()
        saveTask = Task { [weak self] in
            guard let self else { return }
            try? await Task.sleep(nanoseconds: 450_000_000) // 450ms debounce
            await self.saveToDisk()
        }
    }

    private func catalogURL() -> URL? {
        guard let appSupport = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first else {
            return nil
        }
        let folder = appSupport.appendingPathComponent("WB Foto Manager", isDirectory: true)
        return folder.appendingPathComponent("edit-catalog.json", isDirectory: false)
    }

    private func loadFromDisk() async {
        guard let url = catalogURL() else { return }
        do {
            let data = try Data(contentsOf: url)
            let decoded = try JSONDecoder().decode(PersistedCatalog.self, from: data)
            editsByPath = decoded.edits
        } catch {
            // No file yet or decode failed – start fresh
            editsByPath = [:]
        }
    }

    private func saveToDisk() async {
        guard let url = catalogURL() else { return }
        do {
            let folder = url.deletingLastPathComponent()
            try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: true)

            var payload = PersistedCatalog()
            payload.updatedAt = Date()
            payload.edits = editsByPath

            let enc = JSONEncoder()
            enc.outputFormatting = [] // keep file small
            let data = try enc.encode(payload)
            try data.write(to: url, options: [.atomic])
        } catch {
            // Best effort; ignore (no UI spam)
            // print("EditCatalog save failed: \(error)")
        }
    }
}


