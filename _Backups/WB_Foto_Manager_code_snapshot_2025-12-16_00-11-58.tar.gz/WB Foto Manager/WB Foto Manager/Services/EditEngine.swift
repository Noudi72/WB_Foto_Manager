//
//  EditEngine.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import CoreImage
import AppKit

/// Bildbearbeitungs-Engine basierend auf CoreImage
@MainActor
class EditEngine {
    static let shared = EditEngine()
    
    private let context: CIContext
    
    private init() {
        // Optimiert für Performance auf M3/M4 Pro
        let options: [CIContextOption: Any] = [
            .useSoftwareRenderer: false,
            .cacheIntermediates: true,
            .highQualityDownsample: true
        ]
        self.context = CIContext(options: options)
    }
    
    /// Wendet Adjustments auf ein Bild an
    func applyAdjustments(to image: CIImage, adjustments: PhotoAdjustments) -> CIImage? {
        var result = image
        
        // Exposure
        if adjustments.exposure != 0.0 {
            result = result.applyingFilter("CIExposureAdjust", parameters: [
                kCIInputEVKey: adjustments.exposure
            ])
        }
        
        // Contrast
        if adjustments.contrast != 1.0 {
            result = result.applyingFilter("CIColorControls", parameters: [
                kCIInputContrastKey: adjustments.contrast
            ])
        }
        
        // Temperature & Tint
        if adjustments.temperature != 0.0 || adjustments.tint != 0.0 {
            // Temperature: -3000 bis +3000 Kelvin
            // Neutral temperature ist 6500K
            let neutralTemp = 6500.0 + adjustments.temperature
            let tintValue = adjustments.tint / 100.0
            
            result = result.applyingFilter("CITemperatureAndTint", parameters: [
                "inputNeutral": CIVector(x: neutralTemp, y: tintValue),
                "inputTargetNeutral": CIVector(x: 6500, y: 0)
            ])
        }
        
        // Vibrance
        if adjustments.vibrance != 0.0 {
            result = result.applyingFilter("CIVibrance", parameters: [
                "inputAmount": adjustments.vibrance
            ])
        }
        
        // Saturation
        if adjustments.saturation != 0.0 {
            let saturation = 1.0 + (adjustments.saturation / 100.0)
            result = result.applyingFilter("CIColorControls", parameters: [
                kCIInputSaturationKey: saturation
            ])
        }
        
        // Highlights & Shadows
        if adjustments.highlights != 0.0 || adjustments.shadows != 0.0 {
            let highlights = adjustments.highlights / 100.0
            let shadows = adjustments.shadows / 100.0
            
            result = result.applyingFilter("CIHighlightShadowAdjust", parameters: [
                "inputHighlightAmount": highlights,
                "inputShadowAmount": shadows
            ])
        }
        
        // Whites & Blacks
        if adjustments.whites != 0.0 || adjustments.blacks != 0.0 {
            let whites = adjustments.whites / 100.0
            let blacks = adjustments.blacks / 100.0
            
            result = result.applyingFilter("CIColorControls", parameters: [
                "inputBrightness": (whites - blacks) * 0.5
            ])
        }
        
        // Clarity (Unsharp Mask)
        if adjustments.clarity != 0.0 {
            result = result.applyingFilter("CIUnsharpMask", parameters: [
                kCIInputRadiusKey: 1.0,
                kCIInputIntensityKey: adjustments.clarity
            ])
        }
        
        // Texture (Similar to Clarity but different)
        if adjustments.texture != 0.0 {
            result = result.applyingFilter("CIUnsharpMask", parameters: [
                kCIInputRadiusKey: 0.5,
                kCIInputIntensityKey: adjustments.texture / 100.0
            ])
        }
        
        // Dehaze (verwendet CIColorControls mit Saturation und Contrast)
        if adjustments.dehaze != 0.0 {
            let amount = adjustments.dehaze / 100.0
            result = result.applyingFilter("CIColorControls", parameters: [
                kCIInputSaturationKey: 1.0 + amount * 0.3,
                kCIInputContrastKey: 1.0 + amount * 0.2
            ])
        }
        
        return result
    }
    
    /// Wendet Crop und Rotation an
    func applyCropAndRotation(to image: CIImage, cropRect: CGRect?, rotation: Double) -> CIImage {
        var result = image
        
        // Rotation
        if rotation != 0.0 {
            let transform = CGAffineTransform(rotationAngle: rotation * .pi / 180.0)
            result = result.transformed(by: transform)
        }
        
        // Crop
        if let crop = cropRect {
            result = result.cropped(to: crop)
        }
        
        return result
    }
    
    /// Rendert ein CIImage zu NSImage (optimiert für Display)
    func render(_ image: CIImage, size: CGSize? = nil) -> NSImage? {
        let extent = image.extent
        // `size` wird als *Maximalgröße* interpretiert (nicht als fixe Zielgröße),
        // sonst werden kleinere Bilder auf ein Quadrat "gequetscht".
        var targetSize = extent.size
        
        // Optimiere Größe für Display (nicht größer als nötig)
        if let maxSize = size {
            let aspectRatio = extent.width / extent.height
            if extent.width > maxSize.width || extent.height > maxSize.height {
                if extent.width > extent.height {
                    targetSize = CGSize(width: maxSize.width, height: maxSize.width / aspectRatio)
                } else {
                    targetSize = CGSize(width: maxSize.height * aspectRatio, height: maxSize.height)
                }
            }
        }
        
        // Verwende optimierte Render-Optionen für bessere Performance
        let colorSpace = CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()
        
        guard let cgImage = context.createCGImage(image, from: extent, format: .RGBA8, colorSpace: colorSpace, deferred: false) else {
            return nil
        }
        
        return NSImage(cgImage: cgImage, size: targetSize)
    }
    
    /// Rendert ein CIImage zu JPEG/PNG Data
    func renderToData(_ image: CIImage, format: ExportFormat, quality: Double, maxDimension: Int? = nil) -> Data? {
        var workingImage = image
        
        // Resize wenn nötig
        if let maxDim = maxDimension {
            let extent = workingImage.extent
            let currentMax = max(extent.width, extent.height)
            if currentMax > CGFloat(maxDim) {
                let scale = CGFloat(maxDim) / currentMax
                let newSize = CGSize(width: extent.width * scale, height: extent.height * scale)
                workingImage = workingImage.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
            }
        }
        
        let colorSpace = CGColorSpace(name: CGColorSpace.sRGB) ?? CGColorSpaceCreateDeviceRGB()
        
        switch format {
        case .jpeg:
            let options: [CIImageRepresentationOption: Any] = [
                kCGImageDestinationLossyCompressionQuality as CIImageRepresentationOption: quality
            ]
            return context.jpegRepresentation(of: workingImage, colorSpace: colorSpace, options: options)
        case .png:
            return context.pngRepresentation(of: workingImage, format: .RGBA8, colorSpace: colorSpace, options: [:])
        }
    }
    
    /// Wendet Wasserzeichen an
    func applyWatermark(to image: CIImage, settings: WatermarkSettings) -> CIImage? {
        guard let watermark = createWatermarkImage(settings: settings, imageSize: image.extent.size) else {
            return image
        }
        
        // Wichtig: NSImage.size ist in "Points" und kann (Retina) von der effektiven Pixelgröße abweichen.
        // Für korrektes Clamping/Positioning verwenden wir ausschliesslich die CIImage-/CGImage-Extent.
        guard let cgImage = watermark.cgImage(forProposedRect: nil, context: nil, hints: nil) else {
            return image
        }
        
        let imageExtent = image.extent
        let imageSize = imageExtent.size
        
        var finalWatermark = CIImage(cgImage: cgImage)
        var watermarkExtent = finalWatermark.extent
        
        // Falls das Wasserzeichen (Pixel) grösser als das Bild ist, skaliere es proportional herunter.
        if watermarkExtent.width > 0, watermarkExtent.height > 0 {
            let scaleX = imageSize.width / watermarkExtent.width
            let scaleY = imageSize.height / watermarkExtent.height
            let scale = min(1.0, min(scaleX, scaleY))
            if scale < 1.0 {
                finalWatermark = finalWatermark.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
                watermarkExtent = finalWatermark.extent
            }
        }
        
        let watermarkSize = watermarkExtent.size
        let position0 = calculateWatermarkPosition(imageSize: imageSize, watermarkSize: watermarkSize, position: settings.position)
        
        // Clamp in "0-basierten" Bildkoordinaten (ohne Origin)
        let clampedX0 = max(0, min(position0.x, max(0, imageSize.width - watermarkSize.width)))
        let clampedY0 = max(0, min(position0.y, max(0, imageSize.height - watermarkSize.height)))
        
        // Umrechnung in echte CI-Koordinaten via image.extent Origin
        let targetX = imageExtent.minX + clampedX0
        let targetY = imageExtent.minY + clampedY0
        
        // Transformiere so, dass die Watermark-Extent am Ziel sitzt (robust auch bei non-zero Extent-Origin)
        let transform = CGAffineTransform(
            translationX: targetX - watermarkExtent.minX,
            y: targetY - watermarkExtent.minY
        )
        let transformedWatermark = finalWatermark.transformed(by: transform)
        
        // Kritisch: verhindere, dass Compositing den Output-Extent vergrössert (Watermark darf nie "ausserhalb" landen).
        let clippedWatermark = transformedWatermark.cropped(to: imageExtent)
        let composited = clippedWatermark.composited(over: image).cropped(to: imageExtent)
        
        return composited
    }
    
    private func createWatermarkImage(settings: WatermarkSettings, imageSize: CGSize) -> NSImage? {
        // Maximaler "Zielrahmen" (nur als Obergrenze). Das finale Watermark-Image wird
        // absichtlich so klein wie möglich (tight bounds) erzeugt, damit sich die sichtbare
        // Position beim Skalieren nicht durch transparentes Padding verschiebt.
        let maxBox = CGSize(
            width: imageSize.width * settings.size,
            height: imageSize.height * settings.size
        )
        
        let padding: CGFloat = 6
        let spacing: CGFloat = 8
        
        // --- Logo laden (optional, security-scoped) ---
        var logoImage: NSImage?
        if (settings.type == .logo || settings.type == .both), let logoURL = settings.logoURL {
            var resolvedURL = logoURL
            var didStartAccessing = false
            
            if let bookmarkData = settings.logoBookmarkData {
                var isStale = false
                if let bookmarkedURL = try? URL(
                    resolvingBookmarkData: bookmarkData,
                    options: [.withSecurityScope],
                    relativeTo: nil,
                    bookmarkDataIsStale: &isStale
                ) {
                    resolvedURL = bookmarkedURL
                    didStartAccessing = bookmarkedURL.startAccessingSecurityScopedResource()
                }
            }
            
            if !didStartAccessing {
                didStartAccessing = resolvedURL.startAccessingSecurityScopedResource()
            }
            defer {
                if didStartAccessing {
                    resolvedURL.stopAccessingSecurityScopedResource()
                }
            }
            
            logoImage = NSImage(contentsOf: resolvedURL)
        }
        
        // --- Text vorbereiten (optional) ---
        var attributedText: NSAttributedString?
        var textContentSize: CGSize = .zero
        if (settings.type == .text || settings.type == .both),
           let text = settings.text?.trimmingCharacters(in: .whitespacesAndNewlines),
           !text.isEmpty {
            let base = min(imageSize.width, imageSize.height)
            let fontSize = (settings.textSize ?? settings.size * 0.3) * base
            let font = NSFont.systemFont(ofSize: fontSize)
            let attributes: [NSAttributedString.Key: Any] = [
                .font: font,
                .foregroundColor: NSColor.white.withAlphaComponent(settings.opacity),
                .strokeColor: NSColor.black.withAlphaComponent(settings.opacity * 0.5),
                .strokeWidth: -2.0
            ]
            let attr = NSAttributedString(string: text, attributes: attributes)
            attributedText = attr
            textContentSize = attr.size()
        }
        
        let hasLogo = (logoImage != nil)
        let hasText = (attributedText != nil)
        if !hasLogo && !hasText { return nil }
        if settings.type == .logo && !hasLogo { return nil }
        if settings.type == .text && !hasText { return nil }
        
        // Logo target size (tight, ohne Padding)
        var logoTargetSize: CGSize = .zero
        if let logoImage {
            let s = logoImage.size
            if s.width > 0, s.height > 0 {
                let scale = min(maxBox.width / s.width, maxBox.height / s.height)
                let w = max(1, s.width * scale)
                let h = max(1, s.height * scale)
                logoTargetSize = CGSize(width: w, height: h)
            }
        }
        
        // Text box size (mit Padding)
        let textBoxSize = CGSize(
            width: max(1, textContentSize.width + padding * 2),
            height: max(1, textContentSize.height + padding * 2)
        )
        
        // Canvas (tight bounds)
        let canvasSize: CGSize
        if hasLogo && !hasText {
            canvasSize = logoTargetSize
        } else if hasText && !hasLogo {
            canvasSize = textBoxSize
        } else {
            // both: Logo + Text nebeneinander (kompakt)
            canvasSize = CGSize(
                width: max(1, logoTargetSize.width + spacing + textBoxSize.width),
                height: max(1, max(logoTargetSize.height, textBoxSize.height))
            )
        }
        
        let image = NSImage(size: canvasSize)
        image.lockFocus()
        NSGraphicsContext.current?.imageInterpolation = .high
        
        // Draw Logo
        if let logoImage, logoTargetSize.width > 0, logoTargetSize.height > 0 {
            let rect: NSRect
            if hasLogo && !hasText {
                rect = NSRect(x: 0, y: 0, width: canvasSize.width, height: canvasSize.height)
            } else {
                rect = NSRect(
                    x: 0,
                    y: (canvasSize.height - logoTargetSize.height) / 2,
                    width: logoTargetSize.width,
                    height: logoTargetSize.height
                )
            }
            logoImage.draw(
                in: rect,
                from: NSRect(origin: .zero, size: logoImage.size),
                operation: .sourceOver,
                fraction: settings.opacity
            )
        }
        
        // Draw Text
        if let attributedText {
            let rect: NSRect
            if hasText && !hasLogo {
                rect = NSRect(
                    x: padding,
                    y: padding,
                    width: max(1, canvasSize.width - padding * 2),
                    height: max(1, canvasSize.height - padding * 2)
                )
            } else {
                let textX = logoTargetSize.width + spacing + padding
                rect = NSRect(
                    x: textX,
                    y: (canvasSize.height - textContentSize.height) / 2,
                    width: max(1, textContentSize.width),
                    height: max(1, textContentSize.height)
                )
            }
            attributedText.draw(in: rect)
        }
        
        image.unlockFocus()
        return image
    }
    
    private func calculateWatermarkPosition(imageSize: CGSize, watermarkSize: CGSize, position: WatermarkPosition) -> CGPoint {
        // CoreImage verwendet ein Koordinatensystem mit (0,0) unten links
        // margin in Prozent der Bildgröße für konsistente Positionierung
        let marginPercent: CGFloat = 0.02 // 2% des Bildes
        let margin = min(imageSize.width, imageSize.height) * marginPercent
        
        switch position {
        case .topLeft:
            // Oben links: x = margin, y = oben (height - watermark height - margin)
            return CGPoint(x: margin, y: imageSize.height - watermarkSize.height - margin)
        case .topCenter:
            return CGPoint(x: (imageSize.width - watermarkSize.width) / 2, y: imageSize.height - watermarkSize.height - margin)
        case .topRight:
            return CGPoint(x: imageSize.width - watermarkSize.width - margin, y: imageSize.height - watermarkSize.height - margin)
        case .centerLeft:
            return CGPoint(x: margin, y: (imageSize.height - watermarkSize.height) / 2)
        case .center:
            return CGPoint(x: (imageSize.width - watermarkSize.width) / 2, y: (imageSize.height - watermarkSize.height) / 2)
        case .centerRight:
            return CGPoint(x: imageSize.width - watermarkSize.width - margin, y: (imageSize.height - watermarkSize.height) / 2)
        case .bottomLeft:
            // Unten links: x = margin, y = margin (unten im CI-Koordinatensystem)
            return CGPoint(x: margin, y: margin)
        case .bottomCenter:
            return CGPoint(x: (imageSize.width - watermarkSize.width) / 2, y: margin)
        case .bottomRight:
            // Unten rechts: x = rechts - watermark width - margin, y = margin
            return CGPoint(x: imageSize.width - watermarkSize.width - margin, y: margin)
        }
    }
}

