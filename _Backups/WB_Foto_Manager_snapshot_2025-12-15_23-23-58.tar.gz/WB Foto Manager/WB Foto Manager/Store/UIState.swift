//
//  UIState.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import Combine
import SwiftUI

class UIState: ObservableObject {
    @Published var viewMode: ViewMode = .detail
    @Published var zoomLevel: Double = 1.0
    @Published var showBeforeAfter: Bool = false

    // Multi-selection (für Sync-Workflows wie Lightroom)
    @Published var selectionMode: Bool = false
    
    // Watermark Vorschau (nur Anzeige, nicht Export)
    @Published var watermarkPreviewEnabled: Bool = false
    @Published var watermarkPreviewPresetID: UUID? = nil
    
    // Sheets / Modals (zentral, damit Menüs + Topbar zuverlässig funktionieren)
    @Published var activeSheet: SheetRoute? = nil
    
    // Filters
    @Published var ratingFilter: Int? = nil {
        didSet {
            // This is a good place to notify the PhotoStore to re-filter
        }
    }
    @Published var pickStatusFilter: PickStatus? = nil {
        didSet {
            // Trigger re-filtering when pick status filter changes
        }
    }
    @Published var showQuickCollectionOnly: Bool = false {
        didSet {
            // Trigger re-filtering when quick collection filter changes
        }
    }
    @Published var colorTagFilter: ColorTag? = nil {
        didSet {
            // Trigger re-filtering when color tag filter changes
        }
    }
    
    // Sidebar visibility
    @Published var showLeftSidebar: Bool = true
    @Published var showRightSidebar: Bool = true
}

// MARK: - Modal Routing

extension UIState {
    enum SheetRoute: Identifiable {
        case settings
        case export
        case batchExport
        case uploadSettings
        case exportQueueSettings
        case backupRestore
        case syncAdjustments
        case surveyView
        case smartCollections
        
        var id: String {
            switch self {
            case .settings: return "settings"
            case .export: return "export"
            case .batchExport: return "batchExport"
            case .uploadSettings: return "uploadSettings"
            case .exportQueueSettings: return "exportQueueSettings"
            case .backupRestore: return "backupRestore"
            case .syncAdjustments: return "syncAdjustments"
            case .surveyView: return "surveyView"
            case .smartCollections: return "smartCollections"
            }
        }
    }
}

// We can move the ViewMode enum here as it's purely UI-related.
enum ViewMode {
    case detail
    case grid
}
