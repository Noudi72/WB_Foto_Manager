//
//  DesignSystem.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//  Lightroom Classic inspired design system
//

import SwiftUI

struct DesignSystem {
    // MARK: - Colors (Lightroom Classic Style)
    struct Colors {
        // Background Colors - Dark Gray Theme wie Lightroom
        static let background = Color(red: 0.18, green: 0.18, blue: 0.18) // #2E2E2E
        static let background2 = Color(red: 0.22, green: 0.22, blue: 0.22) // #383838 - Top Bar
        static let background3 = Color(red: 0.15, green: 0.15, blue: 0.15) // #262626 - Sidebars
        static let background4 = Color(red: 0.10, green: 0.10, blue: 0.10) // #1A1A1A - Darker areas
        
        // Text Colors
        static let text = Color(white: 0.95) // Almost white
        static let text2 = Color(white: 0.85) // Lighter gray
        static let text3 = Color(white: 0.70) // Medium gray
        static let text4 = Color(white: 0.60) // Darker gray
        
        // Accent Color - Lightroom Blue
        static let accent = Color(red: 0.20, green: 0.50, blue: 0.85) // #3379D9 - Lightroom Blue
        static let accentHover = Color(red: 0.25, green: 0.55, blue: 0.90) // Lighter blue on hover
        
        // Borders
        static let border = Color(white: 0.22) // Subtle borders
        static let border2 = Color(white: 0.10) // Darker borders
        
        // Star/Rating Color
        static let star = Color(red: 1.0, green: 0.80, blue: 0.0) // Gold
        
        // Selection
        static let selection = Color(red: 0.20, green: 0.50, blue: 0.85).opacity(0.3)
        
        // Hover
        static let hover = Color(white: 0.25)
    }
    
    // MARK: - Typography
    struct Fonts {
        static func regular(size: CGFloat) -> Font {
            .system(size: size, weight: .regular, design: .default)
        }
        
        static func medium(size: CGFloat) -> Font {
            .system(size: size, weight: .medium, design: .default)
        }
        
        static func semibold(size: CGFloat) -> Font {
            .system(size: size, weight: .semibold, design: .default)
        }
        
        static func bold(size: CGFloat) -> Font {
            .system(size: size, weight: .bold, design: .default)
        }
    }
    
    // MARK: - Spacing
    struct Spacing {
        static let tiny: CGFloat = 4
        static let small: CGFloat = 8
        static let medium: CGFloat = 12
        static let large: CGFloat = 16
        static let xlarge: CGFloat = 24
    }
    
    // MARK: - Corner Radius
    struct CornerRadius {
        static let small: CGFloat = 4
        static let medium: CGFloat = 6
        static let large: CGFloat = 8
    }
}

// MARK: - View Extensions
extension View {
    func lightroomBorder(color: Color = DesignSystem.Colors.border, width: CGFloat = 1) -> some View {
        self.overlay(
            Rectangle()
                .stroke(color, lineWidth: width)
        )
    }

    /// Erzwingt ein konsistentes, gut lesbares Dark-Theme für Sidebar-Bereiche
    /// (wichtig für systemnahe Controls wie Picker/Segmented/Toggle, wenn die App im Light-Mode läuft).
    func lightroomSidebarTheme() -> some View {
        self
            .environment(\.colorScheme, .dark)
            .tint(DesignSystem.Colors.accent)
            .foregroundStyle(DesignSystem.Colors.text)
            .controlSize(.small)
    }
}

// MARK: - Button Styles

/// Sekundärer Button im Lightroom-Look: dunkler Hintergrund + Border + weiße Schrift (keine "blaue" Accent-Schrift).
struct LightroomSecondaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(DesignSystem.Fonts.medium(size: 12))
            .foregroundColor(DesignSystem.Colors.text)
            .padding(.horizontal, DesignSystem.Spacing.medium)
            .padding(.vertical, 8)
            .background(DesignSystem.Colors.background4)
            .overlay(
                RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
            )
            .cornerRadius(DesignSystem.CornerRadius.small)
            .opacity(configuration.isPressed ? 0.85 : 1.0)
    }
}

/// Kompakte Variante (für kleine Inline-Buttons wie Rotation +/-90°).
struct LightroomSmallButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(DesignSystem.Fonts.medium(size: 11))
            .foregroundColor(DesignSystem.Colors.text)
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(DesignSystem.Colors.background4)
            .overlay(
                RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
            )
            .cornerRadius(DesignSystem.CornerRadius.small)
            .opacity(configuration.isPressed ? 0.85 : 1.0)
    }
}
