//
//  PresetsPanel.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit
import UniformTypeIdentifiers
import Combine

struct PresetsPanel: View {
    @ObservedObject var store: PhotoStore
    @State private var expandedGroups: Set<String> = []
    @State private var showPresetEditor = false
    @State private var editingPreset: AdjustmentPreset?
    @State private var hoveredPresetID: UUID?
    @State private var temporaryAdjustments: PhotoAdjustments?
    @State private var hoverRestoreTask: Task<Void, Never>?
    @State private var showNewGroupSheet = false
    @State private var newGroupName: String = ""
    @State private var selectedPresetIDs: Set<UUID> = []
    @State private var multiSelectMode: Bool = false

    @AppStorage("xmpPresetImportDestination") private var xmpImportDestinationRaw: String = "__auto__"
    private let xmpImportDestinationAuto = "__auto__"
    private let xmpImportDestinationUncategorized = "__none__"

    @State private var showXMPImportSheet: Bool = false
    
    private var groupedPresets: [String: [AdjustmentPreset]] {
        Dictionary(grouping: store.adjustmentPresets) { $0.group ?? "Sonstige" }
    }
    
    private var orderedGroups: [String] {
        let groupsFromPresets = Set(
            store.adjustmentPresets
                .compactMap { $0.group?.trimmingCharacters(in: .whitespacesAndNewlines) }
                .filter { !$0.isEmpty }
        )
        
        var ordered: [String] = []
        
        // User-Reihenfolge zuerst (auch leere Gruppen anzeigen)
        for g in store.presetGroups where !g.isEmpty && g != "Sonstige" {
            ordered.append(g)
        }
        
        // Danach Gruppen, die nur in Presets vorkommen
        let remaining = groupsFromPresets.subtracting(Set(ordered))
        ordered.append(contentsOf: remaining.sorted())
        
        // "Sonstige" immer am Ende
        if !ordered.contains("Sonstige") {
            ordered.append("Sonstige")
        }
        
        return ordered
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Header
            HStack(spacing: 8) {
                Text("Presets")
                    .font(DesignSystem.Fonts.semibold(size: 14))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Spacer()

                Button(action: {
                    multiSelectMode.toggle()
                    if !multiSelectMode {
                        selectedPresetIDs.removeAll()
                    }
                }) {
                    Image(systemName: multiSelectMode ? "checkmark.circle.fill" : "checkmark.circle")
                        .font(.system(size: 13, weight: .medium))
                        .foregroundColor(multiSelectMode ? DesignSystem.Colors.accent : DesignSystem.Colors.text2)
                        .frame(width: 28, height: 28)
                        .background(DesignSystem.Colors.background4)
                        .cornerRadius(DesignSystem.CornerRadius.small)
                        .overlay(
                            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                                .stroke(DesignSystem.Colors.border, lineWidth: 1)
                        )
                }
                .buttonStyle(.plain)
                .help(multiSelectMode ? "Mehrfachauswahl aktiv" : "Mehrfachauswahl")
                
                Menu {
                    Button("XMP importieren...") {
                        showXMPImportSheet = true
                    }
                    
                    Divider()
                    
                    Button("Kategorie erstellen...") {
                        newGroupName = ""
                        showNewGroupSheet = true
                    }
                    
                    Divider()
                    
                    Button(multiSelectMode ? "Multi-Auswahl beenden" : "Mehrere auswählen") {
                        multiSelectMode.toggle()
                        if !multiSelectMode {
                            selectedPresetIDs.removeAll()
                        }
                    }
                    
                    if multiSelectMode && !selectedPresetIDs.isEmpty {
                        Button("Ausgewählte anwenden (\(selectedPresetIDs.count))") {
                            applySelectedPresets()
                        }
                    }
                    
                    if !store.adjustmentPresets.isEmpty {
                        Divider()
                        Button("Alle exportieren...") {
                            exportAllPresets()
                        }
                    }
                } label: {
                    SidebarHeaderIcon(systemName: "ellipsis.circle")
                }
                .help("Mehr Optionen")
                
                Button(action: {
                    editingPreset = nil
                    showPresetEditor = true
                }) {
                    SidebarHeaderIcon(systemName: "plus")
                }
                .help("Neues Preset erstellen")
            }
            .padding(.horizontal, 16)
            .padding(.vertical, 12)

            // Multi-Selection Bar (sichtbar, damit man sofort versteht was ausgewählt ist)
            if multiSelectMode {
                HStack(spacing: 10) {
                    Text(selectedPresetIDs.isEmpty ? "Mehrfachauswahl: Presets anklicken zum Auswählen (⌘ optional)" : "\(selectedPresetIDs.count) ausgewählt")
                        .font(DesignSystem.Fonts.regular(size: 12))
                        .foregroundColor(DesignSystem.Colors.text2)
                    
                    Spacer()
                    
                    Button("Abbrechen") {
                        multiSelectMode = false
                        selectedPresetIDs.removeAll()
                    }
                    .buttonStyle(LightroomSecondaryButtonStyle())
                    
                    Button("Anwenden") {
                        applySelectedPresets()
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(selectedPresetIDs.isEmpty)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 10)
                .background(DesignSystem.Colors.background4)
                .overlay(
                    Rectangle()
                        .fill(DesignSystem.Colors.border)
                        .frame(height: 1),
                    alignment: .top
                )
            }
            
            // Preset List
            ScrollView {
                VStack(alignment: .leading, spacing: 8) {
                    // Gruppierte Presets
                    ForEach(orderedGroups, id: \.self) { group in
                        PresetGroupView(
                            groupName: group,
                            presets: self.groupedPresets[group] ?? [],
                            isExpanded: expandedGroups.contains(group),
                            hoveredPresetID: $hoveredPresetID,
                            selectedPresetIDs: $selectedPresetIDs,
                            multiSelectMode: multiSelectMode,
                            store: store,
                            onToggle: {
                                if expandedGroups.contains(group) {
                                    expandedGroups.remove(group)
                                } else {
                                    expandedGroups.insert(group)
                                }
                            },
                            onPresetClick: { preset in
                                let flags = NSEvent.modifierFlags
                                let wantsMulti = multiSelectMode || flags.contains(.command)
                                
                                if wantsMulti {
                                    if !multiSelectMode { multiSelectMode = true }
                                    if selectedPresetIDs.contains(preset.id) {
                                        selectedPresetIDs.remove(preset.id)
                                    } else {
                                        selectedPresetIDs.insert(preset.id)
                                    }
                                } else {
                                    applyPreset(preset)
                                }
                            },
                            onPresetEdit: { preset in
                                editingPreset = preset
                                showPresetEditor = true
                            },
                            onPresetDelete: { preset in
                                store.deleteAdjustmentPreset(preset)
                            },
                            onPresetExport: { preset in
                                exportPreset(preset)
                            }
                        )
                    }
                }
                .padding(.horizontal)
            }
            .onHover { hovering in
                // Wenn Maus den Preset-Bereich verlässt: Preview zurücksetzen
                if !hovering {
                    hoveredPresetID = nil
                }
            }
        }
        .padding(.vertical)
        .onChange(of: hoveredPresetID) { _, newID in
            handleHoverPreviewChange(newID)
        }
        .onChange(of: multiSelectMode) { _, enabled in
            // In Multi-Select nicht mit Hover-Preview "reinfunken"
            if enabled {
                hoverRestoreTask?.cancel()
                if let original = temporaryAdjustments, let photo = store.currentPhoto {
                    photo.adjustments = original
                    triggerImageUpdate(for: photo)
                }
                temporaryAdjustments = nil
                hoveredPresetID = nil
            }
        }
        .onChange(of: store.currentPhotoID) { _, _ in
            // Keine Hover-Preview über Foto-Wechsel hinweg
            hoverRestoreTask?.cancel()
            temporaryAdjustments = nil
            hoveredPresetID = nil
        }
        .sheet(isPresented: $showPresetEditor) {
            PresetEditorView(
                preset: editingPreset,
                store: store,
                onSave: { preset in
                    if editingPreset != nil {
                        store.updateAdjustmentPreset(preset)
                    } else {
                        store.addAdjustmentPreset(preset)
                    }
                    showPresetEditor = false
                },
                onCancel: {
                    showPresetEditor = false
                }
            )
        }
        .sheet(isPresented: $showNewGroupSheet) {
            NewPresetGroupView(
                name: $newGroupName,
                onCreate: { name in
                    store.addPresetGroup(name)
                    expandedGroups.insert(name)
                    showNewGroupSheet = false
                },
                onCancel: {
                    showNewGroupSheet = false
                }
            )
        }
        .sheet(isPresented: $showXMPImportSheet) {
            XMPImportOptionsSheet(
                store: store,
                destinationRaw: $xmpImportDestinationRaw,
                onCreateCategory: {
                    newGroupName = ""
                    showNewGroupSheet = true
                },
                onCancel: { showXMPImportSheet = false },
                onImport: { destination in
                    showXMPImportSheet = false
                    importXMPPreset(destinationRaw: destination)
                }
            )
        }
    }
    
    private func applyPreset(_ preset: AdjustmentPreset) {
        guard let photo = store.currentPhoto else { return }
        
        // Hover-Preview wird hier "committed" (nicht zurücksetzen)
        hoverRestoreTask?.cancel()
        temporaryAdjustments = nil
        
        photo.adjustments = preset.adjustments
        triggerImageUpdate(for: photo)
    }
    
    private func applySelectedPresets() {
        guard let photo = store.currentPhoto, !selectedPresetIDs.isEmpty else { return }
        
        // Kombiniere als Stack (Delta ggü. Default) und wende auf aktuelle Anpassungen an.
        // So können Presets, die unterschiedliche Regler bedienen, sinnvoll "zusammen" wirken.
        let selectedPresets = store.adjustmentPresets
            .filter { selectedPresetIDs.contains($0.id) }
            .sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        guard !selectedPresets.isEmpty else { return }

        let defaults = PhotoAdjustments()
        var combined = photo.adjustments

        for preset in selectedPresets {
            let delta = deltaAdjustments(from: preset.adjustments, defaults: defaults)
            combined = combined.applying(delta)
        }
        
        hoverRestoreTask?.cancel()
        temporaryAdjustments = nil
        
        photo.adjustments = combined
        triggerImageUpdate(for: photo)
        
        // Multi-Select-Modus beenden
        multiSelectMode = false
        selectedPresetIDs.removeAll()
    }

    private func deltaAdjustments(from preset: PhotoAdjustments, defaults: PhotoAdjustments) -> PhotoAdjustments {
        var delta = PhotoAdjustments()
        delta.exposure = preset.exposure - defaults.exposure
        delta.contrast = defaults.contrast == 0 ? preset.contrast : (preset.contrast / defaults.contrast)
        delta.temperature = preset.temperature - defaults.temperature
        delta.tint = preset.tint - defaults.tint
        delta.clarity = preset.clarity - defaults.clarity
        delta.vibrance = preset.vibrance - defaults.vibrance
        delta.highlights = preset.highlights - defaults.highlights
        delta.shadows = preset.shadows - defaults.shadows
        delta.whites = preset.whites - defaults.whites
        delta.blacks = preset.blacks - defaults.blacks
        delta.saturation = preset.saturation - defaults.saturation
        delta.dehaze = preset.dehaze - defaults.dehaze
        delta.texture = preset.texture - defaults.texture
        return delta
    }
    
    private func handleHoverPreviewChange(_ newID: UUID?) {
        hoverRestoreTask?.cancel()
        guard let photo = store.currentPhoto else { return }
        
        // Hover beginnt / wechselt
        if let id = newID, let preset = store.adjustmentPresets.first(where: { $0.id == id }) {
            if temporaryAdjustments == nil {
                temporaryAdjustments = photo.adjustments
            }
            photo.adjustments = preset.adjustments
            triggerImageUpdate(for: photo)
            return
        }
        
        // Hover endet: mit kleiner Verzögerung zurücksetzen (verhindert Flicker beim Wechsel zwischen Rows)
        let original = temporaryAdjustments
        hoverRestoreTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 60_000_000) // 60ms
            guard hoveredPresetID == nil else { return }
            guard let original, let photo = store.currentPhoto else { return }
            photo.adjustments = original
            temporaryAdjustments = nil
            triggerImageUpdate(for: photo)
        }
    }
    
    private func triggerImageUpdate(for photo: PhotoItem) {
        // Wichtig: Viele Views beobachten den Store, nicht das Photo.
        // Daher zwingen wir hier ein UI-Refresh auf Store-Level (Sliders/Labels springen sonst nicht auf Preset-Werte).
        store.objectWillChange.send()
        photo.objectWillChange.send()
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id]
        )
    }
    
    private func importXMPPreset(destinationRaw: String) {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.xml]
        panel.allowsMultipleSelection = true
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        panel.prompt = "Importieren"
        panel.message = "Wählen Sie ein oder mehrere XMP-Presets aus"
        
        if panel.runModal() == .OK {
            let urls = panel.urls
            guard !urls.isEmpty else { return }
            xmpImportDestinationRaw = destinationRaw

            Task {
                var imported: [AdjustmentPreset] = []
                var failures: [String] = []
                
                for url in urls {
                    do {
                        var preset = try await Task.detached {
                            try XMPPresetParser.shared.importPreset(from: url)
                        }.value

                        // Ziel-Kategorie anwenden (optional Override)
                        if destinationRaw == xmpImportDestinationUncategorized {
                            preset.group = nil
                        } else if destinationRaw != xmpImportDestinationAuto {
                            preset.group = destinationRaw
                        } else {
                            // Auto: group aus XMP übernehmen (aber trimmen)
                            let trimmed = preset.group?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
                            preset.group = trimmed.isEmpty ? nil : trimmed
                        }

                        imported.append(preset)
                    } catch {
                        failures.append("\(url.lastPathComponent): \(error.localizedDescription)")
                    }
                }
                
                await MainActor.run {
                    for preset in imported {
                        store.addAdjustmentPreset(preset)
                    }
                    
                    let alert = NSAlert()
                    if failures.isEmpty {
                        alert.messageText = "Import abgeschlossen"
                        alert.informativeText = "\(imported.count) Preset(s) wurden importiert."
                        alert.alertStyle = .informational
                    } else {
                        alert.messageText = "Import teilweise fehlgeschlagen"
                        let previewFailures = failures.prefix(8).joined(separator: "\n")
                        let more = failures.count > 8 ? "\n… und \(failures.count - 8) weitere." : ""
                        alert.informativeText = "\(imported.count) importiert, \(failures.count) fehlgeschlagen:\n\n\(previewFailures)\(more)"
                        alert.alertStyle = .warning
                    }
                    alert.runModal()
                }
            }
        }
    }
    
    private func exportPreset(_ preset: AdjustmentPreset) {
        let savePanel = NSSavePanel()
        savePanel.allowedContentTypes = [.xml]
        savePanel.nameFieldStringValue = preset.name.replacingOccurrences(of: " ", with: "_") + ".xmp"
        
        if savePanel.runModal() == .OK, let url = savePanel.url {
            Task {
                do {
                    try await Task.detached {
                        try XMPPresetParser.shared.exportPreset(preset, to: url)
                    }.value
                } catch {
                    print("Export error: \(error)")
                    DispatchQueue.main.async {
                        let alert = NSAlert()
                        alert.messageText = "Export fehlgeschlagen"
                        alert.informativeText = error.localizedDescription
                        alert.alertStyle = .warning
                        alert.runModal()
                    }
                }
            }
        }
    }
    
    private func exportAllPresets() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.prompt = "Exportieren"
        panel.message = "Wählen Sie einen Ordner für den Export"
        
        if panel.runModal() == .OK, let directory = panel.url {
            Task {
                do {
                    for preset in store.adjustmentPresets {
                        let fileName = preset.name.replacingOccurrences(of: " ", with: "_") + ".xmp"
                        let fileURL = directory.appendingPathComponent(fileName)
                        try await Task.detached {
                            try XMPPresetParser.shared.exportPreset(preset, to: fileURL)
                        }.value
                    }
                    
                    DispatchQueue.main.async {
                        let alert = NSAlert()
                        alert.messageText = "Export abgeschlossen"
                        alert.informativeText = "\(store.adjustmentPresets.count) Presets wurden exportiert."
                        alert.alertStyle = .informational
                        alert.runModal()
                    }
                } catch {
                    print("Export error: \(error)")
                }
            }
        }
    }
}

struct PresetGroupView: View {
    let groupName: String
    let presets: [AdjustmentPreset]
    let isExpanded: Bool
    @Binding var hoveredPresetID: UUID?
    @Binding var selectedPresetIDs: Set<UUID>
    let multiSelectMode: Bool
    @ObservedObject var store: PhotoStore
    let onToggle: () -> Void
    let onPresetClick: (AdjustmentPreset) -> Void
    let onPresetEdit: (AdjustmentPreset) -> Void
    let onPresetDelete: (AdjustmentPreset) -> Void
    let onPresetExport: (AdjustmentPreset) -> Void
    
    @State private var isDropTargeted: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 2) {
            // Group Header
            Button(action: onToggle) {
                HStack(spacing: 6) {
                    Image(systemName: isExpanded ? "chevron.down" : "chevron.right")
                        .font(.system(size: 10, weight: .medium))
                        .foregroundColor(DesignSystem.Colors.text2)
                        .frame(width: 14)
                    
                    Text(groupName)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundColor(DesignSystem.Colors.text2)
                    
                    Spacer()
                    
                    Text("\(presets.count)")
                        .font(.system(size: 11, weight: .regular))
                        .foregroundColor(DesignSystem.Colors.text2)
                }
                .padding(.horizontal, 16)
                .padding(.vertical, 6)
                .background(isDropTargeted ? DesignSystem.Colors.accent.opacity(0.18) : Color.clear)
                .cornerRadius(6)
            }
            .buttonStyle(.plain)
            .onDrop(of: [UTType.text], isTargeted: $isDropTargeted) { providers in
                handleDrop(providers)
            }
            
            // Presets
            if isExpanded {
                if presets.isEmpty {
                    Text("Presets hierhin ziehen")
                        .font(DesignSystem.Fonts.regular(size: 12))
                        .foregroundColor(DesignSystem.Colors.text2)
                        .padding(.horizontal, 34)
                        .padding(.vertical, 10)
                        .onDrop(of: [UTType.text], isTargeted: $isDropTargeted) { providers in
                            handleDrop(providers)
                        }
                }
                ForEach(presets) { preset in
                    PresetRowView(
                        preset: preset,
                        isHovered: hoveredPresetID == preset.id,
                        isSelected: selectedPresetIDs.contains(preset.id),
                        multiSelectMode: multiSelectMode,
                        selectedPresetIDs: selectedPresetIDs,
                        onHover: { hovering in
                            guard !multiSelectMode else { return }
                            hoveredPresetID = hovering ? preset.id : nil
                        },
                        onClick: {
                            onPresetClick(preset)
                        },
                        onEdit: {
                            onPresetEdit(preset)
                        },
                        onDelete: {
                            onPresetDelete(preset)
                        },
                        store: store,
                        onExport: {
                            onPresetExport(preset)
                        }
                    )
                }
            }
        }
        .padding(.vertical, 4)
    }
    
    private func handleDrop(_ providers: [NSItemProvider]) -> Bool {
        let targetGroup: String? = (groupName == "Sonstige") ? nil : groupName
        
        for provider in providers {
            provider.loadObject(ofClass: NSString.self) { object, _ in
                guard let payload = object as? String else { return }
                let ids = extractPresetIDs(from: payload)
                guard !ids.isEmpty else { return }

                DispatchQueue.main.async {
                    for id in ids {
                        guard let preset = store.adjustmentPresets.first(where: { $0.id == id }) else { continue }
                        var updated = preset
                        updated.group = targetGroup
                        store.updateAdjustmentPreset(updated)
                    }
                }
            }
        }
        
        return true
    }

    private func extractPresetIDs(from payload: String) -> [UUID] {
        let trimmed = payload.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.hasPrefix("["),
           let data = trimmed.data(using: .utf8),
           let decoded = try? JSONDecoder().decode([String].self, from: data) {
            return decoded.compactMap { UUID(uuidString: $0) }
        }
        if let id = UUID(uuidString: trimmed) {
            return [id]
        }
        return []
    }
}

struct PresetRowView: View {
    let preset: AdjustmentPreset
    let isHovered: Bool
    let isSelected: Bool
    let multiSelectMode: Bool
    let selectedPresetIDs: Set<UUID>
    let onHover: (Bool) -> Void
    let onClick: () -> Void
    let onEdit: () -> Void
    let onDelete: () -> Void
    @ObservedObject var store: PhotoStore
    let onExport: () -> Void
    
    var body: some View {
        HStack(spacing: 8) {
            if multiSelectMode {
                Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                    .font(.system(size: 14))
                    .foregroundColor(isSelected ? DesignSystem.Colors.accent : DesignSystem.Colors.text2)
                    .frame(width: 20)
            }
            
            Button(action: onClick) {
                Text(preset.name)
                    .font(.system(size: 13, weight: .regular))
                    .foregroundColor(DesignSystem.Colors.text)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .buttonStyle(.plain)
            
            if isHovered {
                HStack(spacing: 6) {
                    Button(action: onExport) {
                        Image(systemName: "square.and.arrow.up")
                            .font(.system(size: 12))
                            .foregroundColor(DesignSystem.Colors.text2)
                    }
                    .buttonStyle(.plain)
                    .help("Als XMP exportieren")
                    
                    Button(action: onEdit) {
                        Image(systemName: "pencil")
                            .font(.system(size: 12))
                            .foregroundColor(DesignSystem.Colors.text2)
                    }
                    .buttonStyle(.plain)
                    .help("Bearbeiten")
                    
                    Button(action: onDelete) {
                        Image(systemName: "trash")
                            .font(.system(size: 12))
                            .foregroundColor(DesignSystem.Colors.text2)
                    }
                    .buttonStyle(.plain)
                    .help("Löschen")
                }
            }
        }
        .padding(.vertical, 6)
        .padding(.horizontal, 16)
        .background(
            isSelected && multiSelectMode ? DesignSystem.Colors.accent.opacity(0.25) :
            isHovered ? DesignSystem.Colors.accent.opacity(0.15) : Color.clear
        )
        .cornerRadius(5)
        .onHover { hovering in
            onHover(hovering)
        }
        .onDrag {
            if multiSelectMode, isSelected, selectedPresetIDs.count > 1 {
                let ids = selectedPresetIDs.map(\.uuidString)
                if let data = try? JSONEncoder().encode(ids),
                   let json = String(data: data, encoding: .utf8) {
                    return NSItemProvider(object: json as NSString)
                }
            }
            return NSItemProvider(object: preset.id.uuidString as NSString)
        }
    }
}

struct SidebarHeaderIcon: View {
    let systemName: String
    @State private var isHovering = false
    
    var body: some View {
        Image(systemName: systemName)
            .font(.system(size: 13, weight: .medium))
            .foregroundColor(DesignSystem.Colors.text2)
            .frame(width: 28, height: 28)
            .background(isHovering ? DesignSystem.Colors.background3 : DesignSystem.Colors.background4)
            .cornerRadius(DesignSystem.CornerRadius.small)
            .overlay(
                RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
            )
            .onHover { hovering in
                isHovering = hovering
            }
    }
}

private struct XMPImportOptionsSheet: View {
    @ObservedObject var store: PhotoStore
    @Binding var destinationRaw: String
    let onCreateCategory: () -> Void
    let onCancel: () -> Void
    let onImport: (String) -> Void

    private let autoRaw = "__auto__"
    private let uncategorizedRaw = "__none__"

    private struct Option: Identifiable {
        let id = UUID()
        let title: String
        let raw: String
    }

    private var groupNames: [String] {
        store.presetGroups
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty && $0 != "Sonstige" }
            .sorted()
    }

    private var options: [Option] {
        var result: [Option] = [
            Option(title: "Automatisch (aus XMP)", raw: autoRaw),
            Option(title: "Sonstige", raw: uncategorizedRaw)
        ]
        result.append(contentsOf: groupNames.map { Option(title: $0, raw: $0) })
        return result
    }

    private var selectedTitle: String {
        options.first(where: { $0.raw == destinationRaw })?.title ?? "Automatisch (aus XMP)"
    }

    var body: some View {
        ZStack {
            DesignSystem.Colors.background3
                .ignoresSafeArea()

            VStack(alignment: .leading, spacing: 12) {
                Text("XMP Import")
                    .font(DesignSystem.Fonts.semibold(size: 14))
                    .foregroundColor(DesignSystem.Colors.text)

                Text("Wähle die Ziel‑Kategorie, damit importierte Presets direkt dort landen.")
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text2)

                Text("ZIEL‑KATEGORIE")
                    .font(DesignSystem.Fonts.semibold(size: 11))
                    .foregroundColor(DesignSystem.Colors.text2)
                    .tracking(0.6)
                    .padding(.top, 6)

                Menu {
                    ForEach(options) { opt in
                        Button(opt.title) { destinationRaw = opt.raw }
                    }
                } label: {
                    HStack(spacing: 8) {
                        Text(selectedTitle)
                            .font(DesignSystem.Fonts.medium(size: 12))
                            .foregroundColor(DesignSystem.Colors.text)
                            .lineLimit(1)

                        Spacer(minLength: 6)

                        Image(systemName: "chevron.down")
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundColor(DesignSystem.Colors.text2)
                    }
                    .padding(.vertical, 7)
                    .padding(.horizontal, 10)
                    .background(DesignSystem.Colors.background2)
                    .overlay(
                        RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                            .stroke(DesignSystem.Colors.border, lineWidth: 1)
                    )
                    .cornerRadius(DesignSystem.CornerRadius.small)
                }
                .buttonStyle(.plain)

                Button("Neue Kategorie…") {
                    onCreateCategory()
                }
                .buttonStyle(LightroomSecondaryButtonStyle())

                Spacer(minLength: 0)

                HStack {
                    Button("Abbrechen") { onCancel() }
                        .buttonStyle(LightroomSecondaryButtonStyle())

                    Spacer()

                    Button("Dateien auswählen…") {
                        onImport(destinationRaw)
                    }
                    .buttonStyle(.borderedProminent)
                }
            }
            .padding(DesignSystem.Spacing.large)
            .background(DesignSystem.Colors.background4)
            .cornerRadius(DesignSystem.CornerRadius.medium)
            .overlay(
                RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.medium)
                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
            )
            .padding(DesignSystem.Spacing.large)
        }
        .lightroomSidebarTheme()
        .frame(width: 520, height: 300)
    }
}

struct NewPresetGroupView: View {
    @Binding var name: String
    let onCreate: (String) -> Void
    let onCancel: () -> Void
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        ZStack {
            DesignSystem.Colors.background3
                .ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 12) {
                Text("Kategorie erstellen")
                    .font(DesignSystem.Fonts.semibold(size: 14))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Text("Name".uppercased())
                    .font(DesignSystem.Fonts.semibold(size: 11))
                    .foregroundColor(DesignSystem.Colors.text2)
                    .tracking(0.6)
                
                TextField("z.B. \"Eishockey\"", text: $name)
                    .textFieldStyle(.plain)
                    .foregroundColor(DesignSystem.Colors.text)
                    .padding(.vertical, 7)
                    .padding(.horizontal, 10)
                    .background(DesignSystem.Colors.background2)
                    .cornerRadius(DesignSystem.CornerRadius.small)
                    .overlay(
                        RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                            .stroke(DesignSystem.Colors.border, lineWidth: 1)
                    )
                
                HStack {
                    Button("Abbrechen") { onCancel() }
                        .buttonStyle(LightroomSecondaryButtonStyle())
                    
                    Spacer()
                    
                    Button("Erstellen") { onCreate(name) }
                        .buttonStyle(.borderedProminent)
                        .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
                .padding(.top, 4)
            }
            .padding(DesignSystem.Spacing.large)
            .background(DesignSystem.Colors.background4)
            .cornerRadius(DesignSystem.CornerRadius.medium)
            .overlay(
                RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.medium)
                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
            )
            .padding(DesignSystem.Spacing.large)
        }
        .lightroomSidebarTheme()
        .frame(width: 420, height: 220)
    }
}

struct PresetEditorView: View {
    let preset: AdjustmentPreset?
    @ObservedObject var store: PhotoStore
    @State private var name: String
    @State private var group: String
    @State private var adjustments: PhotoAdjustments
    let onSave: (AdjustmentPreset) -> Void
    let onCancel: () -> Void
    
    init(preset: AdjustmentPreset?, store: PhotoStore, onSave: @escaping (AdjustmentPreset) -> Void, onCancel: @escaping () -> Void) {
        self.preset = preset
        self.store = store
        self.onSave = onSave
        self.onCancel = onCancel
        
        if let existing = preset {
            _name = State(initialValue: existing.name)
            _group = State(initialValue: existing.group ?? "")
            _adjustments = State(initialValue: existing.adjustments)
        } else {
            _name = State(initialValue: "")
            _group = State(initialValue: "")
            _adjustments = State(initialValue: PhotoAdjustments())
        }
    }
    
    var body: some View {
        ZStack {
            DesignSystem.Colors.background3
                .ignoresSafeArea()
            
            VStack(alignment: .leading, spacing: 12) {
                Text(preset == nil ? "Neues Preset" : "Preset bearbeiten")
                    .font(DesignSystem.Fonts.semibold(size: 14))
                    .foregroundColor(DesignSystem.Colors.text)
                
                // Name
                VStack(alignment: .leading, spacing: 6) {
                    Text("Name".uppercased())
                        .font(DesignSystem.Fonts.semibold(size: 11))
                        .foregroundColor(DesignSystem.Colors.text2)
                        .tracking(0.6)
                    TextField("Preset Name", text: $name)
                        .textFieldStyle(.plain)
                        .foregroundColor(DesignSystem.Colors.text)
                        .padding(.vertical, 7)
                        .padding(.horizontal, 10)
                        .background(DesignSystem.Colors.background2)
                        .cornerRadius(DesignSystem.CornerRadius.small)
                        .overlay(
                            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                                .stroke(DesignSystem.Colors.border, lineWidth: 1)
                        )
                }
                
                // Group
                VStack(alignment: .leading, spacing: 6) {
                    Text("Kategorie (optional)".uppercased())
                        .font(DesignSystem.Fonts.semibold(size: 11))
                        .foregroundColor(DesignSystem.Colors.text2)
                        .tracking(0.6)
                    TextField("z.B. \"Eishockey\"", text: $group)
                        .textFieldStyle(.plain)
                        .foregroundColor(DesignSystem.Colors.text)
                        .padding(.vertical, 7)
                        .padding(.horizontal, 10)
                        .background(DesignSystem.Colors.background2)
                        .cornerRadius(DesignSystem.CornerRadius.small)
                        .overlay(
                            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                                .stroke(DesignSystem.Colors.border, lineWidth: 1)
                        )
                }
                
                // Create from current adjustments
                if let photo = store.currentPhoto, preset == nil {
                    Button("Von aktuellen Einstellungen übernehmen") {
                        adjustments = photo.adjustments
                    }
                    .buttonStyle(LightroomSecondaryButtonStyle())
                }
                
                // Adjustments Editor
                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        AdjustmentSection(title: "Basis") {
                            AdjustmentSlider(title: "Belichtung", value: $adjustments.exposure, range: -2.0...2.0, unit: "EV", photo: store.currentPhoto)
                            AdjustmentSlider(title: "Kontrast", value: $adjustments.contrast, range: 0.5...1.8, unit: "x", photo: store.currentPhoto)
                            AdjustmentSlider(title: "Temperatur", value: $adjustments.temperature, range: -3000...3000, unit: "K", photo: store.currentPhoto)
                            AdjustmentSlider(title: "Tint", value: $adjustments.tint, range: -80...80, photo: store.currentPhoto)
                            AdjustmentSlider(title: "Klarheit", value: $adjustments.clarity, range: 0.0...1.0, photo: store.currentPhoto)
                            AdjustmentSlider(title: "Vibrance", value: $adjustments.vibrance, range: -0.6...1.0, photo: store.currentPhoto)
                        }
                        
                        AdjustmentSection(title: "Erweitert") {
                            AdjustmentSlider(title: "Highlights", value: $adjustments.highlights, range: -100...100, photo: store.currentPhoto)
                            AdjustmentSlider(title: "Shadows", value: $adjustments.shadows, range: -100...100, photo: store.currentPhoto)
                            AdjustmentSlider(title: "Whites", value: $adjustments.whites, range: -100...100, photo: store.currentPhoto)
                            AdjustmentSlider(title: "Blacks", value: $adjustments.blacks, range: -100...100, photo: store.currentPhoto)
                            AdjustmentSlider(title: "Saturation", value: $adjustments.saturation, range: -100...100, photo: store.currentPhoto)
                            AdjustmentSlider(title: "Dehaze", value: $adjustments.dehaze, range: -100...100, photo: store.currentPhoto)
                            AdjustmentSlider(title: "Texture", value: $adjustments.texture, range: -100...100, photo: store.currentPhoto)
                        }
                    }
                }
                .background(DesignSystem.Colors.background4)
                .cornerRadius(DesignSystem.CornerRadius.medium)
                .overlay(
                    RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.medium)
                        .stroke(DesignSystem.Colors.border, lineWidth: 1)
                )
                
                // Buttons
                HStack {
                    Button("Abbrechen", action: onCancel)
                        .buttonStyle(LightroomSecondaryButtonStyle())
                    
                    Spacer()
                    
                    Button("Speichern") {
                        let newPreset = AdjustmentPreset(
                            id: preset?.id ?? UUID(),
                            name: name,
                            group: group.isEmpty ? nil : group,
                            adjustments: adjustments
                        )
                        onSave(newPreset)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .padding(DesignSystem.Spacing.large)
        }
        .lightroomSidebarTheme()
        .frame(width: 560, height: 760)
    }
}

