//
//  FilmstripView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI

struct FilmstripView: View {
    let photos: [PhotoItem]
    @ObservedObject var store: PhotoStore
    
    var body: some View {
        ScrollViewReader { proxy in
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 4) {
                    ForEach(photos) { photo in
                        FilmstripPhotoCell(
                            photo: photo,
                            store: store,
                            isSelected: store.currentPhotoID == photo.id
                        )
                        .id(photo.id)
                        .onTapGesture {
                            store.selectPhoto(photo)
                        }
                    }
                }
                .padding(.horizontal, 4)
            }
            .background(DesignSystem.Colors.background4)
            .overlay(
                Rectangle()
                    .fill(DesignSystem.Colors.border)
                    .frame(height: 1),
                alignment: .top
            )
            .onChange(of: store.currentPhotoID) { newID in
                if let id = newID {
                    withAnimation {
                        proxy.scrollTo(id, anchor: .center)
                    }
                }
            }
        }
    }
}

struct FilmstripPhotoCell: View {
    let photo: PhotoItem
    @ObservedObject var store: PhotoStore
    let isSelected: Bool
    
    var body: some View {
        ZStack(alignment: .bottom) {
            AsyncThumbnailView(photo: photo, previewSize: .thumbnail, interpolation: .medium)
                .cornerRadius(4)
                .overlay(
                    Group {
                        if photo.pickStatus != .unflagged {
                            HStack(spacing: 4) {
                                Image(systemName: photo.pickStatus.displayIcon)
                                    .font(.system(size: 10, weight: .semibold))
                                    .foregroundColor(Color(photo.pickStatus.displayColor))
                                Text(photo.pickStatus == .pick ? "Pick" : "Reject")
                                    .font(.system(size: 9, weight: .medium))
                                    .foregroundColor(.white)
                                    .padding(.trailing, 2)
                            }
                            .padding(.horizontal, 6)
                            .padding(.vertical, 3)
                            .background(Color.black.opacity(0.6))
                            .cornerRadius(4)
                            .padding(6)
                            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topTrailing)
                        }
                    }
                )
            
            if photo.rating > 0 {
                HStack(spacing: 3) {
                    Image(systemName: "star.fill")
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundColor(DesignSystem.Colors.star)
                    Text("\(photo.rating)")
                        .font(.system(size: 9, weight: .bold))
                        .foregroundColor(.white)
                        .monospacedDigit()
                }
                .padding(.horizontal, 6)
                .padding(.vertical, 3)
                .background(Color.black.opacity(0.6))
                .cornerRadius(4)
                .padding(4)
            }
            
            // Virtual Copy Badge
            if let badge = photo.virtualCopyBadge {
                Text(badge)
                    .font(.system(size: 8, weight: .semibold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 5)
                    .padding(.vertical, 2)
                    .background(Color.blue.opacity(0.8))
                    .cornerRadius(3)
                    .padding(.bottom, 4)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomLeading)
            }
            
            // Quick Collection Badge
            if photo.isInQuickCollection {
                Image(systemName: "circle.fill")
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundColor(.cyan)
                    .padding(4)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomTrailing)
            }
            
            // Color Labels (oben links, als kleine Kreise)
            if !photo.colorTags.isEmpty {
                HStack(spacing: 2) {
                    ForEach(Array(photo.colorTags.sorted(by: { $0.rawValue < $1.rawValue })), id: \.self) { tag in
                        Circle()
                            .fill(Color(tag.color))
                            .frame(width: 8, height: 8)
                            .overlay(
                                Circle()
                                    .stroke(Color.white.opacity(0.8), lineWidth: 0.5)
                            )
                    }
                }
                .padding(4)
                .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            }
            
            if isSelected {
                Rectangle()
                    .stroke(DesignSystem.Colors.accent, lineWidth: 3)
            }
        }
        .frame(width: 100, height: 100)
        .cornerRadius(4)
    }
}
