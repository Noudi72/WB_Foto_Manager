//
//  ExportQueueSettingsView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit

struct ExportQueueSettingsView: View {
    @ObservedObject var store: PhotoStore
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Export-Queue Einstellungen")
                .font(.headline)
            
            Toggle("Export-Queue aktivieren", isOn: $store.exportQueueEnabled)
            
            if store.exportQueueEnabled {
                VStack(alignment: .leading, spacing: 12) {
                    // Min Rating
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Mindest-Rating: \(store.exportQueueMinRating) Sterne")
                            .font(.caption)
                        HStack {
                            ForEach(1...5, id: \.self) { rating in
                                Button(action: {
                                    store.exportQueueMinRating = rating
                                }) {
                                    HStack(spacing: 2) {
                                        ForEach(0..<rating, id: \.self) { _ in
                                            Image(systemName: "star.fill")
                                                .font(.caption2)
                                        }
                                    }
                                }
                                .buttonStyle(.plain)
                                .padding(.horizontal, 8)
                                .padding(.vertical, 4)
                                .background(store.exportQueueMinRating == rating ? Color.accentColor.opacity(0.3) : Color.clear)
                                .cornerRadius(4)
                            }
                        }
                    }
                    
                    // Preset Selection
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Export Preset")
                            .font(.caption)
                        Picker("Preset", selection: $store.exportQueuePreset) {
                            Text("Kein Preset").tag(ExportPreset?.none)
                            ForEach(store.exportPresets) { preset in
                                Text(preset.name).tag(ExportPreset?.some(preset))
                            }
                        }
                        .pickerStyle(.menu)
                    }
                    
                    // Output Directory
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Ausgabeordner")
                            .font(.caption)
                        HStack {
                            Text(store.exportQueueOutputDirectory?.path ?? "Nicht ausgewählt")
                                .foregroundColor(.secondary)
                                .frame(maxWidth: .infinity, alignment: .leading)
                            
                            Button("Auswählen...") {
                                let panel = NSOpenPanel()
                                panel.canChooseFiles = false
                                panel.canChooseDirectories = true
                                panel.allowsMultipleSelection = false
                                
                                if panel.runModal() == .OK, let url = panel.url {
                                    store.exportQueueOutputDirectory = url
                                }
                            }
                        }
                    }
                    
                    // Status
                    if store.isExportQueueRunning {
                        HStack {
                            ProgressView()
                            Text("Export läuft...")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    // Info
                    Text("Fotos mit \(store.exportQueueMinRating) oder mehr Sternen werden automatisch exportiert, sobald das Rating gesetzt wird.")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                .padding()
                .background(Color(red: 0.13, green: 0.13, blue: 0.14))
                .cornerRadius(8)
            }
            
            Spacer()
            
            HStack {
                Spacer()
                Button("Fertig") {
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding()
        .frame(width: 500, height: 400)
    }
}

