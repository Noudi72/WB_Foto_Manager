//
//  IPTCTemplate.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation

/// IPTC-Template mit Token-System
struct IPTCTemplate: Identifiable, Codable, Hashable {
    let id: UUID
    var name: String
    var category: String?
    var caption: String
    var keywords: [String]
    var photographer: String?
    var copyright: String?
    var location: String?
    var city: String?
    var country: String?
    var event: String?
    var venue: String?
    var customFields: [String: String]
    
    init(id: UUID = UUID(), name: String, category: String? = nil, caption: String = "", keywords: [String] = [], photographer: String? = nil, copyright: String? = nil, city: String? = nil, country: String? = nil, location: String? = nil, event: String? = nil, venue: String? = nil, customFields: [String: String] = [:]) {
        self.id = id
        self.name = name
        self.category = category
        self.caption = caption
        self.keywords = keywords
        self.photographer = photographer
        self.copyright = copyright
        self.location = location
        self.city = city
        self.country = country
        self.event = event
        self.venue = venue
        self.customFields = customFields
    }
    
    /// Ersetzt Tokens in den Feldern mit den bereitgestellten Werten
    func apply(tokenValues: [String: String], photoDate: Date? = nil) -> IPTCMetadata {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        let dateString = photoDate.map { formatter.string(from: $0) } ?? ""
        
        let timeFormatter = DateFormatter()
        timeFormatter.dateFormat = "HH:mm"
        let timeString = photoDate.map { timeFormatter.string(from: $0) } ?? ""
        
        var defaultTokens: [String: String] = [
            "{DATE}": dateString,
            "{TIME}": timeString
        ]
        defaultTokens.merge(tokenValues) { (_, new) in new }
        
        func replaceTokens(_ text: String) -> String {
            var result = text
            for (token, value) in defaultTokens {
                result = result.replacingOccurrences(of: token, with: value)
            }
            return result
        }
        
        return IPTCMetadata(
            caption: replaceTokens(caption),
            keywords: keywords.map { replaceTokens($0) },
            photographer: photographer.map { replaceTokens($0) },
            copyright: copyright.map { replaceTokens($0) },
            location: location.map { replaceTokens($0) },
            city: city.map { replaceTokens($0) },
            country: country.map { replaceTokens($0) },
            event: event.map { replaceTokens($0) },
            venue: venue.map { replaceTokens($0) },
            date: photoDate,
            customFields: customFields.mapValues { replaceTokens($0) }
        )
    }
    
    static var defaultTemplates: [IPTCTemplate] {
        [
            IPTCTemplate(
                name: "Allgemein - Event",
                category: "Allgemein",
                caption: "{EVENT} - {LOCATION}, {DATE}",
                keywords: ["{EVENT}", "{LOCATION}", "{VENUE}"],
                location: "{LOCATION}",
                event: "{EVENT}",
                venue: "{VENUE}"
            ),
            IPTCTemplate(
                name: "Allgemein - Beschreibung",
                category: "Allgemein",
                caption: "{DESCRIPTION}",
                keywords: ["{SUBJECT}", "{ACTION}"]
            ),
            IPTCTemplate(
                name: "Eishockey Standard",
                category: "Eishockey",
                caption: "{TEAM_A} vs {TEAM_B} - {LEAGUE}, {ARENA}, {DATE}",
                keywords: ["{TEAM_A}", "{TEAM_B}", "{LEAGUE}", "{ARENA}", "Eishockey"],
                location: "{ARENA}",
                event: "{TEAM_A} vs {TEAM_B}",
                venue: "{ARENA}"
            ),
            IPTCTemplate(
                name: "Eishockey Spieler",
                category: "Eishockey",
                caption: "{PLAYER_NAME} (#{PLAYER_NUMBER}) - {TEAM_A} vs {TEAM_B}, {DATE}",
                keywords: ["{PLAYER_NAME}", "{TEAM_A}", "{TEAM_B}", "Eishockey", "{SITUATION}"],
                location: nil,
                event: "{TEAM_A} vs {TEAM_B}",
                customFields: ["Player": "{PLAYER_NAME}", "Number": "{PLAYER_NUMBER}"]
            ),
            IPTCTemplate(
                name: "Fussball Standard",
                category: "Fussball",
                caption: "{TEAM_A} vs {TEAM_B} - {LEAGUE}, {VENUE}, {DATE}",
                keywords: ["{TEAM_A}", "{TEAM_B}", "{LEAGUE}", "{VENUE}", "Fussball"],
                location: nil,
                event: "{TEAM_A} vs {TEAM_B}",
                venue: "{VENUE}"
            ),
            IPTCTemplate(
                name: "Portrait",
                category: "Portrait",
                caption: "{SUBJECT} - {LOCATION}, {DATE}",
                keywords: ["{SUBJECT}", "Portrait"],
                location: "{LOCATION}"
            )
        ]
    }
}

