//
//  PhotoAdjustments.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation

/// Bildbearbeitungsparameter für ein Foto
struct PhotoAdjustments: Codable, Equatable, Hashable {
    // Basis-Adjustments
    var exposure: Double = 0.0 // -2.0 bis +2.0 EV
    var contrast: Double = 1.0 // 0.5x bis 1.8x
    var temperature: Double = 0.0 // -3000 bis +3000 Kelvin
    var tint: Double = 0.0 // -80 bis +80 (Magenta/Grün)
    var clarity: Double = 0.0 // 0.0 bis 1.0
    var vibrance: Double = 0.0 // -0.6 bis +1.0
    
    // Erweiterte Adjustments (Lightroom Classic Style)
    var highlights: Double = 0.0 // -100 bis +100
    var shadows: Double = 0.0 // -100 bis +100
    var whites: Double = 0.0 // -100 bis +100
    var blacks: Double = 0.0 // -100 bis +100
    var saturation: Double = 0.0 // -100 bis +100
    var dehaze: Double = 0.0 // -100 bis +100
    var texture: Double = 0.0 // -100 bis +100
    
    var hasAdjustments: Bool {
        exposure != 0.0 ||
        contrast != 1.0 ||
        temperature != 0.0 ||
        tint != 0.0 ||
        clarity != 0.0 ||
        vibrance != 0.0 ||
        highlights != 0.0 ||
        shadows != 0.0 ||
        whites != 0.0 ||
        blacks != 0.0 ||
        saturation != 0.0 ||
        dehaze != 0.0 ||
        texture != 0.0
    }
    
    mutating func reset() {
        exposure = 0.0
        contrast = 1.0
        temperature = 0.0
        tint = 0.0
        clarity = 0.0
        vibrance = 0.0
        highlights = 0.0
        shadows = 0.0
        whites = 0.0
        blacks = 0.0
        saturation = 0.0
        dehaze = 0.0
        texture = 0.0
    }
    
    func applying(_ other: PhotoAdjustments) -> PhotoAdjustments {
        var result = self
        result.exposure += other.exposure
        result.contrast *= other.contrast
        result.temperature += other.temperature
        result.tint += other.tint
        result.clarity += other.clarity
        result.vibrance += other.vibrance
        result.highlights += other.highlights
        result.shadows += other.shadows
        result.whites += other.whites
        result.blacks += other.blacks
        result.saturation += other.saturation
        result.dehaze += other.dehaze
        result.texture += other.texture
        return result
    }
}

