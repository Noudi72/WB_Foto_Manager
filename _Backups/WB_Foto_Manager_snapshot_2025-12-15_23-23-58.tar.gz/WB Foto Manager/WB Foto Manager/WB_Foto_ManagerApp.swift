//
//  WB_Foto_ManagerApp.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit
import UniformTypeIdentifiers
import Combine

@main
struct WB_Foto_ManagerApp: App {
    @StateObject private var store = PhotoStore()
    @StateObject private var uiState = UIState()
    
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .environmentObject(uiState)
                .frame(minWidth: 1200, minHeight: 800)
        }
        .defaultSize(width: 1400, height: 900)
        .commands {
            CommandGroup(replacing: .newItem) {
                Button("Ordner öffnen...") {
                    openFolder()
                }
                .keyboardShortcut("o", modifiers: .command)
                
                Divider()
                
                Button("Nächstes Foto") {
                    store.selectNextPhoto()
                }
                .keyboardShortcut(.rightArrow, modifiers: [])
                
                Button("Vorheriges Foto") {
                    store.selectPreviousPhoto()
                }
                .keyboardShortcut(.leftArrow, modifiers: [])
            }

            // File > Save / Save As (normal macOS Workflow)
            CommandGroup(replacing: .saveItem) {
                Button("Speichern") {
                    if let photo = store.currentPhoto {
                        SaveService.shared.saveOriginal(photo: photo)
        }
                }
                .keyboardShortcut("s", modifiers: .command)

                Button("Kopie speichern unter…") {
                    if let photo = store.currentPhoto {
                        SaveService.shared.saveCopyAs(photo: photo)
                    }
                }
                .keyboardShortcut("s", modifiers: [.command, .shift])
            }
            
            CommandGroup(after: .toolbar) {
                // Rating
                Button("1 Stern") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(1, for: photoID)
                    }
                }
                .keyboardShortcut("1", modifiers: [])
                
                Button("2 Sterne") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(2, for: photoID)
                    }
                }
                .keyboardShortcut("2", modifiers: [])
                
                Button("3 Sterne") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(3, for: photoID)
                    }
                }
                .keyboardShortcut("3", modifiers: [])
                
                Button("4 Sterne") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(4, for: photoID)
                    }
                }
                .keyboardShortcut("4", modifiers: [])
                
                Button("5 Sterne") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(5, for: photoID)
                    }
                }
                .keyboardShortcut("5", modifiers: [])
                
                Button("Rating löschen") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(0, for: photoID)
                    }
                }
                .keyboardShortcut("0", modifiers: [])
                
                Divider()
                
                // Pick/Reject (Lightroom-Style)
                Button("Als Pick markieren") {
                    if let photoID = store.currentPhotoID {
                        store.markAsPick(photoID: photoID)
                    }
                }
                .keyboardShortcut("p", modifiers: [])
                
                Button("Als Reject markieren") {
                    if let photoID = store.currentPhotoID {
                        store.markAsReject(photoID: photoID)
                    }
                }
                .keyboardShortcut("x", modifiers: [])
                
                Button("Markierung entfernen") {
                    if let photoID = store.currentPhotoID {
                        store.unflag(photoID: photoID)
                    }
                }
                .keyboardShortcut("u", modifiers: [])
                
                Divider()
                
                // Quick Collection
                Button("Zu Quick Collection hinzufügen/entfernen") {
                    if let photoID = store.currentPhotoID {
                        store.toggleQuickCollection(for: photoID)
                    }
                }
                .keyboardShortcut("b", modifiers: [])
                
                Button("Quick Collection anzeigen") {
                    uiState.showQuickCollectionOnly.toggle()
                }
                .keyboardShortcut("b", modifiers: [.command])
                
                Button("Quick Collection leeren") {
                    store.clearQuickCollection()
                }
                .keyboardShortcut("b", modifiers: [.command, .shift])
                
                Divider()
                
                // Virtual Copies
                Button("Virtuelle Kopie erstellen") {
                    if let photoID = store.currentPhotoID {
                        store.createVirtualCopy(of: photoID)
                    }
                }
                .keyboardShortcut("'", modifiers: [.command])
                
                Button("Virtuelle Kopie löschen") {
                    if let photoID = store.currentPhotoID,
                       let photo = store.photos.first(where: { $0.id == photoID }),
                       !photo.isMaster {
                        store.deleteVirtualCopy(photoID: photoID)
                    }
                }
                .keyboardShortcut("'", modifiers: [.command, .shift])
                .disabled(store.currentPhoto?.isMaster != false)
                
                Divider()
                
                // Pick Filter
                Button("Nur Picks anzeigen") {
                    uiState.pickStatusFilter = uiState.pickStatusFilter == .pick ? nil : .pick
                }
                .keyboardShortcut("p", modifiers: [.command])
                
                Button("Nur Rejects anzeigen") {
                    uiState.pickStatusFilter = uiState.pickStatusFilter == .reject ? nil : .reject
                }
                .keyboardShortcut("x", modifiers: [.command])
                
                Menu("Nach Color Label filtern") {
                    Button("Rot") {
                        uiState.colorTagFilter = uiState.colorTagFilter == .red ? nil : .red
                    }
                    Button("Gelb") {
                        uiState.colorTagFilter = uiState.colorTagFilter == .yellow ? nil : .yellow
                    }
                    Button("Grün") {
                        uiState.colorTagFilter = uiState.colorTagFilter == .green ? nil : .green
                    }
                    Button("Blau") {
                        uiState.colorTagFilter = uiState.colorTagFilter == .blue ? nil : .blue
                    }
                }
                
                Button("Filter zurücksetzen") {
                    uiState.pickStatusFilter = nil
                    uiState.ratingFilter = nil
                    uiState.colorTagFilter = nil
                }
                .keyboardShortcut("l", modifiers: [.command])
                
                Divider()
                
                Button("Alle Rejects löschen...") {
                    store.deleteAllRejects()
                }
                .keyboardShortcut(.delete, modifiers: [.command, .shift])
                
                Divider()
                
                // Color Labels
                Menu("Color Label") {
                    Button("Rot (6)") {
                        if let photoID = store.currentPhotoID {
                            store.toggleColorTag(.red, for: photoID)
                        }
                    }
                    .keyboardShortcut("6", modifiers: [])
                    
                    Button("Gelb (7)") {
                        if let photoID = store.currentPhotoID {
                            store.toggleColorTag(.yellow, for: photoID)
                        }
                    }
                    .keyboardShortcut("7", modifiers: [])
                    
                    Button("Grün (8)") {
                        if let photoID = store.currentPhotoID {
                            store.toggleColorTag(.green, for: photoID)
                        }
                    }
                    .keyboardShortcut("8", modifiers: [])
                    
                    Button("Blau (9)") {
                        if let photoID = store.currentPhotoID {
                            store.toggleColorTag(.blue, for: photoID)
                        }
                    }
                    .keyboardShortcut("9", modifiers: [])
                    
                    Divider()
                    
                    Button("Color Label entfernen") {
                        if let photoID = store.currentPhotoID {
                            let photo = store.photos.first(where: { $0.id == photoID })
                            photo?.colorTags.removeAll()
                        }
                    }
                }
                
                Divider()
                
                // Smart Collections
                Button("Smart Collections verwalten...") {
                    uiState.activeSheet = .smartCollections
                }
                
                Divider()
                
                // AI Tagging
                Button("AI Keywords generieren") {
                    Task {
                        await store.generateAITagsForCurrent()
                    }
                }
                .disabled(store.currentPhoto == nil)
                
                Button("AI Keywords für Auswahl generieren") {
                    Task {
                        await store.generateAITagsForSelection { current, total in
                            // Progress könnte hier angezeigt werden
                            print("AI Tagging: \(current)/\(total)")
                        }
                    }
                }
                .disabled(store.selectedPhotoIDs.count < 2)
                
                Divider()
                
                // Export
                Button("Exportieren...") {
                    uiState.activeSheet = .export
                }
                .keyboardShortcut("e", modifiers: [.command, .shift])
                
                Button("Batch Export...") {
                    uiState.activeSheet = .batchExport
                }
                .keyboardShortcut("b", modifiers: [.command, .shift])
                
                Divider()
                
                Button("Sidebar links ein/aus") {
                    if AppSettings.shared.sidebarAlwaysVisible {
                        uiState.showLeftSidebar = true
                    } else {
                        uiState.showLeftSidebar.toggle()
                    }
                }
                .keyboardShortcut("\\", modifiers: [.command])
                
                Button("Sidebar rechts ein/aus") {
                    uiState.showRightSidebar.toggle()
                }
                .keyboardShortcut("\\", modifiers: [.command, .option])
            }
            
            CommandGroup(replacing: .textEditing) {
                // Bildbearbeitung
                Button("Adjustments zurücksetzen") {
                    resetAdjustments()
                }
                .keyboardShortcut("r", modifiers: [.command, .option])

                Divider()

                // Lightroom-like: Copy/Paste/Sync Adjustments
                Button("Einstellungen kopieren") {
                    store.copyAdjustmentsFromCurrent()
                }
                .keyboardShortcut("c", modifiers: [.command, .shift])
                .disabled(store.currentPhoto == nil)

                Button("Einstellungen einfügen") {
                    store.pasteAdjustmentsToCurrent()
                }
                .keyboardShortcut("v", modifiers: [.command, .shift])
                .disabled(store.currentPhoto == nil || store.copiedAdjustments == nil)

                Button("Einstellungen synchronisieren…") {
                    uiState.activeSheet = .syncAdjustments
                }
                .keyboardShortcut("s", modifiers: [.command, .option])
                .disabled(store.currentPhoto == nil || store.selectedPhotoIDs.count <= 1)
                
                Divider()
                
                // View Mode
                Button("Detail-Ansicht") {
                    uiState.viewMode = .detail
                }
                .keyboardShortcut("1", modifiers: [.command, .control])
                
                Button("Grid-Ansicht") {
                    uiState.viewMode = .grid
                }
                .keyboardShortcut("2", modifiers: [.command, .control])
                
                Divider()
                
                // Before/After
                Button("Before/After umschalten") {
                    uiState.showBeforeAfter.toggle()
                }
                .keyboardShortcut("b", modifiers: [.command, .option])
                
                Divider()
                
                // Zoom
                Button("Zoom zurücksetzen") {
                    uiState.zoomLevel = 1.0
                }
                .keyboardShortcut("0", modifiers: [.command, .option])
                
                Button("Zoom vergrößern") {
                    uiState.zoomLevel = min(5.0, uiState.zoomLevel + 0.5)
                }
                .keyboardShortcut("=", modifiers: [.command, .option])
                
                Button("Zoom verkleinern") {
                    uiState.zoomLevel = max(0.5, uiState.zoomLevel - 0.5)
                }
                .keyboardShortcut("-", modifiers: [.command, .option])
            }
            
            CommandGroup(after: .appSettings) {
                Button("Einstellungen...") {
                    uiState.activeSheet = .settings
                }
                .keyboardShortcut(",", modifiers: .command)
                
                Divider()
                
                Button("Upload-Ziele verwalten...") {
                    uiState.activeSheet = .uploadSettings
                }
                
                Divider()
                
                Button("Batch Export...") {
                    uiState.activeSheet = .batchExport
                }
                .keyboardShortcut("b", modifiers: [.command, .shift])
                
                Button("Export-Queue Einstellungen...") {
                    uiState.activeSheet = .exportQueueSettings
                }
                
                Button("Backup & Wiederherstellung...") {
                    uiState.activeSheet = .backupRestore
                }
            }

            CommandGroup(after: .help) {
                Divider()
                Button("Synchronisieren…") {
                    uiState.activeSheet = .syncAdjustments
                }
                .disabled(store.currentPhoto == nil || store.selectedPhotoIDs.count <= 1)
            }
        }
    }
    
    private func openFolder() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        
        panel.begin { response in
            if response == .OK, let url = panel.url {
                store.loadPhotos(from: url)
            }
        }
    }
    
    private func resetAdjustments() {
        guard let photo = store.currentPhoto else { return }
        var copy = photo.adjustments
        copy.reset()
        photo.adjustments = copy

        // Trigger Re-Render + persist non-destructive edits
        photo.objectWillChange.send()
        store.objectWillChange.send()
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id]
        )
    }
}
