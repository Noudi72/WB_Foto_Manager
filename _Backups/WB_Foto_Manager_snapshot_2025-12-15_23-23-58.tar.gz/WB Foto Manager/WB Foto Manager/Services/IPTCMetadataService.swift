//
//  IPTCMetadataService.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import ImageIO
import CoreImage

/// Service für IPTC-Metadaten-Verwaltung
final class IPTCMetadataService: @unchecked Sendable {
    nonisolated static let shared = IPTCMetadataService()
    
    private init() {}
    
    /// Lädt IPTC-Metadaten aus einem Bild
    nonisolated func loadMetadata(from url: URL) -> IPTCMetadata? {
        guard let imageSource = CGImageSourceCreateWithURL(url as CFURL, nil),
              let metadata = CGImageSourceCopyPropertiesAtIndex(imageSource, 0, nil) as? [String: Any] else {
            return nil
        }
        
        var iptc = IPTCMetadata()
        
        // IPTC Dictionary
        if let iptcDict = metadata[kCGImagePropertyIPTCDictionary as String] as? [String: Any] {
            iptc.caption = iptcDict[kCGImagePropertyIPTCCaptionAbstract as String] as? String
            iptc.keywords = iptcDict[kCGImagePropertyIPTCKeywords as String] as? [String] ?? []
            iptc.photographer = iptcDict[kCGImagePropertyIPTCByline as String] as? String
            iptc.copyright = iptcDict[kCGImagePropertyIPTCCopyrightNotice as String] as? String
            // Location wird als SubLocation gespeichert
            iptc.location = iptcDict[kCGImagePropertyIPTCSubLocation as String] as? String
            iptc.city = iptcDict[kCGImagePropertyIPTCCity as String] as? String
            iptc.country = iptcDict[kCGImagePropertyIPTCCountryPrimaryLocationName as String] as? String
            iptc.event = iptcDict["Event" as String] as? String
            iptc.venue = iptcDict["Venue" as String] as? String
        }
        
        // XMP Keywords (dc:subject)
        if let xmpDict = metadata[kCGImagePropertyIPTCDictionary as String] as? [String: Any],
           let xmpKeywords = xmpDict["dc:subject" as String] as? [String] {
            iptc.keywords.append(contentsOf: xmpKeywords)
        }
        
        // Rating (XMP) - wird separat von RatingPersistenceService gehandhabt
        // Hier nicht laden, da es separat verwaltet wird
        
        // EXIF Date
        if let exifDict = metadata[kCGImagePropertyExifDictionary as String] as? [String: Any],
           let dateTimeOriginal = exifDict[kCGImagePropertyExifDateTimeOriginal as String] as? String {
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy:MM:dd HH:mm:ss"
            iptc.date = formatter.date(from: dateTimeOriginal)
        }
        
        return iptc
    }
    
    /// Schreibt IPTC-Metadaten in ein Bild
    nonisolated func writeMetadata(_ metadata: IPTCMetadata, to url: URL) throws {
        guard let imageSource = CGImageSourceCreateWithURL(url as CFURL, nil),
              let image = CGImageSourceCreateImageAtIndex(imageSource, 0, nil),
              let uti = CGImageSourceGetType(imageSource) else {
            throw NSError(domain: "IPTCMetadataService", code: 1, userInfo: [NSLocalizedDescriptionKey: "Could not read image"])
        }
        
        let mutableData = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(mutableData, uti, 1, nil) else {
            throw NSError(domain: "IPTCMetadataService", code: 2, userInfo: [NSLocalizedDescriptionKey: "Could not create image destination"])
        }
        
        // Lade bestehende Metadaten
        var existingMetadata = CGImageSourceCopyPropertiesAtIndex(imageSource, 0, nil) as? [String: Any] ?? [:]
        
        // IPTC Dictionary
        var iptcDict: [String: Any] = existingMetadata[kCGImagePropertyIPTCDictionary as String] as? [String: Any] ?? [:]
        
        if let caption = metadata.caption {
            iptcDict[kCGImagePropertyIPTCCaptionAbstract as String] = caption
        }
        if !metadata.keywords.isEmpty {
            iptcDict[kCGImagePropertyIPTCKeywords as String] = metadata.keywords
        }
        if let photographer = metadata.photographer {
            iptcDict[kCGImagePropertyIPTCByline as String] = photographer
        }
        if let copyright = metadata.copyright {
            iptcDict[kCGImagePropertyIPTCCopyrightNotice as String] = copyright
        }
        if let location = metadata.location {
            iptcDict[kCGImagePropertyIPTCSubLocation as String] = location
        }
        if let city = metadata.city {
            iptcDict[kCGImagePropertyIPTCCity as String] = city
        }
        if let country = metadata.country {
            iptcDict[kCGImagePropertyIPTCCountryPrimaryLocationName as String] = country
        }
        if let event = metadata.event {
            iptcDict["Event" as String] = event
        }
        if let venue = metadata.venue {
            iptcDict["Venue" as String] = venue
        }
        
        existingMetadata[kCGImagePropertyIPTCDictionary as String] = iptcDict
        
        // XMP Keywords
        var xmpDict: [String: Any] = existingMetadata[kCGImagePropertyIPTCDictionary as String] as? [String: Any] ?? [:]
        xmpDict["dc:subject" as String] = metadata.keywords
        existingMetadata[kCGImagePropertyIPTCDictionary as String] = xmpDict
        
        // Custom Fields (als JSON in einem speziellen Feld)
        if !metadata.customFields.isEmpty {
            if let jsonData = try? JSONSerialization.data(withJSONObject: metadata.customFields),
               let jsonString = String(data: jsonData, encoding: .utf8) {
                iptcDict["CustomFields" as String] = jsonString
            }
        }
        
        // Schreibe Bild mit Metadaten
        CGImageDestinationAddImage(destination, image, existingMetadata as CFDictionary)
        guard CGImageDestinationFinalize(destination) else {
            throw NSError(domain: "IPTCMetadataService", code: 3, userInfo: [NSLocalizedDescriptionKey: "Could not finalize image"])
        }
        
        // Atomare Operation: Schreibe zuerst in temporäre Datei, dann ersetze Original
        let tempURL = url.appendingPathExtension("tmp")
        try mutableData.write(to: tempURL)
        try FileManager.default.replaceItem(at: url, withItemAt: tempURL, backupItemName: nil, options: [], resultingItemURL: nil)
    }
}

