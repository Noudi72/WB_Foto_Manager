//
//  UploadService.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation

/// Service für Upload-Funktionalität
class UploadService {
    static let shared = UploadService()
    
    private init() {}
    
    /// Lädt eine Datei zu einem Upload-Target hoch
    func upload(fileURL: URL, to target: UploadTarget, progress: ((Double) -> Void)? = nil) async throws {
        guard target.isEnabled else {
            throw UploadError.targetDisabled
        }
        
        progress?(0.1)
        
        switch target.type {
        case .ftp:
            try await uploadToFTP(fileURL: fileURL, target: target, progress: progress)
        case .sftp:
            try await uploadToSFTP(fileURL: fileURL, target: target, progress: progress)
        case .s3:
            try await uploadToS3(fileURL: fileURL, target: target, progress: progress)
        case .http:
            try await uploadToHTTP(fileURL: fileURL, target: target, progress: progress)
        case .pictrs:
            try await uploadToPictrs(fileURL: fileURL, target: target, progress: progress)
        case .local:
            try await uploadToLocal(fileURL: fileURL, target: target, progress: progress)
        }
        
        progress?(1.0)
    }
    
    /// Lädt mehrere Dateien hoch
    func uploadBatch(fileURLs: [URL], to target: UploadTarget, progress: ((Int, Int) -> Void)? = nil) async throws {
        for (index, url) in fileURLs.enumerated() {
            try await upload(fileURL: url, to: target) { _ in
                progress?(index + 1, fileURLs.count)
            }
        }
    }
    
    // MARK: - FTP Upload
    
    private func uploadToFTP(fileURL: URL, target: UploadTarget, progress: ((Double) -> Void)?) async throws {
        guard let host = target.ftpHost,
              let _ = target.ftpUsername,
              let password = target.ftpPassword else {
            throw UploadError.missingCredentials
        }
        
        // FTP Upload würde hier implementiert werden
        // Für eine vollständige Implementierung würde man eine FTP-Library verwenden
        // z.B. libcurl oder eine Swift FTP Library
        
        // Placeholder - würde in echter Implementierung FTP-Connection aufbauen
        try await Task.sleep(nanoseconds: 500_000_000) // Simuliere Upload
        
        progress?(0.9)
    }
    
    // MARK: - SFTP Upload
    
    private func uploadToSFTP(fileURL: URL, target: UploadTarget, progress: ((Double) -> Void)?) async throws {
        guard let host = target.ftpHost,
              let username = target.ftpUsername else {
            throw UploadError.missingCredentials
        }
        
        // SFTP Upload würde hier implementiert werden
        // Für eine vollständige Implementierung würde man eine SFTP-Library verwenden
        // z.B. libssh2 oder NMSSH für Swift
        
        // Unterstützt sowohl Password- als auch Key-basierte Authentifizierung
        let hasPassword = target.ftpPassword != nil && !target.ftpPassword!.isEmpty
        let hasPrivateKey = target.ftpPrivateKey != nil && !target.ftpPrivateKey!.isEmpty
        
        guard hasPassword || hasPrivateKey else {
            throw UploadError.missingCredentials
        }
        
        // Placeholder - würde in echter Implementierung SFTP-Connection aufbauen
        progress?(0.3)
        try await Task.sleep(nanoseconds: 500_000_000) // Simuliere Upload
        progress?(0.9)
    }
    
    // MARK: - S3 Upload
    
    private func uploadToS3(fileURL: URL, target: UploadTarget, progress: ((Double) -> Void)?) async throws {
        guard let bucket = target.s3Bucket,
              let accessKey = target.s3AccessKey,
              let secretKey = target.s3SecretKey else {
            throw UploadError.missingCredentials
        }
        
        // S3 Upload würde hier implementiert werden
        // Für eine vollständige Implementierung würde man AWS SDK verwenden
        
        // Placeholder - würde in echter Implementierung S3-API aufrufen
        try await Task.sleep(nanoseconds: 500_000_000) // Simuliere Upload
        
        progress?(0.9)
    }
    
    // MARK: - HTTP Upload
    
    private func uploadToHTTP(fileURL: URL, target: UploadTarget, progress: ((Double) -> Void)?) async throws {
        guard let urlString = target.httpURL,
              let url = URL(string: urlString) else {
            throw UploadError.invalidURL
        }
        
        let fileData = try Data(contentsOf: fileURL)
        
        var request = URLRequest(url: url)
        request.httpMethod = target.httpMethod ?? "POST"
        
        // Headers
        if let headers = target.httpHeaders {
            for (key, value) in headers {
                request.setValue(value, forHTTPHeaderField: key)
            }
        }
        
        // Auth Token
        if let token = target.httpAuthToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        // Multipart Form Data
        let boundary = UUID().uuidString
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        var body = Data()
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"file\"; filename=\"\(fileURL.lastPathComponent)\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: application/octet-stream\r\n\r\n".data(using: .utf8)!)
        body.append(fileData)
        body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)
        
        request.httpBody = body
        
        progress?(0.5)
        
        let (_, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse,
              (200...299).contains(httpResponse.statusCode) else {
            throw UploadError.uploadFailed
        }
        
        progress?(0.9)
    }
    
    // MARK: - Pictrs Upload
    
    private func uploadToPictrs(fileURL: URL, target: UploadTarget, progress: ((Double) -> Void)?) async throws {
        guard let pictrsURL = target.pictrsURL,
              let url = URL(string: pictrsURL) else {
            throw UploadError.invalidURL
        }
        
        let fileData = try Data(contentsOf: fileURL)
        let fileName = fileURL.lastPathComponent
        
        // Pictrs API: POST /image
        let uploadURL = url.appendingPathComponent("image")
        
        var request = URLRequest(url: uploadURL)
        request.httpMethod = "POST"
        
        // Content-Type
        request.setValue("multipart/form-data", forHTTPHeaderField: "Content-Type")
        
        // Auth Token falls vorhanden
        if let token = target.pictrsAuthToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        // Multipart Form Data
        let boundary = UUID().uuidString
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        var body = Data()
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"images[]\"; filename=\"\(fileName)\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
        body.append(fileData)
        body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)
        
        request.httpBody = body
        
        progress?(0.5)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            throw UploadError.uploadFailed
        }
        
        if !(200...299).contains(httpResponse.statusCode) {
            let errorMessage = String(data: data, encoding: .utf8) ?? "Unknown error"
            print("Pictrs upload failed: \(errorMessage)")
            throw UploadError.uploadFailed
        }
        
        // Parse Response (Pictrs gibt JSON zurück mit image URLs)
        if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            print("Pictrs upload successful: \(json)")
        }
        
        progress?(0.9)
    }
    
    // MARK: - Local Upload (Kopieren)
    
    private func uploadToLocal(fileURL: URL, target: UploadTarget, progress: ((Double) -> Void)?) async throws {
        guard let path = target.ftpPath else {
            throw UploadError.missingPath
        }
        
        let destinationURL = URL(fileURLWithPath: path).appendingPathComponent(fileURL.lastPathComponent)
        
        let fileManager = FileManager.default
        try fileManager.createDirectory(at: destinationURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        
        progress?(0.5)
        
        try fileManager.copyItem(at: fileURL, to: destinationURL)
        
        progress?(0.9)
    }
}

enum UploadError: LocalizedError {
    case targetDisabled
    case missingCredentials
    case invalidURL
    case uploadFailed
    case missingPath
    
    var errorDescription: String? {
        switch self {
        case .targetDisabled:
            return "Upload-Ziel ist deaktiviert"
        case .missingCredentials:
            return "Fehlende Anmeldedaten"
        case .invalidURL:
            return "Ungültige URL"
        case .uploadFailed:
            return "Upload fehlgeschlagen"
        case .missingPath:
            return "Fehlender Pfad"
        }
    }
}

