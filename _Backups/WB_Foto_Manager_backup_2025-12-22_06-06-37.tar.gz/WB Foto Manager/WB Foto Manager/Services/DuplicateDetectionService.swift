//
//  DuplicateDetectionService.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 20.12.2025.
//

import Foundation
import CoreImage
import AppKit

/// Service für Duplikat-Erkennung (visuell ähnliche Fotos)
@MainActor
class DuplicateDetectionService {
    static let shared = DuplicateDetectionService()
    
    private let context = CIContext()
    private var imageHashes: [UUID: String] = [:]
    
    private init() {}
    
    /// Berechnet einen visuellen Hash für ein Bild (dHash - Difference Hash)
    /// Verwendet 16x16 für bessere Genauigkeit
    func computeImageHash(for photo: PhotoItem, similarityThreshold: Double = 0.9) async -> String? {
        guard let image = await photo.loadFullImageAsync() else { return nil }
        
        // Reduziere auf 17x16 für dHash (16x16 + 1 Spalte für Differenz)
        let hashSize = 16
        let smallSize = CGSize(width: CGFloat(hashSize + 1), height: CGFloat(hashSize))
        guard let resized = resizeImage(image, to: smallSize) else { return nil }
        
        // Konvertiere zu Graustufen
        guard let grayImage = convertToGrayscale(resized) else { return nil }
        
        // dHash: Vergleiche horizontale Nachbarpixel
        var hash = ""
        
        guard let pixelData = grayImage.dataProvider?.data,
              let data = CFDataGetBytePtr(pixelData) else { return nil }
        
        let bytesPerPixel = 4
        let bytesPerRow = grayImage.width * bytesPerPixel
        
        for y in 0..<hashSize {
            for x in 0..<hashSize {
                let currentIndex = y * bytesPerRow + x * bytesPerPixel
                let nextIndex = y * bytesPerRow + (x + 1) * bytesPerPixel
                
                let currentBrightness = Double(data[currentIndex]) / 255.0
                let nextBrightness = Double(data[nextIndex]) / 255.0
                
                // Hash: 1 wenn nächster Pixel heller, 0 sonst
                hash += (nextBrightness > currentBrightness) ? "1" : "0"
            }
        }
        
        return hash
    }
    
    /// Findet Duplikate in einer Liste von Fotos
    func findDuplicates(in photos: [PhotoItem], similarityThreshold: Double = 0.9, progress: ((Int, Int) -> Void)? = nil) async -> [DuplicateGroup] {
        var groups: [DuplicateGroup] = []
        var processedHashes: [String: [PhotoItem]] = [:]
        var photoHashes: [UUID: String] = [:]
        
        // Berechne Hashes für alle Fotos
        for (index, photo) in photos.enumerated() {
            if let hash = await computeImageHash(for: photo, similarityThreshold: similarityThreshold) {
                photoHashes[photo.id] = hash
                
                // Finde ähnliche Hashes (Hamming-Distanz)
                // Hash-Länge ist 16*16 = 256 Bits
                let hashLength = 256
                let maxDistance = Int(Double(hashLength) * (1.0 - similarityThreshold))
                
                var foundGroup = false
                for (existingHash, _) in processedHashes {
                    let distance = hammingDistance(hash, existingHash)
                    if distance <= maxDistance {
                        processedHashes[existingHash]?.append(photo)
                        foundGroup = true
                        break
                    }
                }
                
                if !foundGroup {
                    processedHashes[hash] = [photo]
                }
            }
            
            progress?(index + 1, photos.count)
        }
        
        // Erstelle Duplikat-Gruppen
        for (_, groupPhotos) in processedHashes where groupPhotos.count > 1 {
            groups.append(DuplicateGroup(photos: groupPhotos))
        }
        
        return groups.sorted { $0.photos.count > $1.photos.count }
    }
    
    // MARK: - Helper Functions
    
    private func resizeImage(_ image: CIImage, to size: CGSize) -> CIImage? {
        let scale = min(size.width / image.extent.width, size.height / image.extent.height)
        let transform = CGAffineTransform(scaleX: scale, y: scale)
        return image.transformed(by: transform).cropped(to: CGRect(origin: .zero, size: size))
    }
    
    private func convertToGrayscale(_ image: CIImage) -> CGImage? {
        let filter = CIFilter(name: "CIColorControls")
        filter?.setValue(image, forKey: kCIInputImageKey)
        filter?.setValue(0.0, forKey: kCIInputSaturationKey)
        
        guard let output = filter?.outputImage,
              let cgImage = context.createCGImage(output, from: output.extent) else {
            return nil
        }
        return cgImage
    }
    
    private func computeAverageBrightness(_ image: CGImage) -> Double {
        guard let pixelData = image.dataProvider?.data,
              let data = CFDataGetBytePtr(pixelData) else { return 0.5 }
        
        var sum: Double = 0
        let width = image.width
        let height = image.height
        let bytesPerPixel = 4
        let bytesPerRow = width * bytesPerPixel
        let totalPixels = width * height
        
        for y in 0..<height {
            for x in 0..<width {
                let pixelIndex = y * bytesPerRow + x * bytesPerPixel
                let brightness = Double(data[pixelIndex]) / 255.0
                sum += brightness
            }
        }
        
        return sum / Double(totalPixels)
    }
    
    private func hammingDistance(_ hash1: String, _ hash2: String) -> Int {
        guard hash1.count == hash2.count else { return Int.max }
        var distance = 0
        for (char1, char2) in zip(hash1, hash2) {
            if char1 != char2 {
                distance += 1
            }
        }
        return distance
    }
}

/// Eine Gruppe von Duplikaten
struct DuplicateGroup: Identifiable {
    let id = UUID()
    let photos: [PhotoItem]
    
    var count: Int { photos.count }
    var primaryPhoto: PhotoItem? { photos.first }
}

