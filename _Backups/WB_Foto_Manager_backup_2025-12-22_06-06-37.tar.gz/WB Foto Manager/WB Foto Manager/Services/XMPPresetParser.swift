//
//  XMPPresetParser.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation

/// Service für XMP-Preset Import/Export
final class XMPPresetParser: @unchecked Sendable {
    nonisolated static let shared = XMPPresetParser()
    
    private init() {}
    
    /// Importiert ein XMP-Preset
    nonisolated func importPreset(from url: URL) throws -> AdjustmentPreset {
        let data = try Data(contentsOf: url)
        
        // XMP-Presets sind XML-Dateien
        guard let xmlString = String(data: data, encoding: .utf8) else {
            throw NSError(domain: "XMPPresetParser", code: 1, userInfo: [NSLocalizedDescriptionKey: "Could not read XMP file"])
        }
        
        // Parse XML (vereinfacht - würde in echter Implementierung XMLParser verwenden)
        var adjustments = PhotoAdjustments()
        let presetName = url.deletingPathExtension().lastPathComponent
        
        // Extrahiere Werte aus XMP (vereinfachte Implementierung)
        // In einer echten Implementierung würde hier ein XML-Parser verwendet
        if let exposureRange = xmlString.range(of: "crs:Exposure2012=\"([^\"]+)\"", options: .regularExpression) {
            let valueString = String(xmlString[exposureRange])
            if let value = Double(valueString.replacingOccurrences(of: "crs:Exposure2012=\"", with: "").replacingOccurrences(of: "\"", with: "")) {
                adjustments.exposure = value
            }
        }
        
        // Weitere Parameter würden hier extrahiert werden...
        // Für jetzt erstellen wir ein Preset mit den gefundenen Werten
        
        return AdjustmentPreset(
            name: presetName,
            adjustments: adjustments
        )
    }
    
    /// Exportiert ein Preset als XMP
    nonisolated func exportPreset(_ preset: AdjustmentPreset, to url: URL) throws {
        // Erstelle XMP-XML
        let xml = """
        <?xml version="1.0" encoding="UTF-8"?>
        <x:xmpmeta xmlns:x="adobe:ns:meta/">
        <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
        <rdf:Description rdf:about=""
            xmlns:crs="http://ns.adobe.com/camera-raw-settings/1.0/">
            <crs:Name>\(preset.name)</crs:Name>
            <crs:Exposure2012>\(preset.adjustments.exposure)</crs:Exposure2012>
            <crs:Contrast2012>\(Int((preset.adjustments.contrast - 1.0) * 100))</crs:Contrast2012>
            <crs:Temperature>\(Int(preset.adjustments.temperature))</crs:Temperature>
            <crs:Tint>\(Int(preset.adjustments.tint))</crs:Tint>
            <crs:Clarity2012>\(Int(preset.adjustments.clarity * 100))</crs:Clarity2012>
            <crs:Vibrance>\(Int(preset.adjustments.vibrance * 100))</crs:Vibrance>
            <crs:Highlights2012>\(Int(preset.adjustments.highlights))</crs:Highlights2012>
            <crs:Shadows2012>\(Int(preset.adjustments.shadows))</crs:Shadows2012>
            <crs:Whites2012>\(Int(preset.adjustments.whites))</crs:Whites2012>
            <crs:Blacks2012>\(Int(preset.adjustments.blacks))</crs:Blacks2012>
            <crs:Saturation>\(Int(preset.adjustments.saturation))</crs:Saturation>
        </rdf:Description>
        </rdf:RDF>
        </x:xmpmeta>
        """
        
        try xml.write(to: url, atomically: true, encoding: .utf8)
    }
}

