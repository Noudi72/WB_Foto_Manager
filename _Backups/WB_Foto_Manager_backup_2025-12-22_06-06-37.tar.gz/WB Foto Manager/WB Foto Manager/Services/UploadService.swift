//
//  UploadService.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation

/// Service für Upload-Funktionalität
class UploadService {
    static let shared = UploadService()
    
    private init() {}
    
    /// Lädt eine Datei zu einem Upload-Target hoch
    func upload(fileURL: URL, to target: UploadTarget, progress: ((Double) -> Void)? = nil) async throws {
        guard target.isEnabled else {
            throw UploadError.targetDisabled
        }
        
        progress?(0.1)
        
        switch target.type {
        case .ftp:
            try await uploadToFTP(fileURL: fileURL, target: target, progress: progress)
        case .sftp:
            try await uploadToSFTP(fileURL: fileURL, target: target, progress: progress)
        case .s3:
            try await uploadToS3(fileURL: fileURL, target: target, progress: progress)
        case .http:
            try await uploadToHTTP(fileURL: fileURL, target: target, progress: progress)
        case .pictrs:
            try await uploadToPictrs(fileURL: fileURL, target: target, progress: progress)
        case .local:
            try await uploadToLocal(fileURL: fileURL, target: target, progress: progress)
        }
        
        progress?(1.0)
    }
    
    /// Lädt mehrere Dateien hoch
    func uploadBatch(fileURLs: [URL], to target: UploadTarget, progress: ((Int, Int) -> Void)? = nil) async throws {
        for (index, url) in fileURLs.enumerated() {
            try await upload(fileURL: url, to: target) { _ in
                progress?(index + 1, fileURLs.count)
            }
        }
    }
    
    // MARK: - FTP Upload
    
    private func uploadToFTP(fileURL: URL, target: UploadTarget, progress: ((Double) -> Void)?) async throws {
        guard let _ = target.ftpHost,
              let _ = target.ftpUsername,
              let _ = target.ftpPassword else {
            throw UploadError.missingCredentials
        }
        
        // FTP Upload würde hier implementiert werden
        // Für eine vollständige Implementierung würde man eine FTP-Library verwenden
        // z.B. libcurl oder eine Swift FTP Library
        
        // Placeholder - würde in echter Implementierung FTP-Connection aufbauen
        try await Task.sleep(nanoseconds: 500_000_000) // Simuliere Upload
        
        progress?(0.9)
    }
    
    // MARK: - SFTP Upload
    
    private func uploadToSFTP(fileURL: URL, target: UploadTarget, progress: ((Double) -> Void)?) async throws {
        guard let hostRaw = target.ftpHost?.trimmingCharacters(in: .whitespacesAndNewlines),
              !hostRaw.isEmpty,
              let usernameRaw = target.ftpUsername?.trimmingCharacters(in: .whitespacesAndNewlines),
              !usernameRaw.isEmpty else {
            throw UploadError.missingCredentials
        }
        
        let host = hostRaw
        let username = usernameRaw
        let port = target.ftpPort ?? 22
        let remoteDirRaw = (target.ftpPath ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        
        // Auth (Password oder Key). Für Key-basierte Auth empfehlen wir einen *unverschlüsselten* Key oder ssh-agent.
        let password = target.ftpPassword?.trimmingCharacters(in: .whitespacesAndNewlines)
        let privateKey = target.ftpPrivateKey?.trimmingCharacters(in: .whitespacesAndNewlines)
        let hasPassword = (password?.isEmpty == false)
        let hasPrivateKey = (privateKey?.isEmpty == false)
        
        guard hasPassword || hasPrivateKey else {
            throw UploadError.missingCredentials
        }
        
        progress?(0.05)
        
        // Build batch commands (mkdir -p like, then put)
        let remoteDir = normalizeRemoteDirectory(remoteDirRaw)
        let remoteFile = buildRemoteFilePath(directory: remoteDir, fileName: fileURL.lastPathComponent)
        let batch = buildSFTPBatchCommands(remoteDirectory: remoteDir, remoteFilePath: remoteFile, localFilePath: fileURL.path)
        
        // Known hosts file inside Application Support (keeps sandbox-friendly + avoids ~/.ssh writes)
        let knownHostsURL = try ensureKnownHostsFile()
        
        // Prepare temporary key file / askpass (for password or key passphrase)
        var keyURL: URL? = nil
        var askpassURL: URL? = nil
        defer {
            if let keyURL { try? FileManager.default.removeItem(at: keyURL) }
            if let askpassURL { try? FileManager.default.removeItem(at: askpassURL) }
        }
        
        if let privateKey, !privateKey.isEmpty {
            keyURL = try writeTemporaryPrivateKey(privateKey)
        }
        if let password, !password.isEmpty {
            askpassURL = try writeTemporaryAskPassScript(password)
        }
        
        progress?(0.15)
        
        try await runSFTPProcess(
            host: host,
            port: port,
            username: username,
            knownHostsURL: knownHostsURL,
            identityFileURL: keyURL,
            askpassScriptURL: askpassURL,
            batchCommands: batch,
            progress: progress
        )
    }
    
    // MARK: - S3 Upload
    
    private func uploadToS3(fileURL: URL, target: UploadTarget, progress: ((Double) -> Void)?) async throws {
        guard let _ = target.s3Bucket,
              let _ = target.s3AccessKey,
              let _ = target.s3SecretKey else {
            throw UploadError.missingCredentials
        }
        
        // S3 Upload würde hier implementiert werden
        // Für eine vollständige Implementierung würde man AWS SDK verwenden
        
        // Placeholder - würde in echter Implementierung S3-API aufrufen
        try await Task.sleep(nanoseconds: 500_000_000) // Simuliere Upload
        
        progress?(0.9)
    }
    
    // MARK: - HTTP Upload
    
    private func uploadToHTTP(fileURL: URL, target: UploadTarget, progress: ((Double) -> Void)?) async throws {
        guard let urlString = target.httpURL,
              let url = URL(string: urlString) else {
            throw UploadError.invalidURL
        }
        
        let fileData = try Data(contentsOf: fileURL)
        
        var request = URLRequest(url: url)
        request.httpMethod = target.httpMethod ?? "POST"
        
        // Headers
        if let headers = target.httpHeaders {
            for (key, value) in headers {
                request.setValue(value, forHTTPHeaderField: key)
            }
        }
        
        // Auth Token
        if let token = target.httpAuthToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        // Multipart Form Data
        let boundary = UUID().uuidString
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        var body = Data()
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"file\"; filename=\"\(fileURL.lastPathComponent)\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: application/octet-stream\r\n\r\n".data(using: .utf8)!)
        body.append(fileData)
        body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)
        
        request.httpBody = body
        
        progress?(0.5)
        
        let (_, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse,
              (200...299).contains(httpResponse.statusCode) else {
            throw UploadError.uploadFailed
        }
        
        progress?(0.9)
    }
    
    // MARK: - Pictrs Upload
    
    private func uploadToPictrs(fileURL: URL, target: UploadTarget, progress: ((Double) -> Void)?) async throws {
        guard let pictrsURL = target.pictrsURL,
              let url = URL(string: pictrsURL) else {
            throw UploadError.invalidURL
        }
        
        let fileData = try Data(contentsOf: fileURL)
        let fileName = fileURL.lastPathComponent
        
        // Pictrs API: POST /image
        let uploadURL = url.appendingPathComponent("image")
        
        var request = URLRequest(url: uploadURL)
        request.httpMethod = "POST"
        
        // Content-Type
        request.setValue("multipart/form-data", forHTTPHeaderField: "Content-Type")
        
        // Auth Token falls vorhanden
        if let token = target.pictrsAuthToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }
        
        // Multipart Form Data
        let boundary = UUID().uuidString
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        var body = Data()
        body.append("--\(boundary)\r\n".data(using: .utf8)!)
        body.append("Content-Disposition: form-data; name=\"images[]\"; filename=\"\(fileName)\"\r\n".data(using: .utf8)!)
        body.append("Content-Type: image/jpeg\r\n\r\n".data(using: .utf8)!)
        body.append(fileData)
        body.append("\r\n--\(boundary)--\r\n".data(using: .utf8)!)
        
        request.httpBody = body
        
        progress?(0.5)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        
        guard let httpResponse = response as? HTTPURLResponse else {
            throw UploadError.uploadFailed
        }
        
        if !(200...299).contains(httpResponse.statusCode) {
            let errorMessage = String(data: data, encoding: .utf8) ?? "Unknown error"
            print("Pictrs upload failed: \(errorMessage)")
            throw UploadError.uploadFailed
        }
        
        // Parse Response (Pictrs gibt JSON zurück mit image URLs)
        if let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            print("Pictrs upload successful: \(json)")
        }
        
        progress?(0.9)
    }
    
    // MARK: - Local Upload (Kopieren)
    
    private func uploadToLocal(fileURL: URL, target: UploadTarget, progress: ((Double) -> Void)?) async throws {
        guard let path = target.ftpPath else {
            throw UploadError.missingPath
        }
        
        let destinationURL = URL(fileURLWithPath: path).appendingPathComponent(fileURL.lastPathComponent)
        
        let fileManager = FileManager.default
        try fileManager.createDirectory(at: destinationURL.deletingLastPathComponent(), withIntermediateDirectories: true)
        
        progress?(0.5)
        
        try fileManager.copyItem(at: fileURL, to: destinationURL)
        
        progress?(0.9)
    }
}

enum UploadError: LocalizedError {
    case targetDisabled
    case missingCredentials
    case invalidURL
    case uploadFailed
    case missingPath
    case unsupportedAuthentication
    
    var errorDescription: String? {
        switch self {
        case .targetDisabled:
            return "Upload-Ziel ist deaktiviert"
        case .missingCredentials:
            return "Fehlende Anmeldedaten"
        case .invalidURL:
            return "Ungültige URL"
        case .uploadFailed:
            return "Upload fehlgeschlagen"
        case .missingPath:
            return "Fehlender Pfad"
        case .unsupportedAuthentication:
            return "SFTP Authentifizierung nicht unterstützt (bitte SSH-Key/ssh-agent verwenden)"
        }
    }
}

// MARK: - SFTP helpers (OpenSSH `sftp` batch mode)

private extension UploadService {
    /// Normalizes user-entered remote path. Supports:
    /// - empty → "."
    /// - "~/" prefix → treated as relative to home (remove "~/" )
    private func normalizeRemoteDirectory(_ raw: String) -> String {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return "." }
        if trimmed == "~" { return "." }
        if trimmed.hasPrefix("~/") { return String(trimmed.dropFirst(2)) }
        return trimmed
    }
    
    private func buildRemoteFilePath(directory: String, fileName: String) -> String {
        guard directory != ".", !directory.isEmpty else { return fileName }
        if directory.hasSuffix("/") { return directory + fileName }
        return directory + "/" + fileName
    }
    
    private func buildSFTPBatchCommands(remoteDirectory: String, remoteFilePath: String, localFilePath: String) -> String {
        var lines: [String] = []
        
        // Create directory structure (best-effort, ignore errors with '-' prefix).
        if remoteDirectory != ".", !remoteDirectory.isEmpty {
            let mkdirs = remoteMkdirCommands(for: remoteDirectory)
            lines.append(contentsOf: mkdirs)
        }
        
        // Upload (quote paths for safety)
        lines.append("put \"\(escapeForBatch(localFilePath))\" \"\(escapeForBatch(remoteFilePath))\"")
        lines.append("bye")
        
        return lines.joined(separator: "\n") + "\n"
    }
    
    private func escapeForBatch(_ s: String) -> String {
        // In sftp batch files, we mainly need to escape quotes/backslashes.
        s
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "\"", with: "\\\"")
    }
    
    private func remoteMkdirCommands(for remoteDirectory: String) -> [String] {
        // Support absolute (/a/b) and relative (a/b). "~/" was normalized earlier.
        let isAbsolute = remoteDirectory.hasPrefix("/")
        let comps = remoteDirectory
            .split(separator: "/")
            .map(String.init)
            .filter { !$0.isEmpty && $0 != "." }
        guard !comps.isEmpty else { return [] }
        
        var out: [String] = []
        out.reserveCapacity(comps.count)
        
        var current = isAbsolute ? "" : ""
        for c in comps {
            if isAbsolute {
                current = current + "/" + c
            } else {
                current = current.isEmpty ? c : (current + "/" + c)
            }
            // '-' prefix: ignore errors (already exists)
            out.append("-mkdir \"\(escapeForBatch(current))\"")
        }
        return out
    }
    
    private func ensureKnownHostsFile() throws -> URL {
        let fm = FileManager.default
        let base = fm.urls(for: .applicationSupportDirectory, in: .userDomainMask).first
            ?? fm.temporaryDirectory
        let dir = base.appendingPathComponent("WB Foto Manager", isDirectory: true)
        try fm.createDirectory(at: dir, withIntermediateDirectories: true)
        let file = dir.appendingPathComponent("known_hosts", isDirectory: false)
        if !fm.fileExists(atPath: file.path) {
            fm.createFile(atPath: file.path, contents: Data(), attributes: nil)
        }
        return file
    }
    
    private func writeTemporaryPrivateKey(_ key: String) throws -> URL {
        let fm = FileManager.default
        let url = fm.temporaryDirectory.appendingPathComponent("wb_sftp_key_\(UUID().uuidString)")
        try key.data(using: .utf8)?.write(to: url, options: [.atomic])
        // Restrict permissions: 0600
        try fm.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
        return url
    }
    
    private func writeTemporaryAskPassScript(_ secret: String) throws -> URL {
        let fm = FileManager.default
        let url = fm.temporaryDirectory.appendingPathComponent("wb_askpass_\(UUID().uuidString).sh")
        // Minimal askpass: print secret (password or key passphrase)
        let script = "#!/bin/sh\n" +
        "printf '%s' \"\(escapeForShell(secret))\"\n"
        try script.data(using: .utf8)?.write(to: url, options: [.atomic])
        try fm.setAttributes([.posixPermissions: 0o700], ofItemAtPath: url.path)
        return url
    }
    
    private func escapeForShell(_ s: String) -> String {
        // Very small escape for double-quoted string inside sh.
        s
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "\"", with: "\\\"")
            .replacingOccurrences(of: "$", with: "\\$")
            .replacingOccurrences(of: "`", with: "\\`")
    }
    
    private func runSFTPProcess(
        host: String,
        port: Int,
        username: String,
        knownHostsURL: URL,
        identityFileURL: URL?,
        askpassScriptURL: URL?,
        batchCommands: String,
        progress: ((Double) -> Void)?
    ) async throws {
        // `sftp` is installed on macOS as part of OpenSSH.
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/bin/sftp")
        
        var args: [String] = []
        args += ["-o", "StrictHostKeyChecking=accept-new"]
        args += ["-o", "UserKnownHostsFile=\(knownHostsURL.path)"]
        args += ["-o", "ConnectTimeout=12"]
        args += ["-o", "ServerAliveInterval=10"]
        args += ["-o", "ServerAliveCountMax=2"]
        
        if let identityFileURL {
            args += ["-i", identityFileURL.path]
        }
        
        // Password/Passphrase support via SSH_ASKPASS (non-interactive).
        if askpassScriptURL == nil {
            // Non-interactive: do not prompt.
            args += ["-o", "BatchMode=yes"]
        } else {
            // Allow prompts (handled by askpass).
            args += ["-o", "BatchMode=no"]
            args += ["-o", "NumberOfPasswordPrompts=1"]
        }
        
        args += ["-P", "\(port)"]
        args += ["-b", "-"] // read batch from stdin
        args += ["\(username)@\(host)"]
        
        process.arguments = args
        
        // Pipes
        let stdin = Pipe()
        let stdout = Pipe()
        let stderr = Pipe()
        process.standardInput = stdin
        process.standardOutput = stdout
        process.standardError = stderr
        
        // Environment for askpass (if provided)
        var env = ProcessInfo.processInfo.environment
        if let askpassScriptURL {
            env["SSH_ASKPASS"] = askpassScriptURL.path
            env["SSH_ASKPASS_REQUIRE"] = "force"
            // Non-empty DISPLAY triggers askpass usage in OpenSSH even without GUI.
            env["DISPLAY"] = "1"
        }
        process.environment = env
        
        // Stream output to parse progress
        var lineBuffer = ""
        let parseChunk: (Data) -> Void = { data in
            guard !data.isEmpty else { return }
            let chunk = String(decoding: data, as: UTF8.self)
            lineBuffer.append(chunk)
            
            while let range = lineBuffer.range(of: "\n") {
                let line = String(lineBuffer[..<range.lowerBound])
                lineBuffer.removeSubrange(..<range.upperBound)
                if let pct = self.extractPercent(from: line) {
                    progress?(Double(pct) / 100.0)
                }
            }
        }
        
        stdout.fileHandleForReading.readabilityHandler = { fh in
            let data = fh.availableData
            if data.isEmpty { fh.readabilityHandler = nil; return }
            parseChunk(data)
        }
        stderr.fileHandleForReading.readabilityHandler = { fh in
            let data = fh.availableData
            if data.isEmpty { fh.readabilityHandler = nil; return }
            parseChunk(data)
        }
        
        // Start
        try process.run()
        
        // Write batch and close stdin
        if let data = batchCommands.data(using: .utf8) {
            stdin.fileHandleForWriting.write(data)
        }
        try? stdin.fileHandleForWriting.close()
        
        // Await completion
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            process.terminationHandler = { proc in
                stdout.fileHandleForReading.readabilityHandler = nil
                stderr.fileHandleForReading.readabilityHandler = nil
                
                let status = proc.terminationStatus
                if status == 0 {
                    continuation.resume(returning: ())
                } else {
                    continuation.resume(throwing: UploadError.uploadFailed)
                }
            }
            
            // Cancellation: terminate process
            Task {
                while !Task.isCancelled {
                    try? await Task.sleep(nanoseconds: 150_000_000)
                }
                if process.isRunning {
                    process.terminate()
                }
            }
        }
    }
    
    private func extractPercent(from line: String) -> Int? {
        // Typical OpenSSH sftp progress line: "file.jpg  42%  1234KB  1.2MB/s 00:01"
        guard let pctIndex = line.firstIndex(of: "%") else { return nil }
        // Walk backwards to find digits before '%'
        var i = pctIndex
        var digits = ""
        while i > line.startIndex {
            i = line.index(before: i)
            let ch = line[i]
            if ch.isNumber {
                digits.insert(ch, at: digits.startIndex)
            } else {
                break
            }
        }
        if digits.isEmpty { return nil }
        return Int(digits)
    }
}

