//
//  ContentAwareCropService.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import CoreImage
import Vision

/// Service für Content-Aware Cropping mit Gesichtserkennung
class ContentAwareCropService {
    static let shared = ContentAwareCropService()
    
    private init() {}
    
    enum CropMode {
        case faceDetection // Automatisches Cropping auf Gesichter
        case center // Cropping auf Bildmitte mit Skalierung
    }
    
    /// Erkennt Gesichter im Bild und gibt Crop-Rect zurück
    func detectFacesAndCrop(image: CIImage, mode: CropMode = .faceDetection) -> CGRect? {
        guard let cgImage = CIContext().createCGImage(image, from: image.extent) else {
            return nil
        }
        
        let request = VNDetectFaceRectanglesRequest()
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        
        do {
            try handler.perform([request])
            
            guard let observations = request.results,
                  !observations.isEmpty else {
                // Keine Gesichter gefunden - verwende Center-Mode
                if mode == .center {
                    return centerCropRect(for: image.extent)
                }
                return nil
            }
            
            // Finde das größte Gesicht oder kombiniere mehrere Gesichter
            let largestFace = observations.max { $0.boundingBox.width * $0.boundingBox.height < $1.boundingBox.width * $1.boundingBox.height }
            
            guard let face = largestFace else {
                return mode == .center ? centerCropRect(for: image.extent) : nil
            }
            
            // Konvertiere Normalized Coordinates zu Image Coordinates
            let imageSize = image.extent.size
            let faceRect = VNImageRectForNormalizedRect(
                face.boundingBox,
                Int(imageSize.width),
                Int(imageSize.height)
            )
            
            // Erweitere Crop-Rect um Padding
            let padding: CGFloat = 0.2 // 20% Padding
            let expandedRect = CGRect(
                x: max(0, faceRect.origin.x - faceRect.width * padding),
                y: max(0, faceRect.origin.y - faceRect.height * padding),
                width: min(imageSize.width - faceRect.origin.x, faceRect.width * (1 + 2 * padding)),
                height: min(imageSize.height - faceRect.origin.y, faceRect.height * (1 + 2 * padding))
            )
            
            return expandedRect
            
        } catch {
            print("Face detection error: \(error)")
            return mode == .center ? centerCropRect(for: image.extent) : nil
        }
    }
    
    /// Erstellt ein Center-Crop-Rect
    private func centerCropRect(for extent: CGRect) -> CGRect {
        let size = extent.size
        let minDimension = min(size.width, size.height)
        let centerX = size.width / 2
        let centerY = size.height / 2
        
        return CGRect(
            x: centerX - minDimension / 2,
            y: centerY - minDimension / 2,
            width: minDimension,
            height: minDimension
        )
    }
}

