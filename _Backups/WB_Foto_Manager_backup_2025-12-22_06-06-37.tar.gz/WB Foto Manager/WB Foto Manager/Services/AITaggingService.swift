//
//  AITaggingService.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 15.12.2025.
//

import Foundation
import CoreImage
import Vision
import AppKit
import Photos

/// AI-basierter Service für automatische Keyword-Generierung via Vision Framework
nonisolated final class AITaggingService {
    static let shared = AITaggingService()
    
    private init() {}
    
    enum KeywordMode: Sendable {
        /// Präziser (weniger Noise) – geeignet zum Schreiben von IPTC Keywords.
        case metadata
        /// Mehr Recall (etwas mehr Noise ok) – geeignet für lokale AI-Suche/Filter.
        case search
    }
    
    /// Analysiert ein Bild und generiert automatische Keywords
    func generateKeywords(for photo: PhotoItem, mode: KeywordMode = .metadata) async -> [String] {
        let image: CIImage
        if let cached = await MainActor.run(body: { photo.loadFullImage() }) {
            image = cached
        } else if let loaded = await photo.loadFullImageAsync() {
            image = loaded
        } else {
            return []
        }
        
        return await Task.detached(priority: .userInitiated) { [weak self] in
            guard let self else { return [] }
            return self.generateKeywords(from: image, mode: mode)
        }.value
    }

    /// Generiert Keywords für eine URL (Datei oder Photos-Library Asset) – ideal für AI-Suche/Indexing.
    /// Für PhotoKit Assets wird bewusst ein **final/high-quality** Bild angefordert (degraded ist oft zu klein für Tiere).
    /// Für Files nutzen wir den `SmartImageLoader` (inkl. Fallback, wenn Embedded-Thumbnails zu klein sind).
    func generateKeywords(for url: URL, previewSize: PreviewSize = .medium, mode: KeywordMode = .search) async -> [String] {
        let image: NSImage?
        
        if let assetID = PHAssetURL.localIdentifier(from: url) {
            image = await loadPhotoKitFinalImage(assetLocalIdentifier: assetID, targetSize: previewSize.size)
        } else {
            // SmartImageLoader ist @MainActor (Cache/Notifications) – `await` hoppt sauber auf den MainActor.
            image = await SmartImageLoader.shared.loadImage(url: url, previewSize: previewSize)
        }
        
        guard let image, let ci = ciImage(from: image) else { return [] }

        return await Task.detached(priority: .userInitiated) { [weak self] in
            guard let self else { return [] }
            return self.generateKeywords(from: ci, mode: mode)
        }.value
    }

    private func loadPhotoKitFinalImage(assetLocalIdentifier: String, targetSize: CGSize) async -> NSImage? {
        let fetched = PHAsset.fetchAssets(withLocalIdentifiers: [assetLocalIdentifier], options: nil)
        guard let asset = fetched.firstObject else { return nil }
        
        let options = PHImageRequestOptions()
        options.isNetworkAccessAllowed = true
        options.deliveryMode = .highQualityFormat
        options.resizeMode = .exact
        options.version = .current
        options.isSynchronous = false
        
        return await withCheckedContinuation { continuation in
            var didResume = false
            var bestDegraded: NSImage?
            
            PHImageManager.default().requestImage(
                for: asset,
                targetSize: targetSize,
                contentMode: .aspectFit,
                options: options
            ) { image, info in
                let cancelled = (info?[PHImageCancelledKey] as? Bool) ?? false
                let degraded = (info?[PHImageResultIsDegradedKey] as? Bool) ?? false
                
                if cancelled {
                    if !didResume {
                        didResume = true
                        continuation.resume(returning: bestDegraded)
                    }
                    return
                }
                
                guard let img = image else { return }
                
                if degraded {
                    bestDegraded = img
                    return
                }
                
                // Finales Bild
                if !didResume {
                    didResume = true
                    continuation.resume(returning: img)
                }
            }
            
            // Safety: falls iCloud sehr langsam ist, gib nach kurzer Zeit zumindest das beste degraded zurück.
            Task {
                try? await Task.sleep(nanoseconds: 8_000_000_000)
                if !didResume {
                    didResume = true
                    continuation.resume(returning: bestDegraded)
                }
            }
        }
    }
    
    /// Analysiert ein CIImage und gibt relevante Keywords zurück
    private func generateKeywords(from image: CIImage, mode: KeywordMode) -> [String] {
        // Such-Mode: etwas lockerer (mehr Recall)
        let (sceneTopLimit, sceneTop3Min, sceneRestMin, roiTopLimit, roiTop3Min, roiRestMin): (Int, Float, Float, Int, Float, Float) = {
            switch mode {
            case .metadata:
                return (12, 0.25, 0.45, 10, 0.20, 0.35)
            case .search:
                // Hunde/Tiere sind oft unter 0.45 Confidence → hier bewusst lockerer.
                return (18, 0.18, 0.28, 14, 0.16, 0.24)
            }
        }()
        
        // Work on a downscaled copy for Vision (much faster, usually same/better accuracy).
        let analysisImage: CIImage = {
            let extent = image.extent
            let maxDim = max(extent.width, extent.height)
            // AI Search soll schnell sein: kleineres Target reduziert Vision-Laufzeit deutlich.
            // AI Keywords (Metadata) darf etwas höher sein (bessere Accuracy).
            let targetMax: CGFloat = (mode == .search) ? 1200 : 1800
            guard maxDim > targetMax, maxDim > 0 else { return image }
            let scale = targetMax / maxDim
            return image.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        }()
        
        let extent = analysisImage.extent
        guard extent.width > 0, extent.height > 0 else { return [] }
        
        // Convert CIImage → CGImage for Vision
        let context = CIContext(options: [.useSoftwareRenderer: false])
        guard let cgImage = context.createCGImage(analysisImage, from: extent) else {
            return []
        }
        
        var keywords: Set<String> = []
        
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])

        // Gender-Labels kommen in VNClassifyImageRequest oft mit sehr niedriger Confidence.
        // Für die Suche wollen wir mehr Recall – aber NUR für echte Gender-Tokens.
        let genderTop3Min: Float = 0.10
        let genderRestMin: Float = 0.14
        
        func isGenderCandidateLabel(_ normalizedLabel: String) -> Bool {
            let lower = normalizedLabel.lowercased()
            let tokens = Set(
                lower.split(whereSeparator: { !$0.isLetter })
                    .map { String($0) }
            )
            return tokens.contains("woman") || tokens.contains("women") || tokens.contains("female") || tokens.contains("lady") || tokens.contains("girl")
                || tokens.contains("man") || tokens.contains("men") || tokens.contains("male") || tokens.contains("guy") || tokens.contains("boy")
        }
        
        func addKeywords(from results: [VNClassificationObservation], topLimit: Int, top3Min: Float, restMin: Float) {
            let top = Array(results.prefix(topLimit))
            for (idx, observation) in top.enumerated() {
                let confidence = observation.confidence
                let baseMin: Float = (idx < 3) ? top3Min : restMin
                let genderMin: Float = (idx < 3) ? genderTop3Min : genderRestMin
                
                // Unterhalb des (niedrigeren) Gender-Min lohnt sich das Parsen nicht.
                if confidence < genderMin { continue }
                
                // Identifier kann mehrere Labels enthalten, z.B. "outdoor scene, nature"
                // Wichtig: NICHT an Leerzeichen splitten, sonst geht z.B. "ice hockey" kaputt.
                let labels = observation.identifier
                    .split(separator: ",")
                    .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
                    .filter { !$0.isEmpty }
                
                for label in labels {
                    let normalized = normalizeLabel(label)
                    guard isUsefulKeyword(normalized) else { continue }
                    
                    // Zwischen genderMin…baseMin akzeptieren wir NUR Gender-Tokens (Search-Mode).
                    if confidence < baseMin {
                        guard mode == .search else { continue }
                        guard isGenderCandidateLabel(normalized) else { continue }
                    }
                    keywords.insert(translateToGerman(normalized))
                    
                    // Extra-Inferenz für robustere Suche (z.B. "Siberian Husky" → auch "Hund").
                    for extra in inferExtraKeywords(from: normalized) {
                        keywords.insert(extra)
                    }
                }
            }
        }
        
        // 1) Scene Classification (Hauptquelle für Keywords)
        do {
            let classifyRequest = VNClassifyImageRequest()
            try handler.perform([classifyRequest])
            
            if let results = classifyRequest.results, !results.isEmpty {
                addKeywords(from: results, topLimit: sceneTopLimit, top3Min: sceneTop3Min, restMin: sceneRestMin)
            }
        } catch {
            // ignore
        }
        
        // 1.1) Saliency → ROI Classification (hilft bei kleinen Motiven wie Vögeln)
        // Für AI Suche skippen wir das bewusst (Performance) – die Scene-Tags reichen für die meisten Workflows.
        if mode == .metadata {
            do {
            func classifyROI(_ rect: CGRect) {
                let roi = rect.intersection(extent)
                guard roi.width > 8, roi.height > 8 else { return }
                
                // Padding, damit das Motiv nicht "zu eng" wird.
                let pad: CGFloat = 0.18
                let padded = roi.insetBy(dx: -(roi.width * pad), dy: -(roi.height * pad)).intersection(extent)
                
                let crop = analysisImage.cropped(to: padded)
                guard let cropCG = context.createCGImage(crop, from: crop.extent) else { return }
                
                let h = VNImageRequestHandler(cgImage: cropCG, options: [:])
                let req = VNClassifyImageRequest()
                try? h.perform([req])
                if let r = req.results, !r.isEmpty {
                    // ROI ist oft etwas noisier → thresholds minimal lockerer.
                    addKeywords(from: r, topLimit: roiTopLimit, top3Min: roiTop3Min, restMin: roiRestMin)
                }
            }
            
            // Try attention-based saliency first.
            let saliencyRequest = VNGenerateAttentionBasedSaliencyImageRequest()
            try handler.perform([saliencyRequest])
            if let obs = saliencyRequest.results?.first as? VNSaliencyImageObservation {
                if let rects = obs.salientObjects, !rects.isEmpty {
                    // Pick the most confident ROI(s)
                    for r in rects.prefix(2) {
                        let px = VNImageRectForNormalizedRect(
                            r.boundingBox,
                            Int(extent.width),
                            Int(extent.height)
                        )
                        classifyROI(px)
                    }
                } else {
                    // Fallback: objectness-based saliency (sometimes better for animals)
                    let objectness = VNGenerateObjectnessBasedSaliencyImageRequest()
                    try? handler.perform([objectness])
                    if let o = objectness.results?.first as? VNSaliencyImageObservation {
                        if let rects = o.salientObjects, !rects.isEmpty {
                            for r in rects.prefix(2) {
                                let px = VNImageRectForNormalizedRect(
                                    r.boundingBox,
                                    Int(extent.width),
                                    Int(extent.height)
                                )
                                classifyROI(px)
                            }
                        }
                    }
                }
            }
            } catch {
                // ignore
            }
        }
        
        // 1.2) Animal Detection (Dog/Cat) – deutlich zuverlässiger als reine Scene-Labels für Haustiere.
        do {
            if #available(macOS 11.0, *) {
                let animalRequest = VNRecognizeAnimalsRequest()
                try handler.perform([animalRequest])
                
                if let results = animalRequest.results, !results.isEmpty {
                    for obs in results {
                        // VNRecognizedObjectObservation: Labels enthalten "Dog"/"Cat" etc.
                        let labels = obs.labels.prefix(2)
                        for l in labels {
                            let id = l.identifier.lowercased()
                            if id.contains("dog") {
                                keywords.insert("Hund")
                                keywords.insert("Tier")
                            } else if id.contains("cat") {
                                keywords.insert("Katze")
                                keywords.insert("Tier")
                            }
                        }
                    }
                }
            }
        } catch {
            // ignore
        }
        
        // 2) Face Detection (falls Gesichter vorhanden)
        var hasFaces: Bool = false
        do {
            let faceRequest = VNDetectFaceRectanglesRequest()
            try handler.perform([faceRequest])
            if let faces = faceRequest.results, !faces.isEmpty {
                hasFaces = true
                keywords.insert("Person")
                if faces.count > 1 {
                    keywords.insert("Gruppe")
                }
                
                // "Portrait" nur, wenn Gesichter wirklich prominent sind (sonst bei Sport zu oft falsch).
                let union = faces.reduce(CGRect.null) { acc, face in
                    acc.union(face.boundingBox)
                }
                let area = union.isNull ? 0.0 : (union.width * union.height) // normalized 0...1
                if area >= 0.06 {
                    keywords.insert("Portrait")
                }
                
                // Gender-Inferenz (für präzisere Suche: Frau/Mann)
                // Wichtig: NICHT für Metadaten-Write verwenden (zu fehleranfällig) → nur im Search-Mode.
                if mode == .search {
                    let gender = inferGenderFromFaces(
                        faces: faces,
                        analysisImage: analysisImage,
                        extent: extent,
                        context: context
                    )
                    
                    if gender.hasFemale {
                        keywords.insert("Frau")
                    }
                    if gender.hasMale {
                        keywords.insert("Mann")
                    }
                    if gender.hasGirl {
                        keywords.insert("Mädchen")
                        // Für Suche: Mädchen gehört meist zur Kategorie "Frau" (bessere Usability, vermeidet 0 Treffer).
                        keywords.insert("Frau")
                    }
                    if gender.hasBoy {
                        keywords.insert("Kind")
                    }
                }
            } else {
                // Fallback: auch ohne Gesicht können Menschen im Bild sein (Sport, Rückenansichten)
                if #available(macOS 10.15, *) {
                    let humanRequest = VNDetectHumanRectanglesRequest()
                    try? handler.perform([humanRequest])
                    if let humans = humanRequest.results, !humans.isEmpty {
                        keywords.insert("Person")
                    }
                }
            }
        } catch {
            // ignore
        }
        
        // Wenn keine Gesichter vorhanden sind: entferne Gender-Tags (die wären sonst reine Noise).
        if !hasFaces {
            keywords.remove("Frau")
            keywords.remove("Mann")
            keywords.remove("Mädchen")
        }
        
        // 3) Text Recognition (OCR) – nützlich bei Sport (Jersey/Sponsoren) oder Dokumenten
        // Für AI Suche skippen wir OCR bewusst (Performance). Für "AI Keywords" (Metadata) bleibt es aktiv.
        if mode == .metadata {
            do {
            let textRequest = VNRecognizeTextRequest()
            textRequest.recognitionLevel = .fast
            textRequest.usesLanguageCorrection = true
            textRequest.minimumTextHeight = 0.02
            textRequest.recognitionLanguages = ["de-DE", "en-US"]
            
            try handler.perform([textRequest])
            
            if let observations = textRequest.results, !observations.isEmpty {
                // Wenn Text erkannt wird, mindestens "Text" hinzufügen
                keywords.insert("Text")
                
                var extracted: [String] = []
                extracted.reserveCapacity(12)
                
                for obs in observations.prefix(12) {
                    guard let cand = obs.topCandidates(1).first else { continue }
                    // Strenger, sonst kommen viele OCR-Artefakte.
                    guard cand.confidence >= 0.60 else { continue }
                    extracted.append(cand.string)
                }
                
                // Aus OCR Strings plausible Tokens ziehen (nur alphanumerische Sequenzen).
                let tokens = extractOCRTokens(from: extracted.joined(separator: " "))
                
                var added = 0
                for token in tokens {
                    guard isUsefulOCRToken(token) else { continue }
                    // Brands/Teams als Uppercase speichern (stabiler, weniger Duplikate)
                    let out = token.uppercased()
                    keywords.insert(out)
                    added += 1
                    if added >= 3 { break }
                }
            }
            } catch {
                // ignore
            }
        }
        
        // 4) Kontext-Postfilter: bei klarer Sport-Szene generische Gebäude/Struktur-Wörter reduzieren
        if keywords.contains("Eishockey") || keywords.contains("Sport") || keywords.contains("Mannschaftssport") {
            keywords.remove("Gebäude")
            keywords.remove("Struktur")
            keywords.remove("Architektur")
        }
        
        // Sortiere Keywords alphabetisch und gib als Array zurück
        return Array(keywords).sorted()
    }

    private func ciImage(from image: NSImage) -> CIImage? {
        // Prefer CGImage path (keine TIFF-Reencode Runde).
        var rect = CGRect(origin: .zero, size: image.size)
        if let cg = image.cgImage(forProposedRect: &rect, context: nil, hints: nil) {
            return CIImage(cgImage: cg)
        }
        // Fallback: TIFF
        if let data = image.tiffRepresentation {
            return CIImage(data: data)
        }
        return nil
    }
    
    /// Einfache Übersetzung englischer Vision-Keywords ins Deutsche
    private func translateToGerman(_ english: String) -> String {
        let lower = english.lowercased()
        
        // Phrase translations first (mehr Genauigkeit, v.a. Sport)
        // IMPORTANT: dup-safe build, damit ein versehentlicher Duplicate-Key NICHT mehr crasht.
        let phrasePairs: [(String, String)] = [
            ("ice hockey", "Eishockey"),
            ("hockey", "Eishockey"),
            ("ice rink", "Eisbahn"),
            ("hockey rink", "Eishalle"),
            ("rink", "Eisbahn"),
            ("sports arena", "Arena"),
            ("arena", "Arena"),
            ("sport", "Sport"),
            ("sports", "Sport"),
            ("recreation", "Freizeit"),
            ("building", "Gebäude"),
            ("structure", "Struktur"),
            ("team sport", "Mannschaftssport"),
            ("stadium", "Stadion"),
            // Wildlife / Nature
            ("bird", "Vogel"),
            ("perching bird", "Vogel"),
            ("songbird", "Singvogel"),
            ("bird of prey", "Greifvogel"),
            ("raptor", "Greifvogel"),
            ("eagle", "Adler"),
            ("hawk", "Greifvogel"),
            ("falcon", "Falke"),
            ("owl", "Eule"),
            ("branch", "Ast"),
            ("twig", "Zweig"),
            ("plant", "Pflanze"),
            ("foliage", "Laub"),
            ("tree branch", "Ast"),
            ("indoor", "Drinnen"),
            ("outdoor", "Draußen"),
            ("night", "Nacht"),
            ("day", "Tag"),
            ("sunset", "Sonnenuntergang"),
            ("sunrise", "Sonnenaufgang"),
            ("landscape", "Landschaft"),
            ("nature", "Natur"),
            ("city", "Stadt"),
            ("architecture", "Architektur"),
            ("sky", "Himmel"),
            ("cloud", "Wolke"),
            ("snow", "Schnee"),
            ("winter", "Winter"),
            ("forest", "Wald"),
            ("tree", "Baum"),
            ("flower", "Blume"),
            ("flowers", "Blumen"),
            ("animal", "Tier"),
            ("dog", "Hund"),
            ("husky", "Husky"),
            ("cat", "Katze"),
            ("wolf", "Wolf"),
            ("woman", "Frau"),
            ("women", "Frau"),
            ("female", "Frau"),
            ("lady", "Frau"),
            ("man", "Mann"),
            ("men", "Mann"),
            ("male", "Mann"),
            ("girl", "Mädchen"),
            ("boy", "Kind"),
            ("child", "Kind"),
            ("children", "Kinder"),
            ("family", "Familie"),
            ("baby", "Baby"),
            ("infant", "Baby"),
            ("wedding", "Hochzeit"),
            ("bride", "Hochzeit"),
            ("groom", "Hochzeit"),
            ("christmas", "Weihnachten"),
            ("xmas", "Weihnachten"),
            ("easter", "Ostern"),
            ("car", "Auto"),
            ("vehicle", "Auto"),
            ("automobile", "Auto"),
            ("motorcycle", "Motorrad"),
            ("motorbike", "Motorrad"),
            ("motocross", "Motocross"),
            ("dirt bike", "Motocross"),
            ("water", "Wasser"),
            ("sea", "Wasser"),
            ("ocean", "Wasser"),
            ("beach", "Strand"),
            ("house", "Haus"),
            ("home", "Haus"),
            ("garden", "Garten"),
            ("heart", "Herz"),
            ("team", "Team"),
            ("couple", "Paar"),
            ("laugh", "lachen"),
            ("laughing", "lachen"),
            ("smile", "lachen"),
            ("smiling", "lachen"),
            ("business", "Business"),
            ("office", "Business"),
            ("computer", "Computer"),
            ("laptop", "Computer"),
            ("coffee", "Kaffee"),
            ("wine", "Wein"),
            ("mountain", "Berge"),
            ("mountains", "Berge"),
            ("wilderness", "Wildnis"),
            ("soccer", "Fussball"),
            ("football", "Fussball"),
            ("food", "Essen"),
            ("restaurant", "Restaurant"),
            ("document", "Dokument"),
            ("text", "Text"),
            ("person", "Person"),
            ("people", "Personen"),
            ("group", "Gruppe"),
            ("portrait", "Portrait")
        ]
        
        var phrase: [String: String] = [:]
        phrase.reserveCapacity(phrasePairs.count)
        for (k, v) in phrasePairs {
            phrase[k] = v
        }
        
        if let t = phrase[lower] {
            return t
        }
        
        // If it's a short phrase we don't know, keep it readable (Title Case)
        return titleCase(english)
    }
    
    // MARK: - Normalization / Filtering
    
    private func normalizeLabel(_ s: String) -> String {
        let cleaned = s
            .replacingOccurrences(of: "_", with: " ")
            .replacingOccurrences(of: "  ", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return cleaned
    }
    
    /// Ergänzt robuste Oberbegriffe/Synonyme für die Suche.
    /// Beispiel: "Siberian Husky" → ["Hund","Husky"] (damit Suche nach "Hund" funktioniert, auch wenn Vision nur die Rasse liefert).
    private func inferExtraKeywords(from normalizedLabel: String) -> [String] {
        let lower = normalizedLabel.lowercased()
        
        // Dog / Breeds (minimal, zielgerichtet)
        if lower.contains("husky") {
            return ["Hund", "Husky", "Tier"]
        }
        if lower.contains("dog") || lower.contains("puppy") || lower.contains("canine") {
            return ["Hund", "Tier"]
        }
        
        // Cat
        if lower.contains("cat") || lower.contains("kitten") || lower.contains("feline") {
            return ["Katze", "Tier"]
        }
        
        return []
    }
    
    // MARK: - Gender (Face-ROI) – nur für Search-Mode
    
    private struct GenderSignals: Sendable {
        var hasFemale: Bool = false
        var hasMale: Bool = false
        var hasGirl: Bool = false
        var hasBoy: Bool = false
    }
    
    private enum GenderGuess {
        case female
        case male
        case girl
        case boy
    }
    
    /// Best-effort Gender-Inferenz via Face-ROI + VNClassifyImageRequest.
    /// - Note: Vision liefert Gender nicht als eigene API; das ist eine Heuristik. Wir sind bewusst **konservativ**,
    ///         damit „Frau“ nicht fälschlich Männer trifft.
    private func inferGenderFromFaces(
        faces: [VNFaceObservation],
        analysisImage: CIImage,
        extent: CGRect,
        context: CIContext
    ) -> GenderSignals {
        guard !faces.isEmpty else { return GenderSignals() }
        
        // Nur die prominentesten Gesichter auswerten (Performance + weniger Noise).
        let rects: [CGRect] = faces.map { face in
            VNImageRectForNormalizedRect(
                face.boundingBox,
                Int(extent.width),
                Int(extent.height)
            )
        }
        let prominent = rects
            .sorted { ($0.width * $0.height) > ($1.width * $1.height) }
            .prefix(3)
        
        var signals = GenderSignals()
        
        for r in prominent {
            // Padding: etwas Kontext hilft (Haare/Schminke/Outfit)
            let pad: CGFloat = 0.28
            let padded = r
                .insetBy(dx: -(r.width * pad), dy: -(r.height * pad))
                .intersection(extent)
            
            guard padded.width >= 28, padded.height >= 28 else { continue }
            
            let crop = analysisImage.cropped(to: padded)
            guard let cropCG = context.createCGImage(crop, from: crop.extent) else { continue }
            
            let handler = VNImageRequestHandler(cgImage: cropCG, options: [:])
            let req = VNClassifyImageRequest()
            try? handler.perform([req])
            guard let results = req.results, !results.isEmpty else { continue }
            
            if let guess = classifyGender(from: results) {
                switch guess {
                case .female: signals.hasFemale = true
                case .male: signals.hasMale = true
                case .girl: signals.hasGirl = true
                case .boy: signals.hasBoy = true
                }
            }
            
            // Früh abbrechen: wenn wir bereits beide haben, reicht es.
            if (signals.hasFemale || signals.hasGirl) && (signals.hasMale || signals.hasBoy) {
                break
            }
        }
        
        return signals
    }
    
    /// Aggressivere Gender-Erkennung für mehr Recall (weniger Präzision, mehr Treffer).
    private func classifyGender(from results: [VNClassificationObservation]) -> GenderGuess? {
        var femaleScore: Float = 0
        var maleScore: Float = 0
        var girlScore: Float = 0
        var boyScore: Float = 0
        var beardScore: Float = 0
        var makeupScore: Float = 0
        
        // Mehr Labels prüfen für bessere Abdeckung
        for o in results.prefix(30) {
            let id = o.identifier.lowercased()
            let c = o.confidence
            
            // Tokenize, damit "woMAN" nicht als "man" zählt etc.
            let tokens = Set(
                id.split(whereSeparator: { !$0.isLetter })
                    .map { String($0) }
            )
            
            // Direkt-Match: wenn Label NUR "woman"/"man" ist (ohne andere Substantive), sehr starkes Signal
            let cleanTokens = tokens.subtracting(["a", "the", "an", "of", "in", "on", "at", "to", "for", "with", "and", "or"])
            if cleanTokens == ["woman"] || cleanTokens == ["female"] || cleanTokens == ["lady"] {
                femaleScore += c * 1.8 // Starker Boost für direkte Matches
            }
            if cleanTokens == ["man"] || cleanTokens == ["male"] || cleanTokens == ["guy"] {
                maleScore += c * 1.8 // Starker Boost für direkte Matches
            }
            
            if tokens.contains("bride") { femaleScore += c * 1.3 }
            if tokens.contains("groom") { maleScore += c * 1.3 }
            
            if tokens.contains("woman") || tokens.contains("women") || tokens.contains("female") || tokens.contains("lady") {
                femaleScore += c
            }
            if tokens.contains("girl") {
                girlScore += c
                femaleScore += c * 0.6
            }
            
            if tokens.contains("man") || tokens.contains("men") || tokens.contains("male") || tokens.contains("guy") {
                maleScore += c
            }
            if tokens.contains("boy") {
                boyScore += c
                maleScore += c * 0.6
            }
            
            // Male signals (facial hair / menswear)
            if tokens.contains("beard") || tokens.contains("bearded") || tokens.contains("stubble") ||
                tokens.contains("mustache") || tokens.contains("moustache") ||
                id.contains("facial hair") {
                beardScore += c
                maleScore += c * 0.9
            }
            if tokens.contains("suit") || tokens.contains("tuxedo") || tokens.contains("necktie") || tokens.contains("tie") || tokens.contains("businessman") {
                maleScore += c * 0.6
            }
            
            // Female signals (makeup / clothing / accessories) – erweitert
            if tokens.contains("makeup") || tokens.contains("lipstick") || tokens.contains("mascara") || tokens.contains("eyeshadow") ||
                tokens.contains("earring") || tokens.contains("earrings") ||
                tokens.contains("dress") || tokens.contains("skirt") ||
                tokens.contains("jewelry") || tokens.contains("necklace") || tokens.contains("purse") || tokens.contains("handbag") ||
                tokens.contains("blouse") || tokens.contains("heels") {
                makeupScore += c
                femaleScore += c * 0.6
            }
        }
        
        // Kinder (nur wenn wirklich stark)
        if girlScore >= 0.45, girlScore > max(maleScore, femaleScore) * 0.85 {
            return .girl
        }
        if boyScore >= 0.45, boyScore > max(maleScore, femaleScore) * 0.85 {
            return .boy
        }
        
        // Erwachsene – SEHR niedrige Schwellen für deutlich mehr Recall
        let minStrong: Float = 0.20  // Sehr niedrig → fast jedes Personen-Foto bekommt Gender
        let delta: Float = 0.08       // Kleiner Delta → weniger Abstand nötig
        
        if femaleScore >= minStrong, femaleScore > maleScore + delta {
            return .female
        }
        if maleScore >= minStrong, maleScore > femaleScore + delta {
            return .male
        }
        
        // Beard-Hard-Rule: wenn "beard" stark ist und male >= female → male (aggressiver)
        if beardScore >= 0.30, maleScore >= 0.18, maleScore >= femaleScore {
            return .male
        }
        
        // Makeup-Hard-Rule: wenn makeup stark ist und female >= male → female
        if makeupScore >= 0.30, femaleScore >= 0.18, femaleScore >= maleScore {
            return .female
        }
        
        return nil
    }
    
    private func isUsefulKeyword(_ s: String) -> Bool {
        let lower = s.lowercased()
        guard lower.count >= 3 else { return false }
        
        // Stopwords / zu generisch
        let stop: Set<String> = [
            "photograph", "photography", "photo", "image", "snapshot",
            "scene", "outdoor scene", "indoor scene", "background", "pattern", "wallpaper", "texture",
            "no person", "nobody",
            // sehr generisch in fast allen Fällen:
            "recreation"
        ]
        if stop.contains(lower) { return false }
        
        // Kein reiner "junk"
        if lower.allSatisfy({ $0.isNumber }) { return false }
        return true
    }
    
    private func extractOCRTokens(from text: String) -> [String] {
        // Extrahiere alphanumerische Sequenzen (Punctuation/Artefakte fallen automatisch weg).
        // Dadurch vermeiden wir Tokens wie "ri_c!_o(" oder "j,".
        let cleaned = text
            .replacingOccurrences(of: "\n", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "©®™"))
        
        var out: [String] = []
        out.reserveCapacity(24)
        
        var current = ""
        current.reserveCapacity(16)
        
        func flush() {
            guard !current.isEmpty else { return }
            out.append(current)
            current.removeAll(keepingCapacity: true)
        }
        
        for ch in cleaned {
            if ch.isLetter || ch.isNumber {
                current.append(ch)
            } else {
                flush()
            }
        }
        flush()
        
        return out
    }
    
    private func isUsefulOCRToken(_ s: String) -> Bool {
        // OCR-Keywords sollen eher "Brands/Teams" sein, sonst wird es schnell noisy.
        // Darum: min. 3 Zeichen, max. 16, muss Buchstaben enthalten, und idealerweise ALLCAPS.
        guard s.count >= 3, s.count <= 16 else { return false }
        
        let lower = s.lowercased()
        if lower.allSatisfy({ $0.isNumber }) { return false }
        guard lower.contains(where: { $0.isLetter }) else { return false }
        
        // Exclude very common tokens
        let stop: Set<String> = ["www", "com", "net", "org", "the", "and", "und", "der", "die", "das", "wb"]
        if stop.contains(lower) { return false }
        
        // Bevorzuge AllCaps (TISSOT, EVZ, HCD, IIHF, ...)
        let isAllCaps = s == s.uppercased()
        let hasDigit = s.contains(where: { $0.isNumber })
        if isAllCaps { return true }
        if hasDigit && s.count >= 4 { return true }
        
        return false
    }
    
    private func titleCase(_ s: String) -> String {
        // Keep acronyms
        if s == s.uppercased(), s.count <= 6 { return s }
        return s
            .split(separator: " ")
            .map { part in
                let w = String(part)
                guard let first = w.first else { return w }
                return String(first).uppercased() + w.dropFirst().lowercased()
            }
            .joined(separator: " ")
    }
    
    /// Batch-Tagging für mehrere Fotos
    func generateKeywordsBatch(for photos: [PhotoItem], progress: @escaping (Int, Int) -> Void) async -> [UUID: [String]] {
        var results: [UUID: [String]] = [:]
        let total = photos.count
        
        for (index, photo) in photos.enumerated() {
            if Task.isCancelled { break }
            let keywords = await generateKeywords(for: photo)
            if Task.isCancelled { break }
            results[photo.id] = keywords
            progress(index + 1, total)
        }
        
        return results
    }
}

