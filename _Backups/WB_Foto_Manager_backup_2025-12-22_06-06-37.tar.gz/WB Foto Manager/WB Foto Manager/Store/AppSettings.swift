//
//  AppSettings.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import SwiftUI
import Combine

class AppSettings: ObservableObject {
    static let shared = AppSettings()
    
    private init() {
        // Load from UserDefaults
        autoOpenLastFolder = UserDefaults.standard.bool(forKey: "autoOpenLastFolder")
        searchSubfolders = UserDefaults.standard.object(forKey: "searchSubfolders") as? Bool ?? true
        saveRatingInXMP = UserDefaults.standard.object(forKey: "saveRatingInXMP") as? Bool ?? true
        autoSaveMetadata = UserDefaults.standard.object(forKey: "autoSaveMetadata") as? Bool ?? false
        autoLoadIPTC = UserDefaults.standard.object(forKey: "autoLoadIPTC") as? Bool ?? true
        backupBeforeOverwrite = UserDefaults.standard.object(forKey: "backupBeforeOverwrite") as? Bool ?? true
        previewQuality = UserDefaults.standard.object(forKey: "previewQuality") as? Double ?? 0.8
        maxCacheSize = UserDefaults.standard.object(forKey: "maxCacheSize") as? Int ?? 1000
        hardwareAcceleration = UserDefaults.standard.object(forKey: "hardwareAcceleration") as? Bool ?? true
        progressiveRendering = UserDefaults.standard.object(forKey: "progressiveRendering") as? Bool ?? true
        defaultExportFormat = UserDefaults.standard.string(forKey: "defaultExportFormat") ?? "jpeg"
        defaultExportQuality = UserDefaults.standard.object(forKey: "defaultExportQuality") as? Double ?? 0.85
        filenameTemplate = UserDefaults.standard.string(forKey: "filenameTemplate") ?? "{originalname}_{preset}"
        theme = UserDefaults.standard.string(forKey: "theme") ?? "dark"
        sidebarAlwaysVisible = UserDefaults.standard.bool(forKey: "sidebarAlwaysVisible")
        showSidebarIcons = UserDefaults.standard.object(forKey: "showSidebarIcons") as? Bool ?? true
        // Legacy: Migriere alte sidebarCompactMode zu beiden Sidebars
        let legacyCompact = UserDefaults.standard.object(forKey: "sidebarCompactMode") as? Bool ?? false
        finderSidebarCompactMode = UserDefaults.standard.object(forKey: "finderSidebarCompactMode") as? Bool ?? legacyCompact
        adjustmentsSidebarCompactMode = UserDefaults.standard.object(forKey: "adjustmentsSidebarCompactMode") as? Bool ?? legacyCompact
        preferWorkflowTopbar = UserDefaults.standard.object(forKey: "preferWorkflowTopbarV1") as? Bool ?? false
        autoAdvanceAfterRating = UserDefaults.standard.object(forKey: "autoAdvanceAfterRating") as? Bool ?? true
        workflowMode = UserDefaults.standard.string(forKey: "workflowMode") ?? "manual"
        bestShotScoringMode = UserDefaults.standard.string(forKey: "bestShotScoringMode") ?? "sport"
        bestOfPickCount = UserDefaults.standard.object(forKey: "bestOfPickCount") as? Int ?? 50
        autoUsesStyleProfile = UserDefaults.standard.object(forKey: "autoUsesStyleProfile") as? Bool ?? false
        autoStylePresetID = UserDefaults.standard.string(forKey: "autoStylePresetID") ?? ""
        recentStylePresetIDs = UserDefaults.standard.stringArray(forKey: "recentStylePresetIDsV1") ?? []
    }
    
    // General Settings
    @Published var autoOpenLastFolder: Bool = false {
        didSet { UserDefaults.standard.set(autoOpenLastFolder, forKey: "autoOpenLastFolder") }
    }
    @Published var searchSubfolders: Bool = true {
        didSet { UserDefaults.standard.set(searchSubfolders, forKey: "searchSubfolders") }
    }
    @Published var saveRatingInXMP: Bool = true {
        didSet { UserDefaults.standard.set(saveRatingInXMP, forKey: "saveRatingInXMP") }
    }
    /// Wenn aktiv, werden Metadaten (Rating, IPTC, Pick Status) automatisch beim Ändern gespeichert
    @Published var autoSaveMetadata: Bool = false {
        didSet { UserDefaults.standard.set(autoSaveMetadata, forKey: "autoSaveMetadata") }
    }
    @Published var autoLoadIPTC: Bool = true {
        didSet { UserDefaults.standard.set(autoLoadIPTC, forKey: "autoLoadIPTC") }
    }
    @Published var backupBeforeOverwrite: Bool = true {
        didSet { UserDefaults.standard.set(backupBeforeOverwrite, forKey: "backupBeforeOverwrite") }
    }
    
    // Performance Settings
    @Published var previewQuality: Double = 0.8 {
        didSet { UserDefaults.standard.set(previewQuality, forKey: "previewQuality") }
    }
    @Published var maxCacheSize: Int = 1000 {
        didSet { UserDefaults.standard.set(maxCacheSize, forKey: "maxCacheSize") }
    }
    @Published var hardwareAcceleration: Bool = true {
        didSet { UserDefaults.standard.set(hardwareAcceleration, forKey: "hardwareAcceleration") }
    }
    @Published var progressiveRendering: Bool = true {
        didSet { UserDefaults.standard.set(progressiveRendering, forKey: "progressiveRendering") }
    }
    
    // Export Settings
    @Published var defaultExportFormat: String = "jpeg" {
        didSet { UserDefaults.standard.set(defaultExportFormat, forKey: "defaultExportFormat") }
    }
    @Published var defaultExportQuality: Double = 0.85 {
        didSet { UserDefaults.standard.set(defaultExportQuality, forKey: "defaultExportQuality") }
    }
    @Published var filenameTemplate: String = "{originalname}_{preset}" {
        didSet { UserDefaults.standard.set(filenameTemplate, forKey: "filenameTemplate") }
    }
    
    // Appearance Settings
    @Published var theme: String = "dark" {
        didSet { UserDefaults.standard.set(theme, forKey: "theme") }
    }
    @Published var sidebarAlwaysVisible: Bool = false {
        didSet { UserDefaults.standard.set(sidebarAlwaysVisible, forKey: "sidebarAlwaysVisible") }
    }
    @Published var showSidebarIcons: Bool = true {
        didSet { UserDefaults.standard.set(showSidebarIcons, forKey: "showSidebarIcons") }
    }
    
    /// Legacy: Für Rückwärtskompatibilität (computed property, ohne @Published)
    var sidebarCompactMode: Bool {
        get { finderSidebarCompactMode && adjustmentsSidebarCompactMode }
        set {
            finderSidebarCompactMode = newValue
            adjustmentsSidebarCompactMode = newValue
        }
    }
    
    @Published var finderSidebarCompactMode: Bool = false {
        didSet { UserDefaults.standard.set(finderSidebarCompactMode, forKey: "finderSidebarCompactMode") }
    }
    
    @Published var adjustmentsSidebarCompactMode: Bool = false {
        didSet { UserDefaults.standard.set(adjustmentsSidebarCompactMode, forKey: "adjustmentsSidebarCompactMode") }
    }
    
    /// Wenn aktiv, wird die reduzierte Workflow‑Topbar bevorzugt (weniger visuelles "Chrome", schneller Export‑Flow).
    @Published var preferWorkflowTopbar: Bool = false {
        didSet { UserDefaults.standard.set(preferWorkflowTopbar, forKey: "preferWorkflowTopbarV1") }
    }
    
    // Workflow Settings
    @Published var autoAdvanceAfterRating: Bool = true {
        didSet { UserDefaults.standard.set(autoAdvanceAfterRating, forKey: "autoAdvanceAfterRating") }
    }
    
    /// "manual" (Feinanpasser) oder "automated" (Automatisierer)
    @Published var workflowMode: String = "manual" {
        didSet { UserDefaults.standard.set(workflowMode, forKey: "workflowMode") }
    }
    
    /// Smart Culling: Priorisierung des Best‑Shot Scorings ("sport" oder "portrait").
    @Published var bestShotScoringMode: String = "sport" {
        didSet { UserDefaults.standard.set(bestShotScoringMode, forKey: "bestShotScoringMode") }
    }
    
    /// Best‑of: wie viele Top‑Shots automatisch als Pick markiert werden sollen.
    @Published var bestOfPickCount: Int = 50 {
        didSet { UserDefaults.standard.set(bestOfPickCount, forKey: "bestOfPickCount") }
    }
    
    /// Wenn aktiv, nutzt der Auto-Button zusätzlich das Stil-Profil (Preset-Delta)
    @Published var autoUsesStyleProfile: Bool = false {
        didSet { UserDefaults.standard.set(autoUsesStyleProfile, forKey: "autoUsesStyleProfile") }
    }
    
    /// UUID-String eines AdjustmentPresets (leer = kein Stil-Profil)
    @Published var autoStylePresetID: String = "" {
        didSet {
            UserDefaults.standard.set(autoStylePresetID, forKey: "autoStylePresetID")
            if !autoStylePresetID.isEmpty, let id = UUID(uuidString: autoStylePresetID) {
                recordRecentStylePreset(id: id)
            }
        }
    }
    
    /// Zuletzt verwendete Stil‑Presets (IDs als Strings). Wird im Stil‑Profil Picker oben angezeigt.
    @Published var recentStylePresetIDs: [String] = [] {
        didSet { UserDefaults.standard.set(recentStylePresetIDs, forKey: "recentStylePresetIDsV1") }
    }
    
    func recordRecentStylePreset(id: UUID) {
        let raw = id.uuidString
        var next = recentStylePresetIDs.filter { $0 != raw }
        next.insert(raw, at: 0)
        if next.count > 12 {
            next = Array(next.prefix(12))
        }
        recentStylePresetIDs = next
    }
}
