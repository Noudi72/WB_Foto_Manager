//
//  SmartCollection.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 15.12.2025.
//

import Foundation

/// Smart Collection Filter-Kriterien (Lightroom-Style)
struct SmartCollectionCriteria: Codable, Hashable {
    var minRating: Int? = nil // 1-5, nil = kein Filter
    var maxRating: Int? = nil // 1-5, nil = kein Filter
    var pickStatus: PickStatus? = nil // nil = kein Filter
    var colorTags: Set<ColorTag> = [] // leer = kein Filter
    var hasColorTag: Bool = false // true = mindestens ein Color Tag muss vorhanden sein
    var isInQuickCollection: Bool? = nil // nil = kein Filter
    var hasAdjustments: Bool? = nil // nil = kein Filter
    var hasCrop: Bool? = nil // nil = kein Filter
    
    // EXIF-basierte Kriterien
    var cameraMake: String? = nil // nil = kein Filter, leerer String = muss vorhanden sein
    var cameraModel: String? = nil // nil = kein Filter, leerer String = muss vorhanden sein
    var lensModel: String? = nil // nil = kein Filter, leerer String = muss vorhanden sein
    var minFocalLengthMM: Double? = nil // nil = kein Filter
    var maxFocalLengthMM: Double? = nil // nil = kein Filter
    var minISO: Int? = nil // nil = kein Filter
    var maxISO: Int? = nil // nil = kein Filter
    var minAperture: Double? = nil // nil = kein Filter
    var maxAperture: Double? = nil // nil = kein Filter
    var minShutterSpeed: Double? = nil // nil = kein Filter (in Sekunden)
    var maxShutterSpeed: Double? = nil // nil = kein Filter (in Sekunden)
    
    var isEmpty: Bool {
        minRating == nil && maxRating == nil &&
        pickStatus == nil &&
        colorTags.isEmpty && !hasColorTag &&
        isInQuickCollection == nil &&
        hasAdjustments == nil &&
        hasCrop == nil &&
        cameraMake == nil &&
        cameraModel == nil &&
        lensModel == nil &&
        minFocalLengthMM == nil && maxFocalLengthMM == nil &&
        minISO == nil && maxISO == nil &&
        minAperture == nil && maxAperture == nil &&
        minShutterSpeed == nil && maxShutterSpeed == nil
    }
}

/// Smart Collection (automatische Filter-Sets)
struct SmartCollection: Identifiable, Codable, Hashable {
    let id: UUID
    var name: String
    var criteria: SmartCollectionCriteria
    var isVisible: Bool = true
    
    init(id: UUID = UUID(), name: String, criteria: SmartCollectionCriteria = SmartCollectionCriteria()) {
        self.id = id
        self.name = name
        self.criteria = criteria
    }
    
    /// Prüft ob ein PhotoItem die Kriterien erfüllt
    func matches(_ photo: PhotoItem) -> Bool {
        // Rating Filter
        if let minRating = criteria.minRating, photo.rating < minRating {
            return false
        }
        if let maxRating = criteria.maxRating, photo.rating > maxRating {
            return false
        }
        
        // Pick Status Filter
        if let pickStatus = criteria.pickStatus, photo.pickStatus != pickStatus {
            return false
        }
        
        // Color Tag Filter
        if !criteria.colorTags.isEmpty {
            if !criteria.colorTags.isSubset(of: photo.colorTags) {
                return false
            }
        }
        if criteria.hasColorTag, photo.colorTags.isEmpty {
            return false
        }
        
        // Quick Collection Filter
        if let isInQuickCollection = criteria.isInQuickCollection, photo.isInQuickCollection != isInQuickCollection {
            return false
        }
        
        // Adjustments Filter
        if let hasAdjustments = criteria.hasAdjustments {
            if hasAdjustments && !photo.adjustments.hasAdjustments {
                return false
            }
            if !hasAdjustments && photo.adjustments.hasAdjustments {
                return false
            }
        }
        
        // Crop Filter
        if let hasCrop = criteria.hasCrop {
            if hasCrop && photo.cropRect == nil {
                return false
            }
            if !hasCrop && photo.cropRect != nil {
                return false
            }
        }
        
        // EXIF-basierte Filter
        guard let exifMeta = photo.exifMeta else {
            // Wenn EXIF-Daten fehlen, schließe aus, wenn EXIF-Kriterien gesetzt sind
            if criteria.cameraMake != nil || criteria.cameraModel != nil || criteria.lensModel != nil ||
               criteria.minFocalLengthMM != nil || criteria.maxFocalLengthMM != nil ||
               criteria.minISO != nil || criteria.maxISO != nil ||
               criteria.minAperture != nil || criteria.maxAperture != nil ||
               criteria.minShutterSpeed != nil || criteria.maxShutterSpeed != nil {
                return false
            }
            return true
        }
        
        // Camera Make Filter
        if let cameraMake = criteria.cameraMake {
            if cameraMake.isEmpty {
                // Leerer String = muss vorhanden sein
                if exifMeta.cameraMake == nil || exifMeta.cameraMake!.isEmpty {
                    return false
                }
            } else {
                // Nicht-leerer String = muss enthalten sein (case-insensitive)
                guard let metaMake = exifMeta.cameraMake else { return false }
                if !metaMake.localizedCaseInsensitiveContains(cameraMake) {
                    return false
                }
            }
        }
        
        // Camera Model Filter
        if let cameraModel = criteria.cameraModel {
            if cameraModel.isEmpty {
                if exifMeta.cameraModel == nil || exifMeta.cameraModel!.isEmpty {
                    return false
                }
            } else {
                guard let metaModel = exifMeta.cameraModel else { return false }
                if !metaModel.localizedCaseInsensitiveContains(cameraModel) {
                    return false
                }
            }
        }
        
        // Lens Model Filter
        if let lensModel = criteria.lensModel {
            if lensModel.isEmpty {
                if exifMeta.lensModel == nil || exifMeta.lensModel!.isEmpty {
                    return false
                }
            } else {
                guard let metaLens = exifMeta.lensModel else { return false }
                if !metaLens.localizedCaseInsensitiveContains(lensModel) {
                    return false
                }
            }
        }
        
        // Focal Length Filter
        if let minFL = criteria.minFocalLengthMM {
            guard let metaFL = exifMeta.focalLengthMM, metaFL >= minFL else { return false }
        }
        if let maxFL = criteria.maxFocalLengthMM {
            guard let metaFL = exifMeta.focalLengthMM, metaFL <= maxFL else { return false }
        }
        
        // ISO Filter
        if let minISO = criteria.minISO {
            guard let metaISO = exifMeta.isoSpeed, metaISO >= minISO else { return false }
        }
        if let maxISO = criteria.maxISO {
            guard let metaISO = exifMeta.isoSpeed, metaISO <= maxISO else { return false }
        }
        
        // Aperture Filter
        if let minAperture = criteria.minAperture {
            guard let metaAperture = exifMeta.apertureValue, metaAperture >= minAperture else { return false }
        }
        if let maxAperture = criteria.maxAperture {
            guard let metaAperture = exifMeta.apertureValue, metaAperture <= maxAperture else { return false }
        }
        
        // Shutter Speed Filter
        if let minShutter = criteria.minShutterSpeed {
            guard let metaShutter = exifMeta.shutterSpeed, metaShutter >= minShutter else { return false }
        }
        if let maxShutter = criteria.maxShutterSpeed {
            guard let metaShutter = exifMeta.shutterSpeed, metaShutter <= maxShutter else { return false }
        }
        
        return true
    }
}

