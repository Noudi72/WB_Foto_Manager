//
//  PhotoItem.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import AppKit
import CoreImage
import Combine
import Photos

/// Pick/Reject Status (Lightroom-Style)
enum PickStatus: String, Codable, CaseIterable {
    case unflagged = "unflagged"  // Standard
    case pick = "pick"            // Grüner Flag (P)
    case reject = "reject"        // Roter Flag (X)
    
    var displayIcon: String {
        switch self {
        case .unflagged: return ""
        case .pick: return "flag.fill"
        case .reject: return "xmark.circle.fill"
        }
    }
    
    var displayColor: NSColor {
        switch self {
        case .unflagged: return .clear
        case .pick: return .systemGreen
        case .reject: return .systemRed
        }
    }
}

/// Repräsentiert ein einzelnes Foto mit allen Metadaten und Bearbeitungsparametern
class PhotoItem: ObservableObject, Identifiable, Hashable {
    let id: UUID
    let url: URL
    let originalFileName: String?
    let pixelWidth: Int?
    let pixelHeight: Int?
    @Published var rating: Int = 0 // 0-5, 0 = kein Rating
    @Published var pickStatus: PickStatus = .unflagged
    @Published var colorTags: Set<ColorTag> = []
    @Published var textTags: Set<String> = [] {
        didSet { invalidateSearchIndexCache() }
    }
    @Published var isInQuickCollection: Bool = false
    @Published var adjustments: PhotoAdjustments
    @Published var localMasks: [LocalAdjustmentMask] = []
    @Published var lensProfileSettings: LensProfileSettings = LensProfileSettings()
    @Published var cropRect: CGRect?
    @Published var rotation: Double = 0.0
    @Published var iptcMetadata: IPTCMetadata? {
        didSet { invalidateSearchIndexCache() }
    }
    @Published var isExported: Bool = false
    
    // EXIF Metadata Cache (loaded via LensProfileService)
    private var _cachedExifMeta: LensMeta?
    var exifMeta: LensMeta? {
        return _cachedExifMeta
    }
    
    func setExifMeta(_ meta: LensMeta?) {
        if _cachedExifMeta != meta {
            _cachedExifMeta = meta
            objectWillChange.send()
        }
    }
    
    // Virtual Copies (Lightroom-Style)
    var isMaster: Bool = true
    var masterID: UUID? = nil // ID des Masters (wenn Virtual Copy)
    var virtualCopyNumber: Int = 0 // 0 = Master, 1+ = Copy
    
    // Cache for full-resolution image used in editing
    private var _fullImage: CIImage?
    private var fullImageTask: Task<CIImage?, Never>?
    
    // Cache for search (performance): normalized blob built from filename + IPTC + AI tags
    private var _cachedSearchIndex: String?
    
    init(url: URL, rating: Int = 0, id: UUID? = nil, originalFileName: String? = nil, pixelWidth: Int? = nil, pixelHeight: Int? = nil) {
        self.id = id ?? UUID()
        self.url = url
        self.originalFileName = originalFileName
        self.pixelWidth = pixelWidth
        self.pixelHeight = pixelHeight
        self.rating = rating
        self.adjustments = PhotoAdjustments()
        self.localMasks = []
        self.lensProfileSettings = LensProfileSettings()
    }
    
    /// Copy-Initializer für Virtual Copies
    init(from master: PhotoItem, copyNumber: Int) {
        self.id = UUID()
        self.url = master.url
        self.originalFileName = master.originalFileName
        self.pixelWidth = master.pixelWidth
        self.pixelHeight = master.pixelHeight
        self.rating = master.rating
        self.pickStatus = master.pickStatus
        self.colorTags = master.colorTags
        self.textTags = master.textTags
        self.adjustments = master.adjustments
        self.localMasks = master.localMasks
        self.lensProfileSettings = master.lensProfileSettings
        self.cropRect = master.cropRect
        self.rotation = master.rotation
        self.iptcMetadata = master.iptcMetadata
        self.isMaster = false
        self.masterID = master.id
        self.virtualCopyNumber = copyNumber
    }
    
    var fileName: String {
        if let name = originalFileName, !name.isEmpty {
            return name
        }
        return url.lastPathComponent
    }
    
    /// Normalisierter Such-Index (für schnelle Filterung). Wird lazy erstellt und bei Änderungen invalidiert.
    var searchIndex: String {
        if let cached = _cachedSearchIndex { return cached }
        
        let caption = iptcMetadata?.caption ?? ""
        let keywords = (iptcMetadata?.keywords ?? []).joined(separator: " ")
        let tags = textTags.joined(separator: " ")
        let raw = "\(fileName) \(caption) \(keywords) \(tags)"
        
        let idx = SearchNormalization.makeSearchIndex(raw)
        _cachedSearchIndex = idx
        return idx
    }
    
    private func invalidateSearchIndexCache() {
        _cachedSearchIndex = nil
    }
    
    var aspectRatio: Double {
        let w = Double(pixelWidth ?? 0)
        let h = Double(pixelHeight ?? 0)
        guard w > 0, h > 0 else { return 1.0 }
        return max(0.2, min(5.0, w / h))
    }
    
    var fileSize: Int64 {
        (try? FileManager.default.attributesOfItem(atPath: url.path)[.size] as? Int64) ?? 0
    }
    
    var displayName: String {
        if isMaster {
            return virtualCopyNumber == 0 ? fileName : "\(fileName) (Master)"
        } else {
            return "\(fileName) (Copy \(virtualCopyNumber))"
        }
    }
    
    var virtualCopyBadge: String? {
        if !isMaster {
            return "Copy \(virtualCopyNumber)"
        } else if virtualCopyNumber > 0 {
            return "Master"
        }
        return nil
    }
    
    // MARK: - Hashable & Equatable
    
    static func == (lhs: PhotoItem, rhs: PhotoItem) -> Bool {
        lhs.id == rhs.id
    }
    
    func hash(into hasher: inout Hasher) {
        hasher.combine(id)
    }
    
    // MARK: - Image Loading (Using Global Cache)
    
    /// Loads a thumbnail of a specific size, utilizing the global cache.
    nonisolated func loadThumbnail(size: CGSize) async -> NSImage? {
        // Prüfe ob Datei existiert
        guard FileManager.default.fileExists(atPath: url.path) else {
            print("⚠️ Datei existiert nicht: \(url.path)")
            return nil
        }
        
        // Cache-Zugriff auf Main Actor
        let cacheKeyString = "\(url.absoluteString)-\(size.width)x\(size.height)"
        
        // Check cache first
        let cachedImage = await MainActor.run {
            ThumbnailCache.shared.get(forKey: cacheKeyString as NSString)
        }
        if let cached = cachedImage {
            return cached
        }
        
        // If not in cache, generate it - auf Background Thread
        let fileURL = self.url
        let cacheKeyStringCopy = cacheKeyString
        return await Task.detached(priority: .userInitiated) {
            guard let imageSource = CGImageSourceCreateWithURL(fileURL as CFURL, nil) else {
                print("⚠️ Konnte ImageSource nicht erstellen für: \(fileURL.path)")
                return nil
            }
            
            // Für bessere Qualität: Verwende größere Max-Pixel-Size und bessere Optionen
            let maxSize = max(size.width, size.height)
            let options: [CFString: Any] = [
                kCGImageSourceThumbnailMaxPixelSize: maxSize * 1.5, // Etwas größer für bessere Qualität
                kCGImageSourceCreateThumbnailFromImageIfAbsent: true,
                kCGImageSourceCreateThumbnailWithTransform: true,
                kCGImageSourceShouldCache: true,
                kCGImageSourceShouldAllowFloat: true
            ]
            
            guard let cgImage = CGImageSourceCreateThumbnailAtIndex(imageSource, 0, options as CFDictionary) else {
                print("⚠️ Konnte Thumbnail nicht erstellen für: \(fileURL.path)")
                return nil
            }
            
            // Erstelle hochwertiges NSImage
            // Wichtig: NSImage.size darf NICHT künstlich auf ein Quadrat gesetzt werden,
            // sonst wirken Bilder in Compare/Culling gestreckt (SwiftUI nutzt NSImage.size für das Seitenverhältnis).
            let thumbnail = NSImage(
                cgImage: cgImage,
                size: NSSize(width: cgImage.width, height: cgImage.height)
            )
            thumbnail.cacheMode = .never // Verhindere automatisches Caching für bessere Qualität
            
            // Store in cache for next time
            await MainActor.run {
                ThumbnailCache.shared.set(thumbnail, forKey: cacheKeyStringCopy as NSString)
            }
            
            return thumbnail
        }.value
    }
    
    /// Loads the full-resolution image for editing.
    func loadFullImage() -> CIImage? {
        if let cached = _fullImage {
            return cached
        }

        // PhotoKit Asset: wird asynchron geladen (siehe loadFullImageAsync()).
        if PHAssetURL.localIdentifier(from: url) != nil {
            return nil
        }
        
        guard let image = CIImage(contentsOf: url, options: [
            .applyOrientationProperty: true,
            .cacheImmediately: false // Lazy loading
        ]) else {
            return nil
        }
        
        _fullImage = image
        return image
    }
    
    /// Lädt das Full-Res Bild asynchron (wichtig für PhotoKit Assets / iCloud Optimize Storage).
    func loadFullImageAsync() async -> CIImage? {
        if let cached = _fullImage { return cached }
        
        if let existing = fullImageTask {
            return await existing.value
        }
        
        // File-backed: einfach synchron laden
        if PHAssetURL.localIdentifier(from: url) == nil {
            return loadFullImage()
        }
        
        guard let assetID = PHAssetURL.localIdentifier(from: url) else { return nil }
        
        let task = Task.detached(priority: .userInitiated) { () -> CIImage? in
            let fetched = PHAsset.fetchAssets(withLocalIdentifiers: [assetID], options: nil)
            guard let asset = fetched.firstObject else { return nil }
            
            let options = PHImageRequestOptions()
            options.isNetworkAccessAllowed = true
            options.deliveryMode = .highQualityFormat
            // Wichtig: konsistent zur Preview (PhotoKit liefert standardmässig die "current" Version inkl. Photos-Edits).
            // Sonst springt/zoomt die Ansicht beim Wechsel zwischen NSImage-Preview und CoreImage-Render.
            options.version = .current
            
            return await withCheckedContinuation { continuation in
                PHImageManager.default().requestImageDataAndOrientation(for: asset, options: options) { data, _, orientation, _ in
                    guard let data else {
                        continuation.resume(returning: nil)
                        return
                    }
                    // PhotoKit liefert Orientation separat – diese MUSS angewendet werden, sonst "springt" die Ansicht
                    // beim Wechsel zwischen NSImage-Preview und CoreImage-Render (wirkt wie Zoom/Rotate).
                    let base = CIImage(data: data, options: [.applyOrientationProperty: false])
                    let ci = base?.oriented(forExifOrientation: Int32(orientation.rawValue))
                    continuation.resume(returning: ci)
                }
            }
        }
        
        fullImageTask = task
        let result = await task.value
        await MainActor.run {
            self.fullImageTask = nil
            if let result {
                self._fullImage = result
                self.objectWillChange.send()
            }
        }
        return result
    }
    
    /// Clears the cached full-resolution image.
    func clearFullImageCache() {
        _fullImage = nil
        fullImageTask?.cancel()
        fullImageTask = nil
    }
}

// MARK: - Color Tags

enum ColorTag: String, CaseIterable, Codable {
    case red = "red"
    case orange = "orange"
    case yellow = "yellow"
    case green = "green"
    case blue = "blue"
    case purple = "purple"
    case pink = "pink"
    case gray = "gray"
    
    var color: NSColor {
        switch self {
        case .red: return .systemRed
        case .orange: return .systemOrange
        case .yellow: return .systemYellow
        case .green: return .systemGreen
        case .blue: return .systemBlue
        case .purple: return .systemPurple
        case .pink: return .systemPink
        case .gray: return .systemGray
        }
    }
    
    /// Lightroom-Style Keyboard Mapping (6-9)
    static func fromKey(_ key: String) -> ColorTag? {
        switch key {
        case "6": return .red
        case "7": return .yellow
        case "8": return .green
        case "9": return .blue
        default: return nil
        }
    }
    
    /// Display name for UI
    var displayName: String {
        switch self {
        case .red: return "Rot"
        case .orange: return "Orange"
        case .yellow: return "Gelb"
        case .green: return "Grün"
        case .blue: return "Blau"
        case .purple: return "Lila"
        case .pink: return "Rosa"
        case .gray: return "Grau"
        }
    }
}

// MARK: - IPTC Metadata

struct IPTCMetadata: Codable, Sendable {
    var caption: String?
    var keywords: [String]
    var photographer: String?
    var copyright: String?
    var location: String?
    var city: String?
    var country: String?
    var event: String?
    var venue: String?
    var date: Date?
    var customFields: [String: String]
    
    nonisolated init(caption: String? = nil, keywords: [String] = [], photographer: String? = nil, copyright: String? = nil, location: String? = nil, city: String? = nil, country: String? = nil, event: String? = nil, venue: String? = nil, date: Date? = nil, customFields: [String: String] = [:]) {
        self.caption = caption
        self.keywords = keywords
        self.photographer = photographer
        self.copyright = copyright
        self.location = location
        self.city = city
        self.country = country
        self.event = event
        self.venue = venue
        self.date = date
        self.customFields = customFields
    }
}

