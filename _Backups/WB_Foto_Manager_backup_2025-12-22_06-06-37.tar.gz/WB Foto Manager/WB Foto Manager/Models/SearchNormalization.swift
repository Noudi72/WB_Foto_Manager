//
//  SearchNormalization.swift
//  WB Foto Manager
//
//  Normalisierung + Synonyme für schnelle/robuste Suche (Deutsch/Englisch, Umlaut, ß/ss, Singular/Plural).
//

import Foundation

enum SearchNormalization {
    /// Normalisiert Text für robuste `contains`-Suche:
    /// - lowercase
    /// - ä/ö/ü → ae/oe/ue
    /// - ß → ss
    /// - diacritics folding (für seltene Fälle)
    nonisolated static func normalize(_ s: String) -> String {
        let lower = s.lowercased()
        let umlautExpanded = lower
            .replacingOccurrences(of: "ä", with: "ae")
            .replacingOccurrences(of: "ö", with: "oe")
            .replacingOccurrences(of: "ü", with: "ue")
            .replacingOccurrences(of: "ß", with: "ss")
        
        // Diacritics (z.B. é) – nach Umlaut-Expansion anwenden
        return umlautExpanded.folding(options: [.diacriticInsensitive, .widthInsensitive], locale: Locale(identifier: "de_CH"))
    }
    
    nonisolated static func normalizeToken(_ s: String) -> String {
        // Token/Query Normalisierung:
        // - Trim punctuation (z.B. "Hund," → "Hund")
        // - Normalisieren (lowercase, umlaut/ß)
        // - interne Separatoren ( _, -, /, ... ) zu Spaces, damit es zum Search-Index passt
        let trimmed = s.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        let normalized = normalize(trimmed)
        let cleaned = normalized.map { ch -> Character in
            (ch.isLetter || ch.isNumber) ? ch : " "
        }
        let collapsed = String(cleaned)
            .split(whereSeparator: { $0.isWhitespace })
            .joined(separator: " ")
        return collapsed.trimmingCharacters(in: .whitespacesAndNewlines)
    }
    
    /// Baut einen **Wort-Index** für schnelle/robuste Suche:
    /// - nur Buchstaben/Zahlen + Spaces
    /// - single spaces
    /// - gepadded mit Spaces, damit wir Wortgrenzen via `" \(token) "` matchen können
    nonisolated static func makeSearchIndex(_ raw: String) -> String {
        let normalized = normalize(raw)
        let cleaned = normalized.map { ch -> Character in
            (ch.isLetter || ch.isNumber) ? ch : " "
        }
        let collapsed = String(cleaned)
            .split(whereSeparator: { $0.isWhitespace })
            .joined(separator: " ")
        // Padding: Wortgrenzen
        return " \(collapsed) "
    }
}

enum SearchSynonyms {
    /// Synonyme/Übersetzungen für Suchbegriffe (alles in **normalisierter** Form).
    nonisolated private static let map: [String: [String]] = [
        // People
        // Hinweis: Gender soll präzise sein (damit „Frau“ keine Männer trifft).
        // Fallback über "person/portrait" ist absichtlich NICHT enthalten.
        // Wichtig: KEIN "man/men" (matcht sonst "woMAN/woMEN") und KEIN "male" (matcht sonst "feMALE"),
        // weil unsere Suche token-basiert ist – wir verlassen uns primär auf AI-Tags "Frau/Mann".
        // "Frau" soll auch "Mädchen" (girl) matchen – das ist i.d.R. gewünscht und vermeidet 0 Treffer.
        "frau": ["woman", "female", "lady", "women", "girl", "maedchen", "mädchen"],
        // Wortgrenzen-Suche verhindert man∈woman / male∈female → wir können man/men wieder erlauben.
        "mann": ["man", "men", "male", "guy"],
        "menschen": ["person", "people", "human", "persons"],
        "kind": ["child", "kid", "children", "kids", "baby"],
        "kinder": ["child", "kid", "children", "kids", "kind", "baby"],
        "maedchen": ["girl", "girls", "female child", "young girl"],
        "senioren": ["senior", "elderly", "old", "retired"],
        "familie": ["family", "parents", "mother", "father", "kids", "children"],
        "paar": ["couple", "partners", "pair"],
        "team": ["team", "squad", "group"],
        "lachen": ["laugh", "laughing", "smile", "smiling"],
        
        // Seasons / holidays
        "winter": ["winter", "snow", "snowy"],
        "weihnachten": ["christmas", "xmas", "noel", "holiday"],
        "ostern": ["easter"],
        
        // Nature / outdoors
        "natur": ["nature", "outdoor", "outdoors"],
        "landschaft": ["landscape", "scenery", "vista"],
        "wildnis": ["wilderness", "wild"],
        "berge": ["mountain", "mountains", "berg"],
        "sonnenuntergang": ["sunset"],
        "sonne": ["sun", "sunlight"],
        "mond": ["moon"],
        "garten": ["garden", "yard"],
        "baum": ["tree", "trees"],
        "blume": ["flower", "flowers", "blossom"],
        "blumen": ["flower", "flowers", "blossom", "blume"],
        
        // Water / beach
        "wasser": ["water", "sea", "ocean", "lake", "river"],
        "strand": ["beach", "coast", "seashore"],
        
        // Animals
        "hund": ["dog", "puppy", "canine"],
        "husky": ["husky", "siberian husky", "dog", "wolf"],
        "katze": ["cat", "kitten", "feline"],
        "vogel": ["bird", "birds"],
        "wolf": ["wolf", "wolves"],
        
        // Sports
        "sport": ["sport", "sports"],
        "eishockey": ["ice hockey", "hockey"],
        "fussball": ["soccer", "football"],
        "motocross": ["motocross", "dirt bike", "off road motorcycle", "off-road motorcycle"],
        
        // Objects / places
        "auto": ["car", "vehicle", "automobile"],
        "motorrad": ["motorcycle", "motorbike"],
        "haus": ["house", "home"],
        "stadt": ["city", "town", "urban"],
        "herz": ["heart"],
        "business": ["business", "office", "work"],
        "computer": ["computer", "laptop", "keyboard", "screen", "monitor"],
        "essen": ["food", "meal", "cuisine", "dinner"],
        "kaffee": ["coffee"],
        "wein": ["wine"]
    ]
    
    nonisolated static func alternatives(for rawToken: String) -> [String] {
        let token = SearchNormalization.normalizeToken(rawToken)
        guard !token.isEmpty else { return [] }
        
        var out = Set<String>()
        out.insert(token)
        
        // Map synonyms/translation
        if let syn = map[token] {
            for s in syn {
                out.insert(SearchNormalization.normalizeToken(s))
            }
        }
        
        // Simple plural/singular heuristics (Deutsch/Englisch)
        // - Fussball/Fußball via Normalisierung bereits abgedeckt (ß→ss)
        // - Blumen → Blume
        if token.hasSuffix("en"), token.count > 4 {
            out.insert(String(token.dropLast(2))) // blumen -> blum (nicht perfekt, aber zusätzlich)
            // häufig: blumen -> blume
            out.insert(String(token.dropLast(2)) + "e")
        }
        if token.hasSuffix("er"), token.count > 4 {
            out.insert(String(token.dropLast(2)))
        }
        if token.hasSuffix("e"), token.count > 4 {
            out.insert(String(token.dropLast(1)))
        }
        if token.hasSuffix("s"), token.count > 3 {
            out.insert(String(token.dropLast(1)))
        }
        
        // Dedup + stabile Reihenfolge
        return Array(out).sorted()
    }
}


