//
//  BestOfOverlayInfo.swift
//  WB Foto Manager
//
//  Best‑of UI helper (Qualität + Auflösung) – erklärt Ranking im Overlay/Inspector.
//

import Foundation

struct BestOfOverlayInfo: Sendable, Equatable {
    /// 0...1 (finaler Best‑of Score innerhalb der Serie)
    let scoreFraction: Double
    /// 0...1 (Auflösung relativ zur höchsten Auflösung im Scope)
    let resolutionFraction: Double
    /// 0...1 (Schärfe/Qualität relativ zur besten im Scope)
    let sharpnessFraction: Double
    
    /// Pixelfläche (für MP Anzeige)
    let pixelArea: Int
    
    /// True, wenn der Score im Fast‑Modus berechnet wurde (für sehr große Sets).
    let usedFastQuality: Bool
    
    var score0to100: Int { BestOfOverlayInfo.clamp100(scoreFraction) }
    var resolution0to100: Int { BestOfOverlayInfo.clamp100(resolutionFraction) }
    var sharpness0to100: Int { BestOfOverlayInfo.clamp100(sharpnessFraction) }
    
    var megapixels: Double { max(0.0, Double(pixelArea) / 1_000_000.0) }
    
    var megapixelsText: String {
        let mp = megapixels
        if mp <= 0 { return "—MP" }
        if mp < 10 { return String(format: "%.1fMP", mp) }
        return String(format: "%.0fMP", mp)
    }
    
    var miniHintText: String {
        // Kurz und gut lesbar: MP + Schärfe (relativ).
        "\(megapixelsText) • S\(sharpness0to100)"
    }
    
    private static func clamp100(_ v: Double) -> Int {
        let clamped = max(0.0, min(1.0, v))
        return Int((clamped * 100.0).rounded())
    }
}


