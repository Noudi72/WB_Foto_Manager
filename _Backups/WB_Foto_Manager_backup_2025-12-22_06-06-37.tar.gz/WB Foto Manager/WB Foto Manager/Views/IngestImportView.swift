//
//  IngestImportView.swift
//  WB Foto Manager
//
//  PhotoMechanic‑Style ingest for sports workflows:
//  SD‑Card → Job Folder (copy RAW+JPG) → open JPG folder for fast culling & delivery.
//

import SwiftUI
import AppKit

struct IngestImportView: View {
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @Environment(\.dismiss) private var dismiss
    @StateObject private var settings = AppSettings.shared
    
    @AppStorage("ingestLastSourcePathV1") private var lastSourcePath: String = ""
    @AppStorage("ingestLastDestinationPathV1") private var lastDestinationPath: String = ""
    
    @State private var sourceFolder: URL?
    @State private var destinationParentFolder: URL?
    @State private var jobName: String = IngestImportView.defaultJobName()
    
    @State private var includeJPG: Bool = true
    @State private var includeRAW: Bool = true
    @State private var createSubfolders: Bool = true
    @State private var openJPGAfterIngest: Bool = true
    
    var body: some View {
        let isCompact = settings.adjustmentsSidebarCompactMode
        
        VStack(spacing: 0) {
            header
            
            Divider()
            
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    sourceSection
                    destinationSection
                    optionsSection
                    statusSection
                }
                .padding(16)
            }
            
            Divider()
            
            footer
                .padding(16)
        }
        .frame(width: 720, height: 520)
        .background(DesignSystem.Colors.background2)
        .lightroomSidebarTheme()
        .controlSize(isCompact ? .mini : .small)
        .onAppear {
            // Restore last paths if present
            if sourceFolder == nil, !lastSourcePath.isEmpty {
                sourceFolder = URL(fileURLWithPath: lastSourcePath)
            }
            if destinationParentFolder == nil, !lastDestinationPath.isEmpty {
                destinationParentFolder = URL(fileURLWithPath: lastDestinationPath)
            }
        }
    }
    
    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("Ingest / Import (SD‑Karte)")
                    .font(DesignSystem.Fonts.semibold(size: 16))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Text("Kopiert RAW+JPG in einen Job‑Ordner. Karte wird **nie** gelöscht.")
                    .font(DesignSystem.Fonts.regular(size: 11))
                    .foregroundColor(DesignSystem.Colors.text3)
            }
            
            Spacer()
            
            Button("Schließen") { dismiss() }
                .buttonStyle(LightroomSecondaryButtonStyle())
                .disabled(store.isIngestRunning)
        }
        .padding(16)
    }
    
    private var sourceSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Quelle")
                .font(DesignSystem.Fonts.semibold(size: 13))
                .foregroundColor(DesignSystem.Colors.text)
            
            HStack(spacing: 10) {
                Text(sourceFolder?.path ?? "Keine Quelle gewählt (SD‑Karte / DCIM)")
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(sourceFolder == nil ? DesignSystem.Colors.text4 : DesignSystem.Colors.text2)
                    .lineLimit(1)
                    .truncationMode(.middle)
                
                Spacer(minLength: 8)
                
                Button("Quelle wählen…") { pickSourceFolder() }
                    .buttonStyle(.borderedProminent)
                    .disabled(store.isIngestRunning)
            }
        }
        .padding(12)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
    }
    
    private var destinationSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Ziel")
                .font(DesignSystem.Fonts.semibold(size: 13))
                .foregroundColor(DesignSystem.Colors.text)
            
            VStack(alignment: .leading, spacing: 10) {
                HStack(spacing: 10) {
                    Text(destinationParentFolder?.path ?? "Kein Ziel gewählt (Job‑Root)")
                        .font(DesignSystem.Fonts.regular(size: 12))
                        .foregroundColor(destinationParentFolder == nil ? DesignSystem.Colors.text4 : DesignSystem.Colors.text2)
                        .lineLimit(1)
                        .truncationMode(.middle)
                    
                    Spacer(minLength: 8)
                    
                    Button("Ziel wählen…") { pickDestinationFolder() }
                        .buttonStyle(.borderedProminent)
                        .disabled(store.isIngestRunning)
                }
                
                VStack(alignment: .leading, spacing: 6) {
                    Text("Job‑Name")
                        .font(DesignSystem.Fonts.semibold(size: 11))
                        .foregroundColor(DesignSystem.Colors.text2)
                        .tracking(0.6)
                    
                    TextField("z.B. 2025-12-20 Eishockey", text: $jobName)
                        .textFieldStyle(.roundedBorder)
                        .disabled(store.isIngestRunning)
                }
            }
        }
        .padding(12)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
    }
    
    private var optionsSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Optionen")
                .font(DesignSystem.Fonts.semibold(size: 13))
                .foregroundColor(DesignSystem.Colors.text)
            
            Toggle("JPG importieren (für schnelle Redaktion/Delivery)", isOn: $includeJPG)
                .disabled(store.isIngestRunning)
            Toggle("RAW importieren (Archiv / später)", isOn: $includeRAW)
                .disabled(store.isIngestRunning)
            Toggle("Unterordner erstellen (JPG / RAW)", isOn: $createSubfolders)
                .disabled(store.isIngestRunning)
            Toggle("Nach Import JPG‑Ordner öffnen", isOn: $openJPGAfterIngest)
                .disabled(store.isIngestRunning)
            
            Text("Hinweis: Die SD‑Karte wird **nie** gelöscht. Es wird nur kopiert.")
                .font(DesignSystem.Fonts.regular(size: 11))
                .foregroundColor(DesignSystem.Colors.text3)
        }
        .padding(12)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
    }
    
    private var statusSection: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Status")
                .font(DesignSystem.Fonts.semibold(size: 13))
                .foregroundColor(DesignSystem.Colors.text)
            
            if store.isIngestRunning {
                VStack(alignment: .leading, spacing: 8) {
                    ProgressView(value: store.ingestProgress)
                        .tint(DesignSystem.Colors.accent)
                    
                    HStack {
                        Text("\(store.ingestProcessedCount)/\(max(1, store.ingestTotalCount))")
                            .font(DesignSystem.Fonts.regular(size: 12))
                            .foregroundColor(DesignSystem.Colors.text2)
                            .monospacedDigit()
                        
                        Spacer()
                        
                        if !store.ingestCurrentName.isEmpty {
                            Text(store.ingestCurrentName)
                                .font(DesignSystem.Fonts.regular(size: 11))
                                .foregroundColor(DesignSystem.Colors.text3)
                                .lineLimit(1)
                                .truncationMode(.middle)
                        }
                    }
                }
            } else {
                Text("Bereit.")
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text3)
            }
        }
        .padding(12)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
    }
    
    private var footer: some View {
        HStack {
            if store.isIngestRunning {
                Button("Abbrechen") {
                    store.cancelIngestImport()
                }
                .buttonStyle(LightroomSecondaryButtonStyle())
                
                Spacer()
                
                Text("Import läuft…")
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text3)
            } else {
                Button("Zurücksetzen") {
                    jobName = Self.defaultJobName()
                    includeJPG = true
                    includeRAW = true
                    createSubfolders = true
                    openJPGAfterIngest = true
                }
                .buttonStyle(LightroomSecondaryButtonStyle())
                
                Spacer()
                
                Button("Import starten") {
                    startIngest()
                }
                .buttonStyle(.borderedProminent)
                .disabled(!canStartIngest)
            }
        }
    }
    
    private var canStartIngest: Bool {
        guard sourceFolder != nil, destinationParentFolder != nil else { return false }
        guard includeJPG || includeRAW else { return false }
        guard !jobName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return false }
        return true
    }
    
    private func pickSourceFolder() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = false
        panel.title = "Quelle auswählen"
        panel.prompt = "Auswählen"
        panel.message = "Wähle den SD‑Karten Ordner (z.B. DCIM) aus"
        
        if panel.runModal() == .OK, let url = panel.url {
            sourceFolder = url
            lastSourcePath = url.path
        }
    }
    
    private func pickDestinationFolder() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = true
        panel.title = "Ziel (Job‑Root) auswählen"
        panel.prompt = "Auswählen"
        panel.message = "Wähle den Zielordner, in dem der Job‑Ordner angelegt werden soll"
        
        if panel.runModal() == .OK, let url = panel.url {
            destinationParentFolder = url
            lastDestinationPath = url.path
        }
    }
    
    private func startIngest() {
        guard let sourceFolder, let destinationParentFolder else { return }
        let name = jobName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !name.isEmpty else { return }
        
        let options = PhotoStore.IngestOptions(
            includeJPG: includeJPG,
            includeRAW: includeRAW,
            createSubfolders: createSubfolders,
            openJPGAfterIngest: openJPGAfterIngest
        )
        
        store.startIngestImport(
            sourceURL: sourceFolder,
            destinationParentURL: destinationParentFolder,
            jobName: name,
            options: options
        )
    }
    
    private static func defaultJobName() -> String {
        let df = DateFormatter()
        df.dateFormat = "yyyy-MM-dd"
        return "\(df.string(from: Date())) Eishockey"
    }
}


