//
//  MaskOverlayView.swift
//  WB Foto Manager
//
//  Lightroom-like Masking Overlay (Linear/Radial) on top of PhotoDetailView
//

import SwiftUI
import AppKit

struct MaskOverlayView: View {
    @ObservedObject var photo: PhotoItem
    @ObservedObject var store: PhotoStore
    
    let containerSize: CGSize
    let imageSize: CGSize
    let zoom: CGFloat
    
    @EnvironmentObject var uiState: UIState
    @State private var reprocessTask: Task<Void, Never>?
    
    var body: some View {
        Group {
            if uiState.showMaskOverlay,
               let id = uiState.activeMaskID,
               let mask = photo.localMasks.first(where: { $0.id == id }) {
                overlay(for: mask)
                    .allowsHitTesting(true)
            }
        }
        .onDisappear {
            reprocessTask?.cancel()
            reprocessTask = nil
        }
    }
    
    @ViewBuilder
    private func overlay(for mask: LocalAdjustmentMask) -> some View {
        let scale = displayScale
        let offset = displayOffset
        
        ZStack {
            // Preview Fill (optional, Lightroom-like)
            if let fill = overlayFill(mask: mask, scale: scale, offset: offset) {
                fill
                    .compositingGroup()
                    .blendMode(.plusLighter)
            }
            
            switch mask.kind {
            case .linear:
                if let linear = mask.linear {
                    linearOverlay(maskID: mask.id, linear: linear, scale: scale, offset: offset)
                }
            case .radial:
                if let radial = mask.radial {
                    radialOverlay(maskID: mask.id, radial: radial, scale: scale, offset: offset)
                }
            case .brush:
                // kommt im nächsten Schritt
                EmptyView()
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
    
    // MARK: - Linear
    
    private func linearOverlay(maskID: UUID, linear: LinearMask, scale: CGFloat, offset: CGSize) -> some View {
        let p0 = viewPoint(from: linear.start, scale: scale, offset: offset)
        let p1 = viewPoint(from: linear.end, scale: scale, offset: offset)
        
        return ZStack {
            Path { path in
                path.move(to: p0)
                path.addLine(to: p1)
            }
            .stroke(Color.white.opacity(0.9), style: StrokeStyle(lineWidth: 2, lineCap: .round))
            .shadow(color: .black.opacity(0.45), radius: 2, x: 0, y: 1)
            
            maskHandle(maskID: maskID, kind: .linearStart, position: p0, scale: scale)
            maskHandle(maskID: maskID, kind: .linearEnd, position: p1, scale: scale)
        }
    }
    
    // MARK: - Radial
    
    private func radialOverlay(maskID: UUID, radial: RadialMask, scale: CGFloat, offset: CGSize) -> some View {
        let center = viewPoint(from: radial.center, scale: scale, offset: offset)
        let radiusPx = max(18, radialRadiusPixels(radial: radial, scale: scale))
        let edge = CGPoint(x: center.x + radiusPx, y: center.y)
        
        return ZStack {
            Circle()
                .stroke(Color.white.opacity(0.9), style: StrokeStyle(lineWidth: 2, dash: [6, 5]))
                .frame(width: radiusPx * 2, height: radiusPx * 2)
                .position(center)
                .shadow(color: .black.opacity(0.35), radius: 2, x: 0, y: 1)
            
            maskHandle(maskID: maskID, kind: .radialCenter, position: center, scale: scale)
            maskHandle(maskID: maskID, kind: .radialRadius, position: edge, scale: scale)
        }
    }
    
    // MARK: - Fill
    
    private func overlayFill(mask: LocalAdjustmentMask, scale: CGFloat, offset: CGSize) -> AnyView? {
        let intensity = 0.22 * max(0.0, min(1.0, mask.opacity))
        
        switch mask.kind {
        case .linear:
            guard let linear = mask.linear else { return nil }
            let start = UnitPoint(x: linear.start.x, y: linear.start.y)
            let end = UnitPoint(x: linear.end.x, y: linear.end.y)
            let a0 = mask.inverted ? 0.0 : intensity
            let a1 = mask.inverted ? intensity : 0.0
            
            return AnyView(
                Rectangle()
                    .fill(
                        LinearGradient(
                            colors: [
                                Color.red.opacity(a0),
                                Color.red.opacity(a1)
                            ],
                            startPoint: start,
                            endPoint: end
                        )
                    )
                    .frame(
                        width: imageSize.width * scale,
                        height: imageSize.height * scale
                    )
                    .position(
                        x: offset.width + (imageSize.width * scale) / 2,
                        y: offset.height + (imageSize.height * scale) / 2
                    )
            )
            
        case .radial:
            guard let radial = mask.radial else { return nil }
            let center = viewPoint(from: radial.center, scale: scale, offset: offset)
            let outer = radialRadiusPixels(radial: radial, scale: scale)
            let inner = outer * max(0.0, (1.0 - CGFloat(mask.feather)))
            
            let a0 = mask.inverted ? 0.0 : intensity
            let a1 = mask.inverted ? intensity : 0.0
            
            return AnyView(
                RadialGradient(
                    colors: [
                        Color.red.opacity(a0),
                        Color.red.opacity(a1)
                    ],
                    center: .init(x: center.x / max(1, containerSize.width), y: center.y / max(1, containerSize.height)),
                    startRadius: inner,
                    endRadius: outer
                )
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            )
            
        case .brush:
            return nil
        }
    }
    
    // MARK: - Handle
    
    private enum HandleKind {
        case linearStart
        case linearEnd
        case radialCenter
        case radialRadius
    }
    
    private func maskHandle(maskID: UUID, kind: HandleKind, position: CGPoint, scale: CGFloat) -> some View {
        MaskHandleDragger(position: position) {
            store.beginEditSession(for: photo)
        } onDelta: { delta in
            applyDrag(maskID: maskID, kind: kind, translation: delta, displayScale: scale)
            scheduleReprocess()
        } onEnd: {
            store.endEditSession(for: photo)
            scheduleReprocess(immediate: true)
        }
    }
    
    private func applyDrag(maskID: UUID, kind: HandleKind, translation: CGSize, displayScale: CGFloat) {
        guard let idx = photo.localMasks.firstIndex(where: { $0.id == maskID }) else { return }
        var list = photo.localMasks
        var mask = list[idx]
        
        let effScaleX = max(1.0, imageSize.width * displayScale * zoom)
        let effScaleY = max(1.0, imageSize.height * displayScale * zoom)
        let dx = Double(translation.width / effScaleX)
        let dy = Double(translation.height / effScaleY)
        
        func clamp01(_ v: Double) -> Double { max(0.0, min(1.0, v)) }
        
        switch mask.kind {
        case .linear:
            guard var linear = mask.linear else { break }
            switch kind {
            case .linearStart:
                linear.start = NormalizedPoint(x: clamp01(linear.start.x + dx), y: clamp01(linear.start.y + dy))
            case .linearEnd:
                linear.end = NormalizedPoint(x: clamp01(linear.end.x + dx), y: clamp01(linear.end.y + dy))
            default:
                break
            }
            mask.linear = linear
            
        case .radial:
            guard var radial = mask.radial else { break }
            switch kind {
            case .radialCenter:
                radial.center = NormalizedPoint(x: clamp01(radial.center.x + dx), y: clamp01(radial.center.y + dy))
            case .radialRadius:
                // Radius anhand horizontaler Bewegung skalieren
                let delta = Double(translation.width / max(1.0, min(containerSize.width, containerSize.height) * zoom))
                radial.radius = max(0.03, min(0.95, radial.radius + delta))
            default:
                break
            }
            mask.radial = radial
            
        case .brush:
            break
        }
        
        list[idx] = mask
        photo.localMasks = list
    }
    
    // MARK: - Geometry helpers
    
    private var displayScale: CGFloat {
        guard imageSize.width > 1, imageSize.height > 1 else { return 1 }
        let imageAspect = imageSize.width / imageSize.height
        let containerAspect = containerSize.width / containerSize.height
        
        if imageAspect > containerAspect {
            return containerSize.width / imageSize.width
        } else {
            return containerSize.height / imageSize.height
        }
    }
    
    private var displayOffset: CGSize {
        let scaledSize = CGSize(width: imageSize.width * displayScale, height: imageSize.height * displayScale)
        return CGSize(
            width: (containerSize.width - scaledSize.width) / 2,
            height: (containerSize.height - scaledSize.height) / 2
        )
    }
    
    private func viewPoint(from p: NormalizedPoint, scale: CGFloat, offset: CGSize) -> CGPoint {
        CGPoint(
            x: offset.width + CGFloat(p.x) * imageSize.width * scale,
            y: offset.height + CGFloat(p.y) * imageSize.height * scale
        )
    }
    
    private func radialRadiusPixels(radial: RadialMask, scale: CGFloat) -> CGFloat {
        let minDim = min(imageSize.width, imageSize.height)
        return CGFloat(radial.radius) * minDim * scale
    }
    
    // MARK: - Reprocess
    
    private func scheduleReprocess(immediate: Bool = false) {
        reprocessTask?.cancel()
        let delay: UInt64 = immediate ? 0 : 70_000_000
        reprocessTask = Task { @MainActor in
            if delay > 0 {
                try? await Task.sleep(nanoseconds: delay)
            }
            NotificationCenter.default.post(
                name: NSNotification.Name("PhotoAdjustmentsChanged"),
                object: nil,
                userInfo: ["photoID": photo.id]
            )
        }
    }
}

private struct MaskHandleView: View {
    let position: CGPoint
    @State private var hovering = false
    
    var body: some View {
        Circle()
            .fill(Color.white)
            .frame(width: 18, height: 18)
            .overlay(
                Circle()
                    .stroke(Color.black.opacity(0.55), lineWidth: 1)
            )
            .overlay(
                Circle()
                    .stroke(Color.red.opacity(0.8), lineWidth: hovering ? 2 : 1)
            )
            .shadow(color: .black.opacity(0.45), radius: 2, x: 0, y: 1)
            .position(position)
            .onHover { hovering in
                self.hovering = hovering
                if hovering {
                    NSCursor.crosshair.push()
                } else {
                    NSCursor.pop()
                }
            }
    }
}

private struct MaskHandleDragger: View {
    let position: CGPoint
    let onBegin: () -> Void
    let onDelta: (CGSize) -> Void
    let onEnd: () -> Void
    
    @State private var isDragging = false
    @State private var lastTranslation: CGSize = .zero
    
    init(position: CGPoint, onBegin: @escaping () -> Void, onDelta: @escaping (CGSize) -> Void, onEnd: @escaping () -> Void) {
        self.position = position
        self.onBegin = onBegin
        self.onDelta = onDelta
        self.onEnd = onEnd
    }
    
    var body: some View {
        MaskHandleView(position: position)
            .highPriorityGesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        if !isDragging {
                            isDragging = true
                            lastTranslation = .zero
                            onBegin()
                        }
                        let incremental = CGSize(
                            width: value.translation.width - lastTranslation.width,
                            height: value.translation.height - lastTranslation.height
                        )
                        lastTranslation = value.translation
                        onDelta(incremental)
                    }
                    .onEnded { _ in
                        isDragging = false
                        lastTranslation = .zero
                        onEnd()
                    }
            )
    }
}


