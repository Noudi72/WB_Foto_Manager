//
//  DetailView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI

struct DetailView: View {
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    @State private var image: NSImage?
    @State private var processedImage: NSImage?
    
    var body: some View {
        ZStack { content }
        .onChange(of: store.currentPhotoID) { _, _ in
            loadImage()
        }
        .onChange(of: store.currentPhoto?.cropRect) { _, _ in processImage() }
        .onChange(of: store.currentPhoto?.rotation) { _, _ in processImage() }
        .onChange(of: uiState.watermarkPreviewEnabled) { _, _ in processImage() }
        .onChange(of: uiState.watermarkPreviewPresetID) { _, _ in processImage() }
        .onReceive(NotificationCenter.default.publisher(for: NSNotification.Name("WatermarkSettingsChanged"))) { _ in
            processImage()
        }
        .onAppear(perform: loadImage)
        .onReceive(NotificationCenter.default.publisher(for: NSNotification.Name("PhotoAdjustmentsChanged"))) { notification in
            if let userInfo = notification.userInfo,
               let photoID = userInfo["photoID"] as? UUID,
               photoID == store.currentPhoto?.id {
                processImage()
            } else if notification.object == nil {
                // Fallback: Wenn keine userInfo, prüfe ob es das aktuelle Foto ist
                processImage()
            }
        }
    }
    
    @ViewBuilder
    private var content: some View {
        if let photo = store.currentPhoto {
            ZStack(alignment: .bottom) {
                if uiState.showBeforeAfter {
                    BeforeAfterView(photo: photo, store: store)
                } else {
                    PhotoDetailView(photo: photo, store: store, image: processedImage ?? image)
                }
                
                VirtualCopiesStrip(photo: photo, store: store)
                    .padding(.horizontal, 12)
                    .padding(.bottom, 10)
            }
        } else {
            DetailPlaceholderView(
                isLoading: store.isLoadingPhotos,
                progress: store.loadingProgress,
                hasPhotos: !store.photos.isEmpty,
                hasFolder: store.currentFolder != nil
            )
        }
    }
    
    private func loadImage() {
        guard let photo = store.currentPhoto else {
            image = nil
            processedImage = nil
            return
        }
        
        // Reset images first
        image = nil
        processedImage = nil
        
        Task(priority: .userInitiated) {
            // PROGRESSIVE LOADING: Erst Low-Res, dann High-Res
            let (lowRes, highRes) = await SmartImageLoader.shared.loadProgressive(url: photo.url)
            
            // Zeige Low-Res sofort für schnelles Feedback
            if let lowRes = lowRes {
                await MainActor.run {
                    self.image = lowRes
                    if !shouldProcess(photo) {
                        self.processedImage = lowRes
                    }
                }
            }
            
            // Ersetze mit High-Res sobald verfügbar
            if let highRes = highRes {
                await MainActor.run {
                    self.image = highRes
                    if !shouldProcess(photo) {
                        self.processedImage = highRes
                    } else {
                        processImage()
                    }
                }
            }
            
            // PREFETCH nächste Bilder für schnelles Browsing
            if let currentIndex = store.currentPhotoIndexInFiltered {
                let nextPhotos = Array(store.filteredPhotos.dropFirst(currentIndex + 1).prefix(5))
                let nextURLs = nextPhotos.map { $0.url }
                SmartImageLoader.shared.prefetchNext(urls: nextURLs)
            }
        }
    }
    
    private func processImage() {
        guard let photo = store.currentPhoto else { return }
        
        guard let originalCIImage = photo.loadFullImage() else {
            // PhotoKit Assets werden asynchron geladen (iCloud-Optimierung).
            Task {
                _ = await photo.loadFullImageAsync()
                await MainActor.run {
                    self.processImage()
                }
            }
            return
        }
        
        // Only re-process if adjustments/crop/rotation OR watermark-preview is active
        guard shouldProcess(photo) else {
            processedImage = image
            return
        }
        
        Task.detached(priority: .userInitiated) {
            // Lens Profile (Auto/Manuell) – async resolve, dann im Render anwenden.
            let (url, lensSettings) = await MainActor.run { (photo.url, photo.lensProfileSettings) }
            let lensMeta = await LensProfileService.shared.lensMeta(for: url)
            let resolvedLensProfile = await LensProfileService.shared.resolveProfile(for: url, settings: lensSettings)
            
            await MainActor.run {
                let editEngine = EditEngine.shared
                var processed = originalCIImage
                
                if let adjusted = editEngine.applyAdjustments(to: processed, adjustments: photo.adjustments) {
                    processed = adjusted
                }
                
                // Lens Profile Corrections (Lightroom-like)
                processed = editEngine.applyLensProfileCorrections(
                    to: processed,
                    settings: lensSettings,
                    profile: resolvedLensProfile,
                    meta: lensMeta
                )
                
                processed = editEngine.applyCropAndRotation(
                    to: processed,
                    cropRect: photo.cropRect,
                    rotation: photo.rotation
                )
                
                // Lokale Masken (Masking)
                if let masked = editEngine.applyLocalMasks(to: processed, masks: photo.localMasks) {
                    processed = masked
                }
                
                if let watermark = watermarkSettingsForPreview() {
                    if let watermarked = editEngine.applyWatermark(to: processed, settings: watermark) {
                        processed = watermarked
                    }
                }
                
                Task.detached(priority: .userInitiated) {
                    let rendered = await editEngine.render(processed, size: CGSize(width: 4000, height: 4000))
                    
                    await MainActor.run {
                        self.processedImage = rendered
                    }
                }
            }
        }
    }
    
    private func shouldProcess(_ photo: PhotoItem) -> Bool {
        photo.adjustments.hasAdjustments ||
        hasLocalAdjustments(photo) ||
        photo.lensProfileSettings.enabled ||
        photo.cropRect != nil ||
        photo.rotation != 0.0 ||
        (uiState.watermarkPreviewEnabled && watermarkSettingsForPreview() != nil)
    }
    
    private func hasLocalAdjustments(_ photo: PhotoItem) -> Bool {
        photo.localMasks.contains { mask in
            mask.isEnabled &&
            mask.opacity > 0.000_1 &&
            mask.adjustments.hasAdjustments
        }
    }
    
    private func watermarkSettingsForPreview() -> WatermarkSettings? {
        guard uiState.watermarkPreviewEnabled else { return nil }
        
        if let id = uiState.watermarkPreviewPresetID,
           let preset = store.exportPresets.first(where: { $0.id == id }) {
            return preset.watermarkSettings
        }
        
        return store.exportPresets.first(where: { $0.watermarkSettings != nil })?.watermarkSettings
    }
}

// MARK: - Subviews

private struct VirtualCopiesStrip: View {
    @ObservedObject var photo: PhotoItem
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    private var variants: [PhotoItem] {
        store.getVirtualCopies(for: photo.id)
    }
    
    private var hasVariants: Bool { variants.count > 1 }
    
    var body: some View {
        Group {
            if hasVariants {
                HStack(spacing: 10) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Varianten")
                            .font(DesignSystem.Fonts.semibold(size: 12))
                            .foregroundColor(.white)
                        Text("\(variants.count) Versionen")
                            .font(DesignSystem.Fonts.regular(size: 10))
                            .foregroundColor(.white.opacity(0.70))
                    }
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 6) {
                            ForEach(variants) { v in
                                VirtualCopyThumb(photo: v, isActive: store.currentPhotoID == v.id)
                                    .onTapGesture {
                                        store.selectPhoto(v)
                                    }
                                    .contextMenu {
                                        Button("In Detail anzeigen") {
                                            store.selectPhoto(v)
                                            uiState.viewMode = .detail
                                        }
                                        
                                        if !v.isMaster {
                                            Divider()
                                            Button("Virtuelle Kopie löschen") {
                                                store.deleteVirtualCopy(photoID: v.id)
                                            }
                                        }
                                    }
                            }
                        }
                        .padding(.vertical, 2)
                    }
                    .frame(maxWidth: 520)
                    
                    Spacer(minLength: 0)
                    
                    Button {
                        store.createVirtualCopy(of: photo.id)
                    } label: {
                        Image(systemName: "plus.square.on.square")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(.white)
                            .frame(width: 30, height: 26)
                            .background(Color.white.opacity(0.10))
                            .cornerRadius(7)
                    }
                    .buttonStyle(.plain)
                    .help("Virtuelle Kopie erstellen (⌘')")
                    
                    Button {
                        if let id = store.currentPhotoID {
                            store.deleteVirtualCopy(photoID: id)
                        }
                    } label: {
                        Image(systemName: "trash")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(canDeleteCurrent ? .white : .white.opacity(0.30))
                            .frame(width: 30, height: 26)
                            .background(Color.white.opacity(0.10))
                            .cornerRadius(7)
                    }
                    .buttonStyle(.plain)
                    .disabled(!canDeleteCurrent)
                    .help("Virtuelle Kopie löschen (⇧⌘')")
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
                .background(Color.black.opacity(0.65))
                .clipShape(RoundedRectangle(cornerRadius: 12))
                .overlay(
                    RoundedRectangle(cornerRadius: 12)
                        .stroke(Color.white.opacity(0.08), lineWidth: 1)
                )
            }
        }
    }
    
    private var canDeleteCurrent: Bool {
        guard let current = store.currentPhoto else { return false }
        return !current.isMaster
    }
}

private struct VirtualCopyThumb: View {
    @ObservedObject var photo: PhotoItem
    let isActive: Bool
    private let thumbMaxDimension: CGFloat = 320
    
    var body: some View {
        ZStack {
            // Rendered thumbnail shows the edits for Master + Virtual Copies.
            RenderedThumbnailView(photo: photo, maxDimension: thumbMaxDimension, interpolation: .high)
                .frame(width: isActive ? 68 : 60, height: isActive ? 48 : 44)
                .cornerRadius(8)
                .overlay(
                    RoundedRectangle(cornerRadius: 8)
                        .stroke(isActive ? DesignSystem.Colors.accent : Color.white.opacity(0.10), lineWidth: isActive ? 2 : 1)
                )
                .animation(.easeOut(duration: 0.12), value: isActive)
            
            // Kleine Info-Badge: Master / Copy #
            if photo.isMaster {
                Text("MASTER")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 3)
                    .background(Color.blue.opacity(0.85))
                    .clipShape(RoundedRectangle(cornerRadius: 6))
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomLeading)
                    .padding(4)
            } else {
                Text("COPY \(max(1, photo.virtualCopyNumber))")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundColor(.white)
                    .padding(.horizontal, 6)
                    .padding(.vertical, 3)
                    .background(Color.blue.opacity(0.85))
                    .clipShape(RoundedRectangle(cornerRadius: 6))
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottomLeading)
                    .padding(4)
            }
        }
    }
}

struct DetailPlaceholderView: View {
    let isLoading: Bool
    let progress: Double
    let hasPhotos: Bool
    let hasFolder: Bool
    
    var body: some View {
        VStack(spacing: 16) {
            if isLoading {
                VStack(spacing: 12) {
                    ProgressView(value: progress)
                        .frame(width: 300)
                    Text("Lade Bilder... \(Int(progress * 100))%")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            } else {
                Image(systemName: "photo.on.rectangle.angled")
                    .font(.system(size: 56))
                    .foregroundColor(DesignSystem.Colors.text3)
                
                if !hasFolder {
                    Text("Wählen Sie einen Ordner aus, um zu beginnen")
                        .font(DesignSystem.Fonts.semibold(size: 16))
                        .foregroundColor(DesignSystem.Colors.text2)
                } else if !hasPhotos {
                    Text("Keine Bilder in diesem Ordner gefunden")
                        .font(DesignSystem.Fonts.semibold(size: 16))
                        .foregroundColor(DesignSystem.Colors.text2)
                } else {
                    Text("Kein Foto ausgewählt")
                        .font(DesignSystem.Fonts.semibold(size: 16))
                        .foregroundColor(DesignSystem.Colors.text2)
                }
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}


struct PhotoDetailView: View {
    let photo: PhotoItem
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    let image: NSImage?
    
    @State private var zoom: CGFloat = 1.0
    @State private var zoomBase: CGFloat = 1.0
    @State private var panOffset: CGSize = .zero
    @State private var lastPanOffset: CGSize = .zero
    
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                if let img = image {
                    // Für Mask-Overlay zählt primär das *Seitenverhältnis* der aktuell angezeigten (ggf. gecroppten) Vorschau.
                    // NSImage.size ist dafür ausreichend; fallback auf Metadaten wenn nötig.
                    let w = (img.size.width > 1) ? img.size.width : CGFloat(photo.pixelWidth ?? 1)
                    let h = (img.size.height > 1) ? img.size.height : CGFloat(photo.pixelHeight ?? 1)
                    let imgSize = CGSize(width: max(1, w), height: max(1, h))
                    
                    ZStack {
                        Image(nsImage: img)
                            .resizable()
                            .interpolation(.high)
                            .antialiased(true)
                            .aspectRatio(contentMode: .fit)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                        
                        // Masking Overlay (Linear/Radial)
                        MaskOverlayView(
                            photo: photo,
                            store: store,
                            containerSize: geometry.size,
                            imageSize: imgSize,
                            zoom: zoom
                        )
                    }
                    .scaleEffect(zoom)
                    .offset(x: panOffset.width, y: panOffset.height)
                    .gesture(
                        MagnificationGesture()
                            .onChanged { value in
                                zoom = clamp(zoomBase * value, 0.5, 5.0)
                            }
                            .onEnded { _ in
                                zoom = clamp(zoom, 0.5, 5.0)
                                zoomBase = zoom
                                uiState.zoomLevel = Double(zoom)
                            }
                    )
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                panOffset = CGSize(
                                    width: lastPanOffset.width + value.translation.width,
                                    height: lastPanOffset.height + value.translation.height
                                )
                            }
                            .onEnded { _ in lastPanOffset = panOffset }
                    )
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    ProgressView().scaleEffect(1.2)
                }
            }
        }
        .background(Color.black)
        .focusable()
        .onAppear {
            let z = clamp(CGFloat(uiState.zoomLevel), 0.5, 5.0)
            zoom = z
            zoomBase = z
        }
        .onChange(of: uiState.zoomLevel) { _, newValue in
            let z = clamp(CGFloat(newValue), 0.5, 5.0)
            guard abs(z - zoom) > 0.0001 else { return }
            withAnimation(.easeOut(duration: 0.12)) {
                zoom = z
                zoomBase = z
            }
        }
        .onKeyPress(.leftArrow) { 
            store.selectPreviousPhoto()
            return .handled 
        }
        .onKeyPress(.rightArrow) { 
            store.selectNextPhoto()
            return .handled 
        }
        .onKeyPress(.space) { 
            resetZoom()
            return .handled 
        }
        .onKeyPress("1") {
            if let photoID = store.currentPhotoID {
                store.setRating(1, for: photoID)
            }
            return .handled
        }
        .onKeyPress("2") {
            if let photoID = store.currentPhotoID {
                store.setRating(2, for: photoID)
            }
            return .handled
        }
        .onKeyPress("3") {
            if let photoID = store.currentPhotoID {
                store.setRating(3, for: photoID)
            }
            return .handled
        }
        .onKeyPress("4") {
            if let photoID = store.currentPhotoID {
                store.setRating(4, for: photoID)
            }
            return .handled
        }
        .onKeyPress("5") {
            if let photoID = store.currentPhotoID {
                store.setRating(5, for: photoID)
            }
            return .handled
        }
        .onKeyPress("0") {
            if let photoID = store.currentPhotoID {
                store.setRating(0, for: photoID, autoAdvance: false)
            }
            return .handled
        }
        .onKeyPress("y") {
            uiState.showBeforeAfter.toggle()
            return .handled
        }
        .onKeyPress("g") {
            uiState.viewMode = .grid
            return .handled
        }
    }
    
    private func resetZoom() {
        withAnimation(.easeOut(duration: 0.2)) {
            zoom = 1.0
            zoomBase = 1.0
            panOffset = .zero
            lastPanOffset = .zero
        }
        uiState.zoomLevel = 1.0
    }
    
    private func clamp(_ value: CGFloat, _ minValue: CGFloat, _ maxValue: CGFloat) -> CGFloat {
        min(maxValue, max(minValue, value))
    }
}

struct BeforeAfterView: View {
    @ObservedObject var photo: PhotoItem
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    @State private var beforeImage: NSImage?
    @State private var afterImage: NSImage?
    @State private var splitFraction: CGFloat = 0.5
    
    var body: some View {
        GeometryReader { geo in
            ZStack {
                Color.black
                
                // BEFORE (links)
                if let before = beforeImage {
                    Image(nsImage: before)
                        .resizable()
                        .interpolation(.high)
                        .antialiased(true)
                        .aspectRatio(contentMode: .fit)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else {
                    ProgressView().scaleEffect(1.1)
                }
                
                // AFTER (rechts, per Mask)
                if let after = afterImage {
                    Image(nsImage: after)
                        .resizable()
                        .interpolation(.high)
                        .antialiased(true)
                        .aspectRatio(contentMode: .fit)
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                        .mask(
                            Rectangle()
                                .frame(width: geo.size.width * (1.0 - splitFraction))
                                .frame(maxWidth: .infinity, alignment: .trailing)
                        )
                }
                
                // Divider + Handle
                let xPos = geo.size.width * splitFraction
                
                Rectangle()
                    .fill(Color.white.opacity(0.85))
                    .frame(width: 2)
                    .frame(maxHeight: .infinity)
                    .position(x: xPos, y: geo.size.height / 2)
                
                BeforeAfterHandle()
                    .position(x: xPos, y: geo.size.height / 2)
                
                // Labels
                HStack {
                    badge("VORHER")
                    Spacer()
                    badge("NACHHER")
                }
                .padding(10)
                .allowsHitTesting(false)
                
                // Drag target (breiter als die Linie)
                Rectangle()
                    .fill(Color.clear)
                    .frame(width: 44)
                    .frame(maxHeight: .infinity)
                    .position(x: xPos, y: geo.size.height / 2)
                    .contentShape(Rectangle())
                    .gesture(
                        DragGesture(minimumDistance: 0)
                            .onChanged { value in
                                let newFrac = value.location.x / max(1, geo.size.width)
                                splitFraction = min(1.0, max(0.0, newFrac))
                            }
                    )
            }
        }
        .onAppear(perform: loadImages)
        .onChange(of: photo.id) { _, _ in loadImages() }
        .onChange(of: photo.adjustments) { _, _ in loadImages() }
        .onChange(of: photo.localMasks) { _, _ in loadImages() }
        .onChange(of: photo.lensProfileSettings) { _, _ in loadImages() }
        .onChange(of: photo.cropRect) { _, _ in loadImages() }
        .onChange(of: photo.rotation) { _, _ in loadImages() }
        .focusable()
        .onKeyPress(.leftArrow) {
            store.selectPreviousPhoto()
            return .handled
        }
        .onKeyPress(.rightArrow) {
            store.selectNextPhoto()
            return .handled
        }
        .onKeyPress("1") {
            if let photoID = store.currentPhotoID { store.setRating(1, for: photoID) }
            return .handled
        }
        .onKeyPress("2") {
            if let photoID = store.currentPhotoID { store.setRating(2, for: photoID) }
            return .handled
        }
        .onKeyPress("3") {
            if let photoID = store.currentPhotoID { store.setRating(3, for: photoID) }
            return .handled
        }
        .onKeyPress("4") {
            if let photoID = store.currentPhotoID { store.setRating(4, for: photoID) }
            return .handled
        }
        .onKeyPress("5") {
            if let photoID = store.currentPhotoID { store.setRating(5, for: photoID) }
            return .handled
        }
        .onKeyPress("0") {
            if let photoID = store.currentPhotoID { store.setRating(0, for: photoID, autoAdvance: false) }
            return .handled
        }
        .onKeyPress("y") {
            uiState.showBeforeAfter.toggle()
            return .handled
        }
        .onKeyPress("g") {
            uiState.viewMode = .grid
            return .handled
        }
    }
    
    private func loadImages() {
        beforeImage = nil
        afterImage = nil
        
        Task { @MainActor in
            // Werte vor dem Render capturen (stabile UI)
            let originalCI: CIImage
            if let cached = photo.loadFullImage() {
                originalCI = cached
            } else if let loaded = await photo.loadFullImageAsync() {
                originalCI = loaded
            } else {
                return
            }
            let cropRect = photo.cropRect
            let rotation = photo.rotation
            let adjustments = photo.adjustments
            let localMasks = photo.localMasks
            let lensSettings = photo.lensProfileSettings
            
            let editEngine = EditEngine.shared
            let lensMeta = await LensProfileService.shared.lensMeta(for: photo.url)
            let resolvedLensProfile = await LensProfileService.shared.resolveProfile(for: photo.url, settings: lensSettings)
            
            // BEFORE: Original + Lens-Corrections + Crop/Rotation (für deckungsgleichen Split)
            var beforeCI = originalCI
            beforeCI = editEngine.applyLensProfileCorrections(
                to: beforeCI,
                settings: lensSettings,
                profile: resolvedLensProfile,
                meta: lensMeta
            )
            beforeCI = editEngine.applyCropAndRotation(to: beforeCI, cropRect: cropRect, rotation: rotation)
            
            // AFTER: Adjustments + Lens-Corrections + Crop/Rotation + Local Masks
            var afterCI = originalCI
            if let adjusted = editEngine.applyAdjustments(to: afterCI, adjustments: adjustments) {
                afterCI = adjusted
            }
            afterCI = editEngine.applyLensProfileCorrections(
                to: afterCI,
                settings: lensSettings,
                profile: resolvedLensProfile,
                meta: lensMeta
            )
            afterCI = editEngine.applyCropAndRotation(to: afterCI, cropRect: cropRect, rotation: rotation)
            if let masked = editEngine.applyLocalMasks(to: afterCI, masks: localMasks) {
                afterCI = masked
            }
            
            // Optional: Wasserzeichen-Vorschau (nur auf AFTER)
            if uiState.watermarkPreviewEnabled,
               let watermark = watermarkSettingsForPreview() {
                if let watermarked = editEngine.applyWatermark(to: afterCI, settings: watermark) {
                    afterCI = watermarked
                }
            }
            
            let targetSize = CGSize(width: 4000, height: 4000)
            self.beforeImage = editEngine.render(beforeCI, size: targetSize)
            self.afterImage = editEngine.render(afterCI, size: targetSize)
        }
    }
    
    private func watermarkSettingsForPreview() -> WatermarkSettings? {
        guard uiState.watermarkPreviewEnabled else { return nil }
        
        if let id = uiState.watermarkPreviewPresetID,
           let preset = store.exportPresets.first(where: { $0.id == id }) {
            return preset.watermarkSettings
        }
        
        return store.exportPresets.first(where: { $0.watermarkSettings != nil })?.watermarkSettings
    }
    
    private func badge(_ text: String) -> some View {
        Text(text)
            .font(DesignSystem.Fonts.semibold(size: 10))
            .foregroundColor(DesignSystem.Colors.text)
            .tracking(0.6)
            .padding(.horizontal, 8)
            .padding(.vertical, 4)
            .background(Color.black.opacity(0.55))
            .overlay(
                RoundedRectangle(cornerRadius: 4)
                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
            )
            .cornerRadius(4)
    }
}

struct BeforeAfterHandle: View {
    var body: some View {
        ZStack {
            Circle()
                .fill(Color.black.opacity(0.55))
                .frame(width: 28, height: 28)
                .overlay(
                    Circle()
                        .stroke(Color.white.opacity(0.75), lineWidth: 1)
                )
            
            Image(systemName: "arrow.left.and.right")
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(Color.white.opacity(0.9))
        }
        .shadow(color: .black.opacity(0.35), radius: 6, x: 0, y: 2)
        .allowsHitTesting(false)
    }
}

