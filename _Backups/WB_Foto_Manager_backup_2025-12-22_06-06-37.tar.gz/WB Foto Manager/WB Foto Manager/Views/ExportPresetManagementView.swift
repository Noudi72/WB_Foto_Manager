//
//  ExportPresetManagementView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit
import UniformTypeIdentifiers

struct ExportPresetManagementView: View {
    @ObservedObject var store: PhotoStore
    @State private var showPresetEditor = false
    @State private var editingPreset: ExportPreset?
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Text("Export Presets verwalten")
                    .font(.headline)
                
                Spacer()
                
                Button(action: {
                    editingPreset = nil
                    showPresetEditor = true
                }) {
                    Image(systemName: "plus")
                    Text("Neu")
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
            
            Divider()
            
            // Preset List
            List {
                ForEach(store.exportPresets) { preset in
                    ExportPresetRowView(
                        preset: preset,
                        onEdit: {
                            editingPreset = preset
                            showPresetEditor = true
                        },
                        onDelete: {
                            store.deleteExportPreset(preset)
                        }
                    )
                }
            }
            .listStyle(.inset)
        }
        .frame(width: 600, height: 500)
        .sheet(isPresented: $showPresetEditor) {
            ExportPresetEditorView(
                preset: editingPreset,
                store: store,
                onSave: { preset in
                    if editingPreset != nil {
                        store.updateExportPreset(preset)
                    } else {
                        store.addExportPreset(preset)
                    }
                    showPresetEditor = false
                },
                onCancel: {
                    showPresetEditor = false
                }
            )
        }
    }
}

struct ExportPresetRowView: View {
    let preset: ExportPreset
    let onEdit: () -> Void
    let onDelete: () -> Void
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(preset.name)
                    .font(.headline)
                
                HStack(spacing: 16) {
                    Label("\(preset.maxDimension)px", systemImage: "ruler")
                    Label("\(Int(preset.quality * 100))%", systemImage: "gauge")
                    Label(preset.format.rawValue, systemImage: "doc")
                    if preset.watermarkSettings != nil {
                        Label("Wasserzeichen", systemImage: "signature")
                    }
                }
                .font(.caption)
                .foregroundColor(.secondary)
            }
            
            Spacer()
            
            HStack {
                Button(action: onEdit) {
                    Image(systemName: "pencil")
                }
                .buttonStyle(.plain)
                
                Button(action: onDelete) {
                    Image(systemName: "trash")
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.vertical, 4)
    }
}

struct ExportPresetEditorView: View {
    let preset: ExportPreset?
    @ObservedObject var store: PhotoStore
    @State private var name: String
    @State private var maxDimension: Int
    @State private var quality: Double
    @State private var format: ExportFormat
    @State private var hasWatermark: Bool
    @State private var watermarkSettings: WatermarkSettings
    @State private var showWatermarkEditor = false
    @State private var selectedUploadTargets: Set<UUID> = []
    @State private var filenameTemplate: String
    @State private var useCustomTemplate: Bool
    @State private var showTemplateHelp = false
    
    let onSave: (ExportPreset) -> Void
    let onCancel: () -> Void
    
    init(preset: ExportPreset?, store: PhotoStore, onSave: @escaping (ExportPreset) -> Void, onCancel: @escaping () -> Void) {
        self.preset = preset
        self.store = store
        self.onSave = onSave
        self.onCancel = onCancel
        
        if let existing = preset {
            _name = State(initialValue: existing.name)
            _maxDimension = State(initialValue: existing.maxDimension)
            _quality = State(initialValue: existing.quality)
            _format = State(initialValue: existing.format)
            _hasWatermark = State(initialValue: existing.watermarkSettings != nil)
            _watermarkSettings = State(initialValue: existing.watermarkSettings ?? WatermarkSettings.default)
            _selectedUploadTargets = State(initialValue: Set(existing.uploadTargets.compactMap { targetID in
                store.uploadTargets.first(where: { $0.id.uuidString == targetID })?.id
            }))
            _filenameTemplate = State(initialValue: existing.filenameTemplate ?? AppSettings.shared.filenameTemplate)
            _useCustomTemplate = State(initialValue: existing.filenameTemplate != nil)
        } else {
            _name = State(initialValue: "")
            _maxDimension = State(initialValue: 2048)
            _quality = State(initialValue: 0.85)
            _format = State(initialValue: .jpeg)
            _hasWatermark = State(initialValue: false)
            _watermarkSettings = State(initialValue: WatermarkSettings.default)
            _filenameTemplate = State(initialValue: AppSettings.shared.filenameTemplate)
            _useCustomTemplate = State(initialValue: false)
        }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(preset == nil ? "Neues Export Preset" : "Export Preset bearbeiten")
                .font(.headline)
            
            // Name
            VStack(alignment: .leading, spacing: 4) {
                Text("Name")
                    .font(.caption)
                TextField("Preset Name", text: $name)
            }
            
            // Format
            VStack(alignment: .leading, spacing: 4) {
                Text("Format")
                    .font(.caption)
                Picker("Format", selection: $format) {
                    Text("JPEG").tag(ExportFormat.jpeg)
                    Text("PNG").tag(ExportFormat.png)
                }
                .pickerStyle(.segmented)
            }
            
            // Max Dimension
            VStack(alignment: .leading, spacing: 4) {
                Text("Maximale Dimension: \(maxDimension)px")
                    .font(.caption)
                Slider(value: Binding(
                    get: { Double(maxDimension) },
                    set: { maxDimension = Int($0) }
                ), in: 500...8000, step: 100)
            }
            
            // Quality
            VStack(alignment: .leading, spacing: 4) {
                Text("Qualität: \(Int(quality * 100))%")
                    .font(.caption)
                Slider(value: $quality, in: 0.1...1.0, step: 0.05)
            }
            
            // Watermark
            Toggle("Wasserzeichen aktivieren", isOn: $hasWatermark)
            
            if hasWatermark {
                Button("Wasserzeichen konfigurieren") {
                    showWatermarkEditor = true
                }
                .buttonStyle(LightroomSecondaryButtonStyle())
            }
            
            Divider()
            
            // Filename Template
            VStack(alignment: .leading, spacing: 8) {
                Toggle("Eigenes Dateinamen-Template", isOn: $useCustomTemplate)
                
                if useCustomTemplate {
                    VStack(alignment: .leading, spacing: 4) {
                        Text("Template")
                            .font(.caption)
                        TextField("{originalname}_{preset}", text: $filenameTemplate)
                        
                        HStack {
                            Button("Variablen anzeigen") {
                                showTemplateHelp = true
                            }
                            .buttonStyle(.plain)
                            .font(.caption)
                            .foregroundColor(.secondary)
                            
                            Spacer()
                            
                            Text("Verwendet: \(useCustomTemplate ? "Preset-Template" : "Globales Template")")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                } else {
                    Text("Verwendet globales Template: \(AppSettings.shared.filenameTemplate)")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            Divider()
            
            // Upload Targets
            VStack(alignment: .leading, spacing: 8) {
                Text("Upload-Ziele")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                if store.uploadTargets.isEmpty {
                    Text("Keine Upload-Ziele konfiguriert")
                        .font(.caption)
                        .foregroundColor(.secondary)
                } else {
                    ForEach(store.uploadTargets) { target in
                        Toggle(target.name, isOn: Binding(
                            get: { selectedUploadTargets.contains(target.id) },
                            set: { isOn in
                                if isOn {
                                    selectedUploadTargets.insert(target.id)
                                } else {
                                    selectedUploadTargets.remove(target.id)
                                }
                            }
                        ))
                    }
                }
            }
            
            Spacer()
            
            // Buttons
            HStack {
                Button("Abbrechen", action: onCancel)
                
                Spacer()
                
                Button("Speichern") {
                    let uploadTargetIDs = selectedUploadTargets.map { $0.uuidString }
                    let newPreset = ExportPreset(
                        id: preset?.id ?? UUID(),
                        name: name,
                        maxDimension: maxDimension,
                        quality: quality,
                        format: format,
                        watermarkSettings: hasWatermark ? watermarkSettings : nil,
                        uploadTargets: uploadTargetIDs,
                        filenameTemplate: useCustomTemplate ? filenameTemplate : nil
                    )
                    onSave(newPreset)
                }
                .buttonStyle(.borderedProminent)
                .disabled(name.isEmpty)
            }
        }
        .padding()
        .frame(width: 500, height: 600)
        .sheet(isPresented: $showWatermarkEditor) {
            WatermarkSettingsView(settings: $watermarkSettings)
        }
        .sheet(isPresented: $showTemplateHelp) {
            FilenameTemplateHelpView()
        }
    }
}

struct FilenameTemplateHelpView: View {
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Verfügbare Template-Variablen")
                .font(.headline)
            
            ScrollView {
                VStack(alignment: .leading, spacing: 12) {
                    ForEach(FilenameTemplateService.availableVariables, id: \.variable) { item in
                        HStack(alignment: .top, spacing: 12) {
                            Text(item.variable)
                                .font(.system(.body, design: .monospaced))
                                .foregroundColor(.blue)
                                .frame(width: 120, alignment: .leading)
                            
                            Text(item.description)
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
            }
            
            Divider()
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Beispiele:")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                
                Text("{originalname}_{preset}")
                    .font(.system(.caption, design: .monospaced))
                    .foregroundColor(.secondary)
                Text("→ IMG_1234_Agentur")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                Text("{date}_{originalname}_{rating}")
                    .font(.system(.caption, design: .monospaced))
                    .foregroundColor(.secondary)
                Text("→ 2025-12-18_IMG_1234_5")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                Text("{originalname}_{index}")
                    .font(.system(.caption, design: .monospaced))
                    .foregroundColor(.secondary)
                Text("→ IMG_1234_0001")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            Button("Schließen") {
                dismiss()
            }
            .buttonStyle(.borderedProminent)
            .frame(maxWidth: .infinity)
        }
        .padding()
        .frame(width: 500, height: 500)
    }
}

struct WatermarkSettingsView: View {
    @Binding var settings: WatermarkSettings
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Wasserzeichen konfigurieren")
                .font(.headline)
            
            // Type
            Picker("Typ", selection: $settings.type) {
                Text("Text").tag(WatermarkType.text)
                Text("Logo").tag(WatermarkType.logo)
                Text("Beides").tag(WatermarkType.both)
            }
            .pickerStyle(.segmented)
            
            // Position (3x3 Grid)
            VStack(alignment: .leading, spacing: 8) {
                Text("Position")
                    .font(.caption)
                    .foregroundColor(.secondary)
                
                let positions: [WatermarkPosition] = [
                    .topLeft, .topCenter, .topRight,
                    .centerLeft, .center, .centerRight,
                    .bottomLeft, .bottomCenter, .bottomRight
                ]
                
                LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 6) {
                    ForEach(positions, id: \.self) { pos in
                        Button(action: { settings.position = pos }) {
                            Text(positionGlyph(pos))
                                .font(.system(size: 14, weight: .semibold))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 8)
                                .background(settings.position == pos ? Color.accentColor.opacity(0.25) : Color.gray.opacity(0.12))
                                .cornerRadius(6)
                        }
                        .buttonStyle(.plain)
                        .help(positionName(pos))
                    }
                }
            }
            
            // Size
            VStack(alignment: .leading, spacing: 4) {
                Text("Größe: \(Int(settings.size * 100))%")
                    .font(.caption)
                Slider(value: $settings.size, in: 0.05...0.5, step: 0.01)
            }
            
            // Text
            if settings.type == .text || settings.type == .both {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Text")
                        .font(.caption)
                    TextField("Wasserzeichen Text", text: Binding(
                        get: { settings.text ?? "" },
                        set: { settings.text = $0.isEmpty ? nil : $0 }
                    ))
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    let textSizeBinding = Binding<Double>(
                        get: { settings.textSize ?? 0.03 },
                        set: { settings.textSize = $0 }
                    )
                    Text("Textgröße: \(Int(textSizeBinding.wrappedValue * 100))%")
                        .font(.caption)
                    Slider(value: textSizeBinding, in: 0.01...0.08, step: 0.002)
                }
            }
            
            // Logo
            if settings.type == .logo || settings.type == .both {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Logo")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    HStack(spacing: 8) {
                        Text(settings.logoURL?.lastPathComponent ?? "Kein Logo ausgewählt")
                            .foregroundColor(.secondary)
                            .lineLimit(1)
                            .truncationMode(.middle)
                        
                        Spacer()
                        
                        Button("Auswählen…") {
                            chooseLogo()
                        }
                        .buttonStyle(LightroomSecondaryButtonStyle())
                        
                        if settings.logoURL != nil {
                            Button("Entfernen") {
                                settings.logoURL = nil
                                settings.logoBookmarkData = nil
                            }
                            .buttonStyle(LightroomSecondaryButtonStyle())
                        }
                    }
                }
            }
            
            // Opacity
            VStack(alignment: .leading, spacing: 4) {
                Text("Deckkraft: \(Int(settings.opacity * 100))%")
                    .font(.caption)
                Slider(value: $settings.opacity, in: 0.0...1.0, step: 0.05)
            }
            
            Spacer()
            
            Button("Fertig") {
                dismiss()
            }
            .buttonStyle(.borderedProminent)
            .frame(maxWidth: .infinity)
        }
        .padding()
        .frame(width: 400, height: 400)
    }
    
    private func chooseLogo() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = false
        panel.allowedContentTypes = [.image]
        panel.title = "Logo auswählen"
        panel.prompt = "Auswählen"
        
        if panel.runModal() == .OK, let url = panel.url {
            settings.logoURL = url
            do {
                let bookmarkData = try url.bookmarkData(
                    options: [.withSecurityScope],
                    includingResourceValuesForKeys: nil,
                    relativeTo: nil
                )
                settings.logoBookmarkData = bookmarkData
            } catch {
                print("⚠️ Konnte Logo-Bookmark nicht speichern: \(error)")
                settings.logoBookmarkData = nil
            }
        }
    }
    
    private func positionGlyph(_ position: WatermarkPosition) -> String {
        switch position {
        case .topLeft: return "↖"
        case .topCenter: return "↑"
        case .topRight: return "↗"
        case .centerLeft: return "←"
        case .center: return "⊙"
        case .centerRight: return "→"
        case .bottomLeft: return "↙"
        case .bottomCenter: return "↓"
        case .bottomRight: return "↘"
        }
    }
    
    private func positionName(_ position: WatermarkPosition) -> String {
        switch position {
        case .topLeft: return "Oben Links"
        case .topCenter: return "Oben Mitte"
        case .topRight: return "Oben Rechts"
        case .centerLeft: return "Mitte Links"
        case .center: return "Mitte"
        case .centerRight: return "Mitte Rechts"
        case .bottomLeft: return "Unten Links"
        case .bottomCenter: return "Unten Mitte"
        case .bottomRight: return "Unten Rechts"
        }
    }
}

