//
//  LensProfilePanel.swift
//  WB Foto Manager
//
//  Lightroom-like Lens Profile Corrections UI (Auto/Manual + Amount + Toggles)
//

import SwiftUI
import Combine

struct LensProfilePanel: View {
    @ObservedObject var photo: PhotoItem
    @EnvironmentObject var store: PhotoStore
    
    @State private var meta: LensMeta?
    @State private var resolvedProfile: LensProfile?
    @State private var userProfiles: [LensProfile] = []
    @State private var loadTask: Task<Void, Never>?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            // Separate label from Toggle so it never wraps into multiple lines (common in tight sidebars).
            HStack(spacing: 10) {
                Text("Profilkorrekturen")
                    .font(DesignSystem.Fonts.medium(size: 12))
                    .foregroundColor(DesignSystem.Colors.text)
                    .lineLimit(1)
                    .truncationMode(.tail)
                    .minimumScaleFactor(0.85)
                    .layoutPriority(1)
                
                Spacer(minLength: 8)
                
                if photo.lensProfileSettings.enabled {
                    Text(resolvedProfileTitle)
                        .font(DesignSystem.Fonts.regular(size: 10))
                        .foregroundColor(DesignSystem.Colors.text3)
                        .lineLimit(1)
                        .truncationMode(.tail)
                }
                
                Toggle("", isOn: binding(\.enabled, defaultValue: false, isDiscreteUndo: true))
                    .labelsHidden()
                    .toggleStyle(.switch)
                    .controlSize(.small)
                    .tint(DesignSystem.Colors.accent)
            }
            .padding(.horizontal, DesignSystem.Spacing.medium)
            
            if photo.lensProfileSettings.enabled {
                modeRow
                
                if photo.lensProfileSettings.mode == .manual {
                    manualPickerRow
                }
                
                if let meta, !meta.displaySummary.isEmpty {
                    Text(meta.displaySummary)
                        .font(DesignSystem.Fonts.regular(size: 10))
                        .foregroundColor(DesignSystem.Colors.text3)
                        .lineLimit(2)
                        .padding(.horizontal, DesignSystem.Spacing.medium)
                }
                
                AdjustmentSlider(
                    title: "Profil‑Stärke",
                    value: binding(\.amount, defaultValue: 1.0),
                    range: 0.0...2.0,
                    unit: "×",
                    defaultValue: 1.0,
                    photo: photo
                )
                
                opticsTogglesRow
            }
        }
        .onAppear { refresh() }
        .onChange(of: photo.id) { _, _ in refresh() }
        .onChange(of: photo.url) { _, _ in refresh() }
        .onChange(of: photo.lensProfileSettings.enabled) { _, _ in refresh() }
        .onChange(of: photo.lensProfileSettings.mode) { _, _ in refresh() }
        .onChange(of: photo.lensProfileSettings.manualProfileID) { _, _ in refresh() }
        .onReceive(NotificationCenter.default.publisher(for: .lensProfileDatabaseDidChange)) { _ in
            refresh()
        }
        .onDisappear {
            loadTask?.cancel()
            loadTask = nil
        }
    }
    
    // MARK: - Mode / Manual Picker
    
    private var modeRow: some View {
        HStack(spacing: 10) {
            Text("Modus")
                .font(DesignSystem.Fonts.regular(size: 11))
                .foregroundColor(DesignSystem.Colors.text2)
                .lineLimit(1)
            
            Spacer()
            
            Picker("", selection: binding(\.mode, defaultValue: .auto, isDiscreteUndo: true)) {
                ForEach(LensProfileMode.allCases, id: \.self) { mode in
                    Text(mode.title).tag(mode)
                }
            }
            .pickerStyle(.segmented)
            .frame(width: 160)
            .labelsHidden()
            .accessibilityLabel("Modus")
        }
        .padding(.horizontal, DesignSystem.Spacing.medium)
    }
    
    private var manualPickerRow: some View {
        HStack(spacing: 10) {
            Text("Profil")
                .font(DesignSystem.Fonts.regular(size: 11))
                .foregroundColor(DesignSystem.Colors.text2)
                .lineLimit(1)
            
            Spacer()
            
            Menu {
                Button("Kein Profil") {
                    setManualProfile("")
                }
                Divider()
                
                let user = userProfiles
                let builtIn = LensProfileCatalog.builtIn
                
                if !user.isEmpty {
                    Text("Eigene Profile")
                    ForEach(user.sorted(by: { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }), id: \.id) { p in
                        Button(p.name) { setManualProfile(p.id) }
                    }
                    Divider()
                }
                
                Text("Standard")
                ForEach(builtIn.sorted(by: { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }), id: \.id) { p in
                    Button(p.name) { setManualProfile(p.id) }
                }
            } label: {
                Text(manualProfileTitle)
                    .font(DesignSystem.Fonts.medium(size: 11))
                    .foregroundColor(DesignSystem.Colors.text)
                    .lineLimit(1)
                    .truncationMode(.tail)
                    .frame(maxWidth: 220, alignment: .leading)
            }
            .menuStyle(.borderlessButton)
        }
        .padding(.horizontal, DesignSystem.Spacing.medium)
    }
    
    private var manualProfileTitle: String {
        let id = photo.lensProfileSettings.manualProfileID
        guard !id.isEmpty else { return "Kein Profil" }
        return userProfiles.first(where: { $0.id == id })?.name ??
        LensProfileCatalog.builtIn.first(where: { $0.id == id })?.name ??
        "Unbekannt (\(id))"
    }
    
    private var resolvedProfileTitle: String {
        if photo.lensProfileSettings.mode == .manual {
            return "Manuell: \(manualProfileTitle)"
        }
        return "Auto: \(resolvedProfile?.name ?? "—")"
    }
    
    // MARK: - Compact Toggles
    
    private var opticsTogglesRow: some View {
        HStack(spacing: 18) {
            compactSwitch(title: "Verz.", help: "Verzeichnung", isOn: binding(\.correctDistortion, defaultValue: true, isDiscreteUndo: true))
            compactSwitch(title: "Vign.", help: "Vignette", isOn: binding(\.correctVignette, defaultValue: true, isDiscreteUndo: true))
            compactSwitch(title: "CA", help: "Chromatische Aberration", isOn: binding(\.removeChromaticAberration, defaultValue: true, isDiscreteUndo: true))
            Spacer(minLength: 0)
        }
        .padding(.horizontal, DesignSystem.Spacing.medium)
        .padding(.top, 2)
    }
    
    private func compactSwitch(title: String, help: String, isOn: Binding<Bool>) -> some View {
        VStack(spacing: 4) {
            Toggle("", isOn: isOn)
                .labelsHidden()
                .toggleStyle(.switch)
                .controlSize(.small)
                .tint(DesignSystem.Colors.accent)
                .help(help)
                .accessibilityLabel(help)
            
            Text(title)
                .font(DesignSystem.Fonts.regular(size: 10))
                .foregroundColor(DesignSystem.Colors.text2)
                .lineLimit(1)
        }
        .frame(width: 56)
    }
    
    // MARK: - Binding helpers
    
    private func binding<T>(_ keyPath: WritableKeyPath<LensProfileSettings, T>, defaultValue: T, isDiscreteUndo: Bool = false) -> Binding<T> {
        Binding(
            get: { photo.lensProfileSettings[keyPath: keyPath] },
            set: { newValue in
                if isDiscreteUndo {
                    store.registerUndoPoint(for: photo)
                }
                var copy = photo.lensProfileSettings
                copy[keyPath: keyPath] = newValue
                photo.lensProfileSettings = copy
                triggerUpdate()
            }
        )
    }
    
    private func setManualProfile(_ id: String) {
        store.registerUndoPoint(for: photo)
        var copy = photo.lensProfileSettings
        copy.manualProfileID = id
        photo.lensProfileSettings = copy
        triggerUpdate()
    }
    
    private func triggerUpdate() {
        photo.objectWillChange.send()
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id]
        )
    }
    
    // MARK: - Refresh
    
    private func refresh() {
        loadTask?.cancel()
        loadTask = Task { @MainActor in
            // Resolve meta + profile async (non-blocking UI)
            let url = photo.url
            let settings = photo.lensProfileSettings
            
            let user = await LensProfileService.shared.userProfilesSnapshot()
            let m = await LensProfileService.shared.lensMeta(for: url)
            let p = await LensProfileService.shared.resolveProfile(for: url, settings: settings)
            
            self.userProfiles = user
            self.meta = m
            self.resolvedProfile = p
        }
    }
}


