//
//  GridView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit

struct GridView: View {
    let photos: [PhotoItem]
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    @AppStorage("gridCellMinSizeV1") private var gridCellMinSize: Double = 190
    @State private var columnsCount: Int = 5
    private let spacing: CGFloat = 4
    
    // Cmd+Drag Bereichsauswahl
    @State private var dragStartPoint: CGPoint?
    @State private var dragCurrentPoint: CGPoint?
    @State private var isDraggingSelection: Bool = false
    
    var body: some View {
        GeometryReader { geo in
            let computedCount = computeColumnsCount(for: geo.size.width)
            let targetRowHeight = max(120, CGFloat(gridCellMinSize))
            let containerWidth = max(1, geo.size.width - (spacing * 2))
            let rows = buildRows(photos: photos, containerWidth: containerWidth, targetRowHeight: targetRowHeight)
            
            gridContent(rows: rows, containerWidth: containerWidth)
                .task(id: computedCount) {
                    // für Keyboard-Navigation (↑↓) brauchen wir die aktuelle Spaltenanzahl
                    columnsCount = computedCount
                }
        }
        .onKeyPress(.upArrow) {
            if let currentIndex = store.currentPhotoIndexInFiltered {
                let newIndex = currentIndex - columnsCount
                if newIndex >= 0 {
                    store.selectPhoto(at: newIndex)
                }
            }
            return .handled
        }
        .onKeyPress(.downArrow) {
            if let currentIndex = store.currentPhotoIndexInFiltered {
                let newIndex = currentIndex + columnsCount
                if newIndex < photos.count {
                    store.selectPhoto(at: newIndex)
                }
            }
            return .handled
        }
        .onKeyPress(.leftArrow) {
            if let currentIndex = store.currentPhotoIndexInFiltered {
                let newIndex = currentIndex - 1
                if newIndex >= 0 {
                    store.selectPhoto(at: newIndex)
                }
            }
            return .handled
        }
        .onKeyPress(.rightArrow) {
            if let currentIndex = store.currentPhotoIndexInFiltered {
                let newIndex = currentIndex + 1
                if newIndex < photos.count {
                    store.selectPhoto(at: newIndex)
                }
            }
            return .handled
        }
        .onKeyPress(.space) {
            uiState.viewMode = .detail
            return .handled
        }
        .onKeyPress("e") {
            uiState.viewMode = .detail
            return .handled
        }
        .onKeyPress("1") {
            if let photoID = store.currentPhotoID { store.setRating(1, for: photoID) }
            return .handled
        }
        .onKeyPress("2") {
            if let photoID = store.currentPhotoID { store.setRating(2, for: photoID) }
            return .handled
        }
        .onKeyPress("3") {
            if let photoID = store.currentPhotoID { store.setRating(3, for: photoID) }
            return .handled
        }
        .onKeyPress("4") {
            if let photoID = store.currentPhotoID { store.setRating(4, for: photoID) }
            return .handled
        }
        .onKeyPress("5") {
            if let photoID = store.currentPhotoID { store.setRating(5, for: photoID) }
            return .handled
        }
        .onKeyPress("0") {
            if let photoID = store.currentPhotoID { store.setRating(0, for: photoID, autoAdvance: false) }
            return .handled
        }
        .onKeyPress("b") {
            if let photoID = store.currentPhotoID { store.toggleQuickCollection(for: photoID) }
            return .handled
        }
        .onKeyPress("6") {
            if let photoID = store.currentPhotoID, let tag = ColorTag.fromKey("6") {
                store.toggleColorTag(tag, for: photoID)
            }
            return .handled
        }
        .onKeyPress("7") {
            if let photoID = store.currentPhotoID, let tag = ColorTag.fromKey("7") {
                store.toggleColorTag(tag, for: photoID)
            }
            return .handled
        }
        .onKeyPress("8") {
            if let photoID = store.currentPhotoID, let tag = ColorTag.fromKey("8") {
                store.toggleColorTag(tag, for: photoID)
            }
            return .handled
        }
        .onKeyPress("9") {
            if let photoID = store.currentPhotoID, let tag = ColorTag.fromKey("9") {
                store.toggleColorTag(tag, for: photoID)
            }
            return .handled
        }
        .onKeyPress("a") {
            if NSEvent.modifierFlags.contains(.command) {
                store.selectAllFilteredPhotos()
                return .handled
            }
            return .ignored
        }
        .focusable()
    }
    
    private func computeColumnsCount(for width: CGFloat) -> Int {
        let minCell = max(120, CGFloat(gridCellMinSize))
        let count = Int((width + spacing) / (minCell + spacing))
        return max(3, min(10, count))
    }
    
    private struct JustifiedRow: Identifiable {
        let id = UUID()
        let items: [JustifiedItem]
        let height: CGFloat
        let isLast: Bool
    }
    
    private struct JustifiedItem {
        let photo: PhotoItem
        let width: CGFloat
    }
    
    private func buildRows(photos: [PhotoItem], containerWidth: CGFloat, targetRowHeight: CGFloat) -> [JustifiedRow] {
        guard containerWidth > 1 else { return [] }
        guard !photos.isEmpty else { return [] }
        
        let minH = max(110, targetRowHeight * 0.75)
        let maxH = min(320, targetRowHeight * 1.35)
        
        var rows: [JustifiedRow] = []
        rows.reserveCapacity(max(1, photos.count / 4))
        
        var current: [PhotoItem] = []
        var aspectSum: CGFloat = 0
        
        func finalizeRow(isLast: Bool) {
            guard !current.isEmpty else { return }
            
            let gaps = spacing * CGFloat(max(0, current.count - 1))
            let available = max(1, containerWidth - gaps)
            
            var h: CGFloat
            if isLast {
                h = clamp(targetRowHeight, minH, maxH)
            } else {
                h = available / max(0.01, aspectSum)
                h = clamp(h, minH, maxH)
            }
            
            var widths = current.map { CGFloat($0.aspectRatio) * h }
            let total = widths.reduce(0, +) + gaps
            let diff = containerWidth - total
            if abs(diff) < 12, let last = widths.indices.last {
                widths[last] += diff
            }
            
            let items = zip(current, widths).map { JustifiedItem(photo: $0.0, width: max(40, $0.1)) }
            rows.append(JustifiedRow(items: items, height: h, isLast: isLast))
            
            current.removeAll(keepingCapacity: true)
            aspectSum = 0
        }
        
        for photo in photos {
            let ar = CGFloat(photo.aspectRatio)
            current.append(photo)
            aspectSum += ar
            
            let gaps = spacing * CGFloat(max(0, current.count - 1))
            let estimatedWidth = (aspectSum * targetRowHeight) + gaps
            if estimatedWidth >= containerWidth, current.count >= 2 {
                finalizeRow(isLast: false)
            }
        }
        
        finalizeRow(isLast: true)
        return rows
    }
    
    private func clamp(_ v: CGFloat, _ lo: CGFloat, _ hi: CGFloat) -> CGFloat {
        max(lo, min(hi, v))
    }
    
    // MARK: - Grid Content (aufgeteilt für Compiler-Performance)
    
    @ViewBuilder
    private func gridContent(rows: [JustifiedRow], containerWidth: CGFloat) -> some View {
        ScrollView {
            ZStack {
                gridStack(rows: rows)
                
                // Cmd+Drag Bereichsauswahl Visualisierung
                if isDraggingSelection, let start = dragStartPoint, let current = dragCurrentPoint {
                    DragSelectionRect(startPoint: start, currentPoint: current)
                        .allowsHitTesting(false)
                }
            }
        }
        .background(DesignSystem.Colors.background)
        .simultaneousGesture(
            DragGesture(minimumDistance: 5)
                .onChanged { value in
                    // Nur aktivieren wenn Cmd gedrückt ist
                    if NSEvent.modifierFlags.contains(.command) {
                        if dragStartPoint == nil {
                            dragStartPoint = value.startLocation
                            isDraggingSelection = true
                            uiState.selectionMode = true
                        }
                        dragCurrentPoint = value.location
                        
                        // Fotos innerhalb des Rechtecks finden und auswählen
                        updateSelectionForDragRect(start: dragStartPoint!, current: value.location, rows: rows, padding: spacing)
                    }
                }
                .onEnded { _ in
                    if isDraggingSelection {
                        dragStartPoint = nil
                        dragCurrentPoint = nil
                        isDraggingSelection = false
                    }
                }
        )
    }
    
    @ViewBuilder
    private func gridStack(rows: [JustifiedRow]) -> some View {
        LazyVStack(alignment: .leading, spacing: spacing) {
            ForEach(rows) { row in
                HStack(spacing: spacing) {
                    ForEach(row.items, id: \.photo.id) { item in
                        gridCell(item: item, row: row)
                    }
                    if row.isLast {
                        Spacer(minLength: 0)
                    }
                }
            }
        }
        .padding(spacing)
    }
    
    @ViewBuilder
    private func gridCell(item: JustifiedItem, row: JustifiedRow) -> some View {
        GridPhotoCell(
            photo: item.photo,
            store: store,
            isSelected: store.selectedPhotoIDs.contains(item.photo.id)
        )
        .frame(width: item.width, height: row.height)
        .contentShape(Rectangle())
        .highPriorityGesture(
            TapGesture(count: 2).onEnded {
                DispatchQueue.main.async {
                    let win = NSApp.keyWindow ?? NSApp.mainWindow
                    win?.endEditing(for: nil)
                    win?.makeFirstResponder(nil)
                }
                // Double-Tap: Immer zu Detail, auch bei Cmd
                store.selectPhoto(item.photo, withModifiers: [])
                uiState.viewMode = .detail
            }
        )
        .simultaneousGesture(
            TapGesture().onEnded {
                // Wenn bereits ein Drag läuft, nicht reagieren
                if !isDraggingSelection {
                    DispatchQueue.main.async {
                        let win = NSApp.keyWindow ?? NSApp.mainWindow
                        win?.endEditing(for: nil)
                        win?.makeFirstResponder(nil)
                    }
                    let modifiers = NSEvent.modifierFlags
                    store.selectPhoto(item.photo, withModifiers: modifiers)
                }
            }
        )
        .contextMenu {
            gridCellContextMenu(item: item)
        }
    }
    
    @ViewBuilder
    private func gridCellContextMenu(item: JustifiedItem) -> some View {
        Button("In Detail anzeigen") {
            DispatchQueue.main.async {
                let win = NSApp.keyWindow ?? NSApp.mainWindow
                win?.endEditing(for: nil)
                win?.makeFirstResponder(nil)
            }
            store.selectPhoto(item.photo, withModifiers: [])
            uiState.viewMode = .detail
        }
        
        Divider()
        
        Menu("Rating") {
            Button("Rating löschen") { store.setRating(0, for: item.photo.id, autoAdvance: false) }
            Divider()
            Button("1 Stern") { store.setRating(1, for: item.photo.id, autoAdvance: false) }
            Button("2 Sterne") { store.setRating(2, for: item.photo.id, autoAdvance: false) }
            Button("3 Sterne") { store.setRating(3, for: item.photo.id, autoAdvance: false) }
            Button("4 Sterne") { store.setRating(4, for: item.photo.id, autoAdvance: false) }
            Button("5 Sterne") { store.setRating(5, for: item.photo.id, autoAdvance: false) }
        }
        
        Menu("Pick/Reject") {
            Button("Als Pick markieren (P)") { store.markAsPick(photoID: item.photo.id) }
            Button("Als Reject markieren (X)") { store.markAsReject(photoID: item.photo.id) }
            Button("Markierung entfernen (U)") { store.unflag(photoID: item.photo.id) }
        }
        
        Menu("Color Label") {
            Button("Rot (6)") { store.toggleColorTag(.red, for: item.photo.id) }
            Button("Gelb (7)") { store.toggleColorTag(.yellow, for: item.photo.id) }
            Button("Grün (8)") { store.toggleColorTag(.green, for: item.photo.id) }
            Button("Blau (9)") { store.toggleColorTag(.blue, for: item.photo.id) }
        }
        
        Divider()
        
        Button(item.photo.isInQuickCollection ? "Aus Quick Collection entfernen (B)" : "Zu Quick Collection hinzufügen (B)") {
            store.toggleQuickCollection(for: item.photo.id)
        }
    }
    
    // MARK: - Cmd+Drag Bereichsauswahl
    
    private func updateSelectionForDragRect(start: CGPoint, current: CGPoint, rows: [JustifiedRow], padding: CGFloat) {
        // Normalisiere Rechteck (start und current können in beliebiger Reihenfolge sein)
        let minX = min(start.x, current.x)
        let maxX = max(start.x, current.x)
        let minY = min(start.y, current.y)
        let maxY = max(start.y, current.y)
        
        let dragRect = CGRect(x: minX, y: minY, width: maxX - minX, height: maxY - minY)
        var accumulatedY: CGFloat = padding
        var selectedIDs = Set<UUID>()
        
        // Durchlaufe alle Reihen und prüfe, welche Fotos sich im Rechteck befinden
        for row in rows {
            var accumulatedX: CGFloat = padding
            
            for item in row.items {
                let itemRect = CGRect(
                    x: accumulatedX,
                    y: accumulatedY,
                    width: item.width,
                    height: row.height
                )
                
                // Prüfe ob das Rechteck sich mit dem Drag-Rechteck überschneidet
                if itemRect.intersects(dragRect) {
                    selectedIDs.insert(item.photo.id)
                }
                
                accumulatedX += item.width + spacing
            }
            
            accumulatedY += row.height + spacing
        }
        
        // Aktualisiere Auswahl: Setze Auswahl auf alle Fotos im Rechteck (nicht Union, damit es wie macOS Finder funktioniert)
        // Aber: wenn bereits andere Fotos ausgewählt sind, fügen wir sie hinzu (Union-Verhalten)
        if !selectedIDs.isEmpty {
            // Wenn der Drag startet, setzen wir die Auswahl neu, sonst Union
            // Für besseres macOS-Verhalten: Union wenn bereits Auswahl vorhanden
            if store.selectedPhotoIDs.isEmpty {
                store.selectedPhotoIDs = selectedIDs
            } else {
                store.selectedPhotoIDs.formUnion(selectedIDs)
            }
            // Setze currentPhotoID auf das erste Foto im Rechteck (wenn noch nicht gesetzt)
            if store.currentPhotoID == nil || !selectedIDs.contains(store.currentPhotoID!) {
                store.currentPhotoID = selectedIDs.first
            }
        }
    }
}

// MARK: - Drag Selection Rectangle Visualisierung

private struct DragSelectionRect: View {
    let startPoint: CGPoint
    let currentPoint: CGPoint
    
    private var rect: CGRect {
        let minX = min(startPoint.x, currentPoint.x)
        let maxX = max(startPoint.x, currentPoint.x)
        let minY = min(startPoint.y, currentPoint.y)
        let maxY = max(startPoint.y, currentPoint.y)
        return CGRect(x: minX, y: minY, width: maxX - minX, height: maxY - minY)
    }
    
    var body: some View {
        Rectangle()
            .stroke(DesignSystem.Colors.accent, lineWidth: 2)
            .background(
                Rectangle()
                    .fill(DesignSystem.Colors.accent.opacity(0.15))
            )
            .frame(width: rect.width, height: rect.height)
            .position(x: rect.midX, y: rect.midY)
    }
}

struct GridPhotoCell: View {
    @ObservedObject var photo: PhotoItem
    @ObservedObject var store: PhotoStore
    let isSelected: Bool
    
    var body: some View {
        ZStack {
            Group {
                if photo.isMaster {
                    AsyncThumbnailView(photo: photo, previewSize: .thumbnail, interpolation: .high)
                } else {
                    RenderedThumbnailView(photo: photo, maxDimension: PreviewSize.thumbnail.maxDimension, interpolation: .high)
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .clipped()
            
            PhotoBadgesOverlay(
                photo: photo,
                style: .grid,
                bestOf: store.bestOfOverlayInfo(for: photo.id)
            )
            
            // Selection Indicator - Lightroom Style
            if isSelected {
                RoundedRectangle(cornerRadius: 6)
                    .stroke(DesignSystem.Colors.accent, lineWidth: 2)
                RoundedRectangle(cornerRadius: 6)
                    .stroke(Color.white.opacity(0.15), lineWidth: 1)
            }
        }
        .background(DesignSystem.Colors.background4)
        .cornerRadius(6)
    }
}
