//
//  ActivityCenterPopover.swift
//  WB Foto Manager
//
//  Central place to see what's running (Export/Upload via Export, AI Indexing, Best-of, Batch Auto),
//  optimized for fast Export → Folder/Cloud workflows.
//

import SwiftUI

struct ActivityCenterButton: View {
    @EnvironmentObject var store: PhotoStore
    @State private var isHovering = false
    @State private var showPopover = false
    
    private var hasAnyRunningTask: Bool {
        store.isIngestRunning ||
        store.isQuickExporting ||
        store.isExportQueueRunning ||
        store.isBatchAutoRunning ||
        store.isAITaggingRunning ||
        store.isAISearchRunning ||
        store.isBestOfRunning
    }
    
    private var hasFailures: Bool {
        !store.exportQueueFailures.isEmpty
    }
    
    var body: some View {
        Button {
            showPopover.toggle()
        } label: {
            ZStack {
                Image(systemName: "waveform.path.ecg")
                    .font(DesignSystem.Fonts.medium(size: 14))
                    .foregroundColor(DesignSystem.Colors.text)
                    .frame(width: 32, height: 32)
                    .background(backgroundColor)
                    .overlay(
                        RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                            .stroke(DesignSystem.Colors.border, lineWidth: 1)
                    )
                    .cornerRadius(DesignSystem.CornerRadius.small)
                
                if hasAnyRunningTask {
                    ProgressView()
                        .progressViewStyle(.circular)
                        .tint(DesignSystem.Colors.accent)
                        .scaleEffect(0.65)
                        .frame(width: 18, height: 18)
                } else if hasFailures {
                    Circle()
                        .fill(Color.red.opacity(0.9))
                        .frame(width: 8, height: 8)
                        .overlay(
                            Circle().stroke(Color.white.opacity(0.8), lineWidth: 0.8)
                        )
                        .offset(x: 10, y: -10)
                }
            }
        }
        .buttonStyle(.plain)
        .help(helpText)
        .popover(isPresented: $showPopover, arrowEdge: .top) {
            ActivityCenterPopover()
                .environmentObject(store)
        }
        .onHover { hovering in
            isHovering = hovering
        }
    }
    
    private var backgroundColor: Color {
        if isHovering { return DesignSystem.Colors.background4 }
        return DesignSystem.Colors.background3
    }
    
    private var helpText: String {
        if hasAnyRunningTask {
            return "Aktivität (läuft…) – Exporte/Indexing/Best‑of"
        }
        if hasFailures {
            return "Aktivität – Fehler in Export‑Queue"
        }
        return "Aktivität – Status & Jobs"
    }
}

private struct ActivityCenterPopover: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @StateObject private var settings = AppSettings.shared
    @Environment(\.dismiss) private var dismiss
    
    private var enabledUploadTargetsCount: Int {
        store.uploadTargets.filter { $0.isEnabled }.count
    }
    
    private var anyRunning: Bool {
        store.isIngestRunning ||
        store.isQuickExporting ||
        store.isExportQueueRunning ||
        store.isBatchAutoRunning ||
        store.isAITaggingRunning ||
        store.isAISearchRunning ||
        store.isBestOfRunning
    }
    
    var body: some View {
        let isCompact = settings.adjustmentsSidebarCompactMode
        
        VStack(alignment: .leading, spacing: isCompact ? 8 : 12) {
            header
            
            ScrollView {
                VStack(alignment: .leading, spacing: isCompact ? 8 : 10) {
                    jobPresetCard
                    
                    if store.isIngestRunning {
                        taskCard(
                            icon: "sdcard",
                            title: "Ingest / Import",
                            detail: "\(store.ingestProcessedCount)/\(max(1, store.ingestTotalCount))",
                            progress: store.ingestProgress,
                            progressText: store.ingestCurrentName.isEmpty ? "Import läuft…" : store.ingestCurrentName,
                            cancelTitle: "Abbrechen",
                            cancelAction: {
                                store.cancelIngestImport()
                            }
                        )
                    }
                    
                    if store.isQuickExporting {
                        taskCard(
                            icon: "square.and.arrow.up",
                            title: "Quick Export",
                            detail: "\(Int((store.quickExportProgress * 100).rounded()))%",
                            progress: store.quickExportProgress,
                            progressText: "Export/Upload läuft…",
                            cancelTitle: "Abbrechen",
                            cancelAction: {
                                store.cancelQuickExport()
                            }
                        )
                    }
                    
                    if store.isExportQueueRunning {
                        let done = store.exportQueueProcessedCount
                        let total = max(1, store.exportQueueTotalCount)
                        let name = store.exportQueueCurrentName.isEmpty ? nil : store.exportQueueCurrentName
                        taskCard(
                            icon: "tray.and.arrow.up",
                            title: "Export‑Queue",
                            detail: "\(done)/\(total)",
                            progress: store.exportQueueProgress,
                            progressText: name ?? "Export/Upload läuft…",
                            cancelTitle: "Abbrechen",
                            cancelAction: {
                                store.cancelExportQueue()
                            }
                        )
                    }
                    
                    if !store.exportQueueFailures.isEmpty {
                        failureCard()
                    }
                    
                    if store.isAISearchRunning {
                        taskCard(
                            icon: "sparkles",
                            title: "AI‑Index (Suche)",
                            detail: "\(store.aiSearchProcessedCount)/\(max(1, store.aiSearchTotalCount))",
                            progress: store.aiSearchProgress,
                            progressText: store.aiSearchCurrentName.isEmpty ? "Indexing…" : store.aiSearchCurrentName,
                            cancelTitle: "Abbrechen",
                            cancelAction: {
                                store.cancelAISearchIndex()
                            }
                        )
                    }
                    
                    if store.isAITaggingRunning {
                        taskCard(
                            icon: "tag",
                            title: "AI Keywords",
                            detail: "\(store.aiTaggingProcessedCount)/\(max(1, store.aiTaggingTotalCount))",
                            progress: store.aiTaggingProgress,
                            progressText: store.aiTaggingCurrentName.isEmpty ? "Generiere…" : store.aiTaggingCurrentName,
                            cancelTitle: "Abbrechen",
                            cancelAction: {
                                store.cancelAITagging()
                            }
                        )
                    }
                    
                    if store.isBestOfRunning {
                        taskCard(
                            icon: "crown.fill",
                            title: "Best‑of",
                            detail: "\(store.bestOfProcessedCount)/\(max(1, store.bestOfTotalCount))",
                            progress: store.bestOfProgress,
                            progressText: store.bestOfCurrentName.isEmpty ? "Analysiere…" : store.bestOfCurrentName,
                            cancelTitle: "Abbrechen",
                            cancelAction: {
                                store.cancelBestOf()
                            }
                        )
                    }
                    
                    if store.isBatchAutoRunning {
                        taskCard(
                            icon: "wand.and.stars",
                            title: settings.autoUsesStyleProfile ? "Batch Auto (+ Stil)" : "Batch Auto",
                            detail: "\(store.batchAutoProcessedCount)/\(max(1, store.batchAutoTotalCount))",
                            progress: store.batchAutoProgress,
                            progressText: store.batchAutoCurrentName.isEmpty ? "Wende an…" : store.batchAutoCurrentName,
                            cancelTitle: "Abbrechen",
                            cancelAction: {
                                store.cancelBatchAuto()
                            }
                        )
                    }
                    
                    if !anyRunning && store.exportQueueFailures.isEmpty {
                        emptyState
                    }
                }
                .padding(.vertical, isCompact ? 2 : 4)
            }
            
            Divider().opacity(0.7)
            
            footer
        }
        .padding(isCompact ? 10 : 14)
        .frame(width: isCompact ? 360 : 380, height: isCompact ? 520 : 560)
        .background(DesignSystem.Colors.background2)
        .lightroomSidebarTheme()
        .controlSize(isCompact ? .mini : .small)
    }
    
    private var jobPresetCard: some View {
        let isCompact = settings.adjustmentsSidebarCompactMode
        
        let folderName: String = {
            guard let url = store.currentFolder else { return "Kein Ordner geöffnet" }
            if url.pathExtension.lowercased() == "photoslibrary" { return "Photos Library" }
            return url.lastPathComponent
        }()
        
        let quickPresetName: String = {
            guard let id = store.quickExportPresetID else { return "—" }
            return store.exportPresets.first(where: { $0.id == id })?.name ?? "—"
        }()
        
        let quickDirName: String = {
            guard let url = store.quickExportDirectory else { return "—" }
            return url.lastPathComponent
        }()
        
        let styleName: String = {
            if !settings.autoUsesStyleProfile { return "Deaktiviert" }
            if settings.autoStylePresetID.isEmpty { return "Aktiv (kein Preset)" }
            if let id = UUID(uuidString: settings.autoStylePresetID),
               let preset = store.adjustmentPresets.first(where: { $0.id == id }) {
                return preset.name
            }
            return "Aktiv (unbekannt)"
        }()
        
        return VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                Image(systemName: "folder")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text2)
                    .frame(width: 16)
                
                VStack(alignment: .leading, spacing: 1) {
                    Text("Job: \(folderName)")
                        .font(DesignSystem.Fonts.semibold(size: 12))
                        .foregroundColor(DesignSystem.Colors.text)
                        .lineLimit(1)
                        .truncationMode(.middle)
                    
                    Text(store.hasJobPresetForCurrentFolder ? "Gespeichert" : "Nicht gespeichert")
                        .font(DesignSystem.Fonts.regular(size: isCompact ? 10 : 11))
                        .foregroundColor(store.hasJobPresetForCurrentFolder ? DesignSystem.Colors.text3 : DesignSystem.Colors.text4)
                        .lineLimit(1)
                }
                
                Spacer(minLength: 8)
                
                if store.currentFolder != nil {
                    if store.hasJobPresetForCurrentFolder {
                        if isCompact {
                            Button("Aktualisieren") {
                                store.saveJobPresetForCurrentFolder()
                            }
                            .buttonStyle(LightroomSmallButtonStyle())
                            
                            Button("Löschen") {
                                store.deleteJobPresetForCurrentFolder()
                            }
                            .buttonStyle(LightroomSmallButtonStyle())
                        } else {
                            Button("Aktualisieren") {
                                store.saveJobPresetForCurrentFolder()
                            }
                            .buttonStyle(LightroomSecondaryButtonStyle())
                            
                            Button("Löschen") {
                                store.deleteJobPresetForCurrentFolder()
                            }
                            .buttonStyle(LightroomSecondaryButtonStyle())
                        }
                    } else {
                        if isCompact {
                            Button("Speichern") {
                                store.saveJobPresetForCurrentFolder()
                            }
                            .buttonStyle(LightroomSmallButtonStyle())
                        } else {
                            Button("Speichern") {
                                store.saveJobPresetForCurrentFolder()
                            }
                            .buttonStyle(LightroomSecondaryButtonStyle())
                        }
                    }
                }
            }
            
            if store.hasJobPresetForCurrentFolder {
                // Summary
                VStack(alignment: .leading, spacing: 4) {
                    Text("Quick Export: \(quickPresetName) • \(quickDirName)")
                        .font(DesignSystem.Fonts.regular(size: isCompact ? 10 : 11))
                        .foregroundColor(DesignSystem.Colors.text3)
                        .lineLimit(1)
                        .truncationMode(.middle)
                    
                    Text("Stil‑Profil: \(styleName)")
                        .font(DesignSystem.Fonts.regular(size: isCompact ? 10 : 11))
                        .foregroundColor(DesignSystem.Colors.text3)
                        .lineLimit(1)
                        .truncationMode(.tail)
                }
                
                Divider().opacity(0.7)
                
                Toggle("Upload‑Ziele pro Job filtern", isOn: $store.jobUsesUploadTargetFilter)
                    .font(DesignSystem.Fonts.regular(size: isCompact ? 11 : 12))
                    .tint(DesignSystem.Colors.accent)
                
                if store.jobUsesUploadTargetFilter {
                    HStack(spacing: 10) {
                        if isCompact {
                            Button("Alle") {
                                store.jobUploadTargetIDs = Set(store.uploadTargets.map { $0.id.uuidString })
                            }
                            .buttonStyle(LightroomSmallButtonStyle())
                            
                            Button("Keine") {
                                store.jobUploadTargetIDs = []
                            }
                            .buttonStyle(LightroomSmallButtonStyle())
                        } else {
                            Button("Alle") {
                                store.jobUploadTargetIDs = Set(store.uploadTargets.map { $0.id.uuidString })
                            }
                            .buttonStyle(LightroomSecondaryButtonStyle())
                            
                            Button("Keine") {
                                store.jobUploadTargetIDs = []
                            }
                            .buttonStyle(LightroomSecondaryButtonStyle())
                        }
                        
                        Spacer()
                    }
                    
                    VStack(alignment: .leading, spacing: isCompact ? 4 : 6) {
                        ForEach(store.uploadTargets) { target in
                            Toggle(isOn: Binding(
                                get: { store.jobUploadTargetIDs.contains(target.id.uuidString) },
                                set: { on in
                                    if on {
                                        store.jobUploadTargetIDs.insert(target.id.uuidString)
                                    } else {
                                        store.jobUploadTargetIDs.remove(target.id.uuidString)
                                    }
                                }
                            )) {
                                HStack(spacing: 8) {
                                    Text(target.name)
                                        .font(DesignSystem.Fonts.regular(size: isCompact ? 11 : 12))
                                        .foregroundColor(DesignSystem.Colors.text2)
                                        .lineLimit(1)
                                    Spacer(minLength: 8)
                                    Text(target.type.rawValue)
                                        .font(DesignSystem.Fonts.regular(size: 10))
                                        .foregroundColor(DesignSystem.Colors.text4)
                                        .lineLimit(1)
                                }
                            }
                            .toggleStyle(.switch)
                        }
                    }
                }
            } else {
                Text("Speichere Quick‑Export, Stil‑Profil und Upload‑Ziele pro Ordner – beim nächsten Öffnen ist alles sofort bereit.")
                    .font(DesignSystem.Fonts.regular(size: isCompact ? 10 : 11))
                    .foregroundColor(DesignSystem.Colors.text4)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
        .padding(10)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
    }
    
    private var header: some View {
        let isCompact = settings.adjustmentsSidebarCompactMode
        
        return HStack(alignment: .firstTextBaseline) {
            VStack(alignment: .leading, spacing: isCompact ? 1 : 2) {
                Text("Aktivität")
                    .font(DesignSystem.Fonts.semibold(size: isCompact ? 13 : 14))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Text("Status für Export → Ordner/Cloud")
                    .font(DesignSystem.Fonts.regular(size: isCompact ? 10 : 11))
                    .foregroundColor(DesignSystem.Colors.text3)
            }
            
            Spacer()
            
            Button {
                dismiss()
            } label: {
                Image(systemName: "xmark")
                    .font(.system(size: isCompact ? 11 : 12, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text2)
                    .frame(width: isCompact ? 22 : 24, height: isCompact ? 22 : 24)
                    .background(DesignSystem.Colors.background4)
                    .cornerRadius(DesignSystem.CornerRadius.small)
                    .overlay(
                        RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                            .stroke(DesignSystem.Colors.border, lineWidth: 1)
                    )
            }
            .buttonStyle(.plain)
            .help("Schließen")
        }
    }
    
    private var footer: some View {
        let isCompact = settings.adjustmentsSidebarCompactMode
        
        return HStack(spacing: 10) {
            VStack(alignment: .leading, spacing: 2) {
                Text("Upload‑Ziele")
                    .font(DesignSystem.Fonts.semibold(size: isCompact ? 10 : 11))
                    .foregroundColor(DesignSystem.Colors.text2)
                Text("\(enabledUploadTargetsCount) aktiv")
                    .font(DesignSystem.Fonts.regular(size: isCompact ? 10 : 11))
                    .foregroundColor(DesignSystem.Colors.text3)
            }
            
            Spacer(minLength: 8)
            
            if isCompact {
                Button("Upload…") {
                    dismiss()
                    uiState.activeSheet = .uploadSettings
                }
                .buttonStyle(LightroomSmallButtonStyle())
                
                Button("Queue…") {
                    dismiss()
                    uiState.activeSheet = .exportQueueSettings
                }
                .buttonStyle(LightroomSmallButtonStyle())
                
                Button("Ingest…") {
                    dismiss()
                    uiState.activeSheet = .ingestImport
                }
                .buttonStyle(LightroomSmallButtonStyle())
            } else {
                Button("Upload…") {
                    dismiss()
                    uiState.activeSheet = .uploadSettings
                }
                .buttonStyle(LightroomSecondaryButtonStyle())
                
                Button("Queue…") {
                    dismiss()
                    uiState.activeSheet = .exportQueueSettings
                }
                .buttonStyle(LightroomSecondaryButtonStyle())
                
                Button("Ingest…") {
                    dismiss()
                    uiState.activeSheet = .ingestImport
                }
                .buttonStyle(LightroomSecondaryButtonStyle())
            }
        }
    }
    
    private var emptyState: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text("Keine aktiven Tasks")
                .font(DesignSystem.Fonts.semibold(size: 12))
                .foregroundColor(DesignSystem.Colors.text2)
            Text("Export/Upload‑Jobs, AI‑Indexing und Best‑of erscheinen hier, sobald sie laufen.")
                .font(DesignSystem.Fonts.regular(size: 11))
                .foregroundColor(DesignSystem.Colors.text4)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(10)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
    }
    
    private func failureCard() -> some View {
        let isCompact = settings.adjustmentsSidebarCompactMode
        let failures = store.exportQueueFailures
        let preview = failures.prefix(3)
        return VStack(alignment: .leading, spacing: 6) {
            HStack {
                Label("Fehler (Export‑Queue)", systemImage: "exclamationmark.triangle.fill")
                    .font(DesignSystem.Fonts.semibold(size: 12))
                    .foregroundColor(Color.orange.opacity(0.95))
                Spacer()
                Text("\(failures.count)")
                    .font(DesignSystem.Fonts.semibold(size: 11))
                    .foregroundColor(DesignSystem.Colors.text2)
                    .monospacedDigit()
            }
            
            ForEach(preview) { f in
                Text("• \(f.fileName): \(f.message)")
                    .font(DesignSystem.Fonts.regular(size: isCompact ? 10 : 11))
                    .foregroundColor(DesignSystem.Colors.text3)
                    .lineLimit(1)
                    .truncationMode(.middle)
            }
            
            if failures.count > 3 {
                Text("… und \(failures.count - 3) weitere")
                    .font(DesignSystem.Fonts.regular(size: 10))
                    .foregroundColor(DesignSystem.Colors.text4)
            }
        }
        .padding(10)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
    }
    
    private func taskCard(
        icon: String,
        title: String,
        detail: String,
        progress: Double,
        progressText: String,
        cancelTitle: String,
        cancelAction: @escaping () -> Void
    ) -> some View {
        let isCompact = settings.adjustmentsSidebarCompactMode
        
        return VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 10) {
                Image(systemName: icon)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text2)
                    .frame(width: 16)
                
                Text(title)
                    .font(DesignSystem.Fonts.semibold(size: 12))
                    .foregroundColor(DesignSystem.Colors.text)
                    .lineLimit(1)
                
                Spacer(minLength: 8)
                
                Text(detail)
                    .font(DesignSystem.Fonts.medium(size: 11))
                    .foregroundColor(DesignSystem.Colors.text3)
                    .monospacedDigit()
                    .lineLimit(1)
                
                Button {
                    cancelAction()
                } label: {
                    Image(systemName: "xmark.circle")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(DesignSystem.Colors.text3)
                }
                .buttonStyle(.plain)
                .help(cancelTitle)
            }
            
            ProgressView(value: max(0.0, min(1.0, progress)))
                .tint(DesignSystem.Colors.accent)
            
            Text(progressText)
                .font(DesignSystem.Fonts.regular(size: isCompact ? 10 : 11))
                .foregroundColor(DesignSystem.Colors.text4)
                .lineLimit(1)
                .truncationMode(.middle)
        }
        .padding(10)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
    }
}


