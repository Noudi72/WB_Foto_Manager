//
//  UploadSettingsView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit

struct UploadSettingsView: View {
    @ObservedObject var store: PhotoStore
    @State private var showTargetEditor = false
    @State private var editingTarget: UploadTarget?
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Text("Upload-Ziele verwalten")
                    .font(.headline)
                
                Spacer()
                
                Button(action: {
                    editingTarget = nil
                    showTargetEditor = true
                }) {
                    Image(systemName: "plus")
                    Text("Neu")
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
            
            Divider()
            
            // Target List
            if store.uploadTargets.isEmpty {
                VStack(spacing: 16) {
                    Image(systemName: "arrow.up.circle")
                        .font(.system(size: 48))
                        .foregroundColor(.secondary)
                    
                    Text("Keine Upload-Ziele konfiguriert")
                        .foregroundColor(.secondary)
                    
                    Text("Erstellen Sie ein Upload-Ziel, um exportierte Fotos automatisch hochzuladen")
                        .font(.caption)
                        .foregroundColor(.secondary)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal)
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                List {
                    ForEach(store.uploadTargets) { target in
                        UploadTargetRowView(
                            target: target,
                            onToggle: {
                                var updated = target
                                updated.isEnabled.toggle()
                                store.updateUploadTarget(updated)
                            },
                            onEdit: {
                                editingTarget = target
                                showTargetEditor = true
                            },
                            onDelete: {
                                store.deleteUploadTarget(target)
                            }
                        )
                    }
                }
                .listStyle(.inset)
            }
        }
        .frame(width: 700, height: 500)
        .sheet(isPresented: $showTargetEditor) {
            UploadTargetEditorView(
                target: editingTarget,
                store: store,
                onSave: { target in
                    if editingTarget != nil {
                        store.updateUploadTarget(target)
                    } else {
                        store.addUploadTarget(target)
                    }
                    showTargetEditor = false
                },
                onCancel: {
                    showTargetEditor = false
                }
            )
        }
    }
}

struct UploadTargetRowView: View {
    let target: UploadTarget
    let onToggle: () -> Void
    let onEdit: () -> Void
    let onDelete: () -> Void
    
    var body: some View {
        HStack {
            Toggle("", isOn: Binding(
                get: { target.isEnabled },
                set: { _ in onToggle() }
            ))
            .toggleStyle(.switch)
            .frame(width: 50)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(target.name)
                    .font(.headline)
                
                HStack(spacing: 16) {
                    Label(target.type.rawValue, systemImage: iconForType(target.type))
                    if let host = target.ftpHost {
                        Label(host, systemImage: "server.rack")
                    }
                    if let url = target.httpURL {
                        Label(url, systemImage: "link")
                    }
                }
                .font(.caption)
                .foregroundColor(.secondary)
            }
            
            Spacer()
            
            HStack {
                Button(action: onEdit) {
                    Image(systemName: "pencil")
                }
                .buttonStyle(.plain)
                
                Button(action: onDelete) {
                    Image(systemName: "trash")
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.vertical, 4)
        .opacity(target.isEnabled ? 1.0 : 0.6)
    }
    
    private func iconForType(_ type: UploadType) -> String {
        switch type {
        case .ftp: return "network"
        case .sftp: return "network"
        case .s3: return "cloud"
        case .http: return "globe"
        case .pictrs: return "photo"
        case .local: return "folder"
        }
    }
}

struct UploadTargetEditorView: View {
    let target: UploadTarget?
    @ObservedObject var store: PhotoStore
    @State private var name: String
    @State private var type: UploadType
    @State private var isEnabled: Bool
    
    // FTP/SFTP
    @State private var ftpHost: String
    @State private var ftpPort: String
    @State private var ftpUsername: String
    @State private var ftpPassword: String
    @State private var ftpPath: String
    @State private var ftpUseSSL: Bool
    @State private var ftpPrivateKey: String
    
    // S3
    @State private var s3Bucket: String
    @State private var s3Region: String
    @State private var s3AccessKey: String
    @State private var s3SecretKey: String
    @State private var s3Path: String
    
    // HTTP
    @State private var httpURL: String
    @State private var httpMethod: String
    @State private var httpAuthToken: String
    
    // Pictrs
    @State private var pictrsURL: String
    @State private var pictrsAuthToken: String
    @State private var pictrsDeleteToken: String
    
    let onSave: (UploadTarget) -> Void
    let onCancel: () -> Void
    
    init(target: UploadTarget?, store: PhotoStore, onSave: @escaping (UploadTarget) -> Void, onCancel: @escaping () -> Void) {
        self.target = target
        self.store = store
        self.onSave = onSave
        self.onCancel = onCancel
        
        if let existing = target {
            _name = State(initialValue: existing.name)
            _type = State(initialValue: existing.type)
            _isEnabled = State(initialValue: existing.isEnabled)
            _ftpHost = State(initialValue: existing.ftpHost ?? "")
            _ftpPort = State(initialValue: existing.ftpPort.map { String($0) } ?? "21")
            _ftpUsername = State(initialValue: existing.ftpUsername ?? "")
            _ftpPassword = State(initialValue: existing.ftpPassword ?? "")
            _ftpPath = State(initialValue: existing.ftpPath ?? "")
            _ftpUseSSL = State(initialValue: existing.ftpUseSSL)
            _s3Bucket = State(initialValue: existing.s3Bucket ?? "")
            _s3Region = State(initialValue: existing.s3Region ?? "")
            _s3AccessKey = State(initialValue: existing.s3AccessKey ?? "")
            _s3SecretKey = State(initialValue: existing.s3SecretKey ?? "")
            _s3Path = State(initialValue: existing.s3Path ?? "")
            _httpURL = State(initialValue: existing.httpURL ?? "")
            _httpMethod = State(initialValue: existing.httpMethod ?? "POST")
            _httpAuthToken = State(initialValue: existing.httpAuthToken ?? "")
            _ftpPrivateKey = State(initialValue: existing.ftpPrivateKey ?? "")
            _pictrsURL = State(initialValue: existing.pictrsURL ?? "")
            _pictrsAuthToken = State(initialValue: existing.pictrsAuthToken ?? "")
            _pictrsDeleteToken = State(initialValue: existing.pictrsDeleteToken ?? "")
        } else {
            _name = State(initialValue: "")
            _type = State(initialValue: .ftp)
            _isEnabled = State(initialValue: true)
            _ftpHost = State(initialValue: "")
            _ftpPort = State(initialValue: "21")
            _ftpUsername = State(initialValue: "")
            _ftpPassword = State(initialValue: "")
            _ftpPath = State(initialValue: "/")
            _ftpUseSSL = State(initialValue: false)
            _ftpPrivateKey = State(initialValue: "")
            _s3Bucket = State(initialValue: "")
            _s3Region = State(initialValue: "us-east-1")
            _s3AccessKey = State(initialValue: "")
            _s3SecretKey = State(initialValue: "")
            _s3Path = State(initialValue: "")
            _httpURL = State(initialValue: "")
            _httpMethod = State(initialValue: "POST")
            _httpAuthToken = State(initialValue: "")
            _pictrsURL = State(initialValue: "")
            _pictrsAuthToken = State(initialValue: "")
            _pictrsDeleteToken = State(initialValue: "")
        }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(target == nil ? "Neues Upload-Ziel" : "Upload-Ziel bearbeiten")
                .font(.headline)
            
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    // Basic Settings
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Grundlagen")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Name")
                                .font(.caption)
                            TextField("Ziel Name", text: $name)
                        }
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text("Typ")
                                .font(.caption)
                            Picker("Typ", selection: $type) {
                                Text("FTP").tag(UploadType.ftp)
                                Text("SFTP").tag(UploadType.sftp)
                                Text("S3").tag(UploadType.s3)
                                Text("HTTP/API").tag(UploadType.http)
                                Text("Pictrs").tag(UploadType.pictrs)
                                Text("Lokal").tag(UploadType.local)
                            }
                            .pickerStyle(.menu)
                        }
                        
                        Toggle("Aktiviert", isOn: $isEnabled)
                    }
                    .onChange(of: type) { _, newType in
                        // UX: SFTP läuft praktisch immer auf Port 22.
                        if newType == .sftp {
                            let p = ftpPort.trimmingCharacters(in: .whitespacesAndNewlines)
                            if p.isEmpty || p == "21" {
                                ftpPort = "22"
                            }
                            ftpUseSSL = true
                        }
                    }
                    
                    Divider()
                    
                    // Type-specific Settings
                    switch type {
                    case .ftp:
                        FTPSettingsView(
                            host: $ftpHost,
                            port: $ftpPort,
                            username: $ftpUsername,
                            password: $ftpPassword,
                            path: $ftpPath,
                            useSSL: $ftpUseSSL,
                            showPrivateKey: false
                        )
                    case .sftp:
                        FTPSettingsView(
                            host: $ftpHost,
                            port: $ftpPort,
                            username: $ftpUsername,
                            password: $ftpPassword,
                            path: $ftpPath,
                            useSSL: $ftpUseSSL,
                            showPrivateKey: true,
                            privateKey: $ftpPrivateKey
                        )
                    case .s3:
                        S3SettingsView(
                            bucket: $s3Bucket,
                            region: $s3Region,
                            accessKey: $s3AccessKey,
                            secretKey: $s3SecretKey,
                            path: $s3Path
                        )
                    case .http:
                        HTTPSettingsView(
                            url: $httpURL,
                            method: $httpMethod,
                            authToken: $httpAuthToken
                        )
                    case .pictrs:
                        PictrsSettingsView(
                            url: $pictrsURL,
                            authToken: $pictrsAuthToken,
                            deleteToken: $pictrsDeleteToken
                        )
                    case .local:
                        LocalSettingsView(path: $ftpPath)
                    }
                }
            }
            
            // Buttons
            HStack {
                Button("Abbrechen", action: onCancel)
                
                Spacer()
                
                Button("Speichern") {
                    var newTarget = UploadTarget(
                        id: target?.id ?? UUID(),
                        name: name,
                        type: type,
                        isEnabled: isEnabled
                    )
                    
                    // Set type-specific fields
                    switch type {
                    case .ftp:
                        newTarget.ftpHost = ftpHost.isEmpty ? nil : ftpHost
                        newTarget.ftpPort = Int(ftpPort)
                        newTarget.ftpUsername = ftpUsername.isEmpty ? nil : ftpUsername
                        newTarget.ftpPassword = ftpPassword.isEmpty ? nil : ftpPassword
                        newTarget.ftpPath = ftpPath.isEmpty ? nil : ftpPath
                        newTarget.ftpUseSSL = ftpUseSSL
                    case .sftp:
                        newTarget.ftpHost = ftpHost.isEmpty ? nil : ftpHost
                        newTarget.ftpPort = Int(ftpPort)
                        newTarget.ftpUsername = ftpUsername.isEmpty ? nil : ftpUsername
                        newTarget.ftpPassword = ftpPassword.isEmpty ? nil : ftpPassword
                        newTarget.ftpPath = ftpPath.isEmpty ? nil : ftpPath
                        newTarget.ftpUseSSL = true // SFTP verwendet immer verschlüsselte Verbindung
                        newTarget.ftpPrivateKey = ftpPrivateKey.isEmpty ? nil : ftpPrivateKey
                    case .s3:
                        newTarget.s3Bucket = s3Bucket.isEmpty ? nil : s3Bucket
                        newTarget.s3Region = s3Region.isEmpty ? nil : s3Region
                        newTarget.s3AccessKey = s3AccessKey.isEmpty ? nil : s3AccessKey
                        newTarget.s3SecretKey = s3SecretKey.isEmpty ? nil : s3SecretKey
                        newTarget.s3Path = s3Path.isEmpty ? nil : s3Path
                    case .http:
                        newTarget.httpURL = httpURL.isEmpty ? nil : httpURL
                        newTarget.httpMethod = httpMethod.isEmpty ? nil : httpMethod
                        newTarget.httpAuthToken = httpAuthToken.isEmpty ? nil : httpAuthToken
                    case .pictrs:
                        newTarget.pictrsURL = pictrsURL.isEmpty ? nil : pictrsURL
                        newTarget.pictrsAuthToken = pictrsAuthToken.isEmpty ? nil : pictrsAuthToken
                        newTarget.pictrsDeleteToken = pictrsDeleteToken.isEmpty ? nil : pictrsDeleteToken
                    case .local:
                        newTarget.ftpPath = ftpPath.isEmpty ? nil : ftpPath
                    }
                    
                    onSave(newTarget)
                }
                .buttonStyle(.borderedProminent)
                .disabled(name.isEmpty)
            }
        }
        .padding()
        .frame(width: 600, height: 600)
    }
}

struct FTPSettingsView: View {
    @Binding var host: String
    @Binding var port: String
    @Binding var username: String
    @Binding var password: String
    @Binding var path: String
    @Binding var useSSL: Bool
    var showPrivateKey: Bool = false
    @Binding var privateKey: String
    
    init(host: Binding<String>, port: Binding<String>, username: Binding<String>, password: Binding<String>, path: Binding<String>, useSSL: Binding<Bool>, showPrivateKey: Bool = false, privateKey: Binding<String> = .constant("")) {
        self._host = host
        self._port = port
        self._username = username
        self._password = password
        self._path = path
        self._useSSL = useSSL
        self.showPrivateKey = showPrivateKey
        self._privateKey = privateKey
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text(showPrivateKey ? "SFTP Einstellungen" : "FTP Einstellungen")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            if showPrivateKey {
                Text("Tipp: Port ist normalerweise 22. Pfad ist ein Remote-Ordner (z.B. \"uploads/spieltag\").\nWenn dein Key eine Passphrase hat: Passphrase ins Passwort-Feld.")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Host")
                    .font(.caption)
                TextField("ftp.example.com", text: $host)
            }
            
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Port")
                        .font(.caption)
                    TextField(showPrivateKey ? "22" : "21", text: $port)
                }
                
                if !showPrivateKey {
                    Toggle("SSL/TLS", isOn: $useSSL)
                }
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Benutzername")
                    .font(.caption)
                TextField("Benutzername", text: $username)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Passwort (optional bei Key-Auth)")
                    .font(.caption)
                SecureField("Passwort", text: $password)
            }
            
            if showPrivateKey {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Private Key (optional, für Key-Auth)")
                        .font(.caption)
                    TextEditor(text: $privateKey)
                        .frame(height: 100)
                        .font(.system(.caption, design: .monospaced))
                }
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Pfad")
                    .font(.caption)
                TextField("/uploads", text: $path)
            }
        }
    }
}

struct PictrsSettingsView: View {
    @Binding var url: String
    @Binding var authToken: String
    @Binding var deleteToken: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Pictrs Einstellungen")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Pictrs URL")
                    .font(.caption)
                TextField("https://pictrs.example.com", text: $url)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Auth Token (optional)")
                    .font(.caption)
                SecureField("Bearer Token", text: $authToken)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Delete Token (optional)")
                    .font(.caption)
                SecureField("Delete Token", text: $deleteToken)
            }
            
            Text("Pictrs ist ein Bild-Upload-Service. Die URL sollte auf die Pictrs-Instanz zeigen (z.B. https://pictrs.example.com)")
                .font(.caption)
                .foregroundColor(.secondary)
        }
    }
}

struct S3SettingsView: View {
    @Binding var bucket: String
    @Binding var region: String
    @Binding var accessKey: String
    @Binding var secretKey: String
    @Binding var path: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("S3 Einstellungen")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Bucket")
                    .font(.caption)
                TextField("my-bucket", text: $bucket)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Region")
                    .font(.caption)
                TextField("us-east-1", text: $region)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Access Key")
                    .font(.caption)
                TextField("Access Key", text: $accessKey)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Secret Key")
                    .font(.caption)
                SecureField("Secret Key", text: $secretKey)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Pfad (optional)")
                    .font(.caption)
                TextField("uploads/", text: $path)
            }
        }
    }
}

struct HTTPSettingsView: View {
    @Binding var url: String
    @Binding var method: String
    @Binding var authToken: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("HTTP/API Einstellungen")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            VStack(alignment: .leading, spacing: 4) {
                Text("URL")
                    .font(.caption)
                TextField("https://api.example.com/upload", text: $url)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Methode")
                    .font(.caption)
                Picker("Methode", selection: $method) {
                    Text("POST").tag("POST")
                    Text("PUT").tag("PUT")
                }
                .pickerStyle(.segmented)
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text("Auth Token (optional)")
                    .font(.caption)
                SecureField("Bearer Token", text: $authToken)
            }
        }
    }
}

struct LocalSettingsView: View {
    @Binding var path: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Lokale Einstellungen")
                .font(.subheadline)
                .foregroundColor(.secondary)
            
            HStack {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Zielordner")
                        .font(.caption)
                    TextField("/Users/name/Desktop", text: $path)
                }
                
                Button("Auswählen...") {
                    let panel = NSOpenPanel()
                    panel.canChooseFiles = false
                    panel.canChooseDirectories = true
                    panel.allowsMultipleSelection = false
                    
                    if panel.runModal() == .OK, let url = panel.url {
                        path = url.path
                    }
                }
            }
        }
    }
}

