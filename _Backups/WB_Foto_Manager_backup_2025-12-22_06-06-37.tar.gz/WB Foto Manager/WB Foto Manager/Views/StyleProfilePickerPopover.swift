//
//  StyleProfilePickerPopover.swift
//  WB Foto Manager
//
//  Quick Style Profile picker for the right sidebar (brush icon).
//  Supports hover preview (delta like Auto+Style) without leaving the main workflow.
//

import SwiftUI
import Combine

struct StyleProfilePickerPopover: View {
    @ObservedObject var store: PhotoStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var settings = AppSettings.shared
    
    @State private var search: String = ""
    @State private var showSearch: Bool = false
    @FocusState private var isSearchFocused: Bool
    
    // Hover Preview (temporär, wird NICHT persistiert)
    @State private var hoveredPresetID: UUID?
    @State private var temporaryAdjustments: PhotoAdjustments?
    @State private var temporaryPhotoID: UUID?
    @State private var hoverRestoreTask: Task<Void, Never>?
    
    private var presets: [AdjustmentPreset] {
        let all = store.adjustmentPresets
            .sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        
        let q = search.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !q.isEmpty else { return all }
        return all.filter { preset in
            preset.name.lowercased().contains(q) || (preset.group?.lowercased().contains(q) ?? false)
        }
    }
    
    private var isSearching: Bool {
        !search.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
    
    private var pinnedHallPreset: AdjustmentPreset? {
        store.adjustmentPresets.first(where: { $0.name == "Halle – stark beleuchtet" })
    }
    
    private var recentStylePresets: [AdjustmentPreset] {
        guard !isSearching else { return [] }
        let hallID = pinnedHallPreset?.id
        let ids = settings.recentStylePresetIDs.compactMap { UUID(uuidString: $0) }
        var result: [AdjustmentPreset] = []
        result.reserveCapacity(8)
        for id in ids {
            if let p = store.adjustmentPresets.first(where: { $0.id == id }) {
                if p.id == hallID { continue }
                result.append(p)
            }
            if result.count >= 8 { break }
        }
        return result
    }
    
    var body: some View {
        let isCompact = settings.adjustmentsSidebarCompactMode
        
        VStack(alignment: .leading, spacing: isCompact ? 6 : 12) {
            header
            
            Toggle("Auto nutzt Stil‑Profil", isOn: $settings.autoUsesStyleProfile)
                .tint(DesignSystem.Colors.accent)
                .font(DesignSystem.Fonts.regular(size: isCompact ? 11 : 12))
            
            if showSearch {
                TextField("Suchen (Name / Kategorie)…", text: $search)
                    .textFieldStyle(.roundedBorder)
                    .font(DesignSystem.Fonts.regular(size: isCompact ? 11 : 12))
                    .focused($isSearchFocused)
            }
            
            Divider().opacity(0.7)
            
            ScrollView {
                LazyVStack(alignment: .leading, spacing: isCompact ? 2 : 8) {
                    StyleProfilePickerRow(
                        title: "Keines",
                        subtitle: "Kein Stil‑Preset",
                        isSelected: settings.autoStylePresetID.isEmpty,
                        isHighlighted: false,
                        onHoverChanged: { hovering in
                            if !hovering { hoveredPresetID = nil }
                        },
                        action: {
                            restorePreviewIfNeeded()
                            settings.autoStylePresetID = ""
                            dismiss()
                        }
                    )
                    
                    if !isSearching {
                        // Zuletzt verwendet (Speed)
                        if !recentStylePresets.isEmpty {
                            Text("Zuletzt")
                                .font(DesignSystem.Fonts.semibold(size: isCompact ? 10 : 11))
                                .foregroundColor(DesignSystem.Colors.text3)
                                .padding(.horizontal, 2)
                                .padding(.top, 4)
                            
                            ForEach(recentStylePresets) { preset in
                                StyleProfilePickerRow(
                                    title: preset.name,
                                    subtitle: preset.group,
                                    isSelected: settings.autoStylePresetID == preset.id.uuidString,
                                    isHighlighted: false,
                                    onHoverChanged: { hovering in
                                        hoveredPresetID = hovering ? preset.id : nil
                                    },
                                    action: {
                                        selectPreset(preset)
                                    }
                                )
                            }
                            
                            Divider().opacity(0.7)
                                .padding(.vertical, 2)
                        }
                        
                        // Pin: Halle – stark beleuchtet (Default Sport)
                        if let hall = pinnedHallPreset {
                            StyleProfilePickerRow(
                                title: hall.name,
                                subtitle: hall.group,
                                isSelected: settings.autoStylePresetID == hall.id.uuidString,
                                isHighlighted: true,
                                onHoverChanged: { hovering in
                                    hoveredPresetID = hovering ? hall.id : nil
                                },
                                action: {
                                    selectPreset(hall)
                                }
                            )
                        }
                    }
                    
                    ForEach(presets) { preset in
                        if !isSearching {
                            // Dedupe: was oben gepinnt/zuletzt war, nicht nochmal zeigen
                            if preset.name == "Halle – stark beleuchtet" { EmptyView() }
                            else if recentStylePresets.contains(where: { $0.id == preset.id }) { EmptyView() }
                            else {
                                StyleProfilePickerRow(
                                    title: preset.name,
                                    subtitle: preset.group,
                                    isSelected: settings.autoStylePresetID == preset.id.uuidString,
                                    isHighlighted: false,
                                    onHoverChanged: { hovering in
                                        hoveredPresetID = hovering ? preset.id : nil
                                    },
                                    action: {
                                        selectPreset(preset)
                                    }
                                )
                            }
                        } else {
                            StyleProfilePickerRow(
                                title: preset.name,
                                subtitle: preset.group,
                                isSelected: settings.autoStylePresetID == preset.id.uuidString,
                                isHighlighted: false,
                                onHoverChanged: { hovering in
                                    hoveredPresetID = hovering ? preset.id : nil
                                },
                                action: {
                                    selectPreset(preset)
                                }
                            )
                        }
                    }
                }
                .padding(.vertical, isCompact ? 0 : 4)
            }
            
            Divider().opacity(0.7)
            
            HStack(spacing: isCompact ? 8 : 10) {
                Text("Hover = Vorschau • Klick = auswählen")
                    .font(DesignSystem.Fonts.regular(size: isCompact ? 9 : 10))
                    .foregroundColor(DesignSystem.Colors.text3)
                
                Spacer(minLength: 8)
                
                if isCompact {
                    Button("Einstellungen…") {
                        restorePreviewIfNeeded()
                        dismiss()
                        store.uiState?.activeSheet = .settings
                    }
                    .buttonStyle(LightroomSmallButtonStyle())
                } else {
                    Button("Einstellungen…") {
                        restorePreviewIfNeeded()
                        dismiss()
                        store.uiState?.activeSheet = .settings
                    }
                    .buttonStyle(LightroomSecondaryButtonStyle())
                }
            }
        }
        .padding(isCompact ? 10 : 14)
        .frame(width: isCompact ? 360 : 380, height: isCompact ? 640 : 700)
        .background(DesignSystem.Colors.background2)
        .lightroomSidebarTheme()
        .controlSize(isCompact ? .mini : .small)
        .onChange(of: hoveredPresetID) { _, newID in
            handleHoverPreviewChange(newID)
        }
        .onChange(of: store.currentPhotoID) { _, _ in
            // Fotowechsel während Popover offen ist: Preview-States zurücksetzen
            hoverRestoreTask?.cancel()
            temporaryAdjustments = nil
            temporaryPhotoID = nil
            hoveredPresetID = nil
        }
        .onDisappear {
            restorePreviewIfNeeded()
        }
    }
    
    private var header: some View {
        let isCompact = settings.adjustmentsSidebarCompactMode
        let titleSize: CGFloat = isCompact ? 13 : 14
        let subSize: CGFloat = isCompact ? 10 : 11
        let closeSize: CGFloat = isCompact ? 22 : 24
        let closeIconSize: CGFloat = isCompact ? 11 : 12
        
        return HStack(alignment: .firstTextBaseline) {
            VStack(alignment: .leading, spacing: isCompact ? 1 : 2) {
                Text("Stil‑Profil")
                    .font(DesignSystem.Fonts.semibold(size: titleSize))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Text(currentSelectionSubtitle)
                    .font(DesignSystem.Fonts.regular(size: subSize))
                    .foregroundColor(DesignSystem.Colors.text3)
                    .lineLimit(1)
            }
            
            Spacer()
            
            Button {
                showSearch.toggle()
                if !showSearch {
                    search = ""
                }
                DispatchQueue.main.async {
                    if showSearch {
                        isSearchFocused = true
                    }
                }
            } label: {
                Image(systemName: showSearch ? "xmark.circle" : "magnifyingglass")
                    .font(.system(size: closeIconSize, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text2)
                    .frame(width: closeSize, height: closeSize)
                    .background(DesignSystem.Colors.background4)
                    .cornerRadius(DesignSystem.CornerRadius.small)
                    .overlay(
                        RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                            .stroke(DesignSystem.Colors.border, lineWidth: 1)
                    )
            }
            .buttonStyle(.plain)
            .help(showSearch ? "Suche schließen" : "Suchen")
            
            Button {
                restorePreviewIfNeeded()
                dismiss()
            } label: {
                Image(systemName: "xmark")
                    .font(.system(size: closeIconSize, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text2)
                    .frame(width: closeSize, height: closeSize)
                    .background(DesignSystem.Colors.background4)
                    .cornerRadius(DesignSystem.CornerRadius.small)
                    .overlay(
                        RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                            .stroke(DesignSystem.Colors.border, lineWidth: 1)
                    )
            }
            .buttonStyle(.plain)
            .help("Schließen")
        }
    }
    
    private var currentSelectionSubtitle: String {
        guard settings.autoUsesStyleProfile else { return "Deaktiviert" }
        guard let id = UUID(uuidString: settings.autoStylePresetID),
              let preset = store.adjustmentPresets.first(where: { $0.id == id }) else {
            return settings.autoStylePresetID.isEmpty ? "Aktiv • Kein Preset" : "Aktiv • Unbekannt"
        }
        return "Aktiv • \(preset.name)"
    }
    
    private func selectPreset(_ preset: AdjustmentPreset) {
        restorePreviewIfNeeded()
        settings.autoUsesStyleProfile = true
        settings.autoStylePresetID = preset.id.uuidString
        dismiss()
    }
    
    private func handleHoverPreviewChange(_ newID: UUID?) {
        hoverRestoreTask?.cancel()
        guard let photo = store.currentPhoto else { return }
        
        // Hover beginnt / wechselt
        if let id = newID, let preset = store.adjustmentPresets.first(where: { $0.id == id }) {
            if temporaryAdjustments == nil {
                temporaryAdjustments = photo.adjustments
                temporaryPhotoID = photo.id
            }
            
            // Stil-Profil als Delta (wie Auto+Style)
            let base = temporaryAdjustments ?? photo.adjustments
            let delta = preset.adjustments.delta(from: PhotoAdjustments())
            let next = base.applying(delta)
            photo.adjustments = next
            triggerImageUpdate(for: photo, isPreview: true)
            return
        }
        
        // Hover endet: mit kleiner Verzögerung zurücksetzen
        let original = temporaryAdjustments
        let originalPhotoID = temporaryPhotoID
        hoverRestoreTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 60_000_000)
            guard hoveredPresetID == nil else { return }
            guard let original,
                  let photo = store.currentPhoto,
                  originalPhotoID == photo.id else {
                temporaryAdjustments = nil
                temporaryPhotoID = nil
                return
            }
            photo.adjustments = original
            temporaryAdjustments = nil
            temporaryPhotoID = nil
            triggerImageUpdate(for: photo, isPreview: true)
        }
    }
    
    private func restorePreviewIfNeeded() {
        hoverRestoreTask?.cancel()
        guard let original = temporaryAdjustments,
              let originalPhotoID = temporaryPhotoID,
              let photo = store.currentPhoto,
              originalPhotoID == photo.id else {
            temporaryAdjustments = nil
            temporaryPhotoID = nil
            hoveredPresetID = nil
            return
        }
        photo.adjustments = original
        temporaryAdjustments = nil
        temporaryPhotoID = nil
        hoveredPresetID = nil
        triggerImageUpdate(for: photo, isPreview: true)
    }
    
    private func triggerImageUpdate(for photo: PhotoItem, isPreview: Bool) {
        // Nur Rendering/Preview, nicht persistieren.
        store.objectWillChange.send()
        photo.objectWillChange.send()
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id, "isPreview": isPreview]
        )
    }
}

private struct StyleProfilePickerRow: View {
    let title: String
    let subtitle: String?
    let isSelected: Bool
    let isHighlighted: Bool
    let onHoverChanged: (Bool) -> Void
    let action: () -> Void
    
    @State private var isHovering = false
    @StateObject private var settings = AppSettings.shared
    
    var body: some View {
        let isCompact = settings.adjustmentsSidebarCompactMode
        let titleSize: CGFloat = isCompact ? 11 : 12
        let subSize: CGFloat = isCompact ? 9 : 10
        
        Button(action: action) {
            if isCompact {
                // Extra-compact: single-line row with trailing "Kategorie"-pill.
                HStack(spacing: 8) {
                    Text(title)
                        .font(DesignSystem.Fonts.medium(size: titleSize))
                        .foregroundColor(DesignSystem.Colors.text)
                        .lineLimit(1)
                        .truncationMode(.tail)
                    
                    Spacer(minLength: 8)
                    
                    if let subtitle, !subtitle.isEmpty {
                        Text(subtitle)
                            .font(DesignSystem.Fonts.regular(size: subSize))
                            .foregroundColor(DesignSystem.Colors.text4)
                            .lineLimit(1)
                            .truncationMode(.tail)
                            .padding(.horizontal, 6)
                            .padding(.vertical, 2)
                            .background(DesignSystem.Colors.background3.opacity(0.55))
                            .cornerRadius(6)
                            .frame(maxWidth: 140, alignment: .trailing)
                    }
                    
                    if isSelected {
                        Image(systemName: "checkmark")
                            .font(.system(size: 10, weight: .semibold))
                            .foregroundColor(DesignSystem.Colors.accent)
                    }
                }
                .padding(.horizontal, 10)
                .padding(.vertical, 4)
                .background(rowBackground)
                .overlay(
                    RoundedRectangle(cornerRadius: 6)
                        .stroke(isHighlighted ? DesignSystem.Colors.accent.opacity(0.55) : Color.clear, lineWidth: 1)
                )
                .cornerRadius(6)
            } else {
                // Regular: two-line card.
                HStack(spacing: 10) {
                    VStack(alignment: .leading, spacing: 1) {
                        Text(title)
                            .font(DesignSystem.Fonts.medium(size: titleSize))
                            .foregroundColor(DesignSystem.Colors.text)
                            .lineLimit(1)
                            .truncationMode(.tail)
                        
                        if let subtitle, !subtitle.isEmpty {
                            Text(subtitle)
                                .font(DesignSystem.Fonts.regular(size: subSize))
                                .foregroundColor(DesignSystem.Colors.text3)
                                .lineLimit(1)
                                .truncationMode(.tail)
                        }
                    }
                    
                    Spacer()
                    
                    if isSelected {
                        Image(systemName: "checkmark")
                            .font(.system(size: 11, weight: .semibold))
                            .foregroundColor(DesignSystem.Colors.accent)
                    }
                }
                .padding(.horizontal, 12)
                .padding(.vertical, 10)
                .background(rowBackground)
                .overlay(
                    RoundedRectangle(cornerRadius: 10)
                        .stroke(isHighlighted ? DesignSystem.Colors.accent.opacity(0.55) : DesignSystem.Colors.border, lineWidth: 1)
                )
                .cornerRadius(10)
            }
        }
        .buttonStyle(.plain)
        .onHover { hovering in
            isHovering = hovering
            onHoverChanged(hovering)
        }
    }
    
    private var rowBackground: Color {
        if isSelected {
            return DesignSystem.Colors.accent.opacity(0.18)
        }
        if isHovering {
            return DesignSystem.Colors.background3
        }
        return DesignSystem.Colors.background4
    }
}


