//
//  CropAspectRatio.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation

/// Seitenverhältnisse für Cropping
struct CropAspectRatio: Identifiable, Hashable {
    let name: String
    let ratio: Double? // width/height, nil = frei
    let socialHint: String?
    
    /// Stabiler Identifier für SwiftUI (Picker/ForEach), damit Auswahl nicht "springt".
    var id: String { "\(name)-\(ratio ?? -1)" }
    
    init(name: String, ratio: Double?, socialHint: String? = nil) {
        self.name = name
        self.ratio = ratio
        self.socialHint = socialHint
    }
    
    var displayLabel: String {
        guard let hint = socialHint, !hint.isEmpty else { return name }
        return "\(name) — \(hint)"
    }
    
    static var commonRatios: [CropAspectRatio] {
        [
            CropAspectRatio(name: "Frei", ratio: nil, socialHint: "Beliebig"),
            
            // Social / Feed
            CropAspectRatio(name: "1:1", ratio: 1.0, socialHint: "Instagram Post (Quadrat)"),
            CropAspectRatio(name: "4:5", ratio: 4.0/5.0, socialHint: "Instagram Feed (Portrait)"),
            CropAspectRatio(name: "9:16", ratio: 9.0/16.0, socialHint: "Stories/Reels/Shorts (IG, TikTok, YouTube)"),
            
            // Foto / Video Standard
            CropAspectRatio(name: "4:3", ratio: 4.0/3.0, socialHint: "Standard Foto (mFT/iPhone)"),
            CropAspectRatio(name: "3:2", ratio: 3.0/2.0, socialHint: "DSLR/Full‑Frame (klassisch)"),
            CropAspectRatio(name: "16:9", ratio: 16.0/9.0, socialHint: "YouTube/Video (Landscape)"),
            
            // Spezial / Print
            CropAspectRatio(name: "21:9", ratio: 21.0/9.0, socialHint: "Cinematic"),
            CropAspectRatio(name: "5:4", ratio: 5.0/4.0, socialHint: "Print (4×5)"),
            CropAspectRatio(name: "2:1", ratio: 2.0/1.0, socialHint: "Panorama/Banner")
        ]
    }
}

