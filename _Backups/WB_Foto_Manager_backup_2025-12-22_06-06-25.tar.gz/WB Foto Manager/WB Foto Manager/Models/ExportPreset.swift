//
//  ExportPreset.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation

/// Export-Preset für verschiedene Ausgabeformate
struct ExportPreset: Identifiable, Codable, Hashable {
    let id: UUID
    var name: String
    var maxDimension: Int // Längste Kante in Pixeln
    var quality: Double // JPEG Qualität 0.0-1.0
    var format: ExportFormat
    var watermarkSettings: WatermarkSettings?
    var uploadTargets: [String] // IDs der Upload-Targets
    var filenameTemplate: String? // Optional: Preset-spezifisches Template (überschreibt globales Template)
    
    init(id: UUID = UUID(), name: String, maxDimension: Int, quality: Double, format: ExportFormat = .jpeg, watermarkSettings: WatermarkSettings? = nil, uploadTargets: [String] = [], filenameTemplate: String? = nil) {
        self.id = id
        self.name = name
        self.maxDimension = maxDimension
        self.quality = quality
        self.format = format
        self.watermarkSettings = watermarkSettings
        self.uploadTargets = uploadTargets
        self.filenameTemplate = filenameTemplate
    }
    
    static var defaultPresets: [ExportPreset] {
        [
            ExportPreset(
                name: "Agentur",
                maxDimension: 3500,
                quality: 0.9,
                format: .jpeg,
                watermarkSettings: nil
            ),
            ExportPreset(
                name: "Social",
                maxDimension: 2048,
                quality: 0.85,
                format: .jpeg,
                watermarkSettings: WatermarkSettings.default
            ),
            ExportPreset(
                name: "Webshop Pictrs",
                maxDimension: 1920,
                quality: 0.8,
                format: .jpeg,
                watermarkSettings: nil
            )
        ]
    }
}

enum ExportFormat: String, Codable, Hashable {
    case jpeg = "JPEG"
    case png = "PNG"
    
    var fileExtension: String {
        switch self {
        case .jpeg: return "jpg"
        case .png: return "png"
        }
    }
}

