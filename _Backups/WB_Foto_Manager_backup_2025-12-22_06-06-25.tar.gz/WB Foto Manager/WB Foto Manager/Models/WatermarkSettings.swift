//
//  WatermarkSettings.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation

/// Wasserzeichen-Konfiguration
struct WatermarkSettings: Codable, Equatable, Hashable {
    var type: WatermarkType
    var position: WatermarkPosition
    var size: Double // Relativ zur Bildgröße (0.05-0.5 = 5%-50%)
    var text: String?
    var textSize: Double? // Relativ zur Bildgröße
    var logoURL: URL?
    /// Security-scoped Bookmark, damit ein Logo auch nach App-Neustart in der Sandbox geladen werden kann.
    var logoBookmarkData: Data? = nil
    var opacity: Double // 0.0-1.0
    
    static var `default`: WatermarkSettings {
        WatermarkSettings(
            type: .text,
            position: .bottomRight,
            size: 0.06,
            text: "© Blaurock Sportpix",
            textSize: 0.03,
            opacity: 0.8
        )
    }
}

enum WatermarkType: String, Codable, Hashable {
    case text = "text"
    case logo = "logo"
    case both = "both"
}

enum WatermarkPosition: String, Codable, Hashable {
    case topLeft = "topLeft"
    case topCenter = "topCenter"
    case topRight = "topRight"
    case centerLeft = "centerLeft"
    case center = "center"
    case centerRight = "centerRight"
    case bottomLeft = "bottomLeft"
    case bottomCenter = "bottomCenter"
    case bottomRight = "bottomRight"
}

