//
//  EditSnapshot.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 15.12.2025.
//

import Foundation
import CoreGraphics

struct CodableRect: Codable, Hashable, Sendable {
    var x: Double
    var y: Double
    var width: Double
    var height: Double
    
    init(_ rect: CGRect) {
        self.x = rect.origin.x
        self.y = rect.origin.y
        self.width = rect.size.width
        self.height = rect.size.height
    }
    
    var cgRect: CGRect {
        CGRect(x: x, y: y, width: width, height: height)
    }
}

/// Ein benannter Snapshot eines Bearbeitungszustands (Lightroom-Style)
struct EditSnapshot: Identifiable, Codable, Hashable, Sendable {
    let id: UUID
    var name: String
    var createdAt: Date
    
    var adjustments: PhotoAdjustments
    /// Lokale Masken (optional für Rückwärtskompatibilität alter Snapshots)
    var localMasks: [LocalAdjustmentMask]? = nil
    /// Lens-Profile Settings (optional für Rückwärtskompatibilität)
    var lensProfileSettings: LensProfileSettings? = nil
    var cropRect: CodableRect?
    var rotation: Double
    
    init(
        id: UUID = UUID(),
        name: String,
        createdAt: Date = Date(),
        adjustments: PhotoAdjustments,
        localMasks: [LocalAdjustmentMask]? = nil,
        lensProfileSettings: LensProfileSettings? = nil,
        cropRect: CGRect?,
        rotation: Double
    ) {
        self.id = id
        self.name = name
        self.createdAt = createdAt
        self.adjustments = adjustments
        self.localMasks = localMasks
        self.lensProfileSettings = lensProfileSettings
        self.cropRect = cropRect.map { CodableRect($0) }
        self.rotation = rotation
    }
}


