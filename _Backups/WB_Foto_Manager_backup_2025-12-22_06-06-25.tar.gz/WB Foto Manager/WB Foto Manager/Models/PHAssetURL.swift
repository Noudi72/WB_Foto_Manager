//
//  PHAssetURL.swift
//  WB Foto Manager
//
//  Helper to represent PhotoKit assets as stable URLs inside the app.
//

import Foundation

enum PHAssetURL {
    nonisolated static let scheme: String = "phasset"
    
    nonisolated static func url(forLocalIdentifier id: String) -> URL {
        // localIdentifier contains "/" → must be percent-encoded to stay a single path component.
        var allowed = CharacterSet.urlPathAllowed
        allowed.remove(charactersIn: "/")
        let encoded = id.addingPercentEncoding(withAllowedCharacters: allowed) ?? id
        // Use path form: phasset:///<encoded>
        return URL(string: "\(scheme):///\(encoded)")!
    }
    
    nonisolated static func localIdentifier(from url: URL) -> String? {
        guard url.scheme?.lowercased() == scheme else { return nil }
        let raw = String(url.path.dropFirst()) // remove leading "/"
        return raw.removingPercentEncoding ?? raw
    }
}


