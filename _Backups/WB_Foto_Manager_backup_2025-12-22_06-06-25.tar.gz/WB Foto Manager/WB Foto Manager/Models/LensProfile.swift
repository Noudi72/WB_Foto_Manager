//
//  LensProfile.swift
//  WB Foto Manager
//
//  Lightweight lens profile model (Lightroom-like).
//

import Foundation

struct LensMeta: Codable, Hashable, Sendable {
    var cameraMake: String?
    var cameraModel: String?
    var lensModel: String?
    var focalLengthMM: Double?
    var isoSpeed: Int?
    var apertureValue: Double?
    var shutterSpeed: Double?
    
    nonisolated init(cameraMake: String? = nil, cameraModel: String? = nil, lensModel: String? = nil, focalLengthMM: Double? = nil, isoSpeed: Int? = nil, apertureValue: Double? = nil, shutterSpeed: Double? = nil) {
        self.cameraMake = cameraMake
        self.cameraModel = cameraModel
        self.lensModel = lensModel
        self.focalLengthMM = focalLengthMM
        self.isoSpeed = isoSpeed
        self.apertureValue = apertureValue
        self.shutterSpeed = shutterSpeed
    }
    
    nonisolated var displaySummary: String {
        var parts: [String] = []
        if let make = cameraMake, !make.isEmpty { parts.append(make) }
        if let model = cameraModel, !model.isEmpty { parts.append(model) }
        if let lens = lensModel, !lens.isEmpty { parts.append(lens) }
        if let fl = focalLengthMM {
            parts.append("\(fl.formatted(.number.precision(.fractionLength(0))))mm")
        }
        return parts.joined(separator: " • ")
    }
}

struct LensProfileCorrectionPoint: Codable, Hashable, Sendable, Identifiable {
    var id: UUID = UUID()
    /// Brennweite in mm (wie im EXIF)
    var focalLengthMM: Double
    /// Distortion parameter for `CILensDistortionCorrection.inputDistortion` (small values).
    var distortion: Double
    /// Scale parameter for `CILensDistortionCorrection.inputScale` (usually ~1.0).
    var distortionScale: Double
    /// Vignette correction strength (0...1).
    var vignette: Double
    /// Chromatic aberration correction strength (0...1).
    var chromaticAberration: Double
    
    nonisolated init(
        focalLengthMM: Double,
        distortion: Double,
        distortionScale: Double = 1.0,
        vignette: Double = 0.0,
        chromaticAberration: Double = 0.0
    ) {
        self.focalLengthMM = focalLengthMM
        self.distortion = distortion
        self.distortionScale = distortionScale
        self.vignette = vignette
        self.chromaticAberration = chromaticAberration
    }
}

struct LensProfile: Identifiable, Codable, Hashable, Sendable {
    /// Stable ID (used for persistence when user selects a profile manually).
    let id: String
    
    var name: String
    
    /// Match rules (case-insensitive "contains").
    var cameraMakeContains: [String] = []
    var cameraModelContains: [String] = []
    var lensModelContains: [String] = []
    
    /// Optional focal-length range to qualify the match.
    var minFocalLengthMM: Double? = nil
    var maxFocalLengthMM: Double? = nil
    
    /// Optional calibration points (zoom lenses): interpolate by EXIF focal length.
    var correctionPoints: [LensProfileCorrectionPoint] = []
    
    // Correction parameters (profile-based)
    // Distortion is fed into `CILensDistortionCorrection.inputDistortion`.
    // Typical values are small (roughly -0.5 ... +0.5).
    var distortion: Double = 0.0
    /// `CILensDistortionCorrection.inputScale` (usually ~1.0).
    var distortionScale: Double = 1.0
    
    /// Vignette correction intensity (0...1). Implemented by applying a *negative* vignette on purpose (brighten edges).
    var vignette: Double = 0.0
    /// Chromatic aberration correction (0...1) mapped to our conservative CA model.
    var chromaticAberration: Double = 0.0
    
    nonisolated func score(for meta: LensMeta) -> Int {
        var score = 0
        
        if let lens = meta.lensModel, !lens.isEmpty {
            for p in lensModelContains where lens.localizedCaseInsensitiveContains(p) {
                score += 100
                break
            }
        }
        
        if let make = meta.cameraMake, !make.isEmpty {
            for p in cameraMakeContains where make.localizedCaseInsensitiveContains(p) {
                score += 20
                break
            }
        }
        
        if let model = meta.cameraModel, !model.isEmpty {
            for p in cameraModelContains where model.localizedCaseInsensitiveContains(p) {
                score += 20
                break
            }
        }
        
        if let fl = meta.focalLengthMM {
            if let min = minFocalLengthMM, fl < min { return 0 }
            if let max = maxFocalLengthMM, fl > max { return 0 }
            score += 10
        }
        
        // Generic fallback profiles should not "win" against a true lens match.
        if lensModelContains.isEmpty {
            score = max(1, score / 10)
        }
        
        return score
    }
    
    nonisolated func resolvedParameters(for meta: LensMeta?) -> (distortion: Double, scale: Double, vignette: Double, chromaticAberration: Double) {
        // Wenn keine Punkte vorhanden sind → statische Werte
        guard !correctionPoints.isEmpty else {
            return (distortion, distortionScale, vignette, chromaticAberration)
        }
        guard let fl = meta?.focalLengthMM else {
            return (distortion, distortionScale, vignette, chromaticAberration)
        }
        
        let sorted = correctionPoints.sorted(by: { $0.focalLengthMM < $1.focalLengthMM })
        guard let first = sorted.first, let last = sorted.last else {
            return (distortion, distortionScale, vignette, chromaticAberration)
        }
        
        if fl <= first.focalLengthMM {
            return (first.distortion, first.distortionScale, first.vignette, first.chromaticAberration)
        }
        if fl >= last.focalLengthMM {
            return (last.distortion, last.distortionScale, last.vignette, last.chromaticAberration)
        }
        
        // Finde Segment [a,b]
        var a = first
        var b = last
        for i in 0..<(sorted.count - 1) {
            let p0 = sorted[i]
            let p1 = sorted[i + 1]
            if fl >= p0.focalLengthMM && fl <= p1.focalLengthMM {
                a = p0
                b = p1
                break
            }
        }
        
        let span = max(0.000_1, b.focalLengthMM - a.focalLengthMM)
        let t = max(0.0, min(1.0, (fl - a.focalLengthMM) / span))
        
        func lerp(_ x: Double, _ y: Double) -> Double { x + (y - x) * t }
        
        return (
            lerp(a.distortion, b.distortion),
            lerp(a.distortionScale, b.distortionScale),
            lerp(a.vignette, b.vignette),
            lerp(a.chromaticAberration, b.chromaticAberration)
        )
    }
}

// MARK: - Helpers
extension LensProfile {
    /// Normalized key used to detect "same" profiles across imports (e.g. LCP re-import) without relying on random IDs.
    /// Intentionally excludes correction parameters, so newer values can replace older ones.
    nonisolated var normalizedMatchKey: String {
        func norm(_ s: String) -> String {
            s.trimmingCharacters(in: .whitespacesAndNewlines)
                .replacingOccurrences(of: "\u{00A0}", with: " ")
                .lowercased()
        }
        let nameKey = norm(name)
        let makeKey = cameraMakeContains.map(norm).filter { !$0.isEmpty }.sorted().joined(separator: ",")
        let modelKey = cameraModelContains.map(norm).filter { !$0.isEmpty }.sorted().joined(separator: ",")
        let lensKey = lensModelContains.map(norm).filter { !$0.isEmpty }.sorted().joined(separator: ",")
        return "name=\(nameKey)|make=\(makeKey)|model=\(modelKey)|lens=\(lensKey)"
    }
    
    nonisolated func copy(withID newID: String) -> LensProfile {
        LensProfile(
            id: newID,
            name: name,
            cameraMakeContains: cameraMakeContains,
            cameraModelContains: cameraModelContains,
            lensModelContains: lensModelContains,
            minFocalLengthMM: minFocalLengthMM,
            maxFocalLengthMM: maxFocalLengthMM,
            correctionPoints: correctionPoints,
            distortion: distortion,
            distortionScale: distortionScale,
            vignette: vignette,
            chromaticAberration: chromaticAberration
        )
    }
}

enum LensProfileCatalog {
    /// Minimal built-in set. This is intentionally conservative and can be extended later (JSON import / LCP).
    nonisolated static let builtIn: [LensProfile] = [
        // --- Templates (pattern-based, zoom-aware) ---
        LensProfile(
            id: "template-14-24",
            name: "Template: 14-24 Zoom",
            cameraMakeContains: [],
            cameraModelContains: [],
            lensModelContains: ["14-24"],
            minFocalLengthMM: 13,
            maxFocalLengthMM: 25,
            correctionPoints: [
                LensProfileCorrectionPoint(focalLengthMM: 14, distortion: 0.30, distortionScale: 1.02, vignette: 0.45, chromaticAberration: 0.35),
                LensProfileCorrectionPoint(focalLengthMM: 18, distortion: 0.22, distortionScale: 1.02, vignette: 0.38, chromaticAberration: 0.30),
                LensProfileCorrectionPoint(focalLengthMM: 24, distortion: 0.16, distortionScale: 1.01, vignette: 0.30, chromaticAberration: 0.26)
            ],
            distortion: 0.22,
            distortionScale: 1.02,
            vignette: 0.38,
            chromaticAberration: 0.30
        ),
        LensProfile(
            id: "template-16-35",
            name: "Template: 16-35 Zoom",
            cameraMakeContains: [],
            cameraModelContains: [],
            lensModelContains: ["16-35"],
            minFocalLengthMM: 15,
            maxFocalLengthMM: 36,
            correctionPoints: [
                LensProfileCorrectionPoint(focalLengthMM: 16, distortion: 0.26, distortionScale: 1.02, vignette: 0.40, chromaticAberration: 0.30),
                LensProfileCorrectionPoint(focalLengthMM: 24, distortion: 0.14, distortionScale: 1.01, vignette: 0.28, chromaticAberration: 0.22),
                LensProfileCorrectionPoint(focalLengthMM: 35, distortion: 0.06, distortionScale: 1.00, vignette: 0.20, chromaticAberration: 0.18)
            ],
            distortion: 0.14,
            distortionScale: 1.01,
            vignette: 0.28,
            chromaticAberration: 0.22
        ),
        LensProfile(
            id: "template-24-70",
            name: "Template: 24-70 Zoom",
            cameraMakeContains: [],
            cameraModelContains: [],
            lensModelContains: ["24-70"],
            minFocalLengthMM: 23,
            maxFocalLengthMM: 71,
            correctionPoints: [
                LensProfileCorrectionPoint(focalLengthMM: 24, distortion: 0.22, distortionScale: 1.02, vignette: 0.34, chromaticAberration: 0.26),
                LensProfileCorrectionPoint(focalLengthMM: 50, distortion: 0.10, distortionScale: 1.01, vignette: 0.22, chromaticAberration: 0.18),
                LensProfileCorrectionPoint(focalLengthMM: 70, distortion: 0.04, distortionScale: 1.00, vignette: 0.18, chromaticAberration: 0.16)
            ],
            distortion: 0.12,
            distortionScale: 1.01,
            vignette: 0.22,
            chromaticAberration: 0.18
        ),
        LensProfile(
            id: "template-70-200",
            name: "Template: 70-200 Zoom",
            cameraMakeContains: [],
            cameraModelContains: [],
            lensModelContains: ["70-200"],
            minFocalLengthMM: 60,
            maxFocalLengthMM: 210,
            correctionPoints: [
                LensProfileCorrectionPoint(focalLengthMM: 70, distortion: 0.10, distortionScale: 1.01, vignette: 0.22, chromaticAberration: 0.20),
                LensProfileCorrectionPoint(focalLengthMM: 135, distortion: 0.04, distortionScale: 1.00, vignette: 0.18, chromaticAberration: 0.16),
                LensProfileCorrectionPoint(focalLengthMM: 200, distortion: 0.02, distortionScale: 1.00, vignette: 0.16, chromaticAberration: 0.14)
            ],
            distortion: 0.04,
            distortionScale: 1.00,
            vignette: 0.18,
            chromaticAberration: 0.16
        ),
        LensProfile(
            id: "template-100-400",
            name: "Template: 100-400 Zoom",
            cameraMakeContains: [],
            cameraModelContains: [],
            lensModelContains: ["100-400"],
            minFocalLengthMM: 90,
            maxFocalLengthMM: 410,
            correctionPoints: [
                LensProfileCorrectionPoint(focalLengthMM: 100, distortion: 0.08, distortionScale: 1.00, vignette: 0.18, chromaticAberration: 0.18),
                LensProfileCorrectionPoint(focalLengthMM: 250, distortion: 0.04, distortionScale: 1.00, vignette: 0.14, chromaticAberration: 0.14),
                LensProfileCorrectionPoint(focalLengthMM: 400, distortion: 0.03, distortionScale: 1.00, vignette: 0.12, chromaticAberration: 0.12)
            ],
            distortion: 0.04,
            distortionScale: 1.00,
            vignette: 0.14,
            chromaticAberration: 0.14
        ),
        LensProfile(
            id: "template-200-600",
            name: "Template: 200-600 Zoom",
            cameraMakeContains: [],
            cameraModelContains: [],
            lensModelContains: ["200-600", "150-600"],
            minFocalLengthMM: 140,
            maxFocalLengthMM: 610,
            correctionPoints: [
                LensProfileCorrectionPoint(focalLengthMM: 200, distortion: 0.05, distortionScale: 1.00, vignette: 0.14, chromaticAberration: 0.14),
                LensProfileCorrectionPoint(focalLengthMM: 400, distortion: 0.03, distortionScale: 1.00, vignette: 0.12, chromaticAberration: 0.12),
                LensProfileCorrectionPoint(focalLengthMM: 600, distortion: 0.02, distortionScale: 1.00, vignette: 0.10, chromaticAberration: 0.10)
            ],
            distortion: 0.03,
            distortionScale: 1.00,
            vignette: 0.12,
            chromaticAberration: 0.12
        ),
        
        // Generic fallbacks (by focal length) – used when no explicit lens match exists.
        LensProfile(
            id: "generic-wide",
            name: "Generic (Weitwinkel)",
            lensModelContains: [],
            minFocalLengthMM: nil,
            maxFocalLengthMM: 24,
            distortion: 0.24,
            distortionScale: 1.02,
            vignette: 0.35,
            chromaticAberration: 0.35
        ),
        LensProfile(
            id: "generic-standard",
            name: "Generic (Standard)",
            lensModelContains: [],
            minFocalLengthMM: 24,
            maxFocalLengthMM: 85,
            distortion: 0.12,
            distortionScale: 1.01,
            vignette: 0.22,
            chromaticAberration: 0.22
        ),
        LensProfile(
            id: "generic-tele",
            name: "Generic (Tele)",
            lensModelContains: [],
            minFocalLengthMM: 85,
            maxFocalLengthMM: nil,
            distortion: 0.06,
            distortionScale: 1.00,
            vignette: 0.14,
            chromaticAberration: 0.16
        )
    ]
}


