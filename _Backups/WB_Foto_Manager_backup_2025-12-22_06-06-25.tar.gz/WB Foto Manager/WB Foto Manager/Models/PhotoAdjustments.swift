//
//  PhotoAdjustments.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation

/// Bildbearbeitungsparameter für ein Foto
nonisolated struct PhotoAdjustments: Codable, Equatable, Hashable, Sendable {
    // Basis-Adjustments
    var exposure: Double = 0.0 // -2.0 bis +2.0 EV
    var contrast: Double = 1.0 // 0.5x bis 1.8x
    var temperature: Double = 0.0 // -3000 bis +3000 Kelvin
    var tint: Double = 0.0 // -80 bis +80 (Magenta/Grün)
    var clarity: Double = 0.0 // 0.0 bis 1.0
    var vibrance: Double = 0.0 // -0.6 bis +1.0
    
    // Erweiterte Adjustments (Lightroom Classic Style)
    var highlights: Double = 0.0 // -100 bis +100
    var shadows: Double = 0.0 // -100 bis +100
    var whites: Double = 0.0 // -100 bis +100
    var blacks: Double = 0.0 // -100 bis +100
    var saturation: Double = 0.0 // -100 bis +100
    var dehaze: Double = 0.0 // -100 bis +100
    var texture: Double = 0.0 // -100 bis +100

    // Details (Lightroom-like)
    var sharpening: Double = 0.0 // 0 bis 100
    var noiseReduction: Double = 0.0 // 0 bis 100

    // Optik (Lightroom-like)
    var lensDistortion: Double = 0.0 // -100 bis +100
    var vignette: Double = 0.0 // -100 bis +100
    var chromaticAberration: Double = 0.0 // 0 bis 100
    
    // MARK: - Init (explizit, damit wir trotz Custom-Codable weiter Memberwise-Init haben)
    init(
        exposure: Double = 0.0,
        contrast: Double = 1.0,
        temperature: Double = 0.0,
        tint: Double = 0.0,
        clarity: Double = 0.0,
        vibrance: Double = 0.0,
        highlights: Double = 0.0,
        shadows: Double = 0.0,
        whites: Double = 0.0,
        blacks: Double = 0.0,
        saturation: Double = 0.0,
        dehaze: Double = 0.0,
        texture: Double = 0.0,
        sharpening: Double = 0.0,
        noiseReduction: Double = 0.0,
        lensDistortion: Double = 0.0,
        vignette: Double = 0.0,
        chromaticAberration: Double = 0.0
    ) {
        self.exposure = exposure
        self.contrast = contrast
        self.temperature = temperature
        self.tint = tint
        self.clarity = clarity
        self.vibrance = vibrance
        self.highlights = highlights
        self.shadows = shadows
        self.whites = whites
        self.blacks = blacks
        self.saturation = saturation
        self.dehaze = dehaze
        self.texture = texture
        self.sharpening = sharpening
        self.noiseReduction = noiseReduction
        self.lensDistortion = lensDistortion
        self.vignette = vignette
        self.chromaticAberration = chromaticAberration
    }
    
    var hasAdjustments: Bool {
        exposure != 0.0 ||
        contrast != 1.0 ||
        temperature != 0.0 ||
        tint != 0.0 ||
        clarity != 0.0 ||
        vibrance != 0.0 ||
        highlights != 0.0 ||
        shadows != 0.0 ||
        whites != 0.0 ||
        blacks != 0.0 ||
        saturation != 0.0 ||
        dehaze != 0.0 ||
        texture != 0.0 ||
        sharpening != 0.0 ||
        noiseReduction != 0.0 ||
        lensDistortion != 0.0 ||
        vignette != 0.0 ||
        chromaticAberration != 0.0
    }
    
    mutating func reset() {
        exposure = 0.0
        contrast = 1.0
        temperature = 0.0
        tint = 0.0
        clarity = 0.0
        vibrance = 0.0
        highlights = 0.0
        shadows = 0.0
        whites = 0.0
        blacks = 0.0
        saturation = 0.0
        dehaze = 0.0
        texture = 0.0
        sharpening = 0.0
        noiseReduction = 0.0
        lensDistortion = 0.0
        vignette = 0.0
        chromaticAberration = 0.0
    }
    
    func applying(_ other: PhotoAdjustments) -> PhotoAdjustments {
        var result = self
        result.exposure += other.exposure
        result.contrast *= other.contrast
        result.temperature += other.temperature
        result.tint += other.tint
        result.clarity += other.clarity
        result.vibrance += other.vibrance
        result.highlights += other.highlights
        result.shadows += other.shadows
        result.whites += other.whites
        result.blacks += other.blacks
        result.saturation += other.saturation
        result.dehaze += other.dehaze
        result.texture += other.texture
        result.sharpening += other.sharpening
        result.noiseReduction += other.noiseReduction
        result.lensDistortion += other.lensDistortion
        result.vignette += other.vignette
        result.chromaticAberration += other.chromaticAberration
        return result
    }
    
    /// Erstellt ein "Delta" relativ zu Defaults (für Preset-Stacking / Auto+Style).
    /// - exposure/temp/tint/...: additiv
    /// - contrast: multiplikativ (Ratio)
    func delta(from defaults: PhotoAdjustments = PhotoAdjustments()) -> PhotoAdjustments {
        var delta = PhotoAdjustments()
        delta.exposure = exposure - defaults.exposure
        delta.contrast = defaults.contrast == 0 ? contrast : (contrast / defaults.contrast)
        delta.temperature = temperature - defaults.temperature
        delta.tint = tint - defaults.tint
        delta.clarity = clarity - defaults.clarity
        delta.vibrance = vibrance - defaults.vibrance
        delta.highlights = highlights - defaults.highlights
        delta.shadows = shadows - defaults.shadows
        delta.whites = whites - defaults.whites
        delta.blacks = blacks - defaults.blacks
        delta.saturation = saturation - defaults.saturation
        delta.dehaze = dehaze - defaults.dehaze
        delta.texture = texture - defaults.texture
        delta.sharpening = sharpening - defaults.sharpening
        delta.noiseReduction = noiseReduction - defaults.noiseReduction
        delta.lensDistortion = lensDistortion - defaults.lensDistortion
        delta.vignette = vignette - defaults.vignette
        delta.chromaticAberration = chromaticAberration - defaults.chromaticAberration
        return delta
    }
    
    // MARK: - Codable (rückwärtskompatibel bei neuen Feldern)
    
    private enum CodingKeys: String, CodingKey {
        case exposure
        case contrast
        case temperature
        case tint
        case clarity
        case vibrance
        case highlights
        case shadows
        case whites
        case blacks
        case saturation
        case dehaze
        case texture
        case sharpening
        case noiseReduction
        case lensDistortion
        case vignette
        case chromaticAberration
    }
    
    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        
        exposure = try c.decodeIfPresent(Double.self, forKey: .exposure) ?? 0.0
        contrast = try c.decodeIfPresent(Double.self, forKey: .contrast) ?? 1.0
        temperature = try c.decodeIfPresent(Double.self, forKey: .temperature) ?? 0.0
        tint = try c.decodeIfPresent(Double.self, forKey: .tint) ?? 0.0
        clarity = try c.decodeIfPresent(Double.self, forKey: .clarity) ?? 0.0
        vibrance = try c.decodeIfPresent(Double.self, forKey: .vibrance) ?? 0.0
        
        highlights = try c.decodeIfPresent(Double.self, forKey: .highlights) ?? 0.0
        shadows = try c.decodeIfPresent(Double.self, forKey: .shadows) ?? 0.0
        whites = try c.decodeIfPresent(Double.self, forKey: .whites) ?? 0.0
        blacks = try c.decodeIfPresent(Double.self, forKey: .blacks) ?? 0.0
        saturation = try c.decodeIfPresent(Double.self, forKey: .saturation) ?? 0.0
        dehaze = try c.decodeIfPresent(Double.self, forKey: .dehaze) ?? 0.0
        texture = try c.decodeIfPresent(Double.self, forKey: .texture) ?? 0.0
        
        sharpening = try c.decodeIfPresent(Double.self, forKey: .sharpening) ?? 0.0
        noiseReduction = try c.decodeIfPresent(Double.self, forKey: .noiseReduction) ?? 0.0
        
        lensDistortion = try c.decodeIfPresent(Double.self, forKey: .lensDistortion) ?? 0.0
        vignette = try c.decodeIfPresent(Double.self, forKey: .vignette) ?? 0.0
        chromaticAberration = try c.decodeIfPresent(Double.self, forKey: .chromaticAberration) ?? 0.0
    }
    
    func encode(to encoder: Encoder) throws {
        var c = encoder.container(keyedBy: CodingKeys.self)
        try c.encode(exposure, forKey: .exposure)
        try c.encode(contrast, forKey: .contrast)
        try c.encode(temperature, forKey: .temperature)
        try c.encode(tint, forKey: .tint)
        try c.encode(clarity, forKey: .clarity)
        try c.encode(vibrance, forKey: .vibrance)
        
        try c.encode(highlights, forKey: .highlights)
        try c.encode(shadows, forKey: .shadows)
        try c.encode(whites, forKey: .whites)
        try c.encode(blacks, forKey: .blacks)
        try c.encode(saturation, forKey: .saturation)
        try c.encode(dehaze, forKey: .dehaze)
        try c.encode(texture, forKey: .texture)
        
        try c.encode(sharpening, forKey: .sharpening)
        try c.encode(noiseReduction, forKey: .noiseReduction)
        try c.encode(lensDistortion, forKey: .lensDistortion)
        try c.encode(vignette, forKey: .vignette)
        try c.encode(chromaticAberration, forKey: .chromaticAberration)
    }
}

