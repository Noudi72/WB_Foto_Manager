//
//  ExportStatistics.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 20.12.2025.
//

import Foundation
import Combine

/// Export-Status
enum ExportStatus: String, Codable {
    case success
    case failed
}

/// Export-Statistiken für einen Export-Vorgang
struct ExportStatistics: Codable, Identifiable {
    let id: UUID
    let date: Date
    let photoCount: Int
    let totalSizeBytes: Int64
    let durationSeconds: Double
    let presetName: String?
    let outputDirectory: String?
    
    // Erweiterte Felder für Fehler-Tracking und Retry (optional für Backward Compatibility)
    let status: ExportStatus?
    let errorMessage: String?
    let photoIDs: [UUID]? // IDs der exportierten Fotos (für Retry)
    let presetID: UUID? // ID des verwendeten Presets (für Retry)
    
    // Computed property für effektiven Status (Standard: success wenn nicht gesetzt)
    var effectiveStatus: ExportStatus {
        status ?? .success
    }
    
    var totalSizeMB: Double {
        Double(totalSizeBytes) / (1024 * 1024)
    }
    
    var averageSizeMB: Double {
        guard photoCount > 0 else { return 0 }
        return totalSizeMB / Double(photoCount)
    }
    
    var photosPerSecond: Double {
        guard durationSeconds > 0 else { return 0 }
        return Double(photoCount) / durationSeconds
    }
    
    init(id: UUID = UUID(), date: Date = Date(), photoCount: Int, totalSizeBytes: Int64, durationSeconds: Double, presetName: String? = nil, outputDirectory: String? = nil, status: ExportStatus? = .success, errorMessage: String? = nil, photoIDs: [UUID]? = nil, presetID: UUID? = nil) {
        self.id = id
        self.date = date
        self.photoCount = photoCount
        self.totalSizeBytes = totalSizeBytes
        self.durationSeconds = durationSeconds
        self.presetName = presetName
        self.outputDirectory = outputDirectory
        self.status = status
        self.errorMessage = errorMessage
        self.photoIDs = photoIDs
        self.presetID = presetID
    }
    
    // Convenience-Initializer für erfolgreiche Exports
    static func success(id: UUID = UUID(), date: Date = Date(), photoCount: Int, totalSizeBytes: Int64, durationSeconds: Double, presetName: String? = nil, outputDirectory: String? = nil, photoIDs: [UUID]? = nil, presetID: UUID? = nil) -> ExportStatistics {
        ExportStatistics(id: id, date: date, photoCount: photoCount, totalSizeBytes: totalSizeBytes, durationSeconds: durationSeconds, presetName: presetName, outputDirectory: outputDirectory, status: .success, errorMessage: nil, photoIDs: photoIDs, presetID: presetID)
    }
    
    // Initializer für fehlgeschlagene Exports
    static func failed(id: UUID = UUID(), date: Date = Date(), photoCount: Int, errorMessage: String, presetName: String? = nil, outputDirectory: String? = nil, photoIDs: [UUID]? = nil, presetID: UUID? = nil) -> ExportStatistics {
        ExportStatistics(id: id, date: date, photoCount: photoCount, totalSizeBytes: 0, durationSeconds: 0, presetName: presetName, outputDirectory: outputDirectory, status: .failed, errorMessage: errorMessage, photoIDs: photoIDs, presetID: presetID)
    }
}

/// Manager für Export-Statistiken
@MainActor
class ExportStatisticsManager: ObservableObject {
    static let shared = ExportStatisticsManager()
    
    @Published var statistics: [ExportStatistics] = []
    
    private let defaultsKey = "exportStatisticsV1"
    private let maxStatistics = 100 // Behalte nur die letzten 100 Exports
    
    private init() {
        loadStatistics()
    }
    
    func addStatistics(_ stats: ExportStatistics) {
        statistics.insert(stats, at: 0)
        
        // Behalte nur die letzten N Statistiken
        if statistics.count > maxStatistics {
            statistics = Array(statistics.prefix(maxStatistics))
        }
        
        saveStatistics()
    }
    
    var totalExports: Int {
        statistics.count
    }
    
    var totalPhotosExported: Int {
        statistics.reduce(0) { $0 + $1.photoCount }
    }
    
    var totalSizeBytes: Int64 {
        statistics.reduce(0) { $0 + $1.totalSizeBytes }
    }
    
    var totalSizeMB: Double {
        Double(totalSizeBytes) / (1024 * 1024)
    }
    
    var averageExportTime: Double {
        guard !statistics.isEmpty else { return 0 }
        let successfulExports = statistics.filter { $0.effectiveStatus == .success && $0.durationSeconds > 0 }
        guard !successfulExports.isEmpty else { return 0 }
        return successfulExports.reduce(0.0) { $0 + $1.durationSeconds } / Double(successfulExports.count)
    }
    
    var failedExports: [ExportStatistics] {
        statistics.filter { $0.effectiveStatus == .failed }
    }
    
    var successfulExports: [ExportStatistics] {
        statistics.filter { $0.effectiveStatus == .success }
    }
    
    private func loadStatistics() {
        guard let data = UserDefaults.standard.data(forKey: defaultsKey),
              let decoded = try? JSONDecoder().decode([ExportStatistics].self, from: data) else {
            return
        }
        statistics = decoded
    }
    
    private func saveStatistics() {
        guard let encoded = try? JSONEncoder().encode(statistics) else { return }
        UserDefaults.standard.set(encoded, forKey: defaultsKey)
    }
    
    func clearStatistics() {
        statistics = []
        saveStatistics()
    }
}

