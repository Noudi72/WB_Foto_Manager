//
//  UIState.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import Combine
import SwiftUI

// MARK: - Sortierung

enum PhotoSortMode: String, CaseIterable, Codable {
    case captureDateDesc
    case captureDateAsc
    case fileNameAsc
    case ratingDesc
    case ratingAsc
    case resolutionDesc
    case resolutionAsc
    case bestOfDesc
    case bestOfAsc
    
    var title: String {
        switch self {
        case .captureDateDesc: return "Aufnahmedatum (neueste zuerst)"
        case .captureDateAsc: return "Aufnahmedatum (älteste zuerst)"
        case .fileNameAsc: return "Dateiname (A→Z)"
        case .ratingDesc: return "Rating (hoch→tief)"
        case .ratingAsc: return "Rating (tief→hoch)"
        case .resolutionDesc: return "Auflösung (hoch→tief)"
        case .resolutionAsc: return "Auflösung (tief→hoch)"
        case .bestOfDesc: return "Best‑of (Qualität+Auflösung)"
        case .bestOfAsc: return "Best‑of (schlecht→gut)"
        }
    }
}

class UIState: ObservableObject {
    @Published var viewMode: ViewMode = .detail
    @Published var zoomLevel: Double = 1.0
    @Published var showBeforeAfter: Bool = false

    // Multi-selection (für Sync-Workflows wie Lightroom)
    @Published var selectionMode: Bool = false
    
    // Watermark Vorschau (nur Anzeige, nicht Export)
    @Published var watermarkPreviewEnabled: Bool = false
    @Published var watermarkPreviewPresetID: UUID? = nil
    
    // Masking (lokale Anpassungen)
    @Published var showMaskOverlay: Bool = true
    @Published var activeMaskID: UUID? = nil
    
    // Sheets / Modals (zentral, damit Menüs + Topbar zuverlässig funktionieren)
    @Published var activeSheet: SheetRoute? = nil
    
    // Filters
    @Published var ratingFilter: Int? = nil {
        didSet {
            // This is a good place to notify the PhotoStore to re-filter
        }
    }
    @Published var searchQuery: String = "" {
        didSet {
            // Trigger re-filtering when search changes
        }
    }
    @Published var pickStatusFilter: PickStatus? = nil {
        didSet {
            // Trigger re-filtering when pick status filter changes
        }
    }
    @Published var showQuickCollectionOnly: Bool = false {
        didSet {
            // Trigger re-filtering when quick collection filter changes
        }
    }
    @Published var colorTagFilter: ColorTag? = nil {
        didSet {
            // Trigger re-filtering when color tag filter changes
        }
    }
    @Published var activeSmartCollectionID: UUID? = nil {
        didSet {
            // Trigger re-filtering when smart collection changes
        }
    }
    
    // EXIF Filters
    @Published var exifCameraMakeFilter: String? = nil {
        didSet {
            // Trigger re-filtering when EXIF filter changes
        }
    }
    @Published var exifCameraModelFilter: String? = nil {
        didSet {
            // Trigger re-filtering when EXIF filter changes
        }
    }
    @Published var exifLensModelFilter: String? = nil {
        didSet {
            // Trigger re-filtering when EXIF filter changes
        }
    }
    @Published var exifFocalLengthMinFilter: Double? = nil {
        didSet {
            // Trigger re-filtering when EXIF filter changes
        }
    }
    @Published var exifFocalLengthMaxFilter: Double? = nil {
        didSet {
            // Trigger re-filtering when EXIF filter changes
        }
    }
    @Published var exifISOMinFilter: Int? = nil {
        didSet {
            // Trigger re-filtering when EXIF filter changes
        }
    }
    @Published var exifISOMaxFilter: Int? = nil {
        didSet {
            // Trigger re-filtering when EXIF filter changes
        }
    }
    @Published var exifApertureMinFilter: Double? = nil {
        didSet {
            // Trigger re-filtering when EXIF filter changes
        }
    }
    @Published var exifApertureMaxFilter: Double? = nil {
        didSet {
            // Trigger re-filtering when EXIF filter changes
        }
    }
    @Published var exifShutterSpeedMinFilter: Double? = nil {
        didSet {
            // Trigger re-filtering when EXIF filter changes
        }
    }
    @Published var exifShutterSpeedMaxFilter: Double? = nil {
        didSet {
            // Trigger re-filtering when EXIF filter changes
        }
    }
    
    // Sortierung
    @Published var sortMode: PhotoSortMode = .captureDateDesc {
        didSet {
            UserDefaults.standard.set(sortMode.rawValue, forKey: "photoSortModeV1")
        }
    }
    
    // AI Search (lokaler Suchindex über Vision-Tags)
    @Published var aiSearchEnabled: Bool = false {
        didSet {
            UserDefaults.standard.set(aiSearchEnabled, forKey: "aiSearchEnabledV1")
        }
    }
    
    // Focus helpers
    @Published var focusSearchField: Bool = false
    
    // Sidebar visibility
    @Published var showLeftSidebar: Bool = true {
        didSet { UserDefaults.standard.set(showLeftSidebar, forKey: "showLeftSidebarV1") }
    }
    @Published var showRightSidebar: Bool = true {
        didSet { UserDefaults.standard.set(showRightSidebar, forKey: "showRightSidebarV1") }
    }
    
    // Layout visibility (Focus‑Mode 2.0)
    @Published var showTopBar: Bool = true {
        didSet { UserDefaults.standard.set(showTopBar, forKey: "showTopBarV1") }
    }
    @Published var showFilmstrip: Bool = true {
        didSet { UserDefaults.standard.set(showFilmstrip, forKey: "showFilmstripV1") }
    }
    
    // Focus Mode (maximale Fläche: Sidebars + Filmstrip + Topbar ausblenden)
    @Published var isFocusMode: Bool = false
    
    init() {
        if let raw = UserDefaults.standard.string(forKey: "photoSortModeV1"),
           let mode = PhotoSortMode(rawValue: raw) {
            self.sortMode = mode
        }
        self.aiSearchEnabled = UserDefaults.standard.object(forKey: "aiSearchEnabledV1") as? Bool ?? false
        self.showLeftSidebar = UserDefaults.standard.object(forKey: "showLeftSidebarV1") as? Bool ?? true
        self.showRightSidebar = UserDefaults.standard.object(forKey: "showRightSidebarV1") as? Bool ?? true
        self.showTopBar = UserDefaults.standard.object(forKey: "showTopBarV1") as? Bool ?? true
        self.showFilmstrip = UserDefaults.standard.object(forKey: "showFilmstripV1") as? Bool ?? true
    }
}

// MARK: - Modal Routing

extension UIState {
    enum SheetRoute: Identifiable {
        case settings
        case export
        case batchExport
        case uploadSettings
        case exportQueueSettings
        case backupRestore
        case ingestImport
        case syncAdjustments
        case surveyView
        case smartCollections
        case shortcutsHelp
        case help
        case duplicateDetection
        case exportStatistics
        
        var id: String {
            switch self {
            case .settings: return "settings"
            case .export: return "export"
            case .batchExport: return "batchExport"
            case .uploadSettings: return "uploadSettings"
            case .exportQueueSettings: return "exportQueueSettings"
            case .backupRestore: return "backupRestore"
            case .ingestImport: return "ingestImport"
            case .syncAdjustments: return "syncAdjustments"
            case .surveyView: return "surveyView"
            case .smartCollections: return "smartCollections"
            case .shortcutsHelp: return "shortcutsHelp"
            case .help: return "help"
            case .duplicateDetection: return "duplicateDetection"
            case .exportStatistics: return "exportStatistics"
            }
        }
    }
}

// We can move the ViewMode enum here as it's purely UI-related.
enum ViewMode {
    case detail
    case grid
    case compare
    case survey
}
