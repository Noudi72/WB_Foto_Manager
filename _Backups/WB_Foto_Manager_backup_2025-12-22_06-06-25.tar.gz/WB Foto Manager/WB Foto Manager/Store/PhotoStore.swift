//
//  PhotoStore.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import SwiftUI
import Combine
import AppKit
import Photos
import UniformTypeIdentifiers

/// Zentraler State Manager für die App
class PhotoStore: ObservableObject {
    // MARK: - Published Properties
    
    @Published var photos: [PhotoItem] = []
    @Published var filteredPhotos: [PhotoItem] = []
    
    @Published var selectedPhotoIDs: Set<UUID> = []
    @Published var currentPhotoID: UUID?
    @Published var currentFolder: URL?
    
    @Published var exportPresets: [ExportPreset] = []
    @Published var adjustmentPresets: [AdjustmentPreset] = []
    /// User-definierte Preset-Kategorien (Reihenfolge wird persistiert).
    @Published var presetGroups: [String] = []
    @Published var uploadTargets: [UploadTarget] = []
    @Published var iptcTemplates: [IPTCTemplate] = []
    @Published var smartCollections: [SmartCollection] = []
    
    // MARK: - History / Snapshots (Lightroom-like)
    @Published var editSnapshotsByKey: [String: [EditSnapshot]] = [:]

    // MARK: - Copy/Paste & Sync (Lightroom-like)

    @Published var copiedAdjustments: PhotoAdjustments? = nil
    
    // Export Queue Settings
    @Published var exportQueueEnabled: Bool = false {
        didSet { saveExportQueueSettings() }
    }
    @Published var exportQueueMinRating: Int = 4 {
        didSet { saveExportQueueSettings() }
    }
    @Published var exportQueuePreset: ExportPreset? {
        didSet { saveExportQueueSettings() }
    }
    @Published var exportQueueOutputDirectory: URL? {
        didSet { saveExportQueueSettings() }
    }
    @Published var isExportQueueRunning: Bool = false
    @Published var exportQueueProgress: Double = 0.0
    @Published var exportQueueProcessedCount: Int = 0
    @Published var exportQueueTotalCount: Int = 0
    @Published var exportQueueCurrentName: String = ""
    
    struct ExportQueueFailure: Identifiable, Codable, Hashable, Sendable {
        let id: UUID
        let fileName: String
        let message: String
        let date: Date
    }
    
    /// Letzte Fehler der Export‑Queue (für Transparenz + Retry).
    @Published var exportQueueFailures: [ExportQueueFailure] = []
    
    // MARK: - Quick Export (1‑Klick Export)
    @Published var quickExportPresetID: UUID? = nil {
        didSet {
            saveQuickExportSettings()
        }
    }
    @Published var quickExportDirectory: URL? = nil {
        didSet {
            saveQuickExportSettings()
        }
    }
    @Published var isQuickExporting: Bool = false
    @Published var quickExportProgress: Double = 0.0
    
    private var quickExportTask: Task<Void, Never>? = nil
    
    // MARK: - Job/Projekt Presets (pro Ordner)
    /// Wenn aktiv/gespeichert, werden pro Ordner Workflow‑Settings automatisch geladen (Quick Export, Stil‑Profil, Upload‑Ziele).
    @Published var hasJobPresetForCurrentFolder: Bool = false
    
    /// Optionaler Upload‑Filter pro Ordner (Subset der konfigurierten Upload‑Ziele).
    /// Wenn deaktiviert, werden die globalen Upload‑Ziele (aus Preset + isEnabled) verwendet.
    @Published var jobUsesUploadTargetFilter: Bool = false
    @Published var jobUploadTargetIDs: Set<String> = []
    
    // MARK: - Ingest / Import (SD‑Karte → Job Ordner)
    @Published var isIngestRunning: Bool = false
    @Published var ingestProgress: Double = 0.0
    @Published var ingestProcessedCount: Int = 0
    @Published var ingestTotalCount: Int = 0
    @Published var ingestCurrentName: String = ""
    
    private var ingestTask: Task<Void, Never>? = nil
    
    // MARK: - Batch Auto (Auto + Stil‑Profil)
    @Published var isBatchAutoRunning: Bool = false
    @Published var batchAutoProgress: Double = 0.0
    @Published var batchAutoProcessedCount: Int = 0
    @Published var batchAutoTotalCount: Int = 0
    @Published var batchAutoCurrentName: String = ""
    
    // MARK: - AI Keywords (Batch)
    @Published var isAITaggingRunning: Bool = false
    @Published var aiTaggingProgress: Double = 0.0
    @Published var aiTaggingProcessedCount: Int = 0
    @Published var aiTaggingTotalCount: Int = 0
    @Published var aiTaggingCurrentName: String = ""
    
    // MARK: - AI Suche (lokaler Suchindex)
    @Published var isAISearchRunning: Bool = false
    @Published var aiSearchProgress: Double = 0.0
    @Published var aiSearchProcessedCount: Int = 0
    @Published var aiSearchTotalCount: Int = 0
    @Published var aiSearchCurrentName: String = ""
    
    // MARK: - Best‑of (Qualität+Auflösung) – schnelle Redaktion/Delivery
    @Published var isBestOfRunning: Bool = false
    @Published var bestOfProgress: Double = 0.0
    @Published var bestOfProcessedCount: Int = 0
    @Published var bestOfTotalCount: Int = 0
    @Published var bestOfCurrentName: String = ""
    
    // MARK: - Computed Properties
    
    var currentPhoto: PhotoItem? {
        guard let id = currentPhotoID else { return nil }
        // Search in the main photos array, not the filtered one.
        return photos.first { $0.id == id }
    }
    
    var currentPhotoIndexInFiltered: Int? {
        guard let currentID = currentPhotoID else { return nil }
        return filteredPhotos.firstIndex { $0.id == currentID }
    }
    
    // MARK: - Services & State
    
    private let ratingService = RatingPersistenceService.shared
    private let metadataService = IPTCMetadataService.shared
    var uiState: UIState?
    private var cancellables = Set<AnyCancellable>()
    
    private var aiTaggingTask: Task<Void, Never>?
    private var bestOfTask: Task<Void, Never>?
    private var aiSearchTask: Task<Void, Never>?
    
    /// In-Memory Scores für Best‑of Sortierung (werden bei neuem Lauf überschrieben).
    private var bestOfScoresByID: [UUID: Double] = [:]
    /// UI/Debug Info pro Foto (Score-Balken + Hint). Wird bei neuem Best‑of Lauf überschrieben.
    private var bestOfOverlayByID: [UUID: BestOfOverlayInfo] = [:]
    
    // Persistierter Best‑of Cache: Roh-Qualität pro Datei (damit Best‑of nach Restart sofort sortieren kann).
    // Wir persistieren bewusst NICHT den finalen Score (der ist relativ zum aktuellen Scope), sondern nur den Rohwert + PixelArea.
    private let bestOfQualityDefaultsKey: String = "bestOfQualityCacheV1"
    private let bestOfQualityMaxEntries: Int = 25000
    
    private struct BestOfQualityEntry: Codable {
        let qualityRaw: Double
        let pixelArea: Int
        let mode: String        // "quick" oder "sport"/"portrait"
        let updatedAt: TimeInterval
    }
    
    // MARK: - Lokale Persistenz (Ratings)
    // Wichtig: Ratings sollen *zuverlässig* sein – auch bei RAW-Dateien (Metadaten-Writes sind je nach Format riskant/oft nicht möglich),
    // bei read-only Kontexten (Photos Library/PhotoKit) und in der Sandbox.
    // Daher persistieren wir Ratings grundsätzlich lokal in UserDefaults (und lesen optional Rating aus Metadaten als Fallback).
    private let localRatingsDefaultsKey: String = "localRatingsV1"
    private let localColorTagsDefaultsKey: String = "localColorTagsV1"
    // Version bump: V8 → Aggressivere Gender-Klassifizierung (minStrong=0.20, delta=0.08, prefix(30), Direkt-Match-Boost, Makeup-Hard-Rule)
    private let localAISearchTagsDefaultsKey: String = "localAISearchTagsV8"
    // Legacy: wir laden alte Tags als Fallback, damit Suche nicht auf 0 fällt während Reindex läuft.
    private let legacyAISearchTagsDefaultsKeys: [String] = [
        "localAISearchTagsV7",
        "localAISearchTagsV6",
        "localAISearchTagsV5",
        "localAISearchTagsV4",
        "localAISearchTagsV3",
        "localAISearchTagsV2",
        "localAISearchTagsV1"
    ]
    
    private func isPhotosLibraryContext(_ url: URL) -> Bool {
        if currentFolder?.pathExtension.lowercased() == "photoslibrary" { return true }
        if url.scheme?.lowercased() == PHAssetURL.scheme { return true }
        // Fallback: falls einzelne Items aus einer Photos-Library stammen
        return url.path.lowercased().contains(".photoslibrary/")
    }
    
    private func loadLocalRatings() -> [String: Int] {
        guard let data = UserDefaults.standard.data(forKey: localRatingsDefaultsKey),
              let decoded = try? JSONDecoder().decode([String: Int].self, from: data) else {
            return [:]
        }
        return decoded
    }
    
    private func saveLocalRatings(_ dict: [String: Int]) {
        guard let data = try? JSONEncoder().encode(dict) else { return }
        UserDefaults.standard.set(data, forKey: localRatingsDefaultsKey)
    }
    
    private func loadLocalRating(for url: URL, from dict: [String: Int]? = nil) -> Int {
        let key = url.isFileURL ? url.standardizedFileURL.path : url.absoluteString
        if let dict { return dict[key] ?? 0 }
        return loadLocalRatings()[key] ?? 0
    }
    
    private func saveLocalRating(_ rating: Int, for url: URL) {
        var dict = loadLocalRatings()
        let key = url.isFileURL ? url.standardizedFileURL.path : url.absoluteString
        // Wichtig: wir speichern auch "0" als explizites Override (sonst würde ein vorhandenes Metadaten-Rating nach Reload wieder auftauchen).
        dict[key] = max(0, min(5, rating))
        saveLocalRatings(dict)
    }
    
    // MARK: - Lokale Persistenz (Color Tags)
    
    private func loadLocalColorTags() -> [String: [String]] {
        guard let data = UserDefaults.standard.data(forKey: localColorTagsDefaultsKey),
              let decoded = try? JSONDecoder().decode([String: [String]].self, from: data) else {
            return [:]
        }
        return decoded
    }
    
    private func saveLocalColorTags(_ dict: [String: [String]]) {
        guard let data = try? JSONEncoder().encode(dict) else { return }
        UserDefaults.standard.set(data, forKey: localColorTagsDefaultsKey)
    }
    
    private func loadLocalColorTags(for url: URL, from dict: [String: [String]]? = nil) -> Set<ColorTag> {
        let key = url.isFileURL ? url.standardizedFileURL.path : url.absoluteString
        let raw = dict?[key] ?? loadLocalColorTags()[key] ?? []
        return Set(raw.compactMap { ColorTag(rawValue: $0) })
    }
    
    private func saveLocalColorTags(_ tags: Set<ColorTag>, for url: URL) {
        var dict = loadLocalColorTags()
        let key = url.isFileURL ? url.standardizedFileURL.path : url.absoluteString
        
        if tags.isEmpty {
            dict.removeValue(forKey: key)
        } else {
            dict[key] = tags.map(\.rawValue).sorted()
        }
        saveLocalColorTags(dict)
    }
    
    // MARK: - Lokale Persistenz (AI Search Tags)
    
    private func loadLocalAISearchTags() -> [String: [String]] {
        guard let data = UserDefaults.standard.data(forKey: localAISearchTagsDefaultsKey),
              let decoded = try? JSONDecoder().decode([String: [String]].self, from: data) else {
            return [:]
        }
        return decoded
    }
    
    private func loadLegacyAISearchTags() -> [String: [String]] {
        for key in legacyAISearchTagsDefaultsKeys {
            guard let data = UserDefaults.standard.data(forKey: key),
                  let decoded = try? JSONDecoder().decode([String: [String]].self, from: data) else {
                continue
            }
            if !decoded.isEmpty { return decoded }
        }
        return [:]
    }
    
    private func saveLocalAISearchTags(_ dict: [String: [String]]) {
        guard let data = try? JSONEncoder().encode(dict) else { return }
        UserDefaults.standard.set(data, forKey: localAISearchTagsDefaultsKey)
    }
    
    private func loadLocalAISearchTags(for url: URL, from dict: [String: [String]]? = nil) -> Set<String> {
        let key = url.isFileURL ? url.standardizedFileURL.path : url.absoluteString
        let raw = dict?[key] ?? loadLocalAISearchTags()[key] ?? []
        return Set(raw)
    }
    
    private func loadAISearchTags(for url: URL, current: [String: [String]], legacy: [String: [String]]) -> Set<String> {
        let key = url.isFileURL ? url.standardizedFileURL.path : url.absoluteString
        if let raw = current[key] { return Set(raw) }
        if let raw = legacy[key] { return Set(raw) }
        return []
    }
    
    // MARK: - Lokale Persistenz (Best‑of Qualität Rohwerte)
    
    private func bestOfPersistKey(for url: URL) -> String {
        url.isFileURL ? url.standardizedFileURL.path : url.absoluteString
    }
    
    private func loadBestOfQualityCache() -> [String: BestOfQualityEntry] {
        guard let data = UserDefaults.standard.data(forKey: bestOfQualityDefaultsKey),
              let decoded = try? JSONDecoder().decode([String: BestOfQualityEntry].self, from: data) else {
            return [:]
        }
        return decoded
    }
    
    private func saveBestOfQualityCache(_ dict: [String: BestOfQualityEntry]) {
        guard let data = try? JSONEncoder().encode(dict) else { return }
        UserDefaults.standard.set(data, forKey: bestOfQualityDefaultsKey)
    }
    
    private func pruneBestOfQualityCacheIfNeeded(_ dict: inout [String: BestOfQualityEntry]) {
        let overflow = dict.count - bestOfQualityMaxEntries
        guard overflow > 0 else { return }
        
        // Entferne die ältesten Einträge (LRU-like via updatedAt).
        let oldestKeys = dict
            .sorted { $0.value.updatedAt < $1.value.updatedAt }
            .prefix(overflow)
            .map(\.key)
        
        for k in oldestKeys {
            dict.removeValue(forKey: k)
        }
    }
    
    // MARK: - Security-Scoped Folder Access
    
    private var currentFolderAccessURL: URL?
    private var isAccessingCurrentFolder: Bool = false
    
    private struct LoadedPhotoInfo: Sendable {
        let url: URL
        let rating: Int
        let pickStatus: PickStatus?
        let iptc: IPTCMetadata?
        let edit: EditCatalogService.EditEntry?
        let captureDate: Date?
        let originalFileName: String?
        let pixelWidth: Int?
        let pixelHeight: Int?
    }
    
    // MARK: - Initialization
    
    init() {
        // Lade alle Presets beim Start
        loadExportPresets()
        loadAdjustmentPresets() // Lädt Standard-Presets wenn keine vorhanden
        loadPresetGroups()
        loadUploadTargets()
        loadIPTCTemplates()
        loadSmartCollections()
        loadEditSnapshots()
        loadQuickExportSettings()
        loadExportQueueSettings()

        // Persist edits (non-destructive) whenever UI signals a reprocess.
        registerEditPersistenceObservers()
    }

    // MARK: - Auto + Stil-Profil
    
    /// Baut Auto-Adjustments und legt optional ein Stil-Preset (Delta ggü. Defaults) darüber.
    func buildAutoAdjustmentsForCurrent() async -> PhotoAdjustments? {
        guard let photo = currentPhoto else { return nil }
        return await buildAutoAdjustments(for: photo)
    }
    
    func buildAutoAdjustments(for photo: PhotoItem) async -> PhotoAdjustments? {
        let base = await AutoAdjustmentService.shared.analyzeAndAdjust(photo: photo)
        guard var result = base else { return nil }
        
        // Optional: Style Profile
        let settings = AppSettings.shared
        guard settings.autoUsesStyleProfile, !settings.autoStylePresetID.isEmpty,
              let presetID = UUID(uuidString: settings.autoStylePresetID),
              let preset = adjustmentPresets.first(where: { $0.id == presetID }) else {
            return result
        }
        
        let delta = preset.adjustments.delta(from: PhotoAdjustments())
        result = result.applying(delta)
        return result
    }

    // MARK: - Batch Auto (Auto + Stil‑Profil) auf Auswahl
    
    private var batchAutoTask: Task<Void, Never>? = nil
    
    @MainActor
    func applyAutoToSelection() {
        let targets = photos.filter { selectedPhotoIDs.contains($0.id) }
        guard !targets.isEmpty else { return }
        startBatchAuto(on: targets)
    }
    
    @MainActor
    func cancelBatchAuto() {
        batchAutoTask?.cancel()
        batchAutoTask = nil
        isBatchAutoRunning = false
        batchAutoProgress = 0.0
        batchAutoProcessedCount = 0
        batchAutoTotalCount = 0
        batchAutoCurrentName = ""
        objectWillChange.send()
    }
    
    @MainActor
    private func startBatchAuto(on targets: [PhotoItem]) {
        guard !isBatchAutoRunning else { return }
        
        isBatchAutoRunning = true
        batchAutoTotalCount = targets.count
        batchAutoProcessedCount = 0
        batchAutoProgress = 0.0
        batchAutoCurrentName = ""
        
        // Cancel any previous task just in case
        batchAutoTask?.cancel()
        
        batchAutoTask = Task { [weak self] in
            guard let self else { return }
            
            let total = max(1, targets.count)
            
            for (index, photo) in targets.enumerated() {
                if Task.isCancelled { break }
                
                await MainActor.run {
                    self.batchAutoCurrentName = photo.fileName
                    self.batchAutoProcessedCount = index
                    self.batchAutoProgress = Double(index) / Double(total)
                }
                
                if let adjustments = await self.buildAutoAdjustments(for: photo) {
                    await MainActor.run {
                        self.registerUndoPoint(for: photo)
                        photo.adjustments = adjustments
                        self.persistEditsForPhoto(photo)
                        
                        // Nur aktuelles Foto muss sofort re-rendern
                        if photo.id == self.currentPhotoID {
                            self.triggerReprocess(for: photo)
                        }
                    }
                }
                
                await MainActor.run {
                    self.batchAutoProcessedCount = index + 1
                    self.batchAutoProgress = Double(index + 1) / Double(total)
                }
            }
            
            await MainActor.run {
                self.isBatchAutoRunning = false
                self.batchAutoCurrentName = ""
                self.batchAutoTask = nil
            }
        }
    }

    // MARK: - Quick Export (WIP)
    private enum QuickExportKeys {
        static let presetID = "quickExportPresetID"
        static let directoryPath = "quickExportDirectoryPath"
    }
    
    private func loadQuickExportSettings() {
        // Preset
        if let raw = UserDefaults.standard.string(forKey: QuickExportKeys.presetID),
           let id = UUID(uuidString: raw) {
            quickExportPresetID = id
        }
        
        // Directory
        if let path = UserDefaults.standard.string(forKey: QuickExportKeys.directoryPath) {
            let url = URL(fileURLWithPath: path)
            // Wir versuchen zuerst ein Security-Scoped Bookmark aus den allgemeinen folderBookmarks zu resolven.
            quickExportDirectory = resolvedBookmarkURL(forPath: url.path) ?? url
        }
    }
    
    private func saveQuickExportSettings() {
        UserDefaults.standard.set(quickExportPresetID?.uuidString, forKey: QuickExportKeys.presetID)
        UserDefaults.standard.set(quickExportDirectory?.path, forKey: QuickExportKeys.directoryPath)
    }
    
    // MARK: - Job/Projekt Presets (pro Ordner)
    
    private let folderJobPresetsDefaultsKey: String = "folderJobPresetsV1"
    
    private struct FolderJobPreset: Codable {
        var version: Int = 1
        var updatedAt: TimeInterval = Date().timeIntervalSince1970
        
        // Quick Export
        var quickExportPresetID: String?
        var quickExportDirectoryPath: String?
        
        // Style Profile (Auto + Look)
        var autoUsesStyleProfile: Bool = false
        var autoStylePresetID: String = ""
        
        // Upload filter (subset of upload targets for this job)
        var jobUsesUploadTargetFilter: Bool = false
        var jobUploadTargetIDs: [String] = []
    }
    
    /// Upload‑Ziele, die in Export/Quick Export/Queue berücksichtigt werden sollen – abhängig vom Job‑Preset.
    var effectiveUploadTargetsForExport: [UploadTarget] {
        if hasJobPresetForCurrentFolder, jobUsesUploadTargetFilter {
            return uploadTargets.filter { jobUploadTargetIDs.contains($0.id.uuidString) }
        }
        return uploadTargets
    }
    
    private func folderJobKey(for folderURL: URL) -> String {
        folderURL.standardizedFileURL.path
    }
    
    private func loadFolderJobPresets() -> [String: FolderJobPreset] {
        guard let data = UserDefaults.standard.data(forKey: folderJobPresetsDefaultsKey),
              let decoded = try? JSONDecoder().decode([String: FolderJobPreset].self, from: data) else {
            return [:]
        }
        return decoded
    }
    
    private func saveFolderJobPresets(_ dict: [String: FolderJobPreset]) {
        guard let data = try? JSONEncoder().encode(dict) else { return }
        UserDefaults.standard.set(data, forKey: folderJobPresetsDefaultsKey)
    }
    
    /// Speichert das aktuelle Setup als Job‑Preset für den aktuellen Ordner.
    @MainActor
    func saveJobPresetForCurrentFolder() {
        guard let folder = currentFolder else { return }
        let key = folderJobKey(for: folder)
        var dict = loadFolderJobPresets()
        dict[key] = makeJobPresetSnapshot()
        saveFolderJobPresets(dict)
        hasJobPresetForCurrentFolder = true
    }
    
    /// Löscht das Job‑Preset für den aktuellen Ordner (ohne die aktuellen Settings zu verändern).
    @MainActor
    func deleteJobPresetForCurrentFolder() {
        guard let folder = currentFolder else { return }
        let key = folderJobKey(for: folder)
        var dict = loadFolderJobPresets()
        dict.removeValue(forKey: key)
        saveFolderJobPresets(dict)
        hasJobPresetForCurrentFolder = false
        jobUsesUploadTargetFilter = false
        jobUploadTargetIDs = []
    }
    
    /// Wird beim Ordnerwechsel aufgerufen: lädt das Job‑Preset (falls vorhanden) und wendet es an.
    @MainActor
    private func applyJobPresetIfAvailable(for folderURL: URL) {
        let key = folderJobKey(for: folderURL)
        let dict = loadFolderJobPresets()
        guard let preset = dict[key] else {
            hasJobPresetForCurrentFolder = false
            jobUsesUploadTargetFilter = false
            jobUploadTargetIDs = []
            return
        }
        
        hasJobPresetForCurrentFolder = true
        
        // Quick Export
        if let raw = preset.quickExportPresetID, let id = UUID(uuidString: raw) {
            quickExportPresetID = id
        }
        if let path = preset.quickExportDirectoryPath {
            let url = URL(fileURLWithPath: path)
            quickExportDirectory = resolvedBookmarkURL(forPath: url.path) ?? url
        }
        
        // Style Profile
        let settings = AppSettings.shared
        settings.autoUsesStyleProfile = preset.autoUsesStyleProfile
        settings.autoStylePresetID = preset.autoStylePresetID
        
        // Upload filter
        jobUsesUploadTargetFilter = preset.jobUsesUploadTargetFilter
        jobUploadTargetIDs = Set(preset.jobUploadTargetIDs)
    }
    
    /// Persistiert Änderungen automatisch – aber nur, wenn für den Ordner bereits ein Job‑Preset existiert.
    private func saveJobPresetForCurrentFolderIfExists() {
        guard hasJobPresetForCurrentFolder else { return }
        guard let folder = currentFolder else { return }
        let key = folderJobKey(for: folder)
        var dict = loadFolderJobPresets()
        guard dict[key] != nil else { return }
        dict[key] = makeJobPresetSnapshot()
        saveFolderJobPresets(dict)
    }
    
    private func makeJobPresetSnapshot() -> FolderJobPreset {
        let settings = AppSettings.shared
        var preset = FolderJobPreset()
        preset.updatedAt = Date().timeIntervalSince1970
        
        preset.quickExportPresetID = quickExportPresetID?.uuidString
        preset.quickExportDirectoryPath = quickExportDirectory?.path
        
        preset.autoUsesStyleProfile = settings.autoUsesStyleProfile
        preset.autoStylePresetID = settings.autoStylePresetID
        
        preset.jobUsesUploadTargetFilter = jobUsesUploadTargetFilter
        preset.jobUploadTargetIDs = Array(jobUploadTargetIDs)
        
        return preset
    }
    
    // MARK: - Ingest / Import (SD‑Karte → Job Ordner)
    
    struct IngestOptions: Sendable {
        var includeJPG: Bool = true
        var includeRAW: Bool = true
        var createSubfolders: Bool = true
        /// Nach Import automatisch den JPG‑Ordner öffnen (für schnellen Sport‑Workflow).
        var openJPGAfterIngest: Bool = true
        /// Sicherheits-Default: niemals überschreiben.
        var skipExisting: Bool = true
    }
    
    @MainActor
    func cancelIngestImport() {
        ingestTask?.cancel()
        ingestTask = nil
        isIngestRunning = false
        ingestProgress = 0.0
        ingestProcessedCount = 0
        ingestTotalCount = 0
        ingestCurrentName = ""
        objectWillChange.send()
    }
    
    /// PhotoMechanic‑Style: SD‑Karte → Job Ordner (kopieren). Karte wird NIE gelöscht.
    @MainActor
    func startIngestImport(
        sourceURL: URL,
        destinationParentURL: URL,
        jobName: String,
        options: IngestOptions
    ) {
        guard !isIngestRunning else { return }
        let trimmedJob = jobName.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedJob.isEmpty else { return }
        guard options.includeJPG || options.includeRAW else { return }
        
        isIngestRunning = true
        ingestProgress = 0.0
        ingestProcessedCount = 0
        ingestTotalCount = 0
        ingestCurrentName = "Scanne…"
        
        ingestTask?.cancel()
        
        let source = sourceURL
        let destParent = destinationParentURL
        let opts = options
        
        ingestTask = Task.detached(priority: .userInitiated) { [weak self] in
            guard let self else { return }
            
            let fm = FileManager.default
            
            // Security Scope (Sandbox): Quelle & Ziel während Copy offen halten.
            let srcAccess = source.startAccessingSecurityScopedResource()
            let dstAccess = destParent.startAccessingSecurityScopedResource()
            defer {
                if srcAccess { source.stopAccessingSecurityScopedResource() }
                if dstAccess { destParent.stopAccessingSecurityScopedResource() }
            }
            
            // Job Folder anlegen (unique)
            let jobFolder = await self.uniqueJobFolderURL(parent: destParent, jobName: trimmedJob)
            do {
                try fm.createDirectory(at: jobFolder, withIntermediateDirectories: true)
            } catch {
                print("Ingest: could not create job folder: \(error)")
                await MainActor.run { self.cancelIngestImport() }
                return
            }
            
            let jpgFolder = opts.createSubfolders ? jobFolder.appendingPathComponent("JPG", isDirectory: true) : jobFolder
            let rawFolder = opts.createSubfolders ? jobFolder.appendingPathComponent("RAW", isDirectory: true) : jobFolder
            if opts.createSubfolders {
                try? fm.createDirectory(at: jpgFolder, withIntermediateDirectories: true)
                try? fm.createDirectory(at: rawFolder, withIntermediateDirectories: true)
            }
            
            // Bookmark + Sidebar "Recents"
            await MainActor.run {
                self.saveBookmark(for: jobFolder)
                self.saveBookmark(for: jpgFolder)
                self.saveBookmark(for: rawFolder)
            }
            
            // Scan files
            let files = await self.enumerateIngestFiles(in: source, options: opts)
            let total = files.count
            
            await MainActor.run {
                self.ingestTotalCount = total
                self.ingestProcessedCount = 0
                self.ingestProgress = 0.0
                self.ingestCurrentName = total == 0 ? "Keine Dateien gefunden" : self.ingestCurrentName
            }
            
            var importedJPGCount = 0
            
            if total > 0 {
                for (idx, file) in files.enumerated() {
                    if Task.isCancelled { break }
                    
                    let ext = file.pathExtension.lowercased()
                    let isJpg = await self.isJPGExtension(ext)
                    _ = await self.isRAWExtension(ext)
                    
                    let targetFolder: URL = isJpg ? jpgFolder : rawFolder
                    let targetURL = targetFolder.appendingPathComponent(file.lastPathComponent)
                    
                    do {
                        if opts.skipExisting, fm.fileExists(atPath: targetURL.path) {
                            // skip
                        } else {
                            try fm.createDirectory(at: targetFolder, withIntermediateDirectories: true)
                            try fm.copyItem(at: file, to: targetURL)
                        }
                        if isJpg { importedJPGCount += 1 }
                    } catch {
                        print("Ingest copy failed for \(file.path): \(error)")
                    }
                    
                    // UI throttling: update every ~6 files
                    if idx == total - 1 || idx % 6 == 0 {
                        let processed = idx + 1
                        await MainActor.run {
                            self.ingestProcessedCount = processed
                            self.ingestProgress = Double(processed) / Double(max(1, total))
                            self.ingestCurrentName = file.lastPathComponent
                        }
                    }
                }
            }
            
            await MainActor.run {
                self.isIngestRunning = false
                self.ingestTask = nil
                self.ingestCurrentName = ""
                
                if !Task.isCancelled {
                    self.ingestProgress = 1.0
                }
                
                // Nach Import: Für Sport-Workflow immer JPG-Ordner öffnen (wenn vorhanden), sonst Job Root.
                let openURL: URL = (opts.openJPGAfterIngest && importedJPGCount > 0) ? jpgFolder : jobFolder
                self.addPathToUserDefaultsList(key: "recentFolders", url: openURL, limit: 12)
                NotificationCenter.default.post(name: NSNotification.Name("SidebarFoldersUpdated"), object: nil)
                
                if opts.openJPGAfterIngest {
                    self.loadPhotos(from: openURL)
                }
            }
        }
    }
    
    private func uniqueJobFolderURL(parent: URL, jobName: String) -> URL {
        let fm = FileManager.default
        let base = parent.appendingPathComponent(jobName, isDirectory: true)
        guard fm.fileExists(atPath: base.path) else { return base }
        
        var i = 2
        while true {
            let candidate = parent.appendingPathComponent("\(jobName) (\(i))", isDirectory: true)
            if !fm.fileExists(atPath: candidate.path) {
                return candidate
            }
            i += 1
            if i > 999 { return candidate }
        }
    }
    
    private func enumerateIngestFiles(in folder: URL, options: IngestOptions) -> [URL] {
        let fm = FileManager.default
        let keys: [URLResourceKey] = [.isRegularFileKey, .isDirectoryKey, .nameKey]
        let extsJPG: Set<String> = ["jpg", "jpeg", "heic"]
        let extsRAW: Set<String> = ["cr2", "cr3", "nef", "arw", "raf", "orf", "rw2", "dng", "pef"]
        
        var out: [URL] = []
        out.reserveCapacity(1024)
        
        guard let enumerator = fm.enumerator(
            at: folder,
            includingPropertiesForKeys: keys,
            options: [.skipsHiddenFiles, .skipsPackageDescendants]
        ) else {
            return []
        }
        
        for case let url as URL in enumerator {
            let ext = url.pathExtension.lowercased()
            if ext.isEmpty { continue }
            
            let isJPG = extsJPG.contains(ext)
            let isRAW = extsRAW.contains(ext)
            if isJPG, !options.includeJPG { continue }
            if isRAW, !options.includeRAW { continue }
            if !isJPG && !isRAW { continue }
            
            out.append(url)
        }
        
        // Stable order
        out.sort { $0.lastPathComponent.localizedCaseInsensitiveCompare($1.lastPathComponent) == .orderedAscending }
        return out
    }
    
    private func isJPGExtension(_ ext: String) -> Bool {
        let extsJPG: Set<String> = ["jpg", "jpeg", "heic"]
        return extsJPG.contains(ext)
    }
    
    private func isRAWExtension(_ ext: String) -> Bool {
        let extsRAW: Set<String> = ["cr2", "cr3", "nef", "arw", "raf", "orf", "rw2", "dng", "pef"]
        return extsRAW.contains(ext)
    }
    
    private func addPathToUserDefaultsList(key: String, url: URL, limit: Int) {
        var paths = UserDefaults.standard.stringArray(forKey: key) ?? []
        let standardized = url.standardizedFileURL.path
        paths.removeAll { URL(fileURLWithPath: $0).standardizedFileURL.path == standardized }
        paths.insert(url.path, at: 0)
        if paths.count > limit {
            paths = Array(paths.prefix(limit))
        }
        UserDefaults.standard.set(paths, forKey: key)
    }

    // MARK: - Export Queue Settings (Persistenz)
    
    private enum ExportQueueKeys {
        static let enabled = "exportQueueEnabled"
        static let minRating = "exportQueueMinRating"
        static let presetID = "exportQueuePresetID"
        static let directoryPath = "exportQueueOutputDirectoryPath"
    }
    
    private func loadExportQueueSettings() {
        exportQueueEnabled = UserDefaults.standard.object(forKey: ExportQueueKeys.enabled) as? Bool ?? false
        exportQueueMinRating = UserDefaults.standard.object(forKey: ExportQueueKeys.minRating) as? Int ?? 4
        
        if let raw = UserDefaults.standard.string(forKey: ExportQueueKeys.presetID),
           let id = UUID(uuidString: raw),
           let preset = exportPresets.first(where: { $0.id == id }) {
            exportQueuePreset = preset
        } else {
            exportQueuePreset = nil
        }
        
        if let path = UserDefaults.standard.string(forKey: ExportQueueKeys.directoryPath) {
            let url = URL(fileURLWithPath: path)
            exportQueueOutputDirectory = resolvedBookmarkURL(forPath: url.path) ?? url
        } else {
            exportQueueOutputDirectory = nil
        }
    }
    
    private func saveExportQueueSettings() {
        UserDefaults.standard.set(exportQueueEnabled, forKey: ExportQueueKeys.enabled)
        UserDefaults.standard.set(exportQueueMinRating, forKey: ExportQueueKeys.minRating)
        UserDefaults.standard.set(exportQueuePreset?.id.uuidString, forKey: ExportQueueKeys.presetID)
        UserDefaults.standard.set(exportQueueOutputDirectory?.path, forKey: ExportQueueKeys.directoryPath)
    }
    
    func chooseExportQueueDirectory() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = true
        panel.prompt = "Auswählen"
        panel.message = "Wählen Sie einen Zielordner für die Export‑Queue"
        
        if panel.runModal() == .OK, let url = panel.url {
            saveBookmark(for: url)
            exportQueueOutputDirectory = url
        }
    }
    
    func setExportQueuePreset(_ preset: ExportPreset?) {
        exportQueuePreset = preset
    }
    
    func setQuickExportPreset(_ preset: ExportPreset?) {
        quickExportPresetID = preset?.id
    }
    
    func chooseQuickExportDirectory() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = true
        panel.prompt = "Auswählen"
        panel.message = "Wählen Sie einen Zielordner für Quick Export"
        
        if panel.runModal() == .OK, let url = panel.url {
            saveBookmark(for: url)
            quickExportDirectory = url
        }
    }
    
    @MainActor
    func quickExportCurrent() {
        guard let photo = currentPhoto else { return }
        
        // Wenn kein Preset oder kein Ordner festgelegt, öffne Dialog
        if quickExportPresetID == nil || quickExportDirectory == nil {
            chooseQuickExportSettingsAndExport(photos: [photo])
            return
        }
        
        // Zeige Bestätigungs-Dialog mit Ordner-Anzeige
        confirmQuickExportAndStart(photos: [photo])
    }
    
    @MainActor
    func quickExportSelection() {
        let targets = photos.filter { selectedPhotoIDs.contains($0.id) }
        guard !targets.isEmpty else { return }
        
        // Wenn kein Preset oder kein Ordner festgelegt, öffne Dialog
        if quickExportPresetID == nil || quickExportDirectory == nil {
            chooseQuickExportSettingsAndExport(photos: targets)
            return
        }
        
        // Zeige Bestätigungs-Dialog mit Ordner-Anzeige
        confirmQuickExportAndStart(photos: targets)
    }
    
    /// Redaktion/Delivery: Quick Export aller Picks im aktuellen Scope (Auswahl oder sichtbare Serie).
    @MainActor
    func quickExportPicksInScope() {
        let scope: [PhotoItem] = {
            if selectedPhotoIDs.count > 1 {
                return photos.filter { selectedPhotoIDs.contains($0.id) }
            }
            return filteredPhotos
        }()
        
        let picks = scope.filter { $0.pickStatus == .pick }
        guard !picks.isEmpty else { return }
        
        // Wenn kein Preset oder kein Ordner festgelegt, öffne Dialog
        if quickExportPresetID == nil || quickExportDirectory == nil {
            chooseQuickExportSettingsAndExport(photos: picks)
            return
        }
        
        // Zeige Bestätigungs-Dialog mit Ordner-Anzeige
        confirmQuickExportAndStart(photos: picks)
    }
    
    /// Wählt Preset und Ordner aus und startet dann den Export
    @MainActor
    private func chooseQuickExportSettingsAndExport(photos: [PhotoItem]) {
        // Zuerst Preset auswählen, wenn noch keines festgelegt
        if quickExportPresetID == nil {
            // Öffne Preset-Auswahl-Dialog ("Keine" ist immer verfügbar)
            let alert = NSAlert()
            alert.messageText = "Export Preset wählen"
            alert.informativeText = "Bitte wählen Sie ein Export Preset (oder 'Keine' für Original-Export):"
            alert.alertStyle = .informational
            
            let presetPicker = NSPopUpButton(frame: NSRect(x: 0, y: 0, width: 300, height: 24))
            presetPicker.addItem(withTitle: "Keine (Original-Export)")
            presetPicker.lastItem?.representedObject = nil as ExportPreset?
            presetPicker.addItem(withTitle: "──────────")
            presetPicker.lastItem?.isEnabled = false
            
            for preset in exportPresets {
                presetPicker.addItem(withTitle: preset.name)
                presetPicker.lastItem?.representedObject = preset
            }
            
            alert.accessoryView = presetPicker
            alert.addButton(withTitle: "Weiter")
            alert.addButton(withTitle: "Abbrechen")
            
            let response = alert.runModal()
            if response == .alertFirstButtonReturn {
                if let selectedPreset = presetPicker.selectedItem?.representedObject as? ExportPreset {
                    quickExportPresetID = selectedPreset.id
                } else {
                    // "Keine" wurde gewählt
                    quickExportPresetID = nil
                }
            } else {
                return // User hat abgebrochen
            }
        }
        
        // Dann Ordner auswählen, wenn noch keiner festgelegt
        if quickExportDirectory == nil {
            let panel = NSOpenPanel()
            panel.canChooseFiles = false
            panel.canChooseDirectories = true
            panel.allowsMultipleSelection = false
            panel.canCreateDirectories = true
            panel.prompt = "Exportieren"
            panel.message = "Wählen Sie einen Zielordner für den Export"
            
            panel.begin { [weak self] response in
                guard let self = self else { return }
                if response == .OK, let url = panel.url {
                    self.saveBookmark(for: url)
                    self.quickExportDirectory = url
                    
                    // Starte Export nach Ordner-Auswahl
                    self.quickExportTask?.cancel()
                    self.quickExportTask = Task { [weak self] in
                        await self?.quickExport(photos: photos)
                    }
                }
            }
        } else {
            // Beides ist bereits festgelegt, starte direkt
            quickExportTask?.cancel()
            quickExportTask = Task { [weak self] in
                await self?.quickExport(photos: photos)
            }
        }
    }
    
    @MainActor
    func cancelQuickExport() {
        quickExportTask?.cancel()
        quickExportTask = nil
        isQuickExporting = false
        quickExportProgress = 0.0
    }
    
    /// Zeigt Bestätigungs-Dialog mit Ordner-Anzeige und startet dann den Export
    @MainActor
    private func confirmQuickExportAndStart(photos: [PhotoItem]) {
        guard let directory = quickExportDirectory else {
            chooseQuickExportSettingsAndExport(photos: photos)
            return
        }
        
        // Preset-Name für Anzeige
        let presetName: String = {
            if let presetID = quickExportPresetID,
               let preset = exportPresets.first(where: { $0.id == presetID }) {
                return preset.name
            }
            return "Original"
        }()
        
        let alert = NSAlert()
        alert.messageText = "Quick Export bestätigen"
        alert.informativeText = """
        \(photos.count) Foto\(photos.count == 1 ? "" : "s") werden exportiert.
        
        Preset: \(presetName)
        Zielordner: \(directory.path)
        
        Möchten Sie fortfahren oder den Ordner ändern?
        """
        alert.alertStyle = .informational
        alert.addButton(withTitle: "Exportieren")
        alert.addButton(withTitle: "Ordner ändern")
        alert.addButton(withTitle: "Abbrechen")
        
        let response = alert.runModal()
        
        switch response {
        case .alertFirstButtonReturn:
            // Exportieren
            quickExportTask?.cancel()
            quickExportTask = Task { [weak self] in
                await self?.quickExport(photos: photos)
            }
        case .alertSecondButtonReturn:
            // Ordner ändern
            let panel = NSOpenPanel()
            panel.canChooseFiles = false
            panel.canChooseDirectories = true
            panel.allowsMultipleSelection = false
            panel.canCreateDirectories = true
            panel.prompt = "Auswählen"
            panel.message = "Wählen Sie einen neuen Zielordner für den Export"
            panel.directoryURL = directory
            
            panel.begin { [weak self] response in
                guard let self = self else { return }
                if response == .OK, let url = panel.url {
                    self.saveBookmark(for: url)
                    self.quickExportDirectory = url
                    
                    // Starte Export mit neuem Ordner
                    self.quickExportTask?.cancel()
                    self.quickExportTask = Task { [weak self] in
                        await self?.quickExport(photos: photos)
                    }
                }
            }
        default:
            // Abbrechen - nichts tun
            break
        }
    }
    
    private func quickExport(photos: [PhotoItem]) async {
        guard !photos.isEmpty else { return }
        guard !isQuickExporting else { return }
        
        // Preset (optional - wenn keines gewählt, wird Original exportiert)
        var preset: ExportPreset
        if let presetID = quickExportPresetID,
           let foundPreset = exportPresets.first(where: { $0.id == presetID }) {
            preset = foundPreset
        } else {
            // Original-Export: Keine Größenänderung, Original-Qualität, kein Wasserzeichen
            preset = ExportPreset(
                name: "Original",
                maxDimension: 99999, // Sehr groß, damit keine Größenänderung
                quality: 1.0, // Beste Qualität
                format: .jpeg,
                watermarkSettings: nil,
                uploadTargets: []
            )
        }
        
        // Directory - sollte jetzt immer gesetzt sein (wird vorher abgefragt)
        guard let dir = quickExportDirectory else {
            await MainActor.run {
                showAlert(title: "Quick Export", message: "Bitte zuerst einen Zielordner wählen.")
            }
            return
        }
        
        await MainActor.run {
            isQuickExporting = true
            quickExportProgress = 0.0
        }
        
        let accessGranted = dir.startAccessingSecurityScopedResource()
        defer {
            if accessGranted { dir.stopAccessingSecurityScopedResource() }
        }
        
        do {
            let total = Double(photos.count)
            for (idx, photo) in photos.enumerated() {
                if Task.isCancelled { break }
                let outputURL = uniqueQuickExportURL(for: photo, preset: preset, in: dir)
                try await ExportService.shared.export(
                    photo: photo,
                    preset: preset,
                    to: outputURL,
                    uploadTargets: effectiveUploadTargetsForExport
                ) { progress in
                    DispatchQueue.main.async {
                        // Pro Foto wird ExportService 0..1 liefern; wir mappen auf Batch‑Progress.
                        let base = Double(idx) / total
                        self.quickExportProgress = min(1.0, base + (progress / total))
                    }
                }
            }
            
            await MainActor.run {
                quickExportTask = nil
                isQuickExporting = false
                quickExportProgress = Task.isCancelled ? 0.0 : 1.0
            }
        } catch {
            await MainActor.run {
                quickExportTask = nil
                isQuickExporting = false
                showAlert(title: "Quick Export fehlgeschlagen", message: error.localizedDescription)
            }
        }
    }
    
    private func uniqueQuickExportURL(for photo: PhotoItem, preset: ExportPreset, in directory: URL) -> URL {
        let fileName = buildFileName(for: photo, preset: preset)
        var candidate = directory.appendingPathComponent(fileName)
        
        let fm = FileManager.default
        if !fm.fileExists(atPath: candidate.path) { return candidate }
        
        let base = (fileName as NSString).deletingPathExtension
        let ext = (fileName as NSString).pathExtension
        var i = 2
        while fm.fileExists(atPath: candidate.path) {
            candidate = directory.appendingPathComponent("\(base)-\(i).\(ext)")
            i += 1
        }
        return candidate
    }
    
    private func buildFileName(for photo: PhotoItem, preset: ExportPreset) -> String {
        let settings = AppSettings.shared
        let template = settings.filenameTemplate
        
        let originalName = (photo.fileName as NSString).deletingPathExtension
        let presetName = preset.name
        let rating = "\(photo.rating)"
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd_HH-mm-ss"
        let date = formatter.string(from: Date())
        
        let rendered = template
            .replacingOccurrences(of: "{originalname}", with: originalName)
            .replacingOccurrences(of: "{preset}", with: presetName)
            .replacingOccurrences(of: "{date}", with: date)
            .replacingOccurrences(of: "{rating}", with: rating)
        
        let safe = sanitizeFileName(rendered)
        return "\(safe).\(preset.format.fileExtension)"
    }
    
    private func sanitizeFileName(_ name: String) -> String {
        let invalid = CharacterSet(charactersIn: "/\\?%*|\"<>:")
        let cleaned = name
            .components(separatedBy: invalid)
            .joined(separator: "_")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return cleaned.isEmpty ? "Export" : cleaned
    }
    
    private func resolvedBookmarkURL(forPath path: String) -> URL? {
        guard let bookmarks = UserDefaults.standard.dictionary(forKey: "folderBookmarks"),
              let bookmarkData = bookmarks[path] as? Data else {
            return nil
        }
        var isStale = false
        return try? URL(
            resolvingBookmarkData: bookmarkData,
            options: [.withSecurityScope],
            relativeTo: nil,
            bookmarkDataIsStale: &isStale
        )
    }
    
    private func saveBookmark(for url: URL) {
        do {
            let bookmarkData = try url.bookmarkData(
                options: [.withSecurityScope],
                includingResourceValuesForKeys: nil,
                relativeTo: nil
            )
            var bookmarks = UserDefaults.standard.dictionary(forKey: "folderBookmarks") ?? [:]
            bookmarks[url.path] = bookmarkData
            UserDefaults.standard.set(bookmarks, forKey: "folderBookmarks")
        } catch {
            print("Fehler beim Speichern des Bookmarks: \(error)")
        }
    }
    
    private func showAlert(title: String, message: String) {
        let alert = NSAlert()
        alert.messageText = title
        alert.informativeText = message
        alert.addButton(withTitle: "OK")
        alert.alertStyle = .warning
        alert.runModal()
    }
    
    deinit {
        stopAccessingCurrentFolderIfNeeded()
    }
    
    private func stopAccessingCurrentFolderIfNeeded() {
        if isAccessingCurrentFolder, let url = currentFolderAccessURL {
            url.stopAccessingSecurityScopedResource()
        }
        isAccessingCurrentFolder = false
        currentFolderAccessURL = nil
    }
    
    func setup(uiState: UIState) {
        self.uiState = uiState
        
        // Listen for filter changes from UIState
        uiState.$ratingFilter
            .debounce(for: .milliseconds(100), scheduler: RunLoop.main)
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)
        
        uiState.$pickStatusFilter
            .debounce(for: .milliseconds(100), scheduler: RunLoop.main)
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)
        
        uiState.$searchQuery
            .debounce(for: .milliseconds(150), scheduler: RunLoop.main)
            .sink { [weak self] _ in
                guard let self else { return }
                if uiState.aiSearchEnabled {
                    self.startAISearchIndexIfNeeded()
                }
                self.updateFilteredPhotos()
            }
            .store(in: &cancellables)

        // Also update when the base photos array changes
        $photos
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)

        // Quick Collection filter
        uiState.$showQuickCollectionOnly
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)

        // Color Tag filter
        uiState.$colorTagFilter
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)
        
        // Smart Collection filter
        uiState.$activeSmartCollectionID
            .sink { [weak self] _ in
                self?.updateFilteredPhotos()
            }
            .store(in: &cancellables)
        
        // Sortierung
        uiState.$sortMode
            .sink { [weak self] mode in
                guard let self else { return }
                
                // Wenn der User nach Best‑of sortiert, starte (falls nötig) die Analyse im Hintergrund.
                if mode == .bestOfDesc || mode == .bestOfAsc {
                    self.startBestOfIfNeeded(desiredSortMode: mode)
                }
                
                self.updateFilteredPhotos()
            }
            .store(in: &cancellables)
        
        uiState.$aiSearchEnabled
            .sink { [weak self] enabled in
                guard let self else { return }
                if enabled {
                    self.startAISearchIndexIfNeeded()
                } else {
                    self.cancelAISearchIndex()
                }
                self.updateFilteredPhotos()
            }
            .store(in: &cancellables)

        // Selection mode: when disabled, keep a single active selection (safer for beginners).
        uiState.$selectionMode
            .sink { [weak self] enabled in
                guard let self else { return }
                guard !enabled else { return }
                if let current = self.currentPhotoID {
                    self.selectedPhotoIDs = [current]
                }
            }
            .store(in: &cancellables)
        
        // Job‑Preset Persistenz ist bewusst manuell (Speichern/Aktualisieren), damit nichts "aus Versehen" überschrieben wird.
    }
    
    // MARK: - Filtering
    
    private func updateFilteredPhotos() {
        guard let uiState = uiState else {
            self.filteredPhotos = self.photos
            return
        }
        
        var newFilteredPhotos = photos
        
        // Smart Collection Filter (zuerst, damit Kriterien wie "hasAdjustments" etc. funktionieren)
        if let activeID = uiState.activeSmartCollectionID,
           let collection = smartCollections.first(where: { $0.id == activeID }) {
            newFilteredPhotos = newFilteredPhotos.filter { collection.matches($0) }
        }
        
        // Textsuche (Dateiname, Caption, Keywords)
        let q = uiState.searchQuery.trimmingCharacters(in: .whitespacesAndNewlines)
        if !q.isEmpty {
            newFilteredPhotos = newFilteredPhotos.filter { matchesSearch($0, query: q) }
        }
        
        // Rating Filter
        if let rating = uiState.ratingFilter {
            newFilteredPhotos = newFilteredPhotos.filter { $0.rating == rating }
        }
        
        // Pick Status Filter
        if let pickStatus = uiState.pickStatusFilter {
            newFilteredPhotos = newFilteredPhotos.filter { $0.pickStatus == pickStatus }
        }
        
        // Quick Collection Filter
        if uiState.showQuickCollectionOnly {
            newFilteredPhotos = newFilteredPhotos.filter { $0.isInQuickCollection }
        }
        
        // Color Tag Filter
        if let colorTag = uiState.colorTagFilter {
            newFilteredPhotos = newFilteredPhotos.filter { $0.colorTags.contains(colorTag) }
        }
        
        // EXIF Filters
        // Note: EXIF data is loaded lazily via LensProfileService (which caches results)
        // Filtering will work once EXIF data is loaded
        if let cameraMake = uiState.exifCameraMakeFilter, !cameraMake.isEmpty {
            newFilteredPhotos = newFilteredPhotos.filter { photo in
                guard let meta = photo.exifMeta, let make = meta.cameraMake else { return false }
                return make.localizedCaseInsensitiveContains(cameraMake)
            }
        }
        
        if let cameraModel = uiState.exifCameraModelFilter, !cameraModel.isEmpty {
            newFilteredPhotos = newFilteredPhotos.filter { photo in
                guard let meta = photo.exifMeta, let model = meta.cameraModel else { return false }
                return model.localizedCaseInsensitiveContains(cameraModel)
            }
        }
        
        if let lensModel = uiState.exifLensModelFilter, !lensModel.isEmpty {
            newFilteredPhotos = newFilteredPhotos.filter { photo in
                guard let meta = photo.exifMeta, let lens = meta.lensModel else { return false }
                return lens.localizedCaseInsensitiveContains(lensModel)
            }
        }
        
        if let minFL = uiState.exifFocalLengthMinFilter {
            newFilteredPhotos = newFilteredPhotos.filter { photo in
                guard let meta = photo.exifMeta, let fl = meta.focalLengthMM else { return false }
                return fl >= minFL
            }
        }
        
        if let maxFL = uiState.exifFocalLengthMaxFilter {
            newFilteredPhotos = newFilteredPhotos.filter { photo in
                guard let meta = photo.exifMeta, let fl = meta.focalLengthMM else { return false }
                return fl <= maxFL
            }
        }
        
        // ISO Filter
        if let minISO = uiState.exifISOMinFilter {
            newFilteredPhotos = newFilteredPhotos.filter { photo in
                guard let meta = photo.exifMeta, let iso = meta.isoSpeed else { return false }
                return iso >= minISO
            }
        }
        
        if let maxISO = uiState.exifISOMaxFilter {
            newFilteredPhotos = newFilteredPhotos.filter { photo in
                guard let meta = photo.exifMeta, let iso = meta.isoSpeed else { return false }
                return iso <= maxISO
            }
        }
        
        // Aperture Filter
        if let minAperture = uiState.exifApertureMinFilter {
            newFilteredPhotos = newFilteredPhotos.filter { photo in
                guard let meta = photo.exifMeta, let aperture = meta.apertureValue else { return false }
                return aperture >= minAperture
            }
        }
        
        if let maxAperture = uiState.exifApertureMaxFilter {
            newFilteredPhotos = newFilteredPhotos.filter { photo in
                guard let meta = photo.exifMeta, let aperture = meta.apertureValue else { return false }
                return aperture <= maxAperture
            }
        }
        
        // Shutter Speed Filter (als Double in Sekunden)
        if let minShutter = uiState.exifShutterSpeedMinFilter {
            newFilteredPhotos = newFilteredPhotos.filter { photo in
                guard let meta = photo.exifMeta, let shutter = meta.shutterSpeed else { return false }
                return shutter >= minShutter
            }
        }
        
        if let maxShutter = uiState.exifShutterSpeedMaxFilter {
            newFilteredPhotos = newFilteredPhotos.filter { photo in
                guard let meta = photo.exifMeta, let shutter = meta.shutterSpeed else { return false }
                return shutter <= maxShutter
            }
        }
        
        // Sortierung (UI‑umschaltbar)
        newFilteredPhotos = sortPhotos(newFilteredPhotos, mode: uiState.sortMode)
        
        self.filteredPhotos = newFilteredPhotos
    }

    private func sortPhotos(_ list: [PhotoItem], mode: PhotoSortMode) -> [PhotoItem] {
        func tiebreak(_ a: PhotoItem, _ b: PhotoItem) -> Bool {
            let aName = a.url.lastPathComponent
            let bName = b.url.lastPathComponent
            if aName != bName { return aName < bName }
            return a.virtualCopyNumber < b.virtualCopyNumber
        }
        
        func fileSequenceNumber(_ p: PhotoItem) -> Int? {
            let base = (p.url.lastPathComponent as NSString).deletingPathExtension
            // Nimm die letzte Ziffernfolge (IMG_01234 → 1234)
            var digits = ""
            digits.reserveCapacity(8)
            for ch in base.reversed() {
                if ch.isNumber {
                    digits.append(ch)
                } else {
                    break
                }
            }
            guard !digits.isEmpty else { return nil }
            let numStr = String(digits.reversed())
            return Int(numStr)
        }
        
        func fileTiebreak(_ a: PhotoItem, _ b: PhotoItem, descending: Bool) -> Bool {
            if let na = fileSequenceNumber(a), let nb = fileSequenceNumber(b), na != nb {
                return descending ? (na > nb) : (na < nb)
            }
            let aName = a.url.lastPathComponent
            let bName = b.url.lastPathComponent
            if aName != bName { return descending ? (aName > bName) : (aName < bName) }
            return a.virtualCopyNumber < b.virtualCopyNumber
        }
        
        func pixelArea(_ p: PhotoItem) -> Int {
            let w = max(0, p.pixelWidth ?? 0)
            let h = max(0, p.pixelHeight ?? 0)
            return w * h
        }
        
        func pickRank(_ p: PhotoItem) -> Int {
            // Lightroom-like: Picks zuerst, dann Unflagged, Rejects immer ganz am Ende.
            switch p.pickStatus {
            case .pick: return 0
            case .unflagged: return 1
            case .reject: return 2
            }
        }
        
        switch mode {
        case .captureDateDesc:
            return list.sorted { a, b in
                let da = a.iptcMetadata?.date ?? Date.distantPast
                let db = b.iptcMetadata?.date ?? Date.distantPast
                if da != db { return da > db }
                // In Serien (Sport) haben viele Bilder identische Sekunden → file sequence als tie‑break (neueste zuerst).
                return fileTiebreak(a, b, descending: true)
            }
        case .captureDateAsc:
            return list.sorted { a, b in
                // Wichtig: fehlende Dates sollen NICHT als "sehr alt" oben landen.
                // Wir behandeln nil als "unknown" und sortieren sie nach hinten.
                let da = a.iptcMetadata?.date ?? Date.distantFuture
                let db = b.iptcMetadata?.date ?? Date.distantFuture
                if da != db { return da < db }
                return fileTiebreak(a, b, descending: false)
            }
        case .fileNameAsc:
            return list.sorted { a, b in
                return tiebreak(a, b)
            }
        case .ratingDesc:
            return list.sorted { a, b in
                if a.rating != b.rating { return a.rating > b.rating }
                return tiebreak(a, b)
            }
        case .ratingAsc:
            return list.sorted { a, b in
                if a.rating != b.rating { return a.rating < b.rating }
                return tiebreak(a, b)
            }
        case .resolutionDesc:
            return list.sorted { a, b in
                let aa = pixelArea(a)
                let bb = pixelArea(b)
                if aa != bb { return aa > bb }
                let da = a.iptcMetadata?.date ?? Date.distantPast
                let db = b.iptcMetadata?.date ?? Date.distantPast
                if da != db { return da > db }
                return tiebreak(a, b)
            }
        case .resolutionAsc:
            return list.sorted { a, b in
                let aa = pixelArea(a)
                let bb = pixelArea(b)
                if aa != bb { return aa < bb }
                let da = a.iptcMetadata?.date ?? Date.distantPast
                let db = b.iptcMetadata?.date ?? Date.distantPast
                if da != db { return da < db }
                return tiebreak(a, b)
            }
        case .bestOfDesc:
            return list.sorted { a, b in
                let ra = pickRank(a)
                let rb = pickRank(b)
                if ra != rb { return ra < rb }
                
                let sa = bestOfScoresByID[a.id]
                let sb = bestOfScoresByID[b.id]
                
                if let sa, let sb, sa != sb { return sa > sb }
                if sa != nil, sb == nil { return true }
                if sa == nil, sb != nil { return false }
                
                // Fallback: stabil bleiben, solange Scores fehlen.
                let aa = pixelArea(a)
                let bb = pixelArea(b)
                if aa != bb { return aa > bb }
                let da = a.iptcMetadata?.date ?? Date.distantPast
                let db = b.iptcMetadata?.date ?? Date.distantPast
                if da != db { return da > db }
                return tiebreak(a, b)
            }
        case .bestOfAsc:
            return list.sorted { a, b in
                let ra = pickRank(a)
                let rb = pickRank(b)
                if ra != rb { return ra < rb }
                
                let sa = bestOfScoresByID[a.id]
                let sb = bestOfScoresByID[b.id]
                
                if let sa, let sb, sa != sb { return sa < sb }
                // Unknown scores always go to the end (stable while computing)
                if sa != nil, sb == nil { return true }
                if sa == nil, sb != nil { return false }
                
                let aa = pixelArea(a)
                let bb = pixelArea(b)
                if aa != bb { return aa < bb }
                let da = a.iptcMetadata?.date ?? Date.distantPast
                let db = b.iptcMetadata?.date ?? Date.distantPast
                if da != db { return da < db }
                return tiebreak(a, b)
            }
        }
    }
    
    // MARK: - Best‑of Overlay/Inspector
    
    private var isBestOfSortActive: Bool {
        guard let mode = uiState?.sortMode else { return false }
        return mode == .bestOfDesc || mode == .bestOfAsc
    }
    
    /// Best‑of UI Info nur anzeigen, wenn Best‑of Sort aktiv ist (oder Best‑of gerade läuft).
    func bestOfOverlayInfo(for photoID: UUID) -> BestOfOverlayInfo? {
        guard isBestOfRunning || isBestOfSortActive else { return nil }
        return bestOfOverlayByID[photoID]
    }
    
    private func matchesSearch(_ photo: PhotoItem, query: String) -> Bool {
        let trimmed = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return true }
        
        // AND-Search über Tokens (mit Synonymen pro Token → OR innerhalb der Gruppe)
        let tokens = trimmed
            .split(whereSeparator: { $0.isWhitespace })
            .map(String.init)
            .map(SearchNormalization.normalizeToken)
            .filter { !$0.isEmpty }
        
        if tokens.isEmpty { return true }

        // Performance: pro Foto gibt es einen gecachten/normalisierten Search-Index.
        let haystack = photo.searchIndex
        
        let groups: [[String]] = tokens.map { SearchSynonyms.alternatives(for: $0) }
        return groups.allSatisfy { group in
            group.contains { alt in
                // Wortgrenzen-Match: verhindert z.B. male∈female oder man∈woman/human
                let needle = " \(alt) "
                return haystack.contains(needle)
            }
        }
    }
    
    // MARK: - Folder Management
    
    @Published var isLoadingPhotos: Bool = false
    @Published var loadingProgress: Double = 0.0
    
    @MainActor
    func loadPhotos(from folderURL: URL) {
        // Fotos-Mediathek ist durch macOS Privacy geschützt. Wir triggern explizit die Photos-Permission,
        // damit das Einlesen nicht stillschweigend leer bleibt.
        let isPhotosLibraryFolder = folderURL.pathExtension.lowercased() == "photoslibrary"
        if isPhotosLibraryFolder {
            let current = PHPhotoLibrary.authorizationStatus(for: .readWrite)
            if current == .notDetermined {
                isLoadingPhotos = true
                loadingProgress = 0.0
                Task { @MainActor in
                    let status = await requestPhotosLibraryAuthorization()
                    if status == .authorized || status == .limited {
                        self.loadPhotos(from: folderURL)
                    } else {
                        self.isLoadingPhotos = false
                        self.loadingProgress = 0.0
                        self.photos = []
                        self.currentPhotoID = nil
                        self.selectedPhotoIDs = []
                        self.updateFilteredPhotos()
                        self.showPhotosPermissionAlert()
                    }
                }
                return
            }
            if !(current == .authorized || current == .limited) {
                showPhotosPermissionAlert()
                return
            }
        }
        
        // Neuer Ordner → Best‑of state zurücksetzen (keine alten Scores/Tasks weiterverwenden).
        cancelBestOf()
        bestOfScoresByID = [:]
        bestOfOverlayByID = [:]
        cancelAISearchIndex()

        // Prüfe ob Ordner existiert und zugänglich ist
        // Für Photos Library verwenden wir PhotoKit – die Paket-Struktur kann in der Sandbox "Operation not permitted" liefern,
        // obwohl PhotoKit Zugriff hat. Daher hier nicht hart abbrechen.
        let fileManager = FileManager.default
        var isDirectory: ObjCBool = false
        if !isPhotosLibraryFolder {
            guard fileManager.fileExists(atPath: folderURL.path, isDirectory: &isDirectory),
                  isDirectory.boolValue else {
                print("Ordner existiert nicht oder ist nicht zugänglich: \(folderURL.path)")
                return
            }
        }
        
        // Wenn wir den Ordner wechseln: alte Security-Scope schließen & Caches leeren.
        // Wichtig: startAccessingSecurityScopedResource() ist referenzgezählt — bei erneutem Laden desselben Ordners
        // dürfen wir nicht blind erneut starten, sonst "leaken" wir die Referenzen.
        let isSameFolderAndAlreadyAccessing = (currentFolderAccessURL?.path == folderURL.path && isAccessingCurrentFolder)
        if !isSameFolderAndAlreadyAccessing {
            stopAccessingCurrentFolderIfNeeded()
            Task { @MainActor in
                SmartImageLoader.shared.clearCache()
            }
            
            // Security-Scoped Resource: während der Nutzung des Ordners offen halten
            currentFolderAccessURL = folderURL
            isAccessingCurrentFolder = folderURL.startAccessingSecurityScopedResource()
        }
        
        currentFolder = folderURL
        // Job‑Preset (pro Ordner) anwenden – muss synchron passieren, damit keine Settings vom vorherigen Ordner "leaken".
        applyJobPresetIfAvailable(for: folderURL)
        isLoadingPhotos = true
        loadingProgress = 0.0
        photos = [] // Leere zuerst für sofortiges UI-Update

        // Settings/Flags einmal capturen (für Concurrency/Sandbox)
        let shouldSearchSubfolders = AppSettings.shared.searchSubfolders
        let isPhotosLibrary = folderURL.pathExtension.lowercased() == "photoslibrary"
        // Ratings werden grundsätzlich lokal persistiert (damit sie auch bei RAW/read-only zuverlässig bleiben).
        let localRatingsSnapshot: [String: Int] = loadLocalRatings()
        let localColorTagsSnapshot: [String: [String]] = loadLocalColorTags()
        let localAISearchTagsSnapshot: [String: [String]] = loadLocalAISearchTags()
        let legacyAISearchTagsSnapshot: [String: [String]] = loadLegacyAISearchTags()
        let scanCandidates: [URL] = {
            guard isPhotosLibrary else { return [folderURL] }
            // Photos.app Library ist ein Package. Die Originale liegen üblicherweise unter "originals" (neu) oder "Masters" (alt).
            // Wichtig: fileExists kann in Sandbox/Permissions false liefern. Daher probieren wir mehrere Kandidaten.
            return [
                folderURL.appendingPathComponent("originals"),
                folderURL.appendingPathComponent("Masters"),
                // Fallback: "resources" enthält bei iCloud "Optimierter Speicher" oft nur Proxies/Derivate – aber damit sind zumindest alle Assets sichtbar.
                folderURL.appendingPathComponent("resources"),
                folderURL
            ]
        }()

        // Photos Library: NICHT den Package-Inhalt scannen (führt zu Duplikaten/gelöschten Medien/verschiedenen Qualitätsstufen).
        // Stattdessen PhotoKit verwenden → 1 Asset = 1 Foto, keine Videos, gelöschte verschwinden automatisch.
        if isPhotosLibrary {
            Task.detached(priority: .userInitiated) {
                let fetchOptions = PHFetchOptions()
                fetchOptions.includeHiddenAssets = false
                
                // Fetch only images (no videos)
                let assets = PHAsset.fetchAssets(with: .image, options: fetchOptions)
                let total = assets.count
                
                let editSnapshot = await EditCatalogService.shared.snapshot()
                var loadedInfos: [LoadedPhotoInfo] = []
                loadedInfos.reserveCapacity(total)
                
                for idx in 0..<total {
                    let asset = assets.object(at: idx)
                    let url = PHAssetURL.url(forLocalIdentifier: asset.localIdentifier)
                    
                    // PhotoKit: nur lokales Rating (keine File-Metadaten)
                    let rating = localRatingsSnapshot[url.absoluteString] ?? 0
                    
                    let date = asset.creationDate ?? asset.modificationDate
                    let iptc = IPTCMetadata(date: date)
                    
                    // Best effort filename (für UI)
                    let resources = PHAssetResource.assetResources(for: asset)
                    let fileName = resources.first(where: { r in
                        switch r.type {
                        case .photo, .fullSizePhoto, .alternatePhoto:
                            return true
                        default:
                            return false
                        }
                    })?.originalFilename ?? resources.first?.originalFilename
                    
                    // Pick Status: aus XMP laden (Lightroom-Style: Pick=1, Reject=-1, Unflagged=0)
                    let pickStatus: PickStatus? = {
                        if let pickStatusValue = self.ratingService.loadPickStatus(from: url) {
                            switch pickStatusValue {
                            case 1: return .pick
                            case -1: return .reject
                            case 0: return .unflagged
                            default: return nil // Normale Ratings (2-5) sind kein Pick Status
                            }
                        }
                        return nil
                    }()
                    
                    let edit = editSnapshot[url.absoluteString]
                    loadedInfos.append(
                        LoadedPhotoInfo(
                            url: url,
                            rating: rating,
                            pickStatus: pickStatus,
                            iptc: iptc,
                            edit: edit,
                            captureDate: date,
                            originalFileName: fileName,
                            pixelWidth: asset.pixelWidth > 0 ? asset.pixelWidth : nil,
                            pixelHeight: asset.pixelHeight > 0 ? asset.pixelHeight : nil
                        )
                    )
                    
                    if idx % 200 == 0 || idx == total - 1 {
                        let progress = total > 0 ? Double(idx + 1) / Double(total) : 1.0
                        DispatchQueue.main.async {
                            self.loadingProgress = progress
                        }
                    }
                }
                
                // Sortiere initial nach Aufnahmedatum (neueste zuerst). UI-Sortierung greift danach sowieso auf filteredPhotos.
                let sortedInfos = loadedInfos.sorted { a, b in
                    let da = a.captureDate ?? Date.distantPast
                    let db = b.captureDate ?? Date.distantPast
                    if da != db { return da > db }
                    return a.originalFileName ?? a.url.absoluteString < (b.originalFileName ?? b.url.absoluteString)
                }
                
                await MainActor.run {
                    func baseKey(for url: URL) -> String {
                        url.isFileURL ? url.standardizedFileURL.path : url.absoluteString
                    }
                    
                    // 1) Masters
                    var loadedPhotos: [PhotoItem] = []
                    var photosByKey: [String: PhotoItem] = [:]
                    loadedPhotos.reserveCapacity(sortedInfos.count)
                    
                    for info in sortedInfos {
                        let photo = PhotoItem(
                            url: info.url,
                            rating: info.rating,
                            originalFileName: info.originalFileName,
                            pixelWidth: info.pixelWidth,
                            pixelHeight: info.pixelHeight
                        )
                        photo.iptcMetadata = info.iptc
                        if let pickStatus = info.pickStatus {
                            photo.pickStatus = pickStatus
                        }
                        photo.colorTags = self.loadLocalColorTags(for: info.url, from: localColorTagsSnapshot)
                        photo.textTags = self.loadLocalAISearchTags(for: info.url, from: localAISearchTagsSnapshot)
                        if let edit = info.edit {
                            photo.adjustments = edit.adjustments
                            photo.localMasks = edit.localMasks
                            photo.lensProfileSettings = edit.lensProfileSettings
                            photo.cropRect = edit.cropRect?.cgRect
                            photo.rotation = edit.rotation
                            photo.isMaster = edit.isMaster
                            photo.masterID = edit.masterID.flatMap { UUID(uuidString: $0) }
                            photo.virtualCopyNumber = edit.virtualCopyNumber
                        }
                        loadedPhotos.append(photo)
                        photosByKey[baseKey(for: info.url)] = photo
                    }
                    
                    // 2) Virtual Copies aus Katalog
                    for (key, edit) in editSnapshot {
                        guard key.contains("#"), !edit.isMaster else { continue }
                        let parts = key.split(separator: "#")
                        guard parts.count == 2,
                              let photoIDStr = parts.last,
                              let photoID = UUID(uuidString: String(photoIDStr)) else { continue }
                        
                        let base = String(parts[0])
                        guard let masterPhoto = photosByKey[base] else { continue }
                        
                        let virtualCopy = PhotoItem(
                            url: masterPhoto.url,
                            rating: masterPhoto.rating,
                            id: photoID,
                            originalFileName: masterPhoto.originalFileName,
                            pixelWidth: masterPhoto.pixelWidth,
                            pixelHeight: masterPhoto.pixelHeight
                        )
                        virtualCopy.adjustments = edit.adjustments
                        virtualCopy.localMasks = edit.localMasks
                        virtualCopy.lensProfileSettings = edit.lensProfileSettings
                        virtualCopy.cropRect = edit.cropRect?.cgRect
                        virtualCopy.rotation = edit.rotation
                        virtualCopy.isMaster = false
                        virtualCopy.masterID = edit.masterID.flatMap { UUID(uuidString: $0) }
                        virtualCopy.virtualCopyNumber = edit.virtualCopyNumber
                        virtualCopy.iptcMetadata = masterPhoto.iptcMetadata
                        virtualCopy.textTags = masterPhoto.textTags
                        virtualCopy.colorTags = masterPhoto.colorTags
                        virtualCopy.pickStatus = masterPhoto.pickStatus
                        loadedPhotos.append(virtualCopy)
                    }
                    
                    // Sort: CaptureDate (neueste) + VirtualCopyNumber
                    loadedPhotos.sort { a, b in
                        let da = a.iptcMetadata?.date ?? Date.distantPast
                        let db = b.iptcMetadata?.date ?? Date.distantPast
                        if da != db { return da > db }
                        let aName = a.fileName
                        let bName = b.fileName
                        if aName != bName { return aName < bName }
                        return a.virtualCopyNumber < b.virtualCopyNumber
                    }
                    
                    self.photos = loadedPhotos
                    self.isLoadingPhotos = false
                    self.loadingProgress = 1.0
                    
                    self.loadQuickCollection()
                    print("✅ \(loadedPhotos.count) Photos (PhotoKit) geladen")
                    
                    self.updateFilteredPhotos()
                    
                    if let firstPhoto = self.filteredPhotos.first {
                        self.currentPhotoID = firstPhoto.id
                        self.selectedPhotoIDs = [firstPhoto.id]
                    } else {
                        self.currentPhotoID = nil
                        self.selectedPhotoIDs = []
                    }
                    
                    // Wenn AI Suche aktiv ist, Index für das neue Set anstossen (best-effort).
                    if self.uiState?.aiSearchEnabled == true {
                        self.startAISearchIndexIfNeeded()
                    }
                    
                    // EXIF-Daten im Hintergrund laden (für Filter-Menü)
                    self.loadAllExifMetadata()
                }
            }
            return
        }
        
        Task.detached(priority: .userInitiated) {
            let fileManager = FileManager.default
            // NOTE: "data" ist KEIN Bildformat → führt in Photos-Libraries zu False-Positives (z.B. Video/DB-Blobs).
            let imageExtensions: Set<String> = [
                "jpg", "jpeg", "png", "heic", "heif", "tiff", "tif",
                "raw", "cr2", "cr3", "nef", "orf", "sr2", "arw", "dng",
                "raf", "rw2", "pef", "srw", "3fr", "mef", "mos",
                "ari", "bay", "crw", "cap", "dcs", "dcr",
                "drf", "eip", "erf", "fff", "iiq", "k25", "kdc",
                "mdc", "mrw", "nrw", "obm", "ptx", "pxn", "r3d",
                "raw", "rwl", "rwz", "sr2", "srf", "srw", "x3f"
            ]
            
            var allFiles: [URL] = []

            // Unterordner optional durchsuchen (Einstellung) + Photos-Library immer rekursiv
            let recursiveScan = shouldSearchSubfolders || isPhotosLibrary
            if recursiveScan {
                let keys: [URLResourceKey] = [.isRegularFileKey, .isDirectoryKey, .isPackageKey]
                
                func scan(_ base: URL) -> Set<URL> {
                    guard let enumerator = fileManager.enumerator(
                        at: base,
                        includingPropertiesForKeys: keys,
                        options: [.skipsHiddenFiles],
                        errorHandler: nil
                    ) else {
                        return []
                    }
                    
                    var collected = Set<URL>()
                    
                    for case let url as URL in enumerator {
                        guard let values = try? url.resourceValues(forKeys: Set(keys)) else { continue }
                        
                        if values.isDirectory == true {
                            // In normalen Ordnern Packages überspringen (z.B. *.app, *.photoslibrary)
                            if !isPhotosLibrary, values.isPackage == true {
                                enumerator.skipDescendants()
                            }
                            continue
                        }
                        
                        guard values.isRegularFile == true else { continue }
                        
                        // Photos Library: Cache/DB Pfade überspringen (aber Derivatives/Proxies NICHT hart ausschliessen,
                        // da bei iCloud "Optimierter Speicher" oft nur diese lokal vorhanden sind).
                        if isPhotosLibrary, base.lastPathComponent.lowercased() == "resources" {
                            let p = url.path.lowercased()
                            if p.contains("/thumbnails/") || p.contains("/caches/") || p.contains("/private/") || p.contains("/database/") {
                                continue
                            }
                        }
                        
                        let ext = url.pathExtension.lowercased()
                        if imageExtensions.contains(ext) {
                            collected.insert(url)
                        }
                    }
                    
                    return collected
                }
                
                if isPhotosLibrary {
                    // WICHTIG: Nur EINE Quelle wählen (sonst erscheinen viele Bilder doppelt/dreifach),
                    // aber nicht blind die erste "nicht-leere" nehmen: bei iCloud/Optimierung kann "originals" nur einen Bruchteil enthalten.
                    let minAcceptableCount = 300
                    var best: Set<URL> = []
                    var bestName: String = ""
                    
                    for base in scanCandidates {
                        let found = scan(base)
                        if found.count > best.count {
                            best = found
                            bestName = base.lastPathComponent
                        }
                        
                        // Early accept: Sobald eine der typischen Quellen "gross genug" ist, stoppen wir.
                        let last = base.lastPathComponent.lowercased()
                        if (last == "resources" || last == "originals" || last == "masters"), found.count >= minAcceptableCount {
                            best = found
                            bestName = base.lastPathComponent
                            break
                        }
                    }
                    
                    allFiles = Array(best)
                    print("📸 Photos Library Scan: \(allFiles.count) Dateien (Quelle: \(bestName.isEmpty ? "?" : bestName))")
                } else {
                    allFiles = Array(scan(folderURL))
                }
            } else {
                // Nur direkte Dateien im Ordner (nicht rekursiv)
                do {
                    let contents = try fileManager.contentsOfDirectory(
                        at: folderURL,
                        includingPropertiesForKeys: [.isRegularFileKey, .contentTypeKey],
                        options: [.skipsHiddenFiles]
                    )
                    
                    for fileURL in contents {
                        guard let resourceValues = try? fileURL.resourceValues(forKeys: [.isRegularFileKey]),
                              resourceValues.isRegularFile == true else {
                            continue
                        }
                        
                        let ext = fileURL.pathExtension.lowercased()
                        if imageExtensions.contains(ext) {
                            allFiles.append(fileURL)
                        }
                    }
                } catch {
                    print("⚠️ Fehler beim Laden des Ordners: \(error.localizedDescription)")
                }
            }

            // Dedupe (nur Pfade) + stabil sortieren (finale Sortierung kommt später nach Capture Date)
            allFiles = Array(Set(allFiles))

            if !isPhotosLibrary {
                print("📸 Gefundene Bilder: \(allFiles.count) in \(folderURL.path)")
            }

            // Services lokal (keine MainActor-Abhängigkeiten über `self` im Background)
            let ratingService = RatingPersistenceService.shared
            let metadataService = IPTCMetadataService.shared
            let editSnapshot = await EditCatalogService.shared.snapshot()

            // MARK: - Photos Library: Filter (keine Videos) + Dedupe (UniqueID → beste Variante)
            struct ScanCandidate: Sendable {
                let url: URL
                let iptc: IPTCMetadata?
                let captureDate: Date?
                let uniqueID: String?
                let pixelWidth: Int?
                let pixelHeight: Int?
                let pixelArea: Int
                let fileSize: Int
                let sourceRank: Int
                let extRank: Int
            }
            
            func extRank(for url: URL) -> Int {
                let ext = url.pathExtension.lowercased()
                if ["dng","cr2","cr3","nef","orf","arw","raf","rw2","pef","srw","3fr","mef","mos","r3d","x3f"].contains(ext) { return 5 }
                if ["tif","tiff"].contains(ext) { return 4 }
                if ["heic","heif"].contains(ext) { return 3 }
                if ["jpg","jpeg"].contains(ext) { return 2 }
                if ["png"].contains(ext) { return 1 }
                return 0
            }
            
            func sourceRank(for url: URL) -> Int {
                let p = url.path.lowercased()
                // Prefer Originale/Masters, dann Derivate, dann Proxies
                if p.contains("/originals/") || p.contains("/masters/") { return 3 }
                if p.contains("/derivatives/") { return 2 }
                if p.contains("/proxies/") { return 1 }
                return 0
            }
            
            func isBetter(_ a: ScanCandidate, than b: ScanCandidate) -> Bool {
                if a.sourceRank != b.sourceRank { return a.sourceRank > b.sourceRank }
                if a.pixelArea != b.pixelArea { return a.pixelArea > b.pixelArea }
                if a.fileSize != b.fileSize { return a.fileSize > b.fileSize }
                if a.extRank != b.extRank { return a.extRank > b.extRank }
                return a.url.lastPathComponent < b.url.lastPathComponent
            }

            let totalFiles = allFiles.count
            var candidates: [ScanCandidate] = []
            candidates.reserveCapacity(totalFiles)
            
            for (index, fileURL) in allFiles.enumerated() {
                // UTType Filter: nur Bilder (keine Videos)
                if let rv = try? fileURL.resourceValues(forKeys: [.contentTypeKey, .fileSizeKey]),
                   let type = rv.contentType {
                    // explizit Videos ausschliessen
                    if type.conforms(to: .movie) || type.conforms(to: .video) || type.conforms(to: .audiovisualContent) {
                        continue
                    }
                    // nur Bildtypen zulassen (rawImage zählt als image-like)
                    if !(type.conforms(to: .image) || type.conforms(to: .rawImage)) {
                        continue
                    }
                }
                
                // Extension Filter (schnell)
                let ext = fileURL.pathExtension.lowercased()
                guard imageExtensions.contains(ext) else { continue }
                
                let scan = metadataService.loadScanMeta(from: fileURL)
                let pw = scan.pixelWidth
                let ph = scan.pixelHeight
                let pixelArea = max(0, (pw ?? 0) * (ph ?? 0))
                let fileSize = (try? fileURL.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
                
                candidates.append(
                    ScanCandidate(
                        url: fileURL,
                        iptc: scan.iptc,
                        captureDate: scan.iptc?.date,
                        uniqueID: scan.exifImageUniqueID,
                        pixelWidth: pw,
                        pixelHeight: ph,
                        pixelArea: pixelArea,
                        fileSize: fileSize,
                        sourceRank: sourceRank(for: fileURL),
                        extRank: extRank(for: fileURL)
                    )
                )
                
                if index % 75 == 0 || index == totalFiles - 1 {
                    let progress = totalFiles > 0 ? Double(index + 1) / Double(totalFiles) : 1.0
                    DispatchQueue.main.async {
                        self.loadingProgress = progress * 0.6 // Scan: 60%
                    }
                }
            }
            
            let selectedCandidates: [ScanCandidate] = {
                guard isPhotosLibrary else { return candidates }
                
                var bestByUniqueID: [String: ScanCandidate] = [:]
                var passThrough: [ScanCandidate] = []
                passThrough.reserveCapacity(candidates.count)
                
                for cand in candidates {
                    let uid = cand.uniqueID?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
                    let key: String? = {
                        if !uid.isEmpty {
                            return "uid:\(uid)"
                        }
                        // Fallback: Photos-Library legt Derivate/Proxies oft unter gleichem Basenamen ab.
                        // Kombiniere optional mit Capture-Date, um echte gleichnamige Imports nicht zu hart zu mergen.
                        let base = cand.url.deletingPathExtension().lastPathComponent
                        guard base.count >= 8 else { return nil }
                        if let d = cand.captureDate {
                            return "name:\(base)|\(Int(d.timeIntervalSince1970))"
                        }
                        return "name:\(base)"
                    }()
                    
                    if let key {
                        if let existing = bestByUniqueID[key] {
                            if isBetter(cand, than: existing) {
                                bestByUniqueID[key] = cand
                            }
                        } else {
                            bestByUniqueID[key] = cand
                        }
                    } else {
                        passThrough.append(cand)
                    }
                }
                
                let deduped = Array(bestByUniqueID.values) + passThrough
                print("📸 Photos Library Dedupe: \(candidates.count) Kandidaten → \(deduped.count) (UniqueID/Basename)")
                return deduped
            }()
            
            // MARK: - Build LoadedPhotoInfo
            var loadedInfos: [LoadedPhotoInfo] = []
            loadedInfos.reserveCapacity(selectedCandidates.count)
            
            for (index, cand) in selectedCandidates.enumerated() {
                let url = cand.url
                
                // Rating: lokales Override hat Vorrang; sonst optional aus Metadaten lesen (z.B. wenn Bilder bereits extern geratet wurden)
                let rating: Int = {
                    let key = url.isFileURL ? url.standardizedFileURL.path : url.absoluteString
                    if let local = localRatingsSnapshot[key] {
                        return local
                    }
                    return ratingService.loadRating(from: url)
                }()
                
                // Pick Status: aus XMP laden (Lightroom-Style: Pick=1, Reject=-1, Unflagged=0)
                // Wichtig: Nur laden wenn es tatsächlich ein Pick Status ist (1, -1, 0), nicht normale Ratings (2-5)
                let pickStatus: PickStatus? = {
                    if let pickStatusValue = ratingService.loadPickStatus(from: url) {
                        switch pickStatusValue {
                        case 1: return .pick
                        case -1: return .reject
                        case 0: return .unflagged
                        default: return nil // Normale Ratings (2-5) sind kein Pick Status
                        }
                    }
                    return nil
                }()
                
                // IPTC: schon geladen; Fallback-Datum NUR ausserhalb Photos-Library, damit "Bearbeitet"-Derivate nicht vorne landen.
                var iptc = cand.iptc
                if !isPhotosLibrary {
                    if iptc == nil { iptc = IPTCMetadata() }
                    if iptc?.date == nil {
                        // Stabiler als "modified": creationDate bleibt eher konstant.
                        let rv = try? url.resourceValues(forKeys: [.creationDateKey])
                        iptc?.date = rv?.creationDate
                    }
                }
                
                let editKey = url.isFileURL ? url.standardizedFileURL.path : url.absoluteString
                let edit = editSnapshot[editKey]
                let captureDate = iptc?.date
                loadedInfos.append(
                    LoadedPhotoInfo(
                        url: url,
                        rating: rating,
                        pickStatus: pickStatus,
                        iptc: iptc,
                        edit: edit,
                        captureDate: captureDate,
                        originalFileName: nil,
                        pixelWidth: cand.pixelWidth,
                        pixelHeight: cand.pixelHeight
                    )
                )
                
                if index % 75 == 0 || index == selectedCandidates.count - 1 {
                    let progress = selectedCandidates.count > 0 ? Double(index + 1) / Double(max(1, selectedCandidates.count)) : 1.0
                    DispatchQueue.main.async {
                        // Metadaten-Build: weitere 40%
                        self.loadingProgress = 0.6 + (progress * 0.4)
                    }
                }
            }
            
            // Sortierung: Photos Library nach Aufnahmedatum (neueste zuerst), sonst stabil nach Dateiname.
            let sortedInfos: [LoadedPhotoInfo] = {
                if isPhotosLibrary {
                    return loadedInfos.sorted { a, b in
                        let da = a.captureDate ?? Date.distantPast
                        let db = b.captureDate ?? Date.distantPast
                        if da != db { return da > db }
                        return a.url.lastPathComponent < b.url.lastPathComponent
                    }
                } else {
                    return loadedInfos.sorted { $0.url.lastPathComponent < $1.url.lastPathComponent }
                }
            }()
            
            await MainActor.run {
                func baseKey(for url: URL) -> String {
                    url.isFileURL ? url.standardizedFileURL.path : url.absoluteString
                }
                
                // 1) Load physical files (Masters)
                var loadedPhotos: [PhotoItem] = []
                var photosByKey: [String: PhotoItem] = [:]
                
                for info in sortedInfos {
                    let photo = PhotoItem(
                        url: info.url,
                        rating: info.rating,
                        originalFileName: info.originalFileName,
                        pixelWidth: info.pixelWidth,
                        pixelHeight: info.pixelHeight
                    )
                    photo.iptcMetadata = info.iptc
                    if let pickStatus = info.pickStatus {
                        photo.pickStatus = pickStatus
                    }
                    photo.colorTags = self.loadLocalColorTags(for: info.url, from: localColorTagsSnapshot)
                    photo.textTags = self.loadAISearchTags(for: info.url, current: localAISearchTagsSnapshot, legacy: legacyAISearchTagsSnapshot)
                    photo.textTags = self.loadAISearchTags(for: info.url, current: localAISearchTagsSnapshot, legacy: legacyAISearchTagsSnapshot)
                    if let edit = info.edit {
                        photo.adjustments = edit.adjustments
                        photo.localMasks = edit.localMasks
                        photo.lensProfileSettings = edit.lensProfileSettings
                        photo.cropRect = edit.cropRect?.cgRect
                        photo.rotation = edit.rotation
                        photo.isMaster = edit.isMaster
                        photo.masterID = edit.masterID.flatMap { UUID(uuidString: $0) }
                        photo.virtualCopyNumber = edit.virtualCopyNumber
                    }
                    loadedPhotos.append(photo)
                    photosByKey[baseKey(for: info.url)] = photo
                }
                
                // 2) Reconstruct Virtual Copies from catalog
                for (key, edit) in editSnapshot {
                    // Virtual Copy entries have a "#UUID" suffix
                    guard key.contains("#"), !edit.isMaster else { continue }
                    
                    let parts = key.split(separator: "#")
                    guard parts.count == 2, let photoIDStr = parts.last, let photoID = UUID(uuidString: String(photoIDStr)) else { continue }
                    
                    let urlKey = String(parts[0])
                    guard let masterPhoto = photosByKey[urlKey] else { continue }
                    
                    // Create virtual copy PhotoItem
                    let virtualCopy = PhotoItem(
                        url: masterPhoto.url,
                        rating: masterPhoto.rating,
                        id: photoID,
                        originalFileName: masterPhoto.originalFileName,
                        pixelWidth: masterPhoto.pixelWidth,
                        pixelHeight: masterPhoto.pixelHeight
                    )
                    virtualCopy.adjustments = edit.adjustments
                    virtualCopy.localMasks = edit.localMasks
                    virtualCopy.lensProfileSettings = edit.lensProfileSettings
                    virtualCopy.cropRect = edit.cropRect?.cgRect
                    virtualCopy.rotation = edit.rotation
                    virtualCopy.isMaster = false
                    virtualCopy.masterID = edit.masterID.flatMap { UUID(uuidString: $0) }
                    virtualCopy.virtualCopyNumber = edit.virtualCopyNumber
                    virtualCopy.iptcMetadata = masterPhoto.iptcMetadata
                    virtualCopy.textTags = masterPhoto.textTags
                    virtualCopy.colorTags = masterPhoto.colorTags
                    virtualCopy.pickStatus = masterPhoto.pickStatus
                    
                    loadedPhotos.append(virtualCopy)
                }
                
                // Sort: nach Capture Date (bei Photos Library), sonst Dateiname. Virtual Copies bleiben direkt beim Master.
                loadedPhotos.sort { a, b in
                    if isPhotosLibrary {
                        let da = a.iptcMetadata?.date ?? Date.distantPast
                        let db = b.iptcMetadata?.date ?? Date.distantPast
                        if da != db { return da > db }
                    }
                    let aURL = a.url.lastPathComponent
                    let bURL = b.url.lastPathComponent
                    if aURL != bURL { return aURL < bURL }
                    return a.virtualCopyNumber < b.virtualCopyNumber
                }
                
                self.photos = loadedPhotos
                self.isLoadingPhotos = false
                self.loadingProgress = 1.0
                
                // Load Quick Collection state
                self.loadQuickCollection()
                
                print("✅ \(loadedPhotos.count) Bilder geladen aus \(folderURL.path)")
                
                // Update filtered photos
                self.updateFilteredPhotos()
                
                if let firstPhoto = self.filteredPhotos.first {
                    self.currentPhotoID = firstPhoto.id
                    self.selectedPhotoIDs = [firstPhoto.id]
                    print("✅ Erstes Foto ausgewählt: \(firstPhoto.fileName)")
                } else {
                    self.currentPhotoID = nil
                    self.selectedPhotoIDs = []
                    print("⚠️ Keine gefilterten Fotos gefunden")
                }
                
                // EXIF-Daten im Hintergrund laden (für Filter-Menü)
                self.loadAllExifMetadata()
            }
        }
    }
    
    /// Lädt EXIF-Daten für alle geladenen Fotos im Hintergrund (für Filter-Menü)
    @MainActor
    private func loadAllExifMetadata() {
        Task.detached(priority: .utility) { [weak self] in
            guard let self else { return }
            let photos = await MainActor.run { self.photos }
            
            // Lade EXIF-Daten in Batches (max 10 gleichzeitig)
            let batchSize = 10
            for i in stride(from: 0, to: photos.count, by: batchSize) {
                let batch = Array(photos[i..<min(i + batchSize, photos.count)])
                
                await withTaskGroup(of: Void.self) { group in
                    for photo in batch {
                        group.addTask {
                            // Prüfe ob EXIF-Daten bereits geladen sind
                            let hasExif = await MainActor.run { photo.exifMeta != nil }
                            if hasExif {
                                return
                            }
                            
                            if let exif = await LensProfileService.shared.lensMeta(for: photo.url) {
                                await MainActor.run {
                                    photo.setExifMeta(exif)
                                    // Trigger UI update für Filter-Menü
                                    self.objectWillChange.send()
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // MARK: - Non-destructive edit persistence

    private func registerEditPersistenceObservers() {
        NotificationCenter.default.publisher(for: NSNotification.Name("PhotoAdjustmentsChanged"))
            // Hover-Preview/temporäre Vorschau darf NICHT persistiert werden.
            .filter { notification in
                !(notification.userInfo?["isPreview"] as? Bool ?? false)
            }
            .compactMap { $0.userInfo?["photoID"] as? UUID }
            .sink { [weak self] photoID in
                guard let self else { return }
                self.persistEditsDebounced(for: photoID)
            }
            .store(in: &cancellables)
    }

    private var persistTasks: [UUID: Task<Void, Never>] = [:]

    private func persistEditsDebounced(for photoID: UUID) {
        persistTasks[photoID]?.cancel()
        persistTasks[photoID] = Task { @MainActor in
            // debounce: sliders spammen viele Notifications
            try? await Task.sleep(nanoseconds: 500_000_000) // 500ms
            guard let photo = self.photos.first(where: { $0.id == photoID }) else { return }
            let entry = EditCatalogService.EditEntry(
                adjustments: photo.adjustments,
                localMasks: photo.localMasks,
                lensProfileSettings: photo.lensProfileSettings,
                cropRect: photo.cropRect,
                rotation: photo.rotation,
                isMaster: photo.isMaster,
                masterID: photo.masterID,
                virtualCopyNumber: photo.virtualCopyNumber
            )
            // Master: stabil per Dateipfad (kein #UUID), Virtual Copy: per url#uuid
            let keyPhotoID: UUID? = photo.isMaster ? nil : photo.id
            await EditCatalogService.shared.upsertEdit(entry, for: photo.url, photoID: keyPhotoID)
            self.persistTasks[photoID] = nil
        }
    }
    
    // MARK: - History / Undo / Snapshots (Lightroom-like)
    
    private struct EditState: Equatable, Sendable {
        var adjustments: PhotoAdjustments
        var localMasks: [LocalAdjustmentMask]
        var lensProfileSettings: LensProfileSettings
        var cropRect: CGRect?
        var rotation: Double
    }
    
    private let maxUndoDepth: Int = 60
    private var undoStackByKey: [String: [EditState]] = [:]
    private var redoStackByKey: [String: [EditState]] = [:]
    private var inFlightEditStartByKey: [String: EditState] = [:]
    
    func beginEditSession(for photo: PhotoItem) {
        let key = editKey(for: photo)
        if inFlightEditStartByKey[key] == nil {
            inFlightEditStartByKey[key] = captureEditState(photo)
        }
    }
    
    func endEditSession(for photo: PhotoItem) {
        let key = editKey(for: photo)
        guard let start = inFlightEditStartByKey.removeValue(forKey: key) else { return }
        let current = captureEditState(photo)
        guard start != current else { return }
        pushUndo(start, forKey: key)
        redoStackByKey[key] = []
        objectWillChange.send()
    }
    
    /// Für diskrete Aktionen (Auto/Reset/Preset/Paste/Sync): Undo-Punkt vor der Änderung speichern.
    func registerUndoPoint(for photo: PhotoItem) {
        let key = editKey(for: photo)
        pushUndo(captureEditState(photo), forKey: key)
        redoStackByKey[key] = []
        objectWillChange.send()
    }
    
    func undoCurrent() {
        guard let photo = currentPhoto else { return }
        undo(photo: photo)
    }
    
    func redoCurrent() {
        guard let photo = currentPhoto else { return }
        redo(photo: photo)
    }
    
    func canUndo(photo: PhotoItem) -> Bool {
        let key = editKey(for: photo)
        return !(undoStackByKey[key]?.isEmpty ?? true)
    }
    
    func canRedo(photo: PhotoItem) -> Bool {
        let key = editKey(for: photo)
        return !(redoStackByKey[key]?.isEmpty ?? true)
    }
    
    var canUndoCurrent: Bool {
        guard let photo = currentPhoto else { return false }
        return canUndo(photo: photo)
    }
    
    var canRedoCurrent: Bool {
        guard let photo = currentPhoto else { return false }
        return canRedo(photo: photo)
    }
    
    private func undo(photo: PhotoItem) {
        let key = editKey(for: photo)
        guard var undoStack = undoStackByKey[key], let previous = undoStack.popLast() else { return }
        undoStackByKey[key] = undoStack
        
        var redoStack = redoStackByKey[key] ?? []
        redoStack.append(captureEditState(photo))
        redoStackByKey[key] = redoStack
        
        applyEditState(previous, to: photo)
        objectWillChange.send()
    }
    
    private func redo(photo: PhotoItem) {
        let key = editKey(for: photo)
        guard var redoStack = redoStackByKey[key], let next = redoStack.popLast() else { return }
        redoStackByKey[key] = redoStack
        
        var undoStack = undoStackByKey[key] ?? []
        undoStack.append(captureEditState(photo))
        undoStackByKey[key] = trimUndo(undoStack)
        
        applyEditState(next, to: photo)
        objectWillChange.send()
    }
    
    // MARK: Snapshots
    
    func snapshots(for photo: PhotoItem) -> [EditSnapshot] {
        editSnapshotsByKey[editKey(for: photo)] ?? []
    }
    
    func createSnapshot(for photo: PhotoItem, name: String? = nil) {
        let key = editKey(for: photo)
        var list = editSnapshotsByKey[key] ?? []
        let defaultName = name ?? "Snapshot \(list.count + 1)"
        let snapshot = EditSnapshot(
            name: defaultName,
            adjustments: photo.adjustments,
            localMasks: photo.localMasks,
            lensProfileSettings: photo.lensProfileSettings,
            cropRect: photo.cropRect,
            rotation: photo.rotation
        )
        list.insert(snapshot, at: 0)
        editSnapshotsByKey[key] = list
        saveEditSnapshots()
        objectWillChange.send()
    }
    
    func applySnapshot(_ snapshot: EditSnapshot, to photo: PhotoItem) {
        registerUndoPoint(for: photo)
        
        photo.adjustments = snapshot.adjustments
        photo.localMasks = snapshot.localMasks ?? []
        photo.lensProfileSettings = snapshot.lensProfileSettings ?? LensProfileSettings()
        photo.cropRect = snapshot.cropRect?.cgRect
        photo.rotation = snapshot.rotation
        
        triggerReprocess(for: photo)
    }
    
    func deleteSnapshot(_ snapshot: EditSnapshot, for photo: PhotoItem) {
        let key = editKey(for: photo)
        var list = editSnapshotsByKey[key] ?? []
        list.removeAll { $0.id == snapshot.id }
        editSnapshotsByKey[key] = list
        saveEditSnapshots()
        objectWillChange.send()
    }
    
    private func loadEditSnapshots() {
        guard let data = UserDefaults.standard.data(forKey: "editSnapshotsV1"),
              let decoded = try? JSONDecoder().decode([String: [EditSnapshot]].self, from: data) else {
            editSnapshotsByKey = [:]
            return
        }
        editSnapshotsByKey = decoded
    }
    
    private func saveEditSnapshots() {
        guard let encoded = try? JSONEncoder().encode(editSnapshotsByKey) else { return }
        UserDefaults.standard.set(encoded, forKey: "editSnapshotsV1")
    }
    
    // MARK: Helpers
    
    private func editKey(for photo: PhotoItem) -> String {
        let base = photo.url.standardizedFileURL.path
        return photo.isMaster ? base : "\(base)#\(photo.id.uuidString)"
    }
    
    private func captureEditState(_ photo: PhotoItem) -> EditState {
        EditState(
            adjustments: photo.adjustments,
            localMasks: photo.localMasks,
            lensProfileSettings: photo.lensProfileSettings,
            cropRect: photo.cropRect,
            rotation: photo.rotation
        )
    }
    
    private func applyEditState(_ state: EditState, to photo: PhotoItem) {
        photo.adjustments = state.adjustments
        photo.localMasks = state.localMasks
        photo.lensProfileSettings = state.lensProfileSettings
        photo.cropRect = state.cropRect
        photo.rotation = state.rotation
        triggerReprocess(for: photo)
    }
    
    private func pushUndo(_ state: EditState, forKey key: String) {
        var stack = undoStackByKey[key] ?? []
        // Dedup: wenn letzter Eintrag identisch, nicht pushen
        if stack.last != state {
            stack.append(state)
        }
        undoStackByKey[key] = trimUndo(stack)
    }
    
    private func trimUndo(_ stack: [EditState]) -> [EditState] {
        if stack.count <= maxUndoDepth { return stack }
        return Array(stack.suffix(maxUndoDepth))
    }

    @MainActor
    private func requestPhotosLibraryAuthorization() async -> PHAuthorizationStatus {
        await withCheckedContinuation { continuation in
            PHPhotoLibrary.requestAuthorization(for: .readWrite) { status in
                continuation.resume(returning: status)
            }
        }
    }

    @MainActor
    private func showPhotosPermissionAlert() {
        let alert = NSAlert()
        alert.messageText = "Zugriff auf Fotos verweigert"
        alert.informativeText = "WB Foto Manager benötigt Zugriff auf die Fotos‑Mediathek. Bitte in „Systemeinstellungen → Datenschutz & Sicherheit → Fotos“ aktivieren und erneut versuchen."
        alert.addButton(withTitle: "OK")
        alert.alertStyle = .warning
        alert.runModal()
    }
    
    // MARK: - Navigation
    
    func selectPhoto(_ photo: PhotoItem, withModifiers: NSEvent.ModifierFlags? = nil) {
        let modifiers = withModifiers ?? NSEvent.modifierFlags
        let isCommandPressed = modifiers.contains(.command)
        
        currentPhotoID = photo.id
        
        if isCommandPressed || uiState?.selectionMode == true {
            // Cmd+Klick oder Mehrfachauswahl-Modus: Toggle (hinzufügen/entfernen)
            if selectedPhotoIDs.contains(photo.id) {
                selectedPhotoIDs.remove(photo.id)
                // Wenn das aktuelle Foto abgewählt wird, setze currentPhotoID auf das erste noch ausgewählte Foto
                if currentPhotoID == photo.id, let firstSelected = selectedPhotoIDs.first,
                   let firstPhoto = photos.first(where: { $0.id == firstSelected }) {
                    currentPhotoID = firstPhoto.id
                }
            } else {
                selectedPhotoIDs.insert(photo.id)
            }
            // Automatisch Mehrfachauswahl-Modus aktivieren, wenn Cmd gedrückt ist
            if isCommandPressed {
                uiState?.selectionMode = true
            }
        } else {
            // Single selection (default)
            selectedPhotoIDs = [photo.id]
        }
    }
    
    /// Wählt alle aktuell sichtbaren/gefilteten Fotos aus (⌘A Workflow).
    /// - Note: Aktiviert automatisch `selectionMode`.
    func selectAllFilteredPhotos() {
        guard !filteredPhotos.isEmpty else { return }
        uiState?.selectionMode = true
        
        selectedPhotoIDs = Set(filteredPhotos.map { $0.id })
        if currentPhotoID == nil {
            currentPhotoID = filteredPhotos.first?.id
        } else if let current = currentPhotoID, !selectedPhotoIDs.contains(current) {
            // Falls Current ausserhalb Filter liegt, setze auf erstes sichtbares Foto.
            currentPhotoID = filteredPhotos.first?.id
        }
    }
    
    func cancelAITagging() {
        aiTaggingTask?.cancel()
        aiTaggingTask = nil
        
        isAITaggingRunning = false
        aiTaggingProgress = 0.0
        aiTaggingProcessedCount = 0
        aiTaggingTotalCount = 0
        aiTaggingCurrentName = ""
    }
    
    func cancelAISearchIndex() {
        aiSearchTask?.cancel()
        aiSearchTask = nil
        
        isAISearchRunning = false
        aiSearchProgress = 0.0
        aiSearchProcessedCount = 0
        aiSearchTotalCount = 0
        aiSearchCurrentName = ""
    }

    /// Baut (best effort) einen lokalen AI-Suchindex auf Basis von Vision-Keywords auf.
    /// - Important: Dieser Index ist **rein lokal** (UserDefaults) und schreibt keine Metadaten in Dateien/PhotoKit.
    /// - Trigger: Wird bei aktivierter `uiState.aiSearchEnabled` automatisch gestartet (z.B. wenn der User im Suchfeld tippt).
    func startAISearchIndexIfNeeded(force: Bool = false) {
        guard uiState?.aiSearchEnabled == true else { return }
        guard !photos.isEmpty else { return }
        
        // Wenn bereits ein Index-Lauf läuft → nicht doppelt starten.
        if aiSearchTask != nil { return }
        
        // Snapshot (damit wir in der Task mit stabilen IDs arbeiten)
        let photosSnapshot = photos
        
        // Persistierter Cache (URL-String → Tags) – NUR aktuelle Version (V5).
        // Legacy-Tags werden für UI geladen, aber NICHT als "fertig" gezählt (sonst würde Reindex nicht laufen).
        var persisted = loadLocalAISearchTags()
        let legacy = loadLegacyAISearchTags()
        
        // Gruppiere Virtual Copies nach URL-Key, damit wir pro Datei nur einmal analysieren.
        let keyForURL: (URL) -> String = { url in
            url.isFileURL ? url.standardizedFileURL.path : url.absoluteString
        }
        
        var idsByKey: [String: [UUID]] = [:]
        var firstURLByKey: [String: URL] = [:]
        var firstNameByKey: [String: String] = [:]
        idsByKey.reserveCapacity(photosSnapshot.count)
        
        for p in photosSnapshot {
            let key = keyForURL(p.url)
            idsByKey[key, default: []].append(p.id)
            if firstURLByKey[key] == nil { firstURLByKey[key] = p.url }
            if firstNameByKey[key] == nil { firstNameByKey[key] = p.fileName }
        }
        
        // Kandidaten: nur Keys die noch NICHT persistiert sind (auch leere Arrays zählen als "bereits verarbeitet").
        // Zusätzlich: falls wir in-memory Tags haben (z.B. aus einem abgebrochenen Lauf), persistieren wir die gleich.
        var candidates: [(key: String, url: URL, name: String)] = []
        candidates.reserveCapacity(photosSnapshot.count)
        var seenKeys: Set<String> = []
        seenKeys.reserveCapacity(max(16, idsByKey.count))
        
        // Wichtig: in stabiler Reihenfolge iterieren (Photos-Order / UI-Sort), nicht Dictionary-Order.
        for p in photosSnapshot {
            let key = keyForURL(p.url)
            if seenKeys.contains(key) { continue }
            seenKeys.insert(key)
            
            guard let url = firstURLByKey[key], let name = firstNameByKey[key] else { continue }
            
            if let _ = persisted[key], !force {
                continue
            }
            
            if !force, !p.textTags.isEmpty {
                // Falls bereits Tags im Speicher vorhanden, aber noch nicht persistiert:
                // - wenn diese aus Legacy stammen → NICHT überspringen (wir wollen reindexen)
                // - sonst (z.B. abgebrochener Run) → persistieren und überspringen
                if legacy[key] == nil {
                    persisted[key] = Array(p.textTags).sorted()
                    continue
                }
            }
            
            candidates.append((key: key, url: url, name: name))
        }
        
        if candidates.isEmpty {
            // Persist "in-memory" Fixups (falls wir oben welche ergänzt haben).
            saveLocalAISearchTags(persisted)
            return
        }
        
        // Persist evtl. bereits ergänzte Einträge.
        saveLocalAISearchTags(persisted)
        
        // Schnelles Lookup für Updates
        let idToIndex: [UUID: Int] = Dictionary(uniqueKeysWithValues: photosSnapshot.enumerated().map { ($0.element.id, $0.offset) })
        
        // UI State
        isAISearchRunning = true
        aiSearchProcessedCount = 0
        aiSearchTotalCount = candidates.count
        aiSearchProgress = 0.0
        aiSearchCurrentName = ""
        
        aiSearchTask = Task(priority: .userInitiated) { [weak self] in
            guard let self else { return }
            
            var dict = self.loadLocalAISearchTags()
            let total = candidates.count
            var processed = 0
            let saveEvery = 12
            
            for cand in candidates {
                if Task.isCancelled { break }
                
                await MainActor.run {
                    self.aiSearchCurrentName = cand.name
                }
                
                // AI Suche: schnell indexieren – 1024px genügt, intern wird zusätzlich auf ~1200px downscaled.
                let tags = await AITaggingService.shared.generateKeywords(for: cand.url, previewSize: .strip, mode: .search)
                if Task.isCancelled { break }
                
                // Persistiere (auch leer -> gilt als "verarbeitet", damit wir nicht bei jedem Such-Event neu rechnen).
                dict[cand.key] = tags
                processed += 1
                
                if processed % saveEvery == 0 {
                    self.saveLocalAISearchTags(dict)
                }
                
                await MainActor.run {
                    let tagSet = Set(tags)
                    if let ids = idsByKey[cand.key] {
                        for id in ids {
                            if let idx = idToIndex[id], idx < self.photos.count {
                                self.photos[idx].textTags = tagSet
                            }
                        }
                    }
                    
                    self.aiSearchProcessedCount = processed
                    self.aiSearchTotalCount = total
                    self.aiSearchProgress = total > 0 ? Double(processed) / Double(total) : 1.0
                    
                    // Wenn der User gerade sucht, sollen Treffer "nach und nach" auftauchen.
                    let q = self.uiState?.searchQuery.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
                    if !q.isEmpty {
                        // UI nicht zu häufig refreshen (sonst wirkt es "hängig")
                        if processed == total || processed % 24 == 0 {
                            self.updateFilteredPhotos()
                        }
                    }
                }
            }
            
            // Final save (auch bei Abbruch sinnvoll)
            self.saveLocalAISearchTags(dict)
            
            if Task.isCancelled {
                return
            }
            
            await MainActor.run {
                self.aiSearchTask = nil
                self.isAISearchRunning = false
                self.aiSearchCurrentName = ""
                self.aiSearchProgress = total > 0 ? 1.0 : 0.0
                self.updateFilteredPhotos()
            }
        }
    }
    
    func cancelBestOf() {
        bestOfTask?.cancel()
        bestOfTask = nil
        
        isBestOfRunning = false
        bestOfProgress = 0.0
        bestOfProcessedCount = 0
        bestOfTotalCount = 0
        bestOfCurrentName = ""
    }

    func clearSelectionToCurrent() {
        if let current = currentPhotoID {
            selectedPhotoIDs = [current]
        } else {
            selectedPhotoIDs = []
        }
    }

    func copyAdjustmentsFromCurrent() {
        guard let photo = currentPhoto else { return }
        copiedAdjustments = photo.adjustments
    }

    func pasteAdjustmentsToCurrent() {
        guard let photo = currentPhoto, let copiedAdjustments else { return }
        registerUndoPoint(for: photo)
        photo.adjustments = copiedAdjustments
        triggerReprocess(for: photo)
    }

    func pasteAdjustmentsToSelection() {
        guard let copiedAdjustments else { return }
        let targets = photos.filter { selectedPhotoIDs.contains($0.id) }
        guard !targets.isEmpty else { return }

        for photo in targets {
            registerUndoPoint(for: photo)
            photo.adjustments = copiedAdjustments
            persistEditsForPhoto(photo)
        }

        if let current = currentPhoto {
            triggerReprocess(for: current)
        } else {
            objectWillChange.send()
        }
    }

    func syncFromCurrentToSelection(scope: SyncScope) {
        guard let source = currentPhoto else { return }
        let sourceAdjustments = source.adjustments
        let sourceCrop = source.cropRect
        let sourceRotation = source.rotation

        let targets = photos.filter { selectedPhotoIDs.contains($0.id) && $0.id != source.id }
        guard !targets.isEmpty else { return }

        for photo in targets {
            registerUndoPoint(for: photo)
            var updated = photo.adjustments
            applySyncAdjustments(from: sourceAdjustments, to: &updated, scope: scope)
            photo.adjustments = updated
            if scope.cropAndRotation {
                photo.cropRect = sourceCrop
                photo.rotation = sourceRotation
            }
            persistEditsForPhoto(photo)
        }

        // Ensure current image refresh (and also persist current via existing observer).
        triggerReprocess(for: source)
    }

    private func applySyncAdjustments(from source: PhotoAdjustments, to target: inout PhotoAdjustments, scope: SyncScope) {
        if scope.whiteBalance {
            target.temperature = source.temperature
            target.tint = source.tint
        }
        if scope.exposure {
            target.exposure = source.exposure
        }
        if scope.contrast {
            target.contrast = source.contrast
        }
        if scope.tone {
            target.highlights = source.highlights
            target.shadows = source.shadows
            target.whites = source.whites
            target.blacks = source.blacks
        }
        if scope.presence {
            target.clarity = source.clarity
            target.texture = source.texture
            target.dehaze = source.dehaze
            target.vibrance = source.vibrance
            target.saturation = source.saturation
        }
        if scope.details {
            target.sharpening = source.sharpening
            target.noiseReduction = source.noiseReduction
            target.lensDistortion = source.lensDistortion
            target.vignette = source.vignette
            target.chromaticAberration = source.chromaticAberration
        }
        // ColorAdjustments (hue shifts) - not yet implemented in PhotoAdjustments
    }

    private func triggerReprocess(for photo: PhotoItem) {
        // DetailView observes notification; persistence observers hook into this as well.
        photo.objectWillChange.send()
        objectWillChange.send()
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id]
        )
    }

    private func persistEditsForPhoto(_ photo: PhotoItem) {
        let entry = EditCatalogService.EditEntry(
            adjustments: photo.adjustments,
            localMasks: photo.localMasks,
            lensProfileSettings: photo.lensProfileSettings,
            cropRect: photo.cropRect,
            rotation: photo.rotation,
            isMaster: photo.isMaster,
            masterID: photo.masterID,
            virtualCopyNumber: photo.virtualCopyNumber
        )
        Task {
            // Master: stabil per Dateipfad (kein #UUID), Virtual Copy: per url#uuid
            let keyPhotoID: UUID? = photo.isMaster ? nil : photo.id
            await EditCatalogService.shared.upsertEdit(entry, for: photo.url, photoID: keyPhotoID)
        }
    }
    
    func selectNextPhoto() {
        guard let currentIndex = currentPhotoIndexInFiltered else { return }
        if currentIndex < filteredPhotos.count - 1 {
            selectPhoto(filteredPhotos[currentIndex + 1])
        }
    }
    
    func selectPreviousPhoto() {
        guard let currentIndex = currentPhotoIndexInFiltered else { return }
        if currentIndex > 0 {
            selectPhoto(filteredPhotos[currentIndex - 1])
        }
    }
    
    // MARK: - Culling Queue (Turbo Navigation)
    
    private func selectNext(where predicate: (PhotoItem) -> Bool, wrap: Bool = true) {
        guard !filteredPhotos.isEmpty else { return }
        guard let idx = currentPhotoIndexInFiltered else { return }
        
        let start = idx + 1
        if start < filteredPhotos.count {
            for i in start..<filteredPhotos.count {
                let p = filteredPhotos[i]
                if predicate(p) {
                    selectPhoto(p)
                    return
                }
            }
        }
        
        guard wrap else { return }
        
        if idx > 0 {
            for i in 0..<min(idx, filteredPhotos.count) {
                let p = filteredPhotos[i]
                if predicate(p) {
                    selectPhoto(p)
                    return
                }
            }
        }
    }
    
    private func selectPrevious(where predicate: (PhotoItem) -> Bool, wrap: Bool = true) {
        guard !filteredPhotos.isEmpty else { return }
        guard let idx = currentPhotoIndexInFiltered else { return }
        
        let start = idx - 1
        if start >= 0 {
            for i in stride(from: start, through: 0, by: -1) {
                let p = filteredPhotos[i]
                if predicate(p) {
                    selectPhoto(p)
                    return
                }
            }
        }
        
        guard wrap else { return }
        
        if idx < filteredPhotos.count - 1 {
            for i in stride(from: filteredPhotos.count - 1, through: idx + 1, by: -1) {
                let p = filteredPhotos[i]
                if predicate(p) {
                    selectPhoto(p)
                    return
                }
            }
        }
    }
    
    func selectNextUnflagged() {
        selectNext(where: { $0.pickStatus == .unflagged })
    }
    
    func selectPreviousUnflagged() {
        selectPrevious(where: { $0.pickStatus == .unflagged })
    }
    
    func selectNextUnrated() {
        selectNext(where: { $0.rating == 0 })
    }
    
    func selectPreviousUnrated() {
        selectPrevious(where: { $0.rating == 0 })
    }
    
    /// Unreviewed = noch kein Rating und keine Pick/Reject Markierung.
    func selectNextUnreviewed() {
        selectNext(where: { $0.rating == 0 && $0.pickStatus == .unflagged })
    }
    
    func selectPreviousUnreviewed() {
        selectPrevious(where: { $0.rating == 0 && $0.pickStatus == .unflagged })
    }
    
    func selectPhoto(at index: Int) {
        guard index >= 0 && index < filteredPhotos.count else { return }
        selectPhoto(filteredPhotos[index], withModifiers: nil)
    }
    
    // MARK: - Rating & Tags
    
    func setRating(_ rating: Int, for photoID: UUID, autoAdvance: Bool = true) {
        guard let index = photos.firstIndex(where: { $0.id == photoID }) else { return }
        let photo = photos[index]
        let clamped = max(0, min(5, rating))
        
        // Rating gilt Lightroom-like pro "Bild" (Master + Virtual Copies teilen sich das Rating).
        // Unsere lokale Persistenz ist URL-basiert → wir synchronisieren deshalb alle PhotoItems mit gleicher URL sofort.
        let key = photo.url.isFileURL ? photo.url.standardizedFileURL.path : photo.url.absoluteString
        for p in photos {
            let pKey = p.url.isFileURL ? p.url.standardizedFileURL.path : p.url.absoluteString
            if pKey == key {
                p.rating = clamped
            }
        }
        
        // Manually trigger an update for the specific photo and re-filtering
        objectWillChange.send()
        updateFilteredPhotos()
        
        // Rating IMMER lokal persistieren (zuverlässig, RAW/read-only/sandbox-safe).
        saveLocalRating(clamped, for: photo.url)
        
        // Optional: Rating zusätzlich in File-Metadaten schreiben (nur wenn sinnvoll/risikoarm).
        // Photos Library / PhotoKit: read-only → skip.
        if AppSettings.shared.saveRatingInXMP, !isPhotosLibraryContext(photo.url), canWriteRatingToFile(photo.url) {
            Task(priority: .background) {
                try? self.ratingService.writeRating(clamped, to: photo.url)
            }
        }
        
        // Auto-Save Metadaten: Speichere auch IPTC wenn aktiviert
        if AppSettings.shared.autoSaveMetadata, !isPhotosLibraryContext(photo.url), let iptc = photo.iptcMetadata {
            Task(priority: .background) {
                try? IPTCMetadataService.shared.writeMetadata(iptc, to: photo.url)
            }
        }
        
        if exportQueueEnabled && clamped >= exportQueueMinRating {
            enqueueExport(photo)
        }
        
        // AUTO-ADVANCE: Gehe zum nächsten Bild (KRITISCH für Sportfotografie!)
        if autoAdvance && AppSettings.shared.autoAdvanceAfterRating {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.selectNextPhoto()
            }
        }
    }
    
    /// Batch: Setzt ein Rating für die aktuelle Auswahl (oder das aktuelle Foto, falls keine Auswahl aktiv ist).
    /// - Important: Kein Auto‑Advance (Batch‑Workflow soll nicht „springen“).
    @MainActor
    func setRatingForSelection(_ rating: Int) {
        let clamped = max(0, min(5, rating))
        
        let ids: Set<UUID> = {
            if !selectedPhotoIDs.isEmpty { return selectedPhotoIDs }
            if let id = currentPhotoID { return [id] }
            return []
        }()
        guard !ids.isEmpty else { return }
        
        // Group by URL-Key (Lightroom-like: Rating gilt pro "Bild" inkl. Virtual Copies)
        var keysToUpdate = Set<String>()
        var representativeURLByKey: [String: URL] = [:]
        
        for p in photos where ids.contains(p.id) {
            let key = p.url.isFileURL ? p.url.standardizedFileURL.path : p.url.absoluteString
            keysToUpdate.insert(key)
            if representativeURLByKey[key] == nil {
                representativeURLByKey[key] = p.url
            }
        }
        guard !keysToUpdate.isEmpty else { return }
        
        // Apply in one pass (fast, one UI refresh)
        for p in photos {
            let key = p.url.isFileURL ? p.url.standardizedFileURL.path : p.url.absoluteString
            if keysToUpdate.contains(key) {
                p.rating = clamped
            }
        }
        
        // Persist local overrides (one per key)
        for (_, url) in representativeURLByKey {
            saveLocalRating(clamped, for: url)
        }
        
        objectWillChange.send()
        updateFilteredPhotos()
        
        // Optional: write to file metadata (gated by setting + safe formats)
        if AppSettings.shared.saveRatingInXMP {
            let urlsToWrite = representativeURLByKey.values.filter { url in
                !isPhotosLibraryContext(url) && canWriteRatingToFile(url)
            }
            if !urlsToWrite.isEmpty {
                Task(priority: .background) { [ratingService] in
                    for url in urlsToWrite {
                        try? ratingService.writeRating(clamped, to: url)
                    }
                }
            }
        }
    }

    /// Schreib-Ratings in Originaldateien ist für viele Formate (v.a. RAW) riskant/oft nicht möglich.
    /// Wir erlauben es deshalb nur für "klassische" Rasterformate.
    private func canWriteRatingToFile(_ url: URL) -> Bool {
        guard url.isFileURL else { return false }
        guard FileManager.default.isWritableFile(atPath: url.path) else { return false }
        let ext = url.pathExtension.lowercased()
        return ["jpg", "jpeg", "heic", "heif", "png", "tif", "tiff"].contains(ext)
    }
    
    // MARK: - Pick/Reject (Lightroom-Style)
    
    func setPickStatus(_ status: PickStatus, for photoID: UUID, autoAdvance: Bool = true) {
        guard let photo = photos.first(where: { $0.id == photoID }) else { return }
        photo.pickStatus = status
        objectWillChange.send()
        updateFilteredPhotos()
        
        // Persist to XMP or sidecar (Lightroom-Style: Pick=1, Reject=-1, Unflagged=0)
        let pickStatusValue: Int = {
            switch status {
            case .pick: return 1
            case .reject: return -1
            case .unflagged: return 0
            }
        }()
        
        // Asynchron speichern (non-blocking)
        Task.detached(priority: .utility) { [weak self] in
            guard self != nil else { return }
            do {
                try RatingPersistenceService.shared.writePickStatus(pickStatusValue, to: photo.url)
            } catch {
                print("⚠️ Could not save pick status to \(photo.url.path): \(error.localizedDescription)")
            }
        }
        
        // AUTO-ADVANCE nach Pick/Reject
        if autoAdvance && AppSettings.shared.autoAdvanceAfterRating {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.selectNextPhoto()
            }
        }
    }
    
    func markAsPick(photoID: UUID) {
        setPickStatus(.pick, for: photoID)
    }
    
    func markAsReject(photoID: UUID) {
        setPickStatus(.reject, for: photoID)
    }
    
    func unflag(photoID: UUID) {
        setPickStatus(.unflagged, for: photoID)
    }
    
    /// Batch: Setzt Pick/Reject/Unflagged für die aktuelle Auswahl (oder aktuelles Foto).
    /// - Important: Kein Auto‑Advance.
    @MainActor
    func setPickStatusForSelection(_ status: PickStatus) {
        let ids: Set<UUID> = {
            if !selectedPhotoIDs.isEmpty { return selectedPhotoIDs }
            if let id = currentPhotoID { return [id] }
            return []
        }()
        guard !ids.isEmpty else { return }
        
        for p in photos where ids.contains(p.id) {
            p.pickStatus = status
        }
        
        objectWillChange.send()
        updateFilteredPhotos()
    }
    
    /// Smart‑Culling Helper: Markiert den Best‑Shot als Pick und setzt alle anderen IDs der Gruppe auf den gewünschten Status.
    /// - Note: Wird absichtlich **ohne Auto‑Advance** ausgeführt, damit der Compare/Survey Workflow nicht „springt“.
    func applyPickBurst(bestID: UUID, groupIDs: [UUID], restStatus: PickStatus) {
        guard groupIDs.count >= 2 else { return }
        let group = Set(groupIDs)
        guard group.contains(bestID) else { return }
        
        // Batch‑Update (nur einmal filter/refresh), damit UI flüssig bleibt.
        for photo in photos where group.contains(photo.id) {
            photo.pickStatus = (photo.id == bestID) ? .pick : restStatus
        }
        
        objectWillChange.send()
        updateFilteredPhotos()
    }
    
    func deleteAllRejects() {
        let rejects = photos.filter { $0.pickStatus == .reject }
        guard !rejects.isEmpty else { return }
        
        // Ask user for confirmation
        let alert = NSAlert()
        alert.messageText = "Alle abgelehnten Bilder löschen?"
        alert.informativeText = "\(rejects.count) Bild(er) werden permanent gelöscht."
        alert.alertStyle = .critical
        alert.addButton(withTitle: "Löschen")
        alert.addButton(withTitle: "Abbrechen")
        
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        
        // Delete from file system
        for photo in rejects {
            try? FileManager.default.trashItem(at: photo.url, resultingItemURL: nil)
        }
        
        // Remove from array
        photos.removeAll { $0.pickStatus == .reject }
        objectWillChange.send()
        updateFilteredPhotos()
    }
    
    // MARK: - Quick Collection (Lightroom-Style)
    
    func toggleQuickCollection(for photoID: UUID) {
        guard let photo = photos.first(where: { $0.id == photoID }) else { return }
        photo.isInQuickCollection.toggle()
        objectWillChange.send()
        updateFilteredPhotos()
        saveQuickCollection()
    }
    
    func clearQuickCollection() {
        for photo in photos {
            photo.isInQuickCollection = false
        }
        objectWillChange.send()
        updateFilteredPhotos()
        saveQuickCollection()
    }
    
    private func saveQuickCollection() {
        let quickCollectionIDs = photos.filter { $0.isInQuickCollection }.map { $0.url.path }
        UserDefaults.standard.set(quickCollectionIDs, forKey: "quickCollectionURLs")
    }
    
    private func loadQuickCollection() {
        guard let savedURLs = UserDefaults.standard.stringArray(forKey: "quickCollectionURLs") else { return }
        let urlSet = Set(savedURLs)
        for photo in photos {
            photo.isInQuickCollection = urlSet.contains(photo.url.path)
        }
    }
    
    // MARK: - Virtual Copies (Lightroom-Style)
    
    func createVirtualCopy(of photoID: UUID) {
        guard let master = photos.first(where: { $0.id == photoID }) else { return }
        
        // Find all existing copies of this master (or master itself if it's a copy)
        let actualMasterID = master.isMaster ? master.id : master.masterID!
        let allCopies = photos.filter {
            ($0.id == actualMasterID) || ($0.masterID == actualMasterID)
        }
        
        // Determine next copy number
        let maxCopyNumber = allCopies.map(\.virtualCopyNumber).max() ?? 0
        let newCopyNumber = maxCopyNumber + 1
        
        // Create virtual copy
        let actualMaster = master.isMaster ? master : photos.first(where: { $0.id == actualMasterID })!
        let virtualCopy = PhotoItem(from: actualMaster, copyNumber: newCopyNumber)
        
        // Mark master if needed
        if actualMaster.virtualCopyNumber == 0, allCopies.count == 1 {
            // First copy created, mark original as "Master"
            actualMaster.virtualCopyNumber = 0
            actualMaster.isMaster = true
        }
        
        // Insert after master/last copy
        if let masterIndex = photos.firstIndex(where: { $0.id == actualMasterID }) {
            let insertIndex = masterIndex + allCopies.count
            photos.insert(virtualCopy, at: min(insertIndex, photos.count))
        } else {
            photos.append(virtualCopy)
        }
        
        // Select new copy
        selectPhoto(virtualCopy)
        
        objectWillChange.send()
        updateFilteredPhotos()
        
        // Persist
        persistEditsForPhoto(virtualCopy)
    }
    
    func deleteVirtualCopy(photoID: UUID) {
        guard let photo = photos.first(where: { $0.id == photoID }), !photo.isMaster else {
            return // Can't delete master
        }
        
        photos.removeAll { $0.id == photoID }
        objectWillChange.send()
        updateFilteredPhotos()
        
        // Remove snapshots for this virtual copy
        editSnapshotsByKey.removeValue(forKey: editKey(for: photo))
        saveEditSnapshots()
        
        // Remove from catalog (Virtual Copy key = url#uuid)
        Task {
            await EditCatalogService.shared.removeEdit(for: photo.url, photoID: photo.id)
        }
    }
    
    func getVirtualCopies(for photoID: UUID) -> [PhotoItem] {
        guard let photo = photos.first(where: { $0.id == photoID }) else { return [] }
        let masterID = photo.isMaster ? photo.id : photo.masterID!
        return photos.filter { ($0.id == masterID) || ($0.masterID == masterID) }.sorted { $0.virtualCopyNumber < $1.virtualCopyNumber }
    }
    
    // ... (rest of the file remains largely the same, but methods like toggleColorTag would also need objectWillChange.send() and updateFilteredPhotos())
    
    func toggleColorTag(_ tag: ColorTag, for photoID: UUID) {
        guard let photo = photos.first(where: { $0.id == photoID }) else { return }
        
        // Lightroom-like: Color Tags gelten pro "Bild" (Master + Virtual Copies teilen sich die Labels).
        let key = photo.url.isFileURL ? photo.url.standardizedFileURL.path : photo.url.absoluteString
        
        var updated = photo.colorTags
        if updated.contains(tag) {
            updated.remove(tag)
        } else {
            updated.insert(tag)
        }
        
        for p in photos {
            let pKey = p.url.isFileURL ? p.url.standardizedFileURL.path : p.url.absoluteString
            if pKey == key {
                p.colorTags = updated
            }
        }
        
        // Persist (lokal, format-/sandbox-safe)
        saveLocalColorTags(updated, for: photo.url)
        
        objectWillChange.send()
        updateFilteredPhotos()
    }
    
    /// Batch: toggelt ein Color‑Tag für die aktuelle Auswahl (oder aktuelles Foto).
    /// - Note: Color Tags gelten pro "Bild" (URL-Key) inkl. Virtual Copies.
    @MainActor
    func toggleColorTagForSelection(_ tag: ColorTag) {
        let ids: Set<UUID> = {
            if !selectedPhotoIDs.isEmpty { return selectedPhotoIDs }
            if let id = currentPhotoID { return [id] }
            return []
        }()
        guard !ids.isEmpty else { return }
        
        // Determine per URL-key what the updated tag set should be
        var updatedByKey: [String: Set<ColorTag>] = [:]
        var representativeURLByKey: [String: URL] = [:]
        
        for p in photos where ids.contains(p.id) {
            let key = p.url.isFileURL ? p.url.standardizedFileURL.path : p.url.absoluteString
            if updatedByKey[key] != nil { continue }
            representativeURLByKey[key] = p.url
            
            var tags = p.colorTags
            if tags.contains(tag) { tags.remove(tag) } else { tags.insert(tag) }
            updatedByKey[key] = tags
        }
        
        guard !updatedByKey.isEmpty else { return }
        
        for p in photos {
            let key = p.url.isFileURL ? p.url.standardizedFileURL.path : p.url.absoluteString
            if let tags = updatedByKey[key] {
                p.colorTags = tags
            }
        }
        
        // Persist (lokal, sandbox-safe)
        for (key, url) in representativeURLByKey {
            if let tags = updatedByKey[key] {
                saveLocalColorTags(tags, for: url)
            }
        }
        
        objectWillChange.send()
        updateFilteredPhotos()
    }
    
    // MARK: - Batch Keywords
    
    /// Batch: fügt Keywords zur Auswahl hinzu (ohne bestehende Keywords zu überschreiben).
    @MainActor
    func addKeywordsToSelection(from text: String) {
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        
        let adding = parseKeywords(from: trimmed)
        guard !adding.isEmpty else { return }
        
        let ids: Set<UUID> = {
            if !selectedPhotoIDs.isEmpty { return selectedPhotoIDs }
            if let id = currentPhotoID { return [id] }
            return []
        }()
        guard !ids.isEmpty else { return }
        
        for target in photos where ids.contains(target.id) {
            var meta = target.iptcMetadata ?? IPTCMetadata()
            meta.keywords = mergeKeywords(existing: meta.keywords, adding: adding)
            target.iptcMetadata = meta
            
            if canPersistIPTCToFile(target.url) {
                let url = target.url
                let metaCopy = meta
                Task.detached(priority: .background) {
                    try? IPTCMetadataService.shared.writeMetadata(metaCopy, to: url)
                }
            }
        }
        
        objectWillChange.send()
        // Falls der User gerade filtert/sucht, sollen Treffer direkt aktualisieren.
        updateFilteredPhotos()
    }
    
    private func canPersistIPTCToFile(_ url: URL) -> Bool {
        // Photos Library / PhotoKit Items sind read-only (und haben keine file:// URL).
        if currentFolder?.pathExtension.lowercased() == "photoslibrary" { return false }
        if url.scheme?.lowercased() == PHAssetURL.scheme { return false }
        if url.path.lowercased().contains(".photoslibrary/") { return false }
        return url.isFileURL
    }
    
    private func mergeKeywords(existing: [String], adding: [String]) -> [String] {
        var seen = Set(existing.map { $0.trimmingCharacters(in: .whitespacesAndNewlines).lowercased() })
        var out = existing
        for kw in adding {
            let trimmed = kw.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty else { continue }
            let key = trimmed.lowercased()
            guard !seen.contains(key) else { continue }
            seen.insert(key)
            out.append(trimmed)
        }
        return out
    }
    
    private func parseKeywords(from text: String) -> [String] {
        let parts = text.split { ch in
            ch == "," || ch == "\n" || ch == ";" || ch == "\t"
        }
        
        var seen: Set<String> = []
        var out: [String] = []
        out.reserveCapacity(parts.count)
        
        for p in parts {
            let trimmed = p.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !trimmed.isEmpty else { continue }
            let key = trimmed.lowercased()
            guard !seen.contains(key) else { continue }
            seen.insert(key)
            out.append(trimmed)
        }
        
        return out
    }
    
    // MARK: - Export Queue
    
    private var exportQueueIDs: [UUID] = []
    private var exportQueueIDSet: Set<UUID> = []
    private var exportQueueTask: Task<Void, Never>? = nil
    
    /// Anzahl aktuell wartender Elemente in der Queue (nur Pending, ohne das gerade laufende).
    @MainActor
    var exportQueuePendingCount: Int { exportQueueIDs.count }
    
    /// Vorschau der wartenden Queue-Elemente (Dateinamen).
    @MainActor
    func exportQueuePendingNames(limit: Int = 12) -> [String] {
        guard limit > 0 else { return [] }
        let ids = exportQueueIDs.prefix(limit)
        return ids.compactMap { id in
            photos.first(where: { $0.id == id })?.fileName
        }
    }
    
    /// Fügt ein Foto der Export‑Queue hinzu (falls nicht schon in Queue oder bereits exportiert).
    private func enqueueExport(_ photo: PhotoItem) {
        guard exportQueueEnabled else { return }
        guard photo.rating >= exportQueueMinRating else { return }
        guard !photo.isExported else { return }
        
        if exportQueueIDSet.contains(photo.id) { return }
        exportQueueIDs.append(photo.id)
        exportQueueIDSet.insert(photo.id)
        
        startExportQueueIfNeeded()
    }
    
    func cancelExportQueue() {
        exportQueueTask?.cancel()
        exportQueueTask = nil
        exportQueueIDs.removeAll()
        exportQueueIDSet.removeAll()
        isExportQueueRunning = false
        exportQueueProgress = 0.0
        exportQueueProcessedCount = 0
        exportQueueTotalCount = 0
        exportQueueCurrentName = ""
        objectWillChange.send()
    }
    
    /// Entfernt alle wartenden Elemente aus der Queue (ohne Settings zu verändern).
    @MainActor
    func clearExportQueuePending() {
        exportQueueIDs.removeAll()
        exportQueueIDSet.removeAll()
        exportQueueProgress = 0.0
        exportQueueProcessedCount = 0
        exportQueueTotalCount = 0
        exportQueueCurrentName = ""
        objectWillChange.send()
    }
    
    @MainActor
    func clearExportQueueFailures() {
        exportQueueFailures.removeAll()
        objectWillChange.send()
    }
    
    /// Versucht fehlgeschlagene Exports erneut in die Queue zu legen (wenn weiterhin gültig).
    @MainActor
    func retryExportQueueFailures() {
        guard exportQueueEnabled else { return }
        guard !exportQueueFailures.isEmpty else { return }
        
        // Enqueue in der Reihenfolge der Fehler (neueste zuerst)
        let failedIDs = exportQueueFailures.map(\.id)
        for id in failedIDs {
            guard let photo = photos.first(where: { $0.id == id }) else { continue }
            enqueueExport(photo)
        }
        
        // UI aktualisieren
        objectWillChange.send()
    }
    
    private func startExportQueueIfNeeded() {
        guard exportQueueTask == nil else { return }
        guard exportQueueEnabled else { return }
        let hasItems = !exportQueueIDs.isEmpty
        let initialCount = exportQueueIDs.count
        guard hasItems else { return }
        
        // Preconditions
        guard let preset = exportQueuePreset else {
            showAlert(title: "Export‑Queue", message: "Bitte ein Export‑Preset auswählen.")
            exportQueueIDs.removeAll()
            exportQueueIDSet.removeAll()
            return
        }
        guard let dir = exportQueueOutputDirectory else {
            showAlert(title: "Export‑Queue", message: "Bitte einen Ausgabeordner auswählen.")
            exportQueueIDs.removeAll()
            exportQueueIDSet.removeAll()
            return
        }
        
        isExportQueueRunning = true
        exportQueueTotalCount = initialCount
        exportQueueProcessedCount = 0
        exportQueueProgress = 0.0
        exportQueueCurrentName = ""
        
        let accessGranted = dir.startAccessingSecurityScopedResource()
        
        exportQueueTask = Task { [weak self] in
            defer {
                if accessGranted { dir.stopAccessingSecurityScopedResource() }
            }
            guard let self else { return }
            
            while !Task.isCancelled {
                // Nächstes Element aus Queue holen (async-safe via MainActor)
                let (nextID, remainingCount): (UUID?, Int) = await MainActor.run {
                    let nextID: UUID? = self.exportQueueIDs.isEmpty ? nil : self.exportQueueIDs.removeFirst()
                    if let nextID {
                        self.exportQueueIDSet.remove(nextID)
                    }
                    return (nextID, self.exportQueueIDs.count)
                }
                
                guard let nextID else { break }
                
                guard let photo = await MainActor.run(body: { self.photos.first(where: { $0.id == nextID }) }) else {
                    continue
                }
                
                // Skip, falls Rating wieder runtergesetzt wurde oder schon exportiert
                if !self.exportQueueEnabled || photo.rating < self.exportQueueMinRating || photo.isExported {
                    continue
                }
                
                let processedAtStart = await MainActor.run { self.exportQueueProcessedCount }
                let totalNow = max(1, processedAtStart + remainingCount + 1)
                
                await MainActor.run {
                    self.exportQueueCurrentName = photo.fileName
                    self.exportQueueTotalCount = totalNow
                    self.exportQueueProgress = Double(processedAtStart) / Double(totalNow)
                }
                
                do {
                    let outputURL = self.uniqueOutputURL(for: photo, preset: preset, in: dir)
                    try await ExportService.shared.export(
                        photo: photo,
                        preset: preset,
                        to: outputURL,
                        uploadTargets: self.effectiveUploadTargetsForExport
                    ) { progress in
                        DispatchQueue.main.async {
                            let processed = self.exportQueueProcessedCount
                            let total = max(1, self.exportQueueTotalCount)
                            let base = Double(processed) / Double(total)
                            let frac = min(1.0, base + (progress / Double(total)))
                            self.exportQueueProgress = frac
                        }
                    }
                    
                    await MainActor.run {
                        photo.isExported = true
                        // Wenn vorher als Fehler geloggt, entfernen wir es bei Erfolg
                        self.exportQueueFailures.removeAll { $0.id == photo.id }
                    }
                } catch {
                    // Fail-safe: nicht die ganze Queue abbrechen, nur loggen
                    print("Export‑Queue Fehler für \(photo.fileName): \(error)")
                    
                    await MainActor.run {
                        let failure = ExportQueueFailure(
                            id: photo.id,
                            fileName: photo.fileName,
                            message: error.localizedDescription,
                            date: Date()
                        )
                        self.exportQueueFailures.insert(failure, at: 0)
                        if self.exportQueueFailures.count > 50 {
                            self.exportQueueFailures = Array(self.exportQueueFailures.prefix(50))
                        }
                    }
                }
                
                await MainActor.run {
                    self.exportQueueProcessedCount += 1
                    // Total dynamisch: bereits verarbeitet + noch in Queue
                    let remaining = self.exportQueueIDs.count
                    let total = max(1, self.exportQueueProcessedCount + remaining)
                    self.exportQueueTotalCount = total
                    self.exportQueueProgress = Double(self.exportQueueProcessedCount) / Double(total)
                }
            }
            
            await MainActor.run {
                self.exportQueueCurrentName = ""
                self.isExportQueueRunning = false
                self.exportQueueTask = nil
                
                // Reset progress if queue finished (keeps UI clean)
                if !self.exportQueueEnabled {
                    self.exportQueueProgress = 0.0
                    self.exportQueueProcessedCount = 0
                    self.exportQueueTotalCount = 0
                }
            }
        }
    }
    
    private func uniqueOutputURL(for photo: PhotoItem, preset: ExportPreset, in directory: URL) -> URL {
        let fileName = buildFileName(for: photo, preset: preset)
        var candidate = directory.appendingPathComponent(fileName)
        
        let fm = FileManager.default
        if !fm.fileExists(atPath: candidate.path) { return candidate }
        
        let base = (fileName as NSString).deletingPathExtension
        let ext = (fileName as NSString).pathExtension
        var i = 2
        while fm.fileExists(atPath: candidate.path) {
            candidate = directory.appendingPathComponent("\(base)-\(i).\(ext)")
            i += 1
        }
        return candidate
    }
    
    func checkAndExportQueue() {
        // Fallback/Manuell: scanne alle passenden Fotos und enqueu sie.
        let candidates = photos.filter { $0.rating >= exportQueueMinRating }
        for photo in candidates {
            enqueueExport(photo)
        }
    }
    
    // MARK: - Preset Management (Export, Adjustment, etc.)
    
    func loadExportPresets() {
        if let data = UserDefaults.standard.data(forKey: "exportPresets"),
           let decoded = try? JSONDecoder().decode([ExportPreset].self, from: data) {
            exportPresets = decoded
            migrateBuiltinWatermarkDefaultsIfNeeded()
        } else {
            exportPresets = ExportPreset.defaultPresets
            saveExportPresets()
        }
    }
    
    /// Migration: alte Default-Watermark-Grösse (10%) auf neuen Default (6%) umstellen,
    /// aber nur wenn das Preset ansonsten noch exakt dem alten Default entspricht.
    private func migrateBuiltinWatermarkDefaultsIfNeeded() {
        var changed = false
        
        for i in exportPresets.indices {
            guard var wm = exportPresets[i].watermarkSettings else { continue }
            guard isLegacyDefaultWatermark(wm) else { continue }
            wm.size = WatermarkSettings.default.size // 0.06
            exportPresets[i].watermarkSettings = wm
            changed = true
        }
        
        if changed {
            saveExportPresets()
        }
    }
    
    private func isLegacyDefaultWatermark(_ wm: WatermarkSettings) -> Bool {
        // Old default values (before we switched to 6%):
        // - bottom-right, size 0.10, text "© Blaurock Sportpix", textSize 0.03, opacity 0.8
        // Hinweis: Einige Nutzer haben später den Typ (Text/Logo/Both) geändert,
        // aber die Grösse blieb auf 10%. Wir migrieren daher unabhängig vom Typ/Logo,
        // solange die übrigen Default-Werte noch passen.
        let eps = 0.000_1
        let d = WatermarkSettings.default
        
        let wmText = wm.text ?? d.text ?? ""
        let dText = d.text ?? ""
        let wmTextSize = wm.textSize ?? d.textSize ?? 0.0
        let dTextSize = d.textSize ?? 0.0
        
        return wm.position == d.position &&
        abs(wm.size - 0.10) < eps &&
        wmText == dText &&
        abs(wmTextSize - dTextSize) < eps &&
        abs(wm.opacity - d.opacity) < eps
    }
    
    func saveExportPresets() {
        if let encoded = try? JSONEncoder().encode(exportPresets) {
            UserDefaults.standard.set(encoded, forKey: "exportPresets")
        }
    }
    
    // ... etc. for all preset types
    func addExportPreset(_ preset: ExportPreset) {
        exportPresets.append(preset)
        saveExportPresets()
    }
    
    func updateExportPreset(_ preset: ExportPreset) {
        if let index = exportPresets.firstIndex(where: { $0.id == preset.id }) {
            exportPresets[index] = preset
            saveExportPresets()
        }
    }
    
    func deleteExportPreset(_ preset: ExportPreset) {
        exportPresets.removeAll { $0.id == preset.id }
        saveExportPresets()
    }
    func loadAdjustmentPresets() {
        if let data = UserDefaults.standard.data(forKey: "adjustmentPresets"),
           let decoded = try? JSONDecoder().decode([AdjustmentPreset].self, from: data) {
            adjustmentPresets = decoded
            migrateBuiltinAdjustmentPresetsIfNeeded()
        } else {
            // Lade Standard-Presets wenn keine vorhanden
            loadDefaultPresets()
            migrateBuiltinAdjustmentPresetsIfNeeded()
        }
    }

    // MARK: - Built-in Presets (Migration)
    
    private enum BuiltinAdjustmentPresetIDs {
        // Stabiler ID, damit Updates keine Duplikate erzeugen
        static let hallStrongLit: UUID = UUID(uuidString: "5D8C6A8D-6F89-4B0D-AE8D-1A9C8D2A6E3F")!
        static let bwNoirPortrait: UUID = UUID(uuidString: "A9F8D1B0-8B9F-4B7D-9C2E-3AE1C5C9E8D7")!
        static let bwFilmPunch: UUID = UUID(uuidString: "2B34C89A-6E2A-4F2C-9A5B-0A7D2E4B6C11")!
    }
    
    /// Fügt neue, eingebaute Presets zu bestehenden Libraries hinzu (ohne Duplikate).
    private func migrateBuiltinAdjustmentPresetsIfNeeded() {
        var changed = false
        
        let hallAdjustments = PhotoAdjustments(
            exposure: 0.20,       // etwas heller (Indoor/Halle war noch zu dunkel)
            contrast: 1.14,       // knackig, aber nicht "crunchy"
            temperature: -120,    // etwas kühler (Arena/LED)
            tint: 8,              // leichte Magenta-Korrektur gegen Grünstich
            clarity: 0.20,        // crisp
            vibrance: 0.16,       // CIVibrance inputAmount (≈ 16 in LR)
            highlights: -22,      // Highlights schützen (Trikots/LED-Spots)
            shadows: 22,          // Gesichter/Details öffnen (heller)
            whites: -6,           // (Mapping ist grob) daher moderat
            blacks: -5,           // etwas Tiefe, aber nicht zu dunkel
            saturation: 4,        // subtil
            dehaze: 3,            // minimaler Punch
            texture: 12           // Details (Sport)
        )
        
        // B&W – Noir Portrait (dramatischer Schwarz‑Weiß Look, ähnlich "Noir / Regen / hartes Licht")
        // Wichtig: dehaze bleibt 0, weil Dehaze im Pipeline‑Order nach Saturation kommt und sonst wieder Farbe reinbringen könnte.
        let noirAdjustments = PhotoAdjustments(
            exposure: -0.20,
            contrast: 1.40,
            clarity: 0.65,
            highlights: 0,
            shadows: 0,
            whites: 5,
            blacks: 25,
            saturation: -100,
            texture: 28,
            sharpening: 25,
            vignette: 40
        )
        
        // B&W – Film Punch (Import aus XMP: Contrast +40, Highlights -35, Shadows -45, Whites +20, Blacks -55,
        // Texture +35, Clarity +25, Dehaze +12, Sharpening +55, Luminance NR +10, Vignette -18)
        // Hinweis: Tonkurve/Grain/Vignette-Midpoint/Feather werden (noch) nicht abgebildet.
        // Vignette: Lightroom neg. = Abdunkeln; unsere Vignette ist pos. = Abdunkeln → Vorzeichen invertiert.
        let bwFilmPunchAdjustments = PhotoAdjustments(
            exposure: 0.0,
            contrast: 1.40,     // 40 → 1.40
            clarity: 0.25,      // 25 → 0.25
            highlights: -35,
            shadows: -45,
            whites: 20,
            blacks: -55,
            saturation: -100,   // Treatment: BlackAndWhite
            dehaze: 12,
            texture: 35,
            sharpening: 55,
            noiseReduction: 10,
            vignette: 18
        )
        
        // Falls schon vorhanden (stabile ID), bei Bedarf auf neue Defaults migrieren (ohne Duplikate).
        if let idx = adjustmentPresets.firstIndex(where: { $0.id == BuiltinAdjustmentPresetIDs.hallStrongLit }) {
            var updated = adjustmentPresets[idx]
            updated.name = "Halle – stark beleuchtet"
            updated.group = "Sport"
            updated.adjustments = hallAdjustments
            adjustmentPresets[idx] = updated
            changed = true
        }
        
        if !adjustmentPresets.contains(where: { $0.id == BuiltinAdjustmentPresetIDs.hallStrongLit || $0.name == "Halle – stark beleuchtet" }) {
            let preset = AdjustmentPreset(
                id: BuiltinAdjustmentPresetIDs.hallStrongLit,
                name: "Halle – stark beleuchtet",
                group: "Sport",
                adjustments: hallAdjustments
            )
            adjustmentPresets.append(preset)
            changed = true
        }
        
        if let idx = adjustmentPresets.firstIndex(where: { $0.id == BuiltinAdjustmentPresetIDs.bwNoirPortrait }) {
            var updated = adjustmentPresets[idx]
            updated.name = "Noir Portrait"
            updated.group = "B&W"
            updated.adjustments = noirAdjustments
            adjustmentPresets[idx] = updated
            changed = true
        }
        
        if !adjustmentPresets.contains(where: { $0.id == BuiltinAdjustmentPresetIDs.bwNoirPortrait || $0.name == "Noir Portrait" }) {
            let preset = AdjustmentPreset(
                id: BuiltinAdjustmentPresetIDs.bwNoirPortrait,
                name: "Noir Portrait",
                group: "B&W",
                adjustments: noirAdjustments
            )
            adjustmentPresets.append(preset)
            changed = true
        }
        
        if let idx = adjustmentPresets.firstIndex(where: { $0.id == BuiltinAdjustmentPresetIDs.bwFilmPunch }) {
            var updated = adjustmentPresets[idx]
            updated.name = "Film Punch"
            updated.group = "B&W"
            updated.adjustments = bwFilmPunchAdjustments
            adjustmentPresets[idx] = updated
            changed = true
        }
        
        if !adjustmentPresets.contains(where: { $0.id == BuiltinAdjustmentPresetIDs.bwFilmPunch || $0.name == "Film Punch" }) {
            let preset = AdjustmentPreset(
                id: BuiltinAdjustmentPresetIDs.bwFilmPunch,
                name: "Film Punch",
                group: "B&W",
                adjustments: bwFilmPunchAdjustments
            )
            adjustmentPresets.append(preset)
            changed = true
        }
        
        if changed {
            saveAdjustmentPresets()
        }
    }
    
    func saveAdjustmentPresets() {
        if let encoded = try? JSONEncoder().encode(adjustmentPresets) {
            UserDefaults.standard.set(encoded, forKey: "adjustmentPresets")
        }
    }
    
    func addAdjustmentPreset(_ preset: AdjustmentPreset) {
        adjustmentPresets.append(preset)
        if let group = preset.group?.trimmingCharacters(in: .whitespacesAndNewlines),
           !group.isEmpty,
           !presetGroups.contains(group) {
            presetGroups.append(group)
            savePresetGroups()
        }
        saveAdjustmentPresets()
    }
    
    func updateAdjustmentPreset(_ preset: AdjustmentPreset) {
        if let index = adjustmentPresets.firstIndex(where: { $0.id == preset.id }) {
            adjustmentPresets[index] = preset
            if let group = preset.group?.trimmingCharacters(in: .whitespacesAndNewlines),
               !group.isEmpty,
               !presetGroups.contains(group) {
                presetGroups.append(group)
                savePresetGroups()
            }
            saveAdjustmentPresets()
        }
    }
    
    func deleteAdjustmentPreset(_ preset: AdjustmentPreset) {
        adjustmentPresets.removeAll { $0.id == preset.id }
        saveAdjustmentPresets()
    }
    
    // MARK: - Preset Group Management
    
    func loadPresetGroups() {
        if let groups = UserDefaults.standard.stringArray(forKey: "presetGroups") {
            presetGroups = groups
            return
        }
        
        // Default: aus vorhandenen Presets ableiten
        let groupsFromPresets = Set(adjustmentPresets.compactMap { $0.group?.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty })
        presetGroups = groupsFromPresets.sorted()
        savePresetGroups()
    }
    
    func savePresetGroups() {
        UserDefaults.standard.set(presetGroups, forKey: "presetGroups")
    }
    
    func addPresetGroup(_ name: String) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return }
        guard !presetGroups.contains(trimmed) else { return }
        presetGroups.append(trimmed)
        savePresetGroups()
    }
    
    private func loadDefaultPresets() {
        adjustmentPresets = [
            AdjustmentPreset(
                name: "Vivid",
                group: "Farbe",
                adjustments: PhotoAdjustments(
                    exposure: 0.1,
                    contrast: 1.15,
                    clarity: 0.2,
                    vibrance: 0.30,
                    saturation: 25
                )
            ),
            AdjustmentPreset(
                name: "Portrait",
                group: "Portrait",
                adjustments: PhotoAdjustments(
                    exposure: 0.2,
                    contrast: 1.05,
                    temperature: 200,
                    clarity: 0.15,
                    texture: 10
                )
            ),
            AdjustmentPreset(
                name: "Landschaft",
                group: "Stil",
                adjustments: PhotoAdjustments(
                    exposure: 0.1,
                    contrast: 1.2,
                    clarity: 0.3,
                    saturation: 20,
                    dehaze: 15
                )
            ),
            AdjustmentPreset(
                name: "Schwarz-Weiß",
                group: "Stil",
                adjustments: PhotoAdjustments(
                    exposure: 0.1,
                    contrast: 1.3,
                    clarity: 0.25,
                    saturation: -100
                )
            ),
            AdjustmentPreset(
                name: "Warm",
                group: "Farbe",
                adjustments: PhotoAdjustments(
                    temperature: 500,
                    tint: 10,
                    vibrance: 0.20
                )
            ),
            AdjustmentPreset(
                name: "Cool",
                group: "Farbe",
                adjustments: PhotoAdjustments(
                    temperature: -500,
                    tint: -10,
                    vibrance: 0.15
                )
            )
        ]
        saveAdjustmentPresets()
    }
    func loadUploadTargets() {
        if let data = UserDefaults.standard.data(forKey: "uploadTargets"),
           let decoded = try? JSONDecoder().decode([UploadTarget].self, from: data) {
            uploadTargets = decoded
        } else {
            uploadTargets = []
        }
    }
    
    func saveUploadTargets() {
        if let encoded = try? JSONEncoder().encode(uploadTargets) {
            UserDefaults.standard.set(encoded, forKey: "uploadTargets")
        }
    }
    
    func addUploadTarget(_ target: UploadTarget) {
        uploadTargets.append(target)
        saveUploadTargets()
    }
    
    func updateUploadTarget(_ target: UploadTarget) {
        if let index = uploadTargets.firstIndex(where: { $0.id == target.id }) {
            uploadTargets[index] = target
            saveUploadTargets()
        }
    }
    
    func deleteUploadTarget(_ target: UploadTarget) {
        uploadTargets.removeAll { $0.id == target.id }
        saveUploadTargets()
    }
    
    func loadIPTCTemplates() {
        if let data = UserDefaults.standard.data(forKey: "iptcTemplates"),
           let decoded = try? JSONDecoder().decode([IPTCTemplate].self, from: data) {
            iptcTemplates = decoded
        } else {
            iptcTemplates = IPTCTemplate.defaultTemplates
            saveIPTCTemplates()
        }
    }
    
    func saveIPTCTemplates() {
        if let encoded = try? JSONEncoder().encode(iptcTemplates) {
            UserDefaults.standard.set(encoded, forKey: "iptcTemplates")
        }
    }
    
    func addIPTCTemplate(_ template: IPTCTemplate) {
        iptcTemplates.append(template)
        saveIPTCTemplates()
    }
    
    func updateIPTCTemplate(_ template: IPTCTemplate) {
        if let index = iptcTemplates.firstIndex(where: { $0.id == template.id }) {
            iptcTemplates[index] = template
            saveIPTCTemplates()
        }
    }
    
    func deleteIPTCTemplate(_ template: IPTCTemplate) {
        iptcTemplates.removeAll { $0.id == template.id }
        saveIPTCTemplates()
    }
    
    // MARK: - Smart Collections
    
    func loadSmartCollections() {
        if let data = UserDefaults.standard.data(forKey: "smartCollections"),
           let decoded = try? JSONDecoder().decode([SmartCollection].self, from: data) {
            smartCollections = decoded
        } else {
            // Standard Smart Collections
            smartCollections = [
                SmartCollection(name: "Picks", criteria: SmartCollectionCriteria(pickStatus: .pick)),
                SmartCollection(name: "5 Sterne", criteria: SmartCollectionCriteria(minRating: 5, maxRating: 5)),
                SmartCollection(name: "Mit Adjustments", criteria: SmartCollectionCriteria(hasAdjustments: true)),
                SmartCollection(name: "Quick Collection", criteria: SmartCollectionCriteria(isInQuickCollection: true))
            ]
            saveSmartCollections()
        }
    }
    
    func saveSmartCollections() {
        if let encoded = try? JSONEncoder().encode(smartCollections) {
            UserDefaults.standard.set(encoded, forKey: "smartCollections")
        }
    }
    
    func addSmartCollection(_ collection: SmartCollection) {
        smartCollections.append(collection)
        saveSmartCollections()
    }
    
    func updateSmartCollection(_ collection: SmartCollection) {
        if let index = smartCollections.firstIndex(where: { $0.id == collection.id }) {
            smartCollections[index] = collection
            saveSmartCollections()
        }
    }
    
    func deleteSmartCollection(_ collection: SmartCollection) {
        smartCollections.removeAll { $0.id == collection.id }
        saveSmartCollections()
    }
    
    /// Filtert Photos basierend auf Smart Collection Kriterien
    func filterPhotos(by collection: SmartCollection) -> [PhotoItem] {
        return photos.filter { collection.matches($0) }
    }
    
    // MARK: - AI Tagging
    
    /// Generiert AI-Keywords für das aktuelle Foto
    func generateAITagsForCurrent() async {
        guard let photo = currentPhoto else { return }
        await generateAITags(for: photo)
    }
    
    /// Startet AI‑Keywords für das aktuelle Foto mit UI‑Progress State (Toolbar).
    func startAITagsForCurrent() {
        // Restart-Behaviour: falls schon laufend, abbrechen und neu starten.
        if isAITaggingRunning {
            cancelAITagging()
        }
        guard let photo = currentPhoto else { return }
        
        aiTaggingTask?.cancel()
        isAITaggingRunning = true
        aiTaggingProcessedCount = 0
        aiTaggingTotalCount = 1
        aiTaggingProgress = 0.0
        aiTaggingCurrentName = photo.fileName
        
        aiTaggingTask = Task {
            await generateAITags(for: photo)
            if Task.isCancelled { return }
            await MainActor.run {
                self.aiTaggingProcessedCount = 1
                self.aiTaggingProgress = 1.0
                self.isAITaggingRunning = false
                self.aiTaggingCurrentName = ""
            }
        }
    }
    
    /// Generiert AI-Keywords für ein bestimmtes Foto
    func generateAITags(for photo: PhotoItem) async {
        if Task.isCancelled { return }
        let keywords = await AITaggingService.shared.generateKeywords(for: photo)
        if Task.isCancelled { return }
        
        await MainActor.run {
            // Füge Keywords zu IPTC Metadata hinzu
            if photo.iptcMetadata == nil {
                photo.iptcMetadata = IPTCMetadata()
            }
            
            // Kombiniere neue Keywords mit existierenden (keine Duplikate)
            var existingKeywords = Set(photo.iptcMetadata?.keywords ?? [])
            for keyword in keywords {
                existingKeywords.insert(keyword)
            }
            
            photo.iptcMetadata?.keywords = Array(existingKeywords).sorted()
            
            // Persistiere IPTC Metadata
            if let iptc = photo.iptcMetadata, !isPhotosLibraryContext(photo.url) {
                Task {
                    try? IPTCMetadataService.shared.writeMetadata(iptc, to: photo.url)
                }
            }
            
            objectWillChange.send()
        }
    }
    
    /// Batch AI-Tagging für ausgewählte Fotos
    func generateAITagsForSelection(progress: @escaping (Int, Int) -> Void) async {
        let selectedPhotos = photos.filter { selectedPhotoIDs.contains($0.id) }
        guard !selectedPhotos.isEmpty else { return }
        if Task.isCancelled { return }
        
        let results = await AITaggingService.shared.generateKeywordsBatch(for: selectedPhotos, progress: progress)
        if Task.isCancelled { return }
        
        await MainActor.run {
            for photo in selectedPhotos {
                if let keywords = results[photo.id], !keywords.isEmpty {
                    if photo.iptcMetadata == nil {
                        photo.iptcMetadata = IPTCMetadata()
                    }
                    
                    var existingKeywords = Set(photo.iptcMetadata?.keywords ?? [])
                    for keyword in keywords {
                        existingKeywords.insert(keyword)
                    }
                    
                    photo.iptcMetadata?.keywords = Array(existingKeywords).sorted()
                    
                    // Persistiere IPTC Metadata
                    if let iptc = photo.iptcMetadata, !isPhotosLibraryContext(photo.url) {
                        Task {
                            try? IPTCMetadataService.shared.writeMetadata(iptc, to: photo.url)
                        }
                    }
                }
            }
            
            objectWillChange.send()
        }
    }
    
    /// Startet Batch AI‑Keywords für die aktuelle Auswahl mit UI‑Progress State (Toolbar).
    func startAITagsForSelection() {
        // Restart-Behaviour: falls schon laufend, abbrechen und neu starten.
        if isAITaggingRunning {
            cancelAITagging()
        }
        let selectedCount = selectedPhotoIDs.count
        guard selectedCount > 0 else { return }
        
        aiTaggingTask?.cancel()
        isAITaggingRunning = true
        aiTaggingProcessedCount = 0
        aiTaggingTotalCount = selectedCount
        aiTaggingProgress = 0.0
        aiTaggingCurrentName = ""
        
        aiTaggingTask = Task {
            await generateAITagsForSelection { done, total in
                DispatchQueue.main.async {
                    self.aiTaggingProcessedCount = done
                    self.aiTaggingTotalCount = total
                    self.aiTaggingProgress = total > 0 ? Double(done) / Double(total) : 1.0
                }
            }
            await MainActor.run {
                self.isAITaggingRunning = false
                self.aiTaggingCurrentName = ""
            }
        }
    }
    
    // MARK: - Best‑of (Qualität+Auflösung)
    
    /// One‑click Workflow: analysiert die sichtbare Serie (oder Auswahl) und markiert die Top‑Shots als Picks,
    /// danach wird nach Best‑of sortiert (beste zuerst) – ideal für schnelle Redaktion/Delivery.
    func startBestOfWorkflow() {
        startBestOf(desiredSortMode: .bestOfDesc, markTopPicks: true, exportTopPicks: false)
    }
    
    /// Redaktion/Delivery: Best‑of analysieren und die Top‑Picks direkt exportieren (Quick Export Preset + Zielordner).
    @MainActor
    func startBestOfAndExportTopPicks() {
        // Wenn kein Preset oder kein Ordner festgelegt, öffne Dialog
        if quickExportPresetID == nil || quickExportDirectory == nil {
            chooseQuickExportSettingsAndStartBestOf()
            return
        }
        
        startBestOf(desiredSortMode: .bestOfDesc, markTopPicks: true, exportTopPicks: true)
    }
    
    /// Wählt Preset und Ordner aus und startet dann Best-of mit Export
    @MainActor
    private func chooseQuickExportSettingsAndStartBestOf() {
        // Zuerst Preset auswählen, wenn noch keines festgelegt
        if quickExportPresetID == nil {
            // "Keine" ist immer verfügbar, auch wenn keine Presets existieren
            
            // Öffne Preset-Auswahl-Dialog
            let alert = NSAlert()
            alert.messageText = "Export Preset wählen"
            alert.informativeText = "Bitte wählen Sie ein Export Preset (oder 'Keine' für Original-Export):"
            alert.alertStyle = .informational
            
            let presetPicker = NSPopUpButton(frame: NSRect(x: 0, y: 0, width: 300, height: 24))
            presetPicker.addItem(withTitle: "Keine (Original-Export)")
            presetPicker.lastItem?.representedObject = nil as ExportPreset?
            presetPicker.addItem(withTitle: "──────────")
            presetPicker.lastItem?.isEnabled = false
            
            for preset in exportPresets {
                presetPicker.addItem(withTitle: preset.name)
                presetPicker.lastItem?.representedObject = preset
            }
            
            alert.accessoryView = presetPicker
            alert.addButton(withTitle: "Weiter")
            alert.addButton(withTitle: "Abbrechen")
            
            let response = alert.runModal()
            if response == .alertFirstButtonReturn {
                if let selectedPreset = presetPicker.selectedItem?.representedObject as? ExportPreset {
                    quickExportPresetID = selectedPreset.id
                } else {
                    // "Keine" wurde gewählt
                    quickExportPresetID = nil
                }
            } else {
                return // User hat abgebrochen
            }
        }
        
        // Dann Ordner auswählen, wenn noch keiner festgelegt
        if quickExportDirectory == nil {
            let panel = NSOpenPanel()
            panel.canChooseFiles = false
            panel.canChooseDirectories = true
            panel.allowsMultipleSelection = false
            panel.canCreateDirectories = true
            panel.prompt = "Exportieren"
            panel.message = "Wählen Sie einen Zielordner für den Best-of Export"
            
            panel.begin { [weak self] response in
                guard let self = self else { return }
                if response == .OK, let url = panel.url {
                    self.saveBookmark(for: url)
                    self.quickExportDirectory = url
                    
                    // Starte Best-of mit Export nach Ordner-Auswahl
                    self.startBestOf(desiredSortMode: .bestOfDesc, markTopPicks: true, exportTopPicks: true)
                }
            }
        } else {
            // Beides ist bereits festgelegt, starte direkt
            startBestOf(desiredSortMode: .bestOfDesc, markTopPicks: true, exportTopPicks: true)
        }
    }
    
    /// Wird automatisch getriggert, wenn der User auf "Best‑of sortieren" umstellt.
    private func startBestOfIfNeeded(desiredSortMode: PhotoSortMode) {
        guard desiredSortMode == .bestOfDesc || desiredSortMode == .bestOfAsc else { return }
        guard !isBestOfRunning else { return }
        
        let target = bestOfTargetPhotos()
        guard target.count >= 2 else { return }
        
        let ids = Set(target.map(\.id))
        let hasAllScores = ids.allSatisfy { bestOfScoresByID[$0] != nil }
        guard !hasAllScores else { return }
        
        // Sort-only: keine Picks setzen, nur Scores berechnen.
        startBestOf(desiredSortMode: desiredSortMode, markTopPicks: false, exportTopPicks: false)
    }
    
    private func bestOfTargetPhotos() -> [PhotoItem] {
        if selectedPhotoIDs.count > 1 {
            return photos.filter { selectedPhotoIDs.contains($0.id) }
        }
        // Best-Of sollte auf allen Photos im Scope arbeiten, nicht auf gefilterten
        // (sonst würde es z.B. nur auf bereits gefilterten Picks arbeiten, wenn pickStatusFilter aktiv ist)
        // Wir verwenden daher photos statt filteredPhotos, aber wenden andere relevante Filter an
        var scope = photos
        
        // Wende relevante Filter an (aber NICHT pickStatusFilter, damit Best-Of auf allen Photos arbeitet)
        if let uiState = uiState {
            // Smart Collection Filter
            if let activeID = uiState.activeSmartCollectionID,
               let collection = smartCollections.first(where: { $0.id == activeID }) {
                scope = scope.filter { collection.matches($0) }
            }
            
            // Textsuche
            let q = uiState.searchQuery.trimmingCharacters(in: .whitespacesAndNewlines)
            if !q.isEmpty {
                scope = scope.filter { matchesSearch($0, query: q) }
            }
            
            // Quick Collection Filter
            if uiState.showQuickCollectionOnly {
                scope = scope.filter { $0.isInQuickCollection }
            }
        }
        
        return scope
    }
    
    private struct BestOfCandidate: Sendable {
        let id: UUID
        let url: URL
        let name: String
        let pixelArea: Int
        let isRejected: Bool
    }
    
    private func startBestOf(desiredSortMode: PhotoSortMode, markTopPicks: Bool, exportTopPicks: Bool) {
        // Restart-Behaviour: falls schon laufend, abbrechen und neu starten.
        if isBestOfRunning {
            cancelBestOf()
        }
        
        let target = bestOfTargetPhotos()
        guard !target.isEmpty else { return }
        
        // Kandidaten (Sendable) vorbereiten – keine PhotoItem Accesses in Background Tasks.
        let candidates: [BestOfCandidate] = target.map { p in
            let w = max(0, p.pixelWidth ?? 0)
            let h = max(0, p.pixelHeight ?? 0)
            return BestOfCandidate(
                id: p.id,
                url: p.url,
                name: p.fileName,
                pixelArea: w * h,
                isRejected: p.pickStatus == .reject
            )
        }
        
        let total = candidates.count
        guard total >= 2 else {
            // Für 1 Bild macht Best‑of keinen Sinn – aber wir setzen Sortierung trotzdem stabil.
            uiState?.sortMode = desiredSortMode
            updateFilteredPhotos()
            return
        }
        
        bestOfTask?.cancel()
        bestOfScoresByID = [:]
        bestOfOverlayByID = [:]
        
        isBestOfRunning = true
        bestOfProcessedCount = 0
        bestOfTotalCount = total
        bestOfProgress = 0.0
        bestOfCurrentName = ""
        
        let maxArea = candidates.map(\.pixelArea).max() ?? 0
        let pickCountSetting = max(1, AppSettings.shared.bestOfPickCount)
        
        // Qualität+Auflösung auch bei sehr grossen Serien (z.B. 600+ Hockeybilder):
        // - Für grosse Sets nutzen wir den schnellen Sharpness‑Only Score (kein Vision), sonst Full Score.
        let useFastQuality: Bool = (total > 220)
        
        bestOfTask = Task(priority: .userInitiated) { [weak self] in
            guard let self else { return }
            if Task.isCancelled { return }
            
            var qualityRawByID: [UUID: Double] = [:]
            qualityRawByID.reserveCapacity(total)
            
            let qualityModeKey: String = {
                if useFastQuality { return "quick" }
                return AppSettings.shared.bestShotScoringMode
            }()
            
            let now = Date().timeIntervalSince1970
            var qualityCache = loadBestOfQualityCache()
            
            // Kandidaten in "cached" vs "missing" splitten
            struct MissingRef {
                let ref: BestShotService.PhotoRef
                let name: String
                let persistKey: String
                let pixelArea: Int
            }
            
            var missing: [MissingRef] = []
            missing.reserveCapacity(total)
            
            var cachedCount = 0
            for c in candidates {
                let key = bestOfPersistKey(for: c.url)
                if let entry = qualityCache[key],
                   entry.mode == qualityModeKey,
                   entry.pixelArea == c.pixelArea {
                    qualityRawByID[c.id] = entry.qualityRaw
                    cachedCount += 1
                    // bump usage
                    qualityCache[key] = BestOfQualityEntry(
                        qualityRaw: entry.qualityRaw,
                        pixelArea: entry.pixelArea,
                        mode: entry.mode,
                        updatedAt: now
                    )
                } else {
                    missing.append(
                        MissingRef(
                            ref: BestShotService.PhotoRef(id: c.id, url: c.url),
                            name: c.name,
                            persistKey: key,
                            pixelArea: c.pixelArea
                        )
                    )
                }
            }
            
            await MainActor.run {
                self.bestOfProcessedCount = cachedCount
                self.bestOfTotalCount = total
                self.bestOfProgress = total > 0 ? Double(cachedCount) / Double(total) : 1.0
                self.bestOfCurrentName = ""
            }
            
            let maxConcurrent = useFastQuality ? 6 : 4
            var nextIndex = 0
            
            await withTaskGroup(of: (UUID, Double, String, String, Int).self) { group in
                func addNext() {
                    guard nextIndex < missing.count else { return }
                    let item = missing[nextIndex]
                    nextIndex += 1
                    group.addTask {
                        let s = useFastQuality
                            ? await BestShotService.shared.quickScore(for: item.ref)
                            : await BestShotService.shared.score(for: item.ref)
                        return (item.ref.id, s, item.name, item.persistKey, item.pixelArea)
                    }
                }
                
                for _ in 0..<min(maxConcurrent, missing.count) {
                    addNext()
                }
                
                var done = cachedCount
                while let (id, score, name, persistKey, pxArea) = await group.next() {
                    if Task.isCancelled {
                        group.cancelAll()
                        break
                    }
                    qualityRawByID[id] = score
                    qualityCache[persistKey] = BestOfQualityEntry(
                        qualityRaw: score,
                        pixelArea: pxArea,
                        mode: qualityModeKey,
                        updatedAt: now
                    )
                    done += 1
                    
                    await MainActor.run {
                        self.bestOfProcessedCount = done
                        self.bestOfTotalCount = total
                        self.bestOfProgress = total > 0 ? Double(done) / Double(total) : 1.0
                        self.bestOfCurrentName = name
                    }
                    
                    addNext()
                }
            }
            
            if Task.isCancelled { return }
            
            // Cache persistieren (prune, dann speichern)
            pruneBestOfQualityCacheIfNeeded(&qualityCache)
            saveBestOfQualityCache(qualityCache)
            
            // Quality normalization (0..1)
            let qValues = Array(qualityRawByID.values)
            let qMin = qValues.min() ?? 0
            let qMax = qValues.max() ?? 0
            let qDenom = max(0.000001, qMax - qMin)
            
            func qNorm(for id: UUID) -> Double {
                let v = qualityRawByID[id] ?? qMin
                if qMax - qMin < 0.000001 { return 0.5 } // alles gleich → neutral
                return max(0.0, min(1.0, (v - qMin) / qDenom))
            }
            
            // Final score: Resolution (dominant) + optional Quality tie-breaker
            var scores: [UUID: Double] = [:]
            scores.reserveCapacity(total)
            var overlays: [UUID: BestOfOverlayInfo] = [:]
            overlays.reserveCapacity(total)
            for c in candidates {
                let resNorm = maxArea > 0 ? Double(c.pixelArea) / Double(maxArea) : 0.0
                let qual = qNorm(for: c.id)
                // Auflösung hat Priorität; Qualität ist Tie‑Breaker (v.a. wenn alle gleiche Auflösung haben).
                let final = (resNorm * 0.85 + qual * 0.15)
                scores[c.id] = final
                
                overlays[c.id] = BestOfOverlayInfo(
                    scoreFraction: final,
                    resolutionFraction: resNorm,
                    sharpnessFraction: qual,
                    pixelArea: c.pixelArea,
                    usedFastQuality: useFastQuality
                )
            }
            
            if Task.isCancelled { return }
            
            await MainActor.run {
                self.bestOfScoresByID = scores
                self.bestOfOverlayByID = overlays
                self.isBestOfRunning = false
                self.bestOfProgress = 1.0
                self.bestOfCurrentName = ""
                
                // Sortierung setzen/halten
                self.uiState?.sortMode = desiredSortMode
                self.objectWillChange.send()
                self.updateFilteredPhotos()
            }
            
            if markTopPicks {
                let eligible = candidates.filter { !$0.isRejected }
                guard !eligible.isEmpty else { return }
                
                let topCount = min(eligible.count, pickCountSetting)
                
                let topIDs = eligible
                    .sorted { (scores[$0.id] ?? 0) > (scores[$1.id] ?? 0) }
                    .prefix(topCount)
                    .map(\.id)
                
                await MainActor.run {
                    self.applyBestOfPickMarks(topIDs: topIDs)
                    
                    // Fokus auf den besten Shot (schneller "Senden" Workflow)
                    if let first = topIDs.first {
                        self.currentPhotoID = first
                        if self.uiState?.selectionMode == true {
                            self.selectedPhotoIDs.insert(first)
                        } else {
                            self.selectedPhotoIDs = [first]
                        }
                    }
                }
                
                if exportTopPicks {
                    // Direkt exportieren (Quick Export Preset + Zielordner) – ohne manuelles Filtern.
                    let exportList: [PhotoItem] = await MainActor.run {
                        let set = Set(topIDs)
                        return self.photos.filter { set.contains($0.id) }
                    }
                    await self.quickExport(photos: exportList)
                }
            }
        }
    }
    
    private func applyBestOfPickMarks(topIDs: [UUID]) {
        let set = Set(topIDs)
        guard !set.isEmpty else { return }
        
        // Batch update (nur einmal refresh)
        for photo in photos where set.contains(photo.id) {
            if photo.pickStatus == .reject { continue }
            photo.pickStatus = .pick
        }
        
        objectWillChange.send()
        updateFilteredPhotos()
    }
}

