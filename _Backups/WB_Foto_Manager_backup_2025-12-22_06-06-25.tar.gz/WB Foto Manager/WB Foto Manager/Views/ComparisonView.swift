//
//  ComparisonView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit

private enum BestShotGroupKind: Equatable {
    case selection(totalSelected: Int, shown: Int)
    case burst(totalBurst: Int, shown: Int)
    case compareStrip(shown: Int)
    
    var isActionable: Bool {
        switch self {
        case .selection, .burst: return true
        case .compareStrip: return false
        }
    }
    
    var icon: String {
        switch self {
        case .selection: return "checkmark.circle"
        case .burst: return "bolt.fill"
        case .compareStrip: return "rectangle.stack"
        }
    }
    
    var title: String {
        switch self {
        case .selection: return "Auswahl"
        case .burst: return "Burst"
        case .compareStrip: return "Vergleich"
        }
    }
    
    var detailText: String {
        switch self {
        case .selection(let total, let shown):
            return total > shown ? "\(shown)/\(total)" : "\(shown)"
        case .burst(let total, let shown):
            return total > shown ? "\(shown)/\(total)" : "\(shown)"
        case .compareStrip(let shown):
            return "\(shown)"
        }
    }
}

private struct BestShotGroup {
    let kind: BestShotGroupKind
    let main: PhotoItem
    let others: [PhotoItem]
    
    var all: [PhotoItem] { [main] + others }
}

private struct BestShotTaskID: Equatable {
    let kind: BestShotGroupKind
    let ids: [UUID]
}

private struct BestShotHelpPopover: View {
    @StateObject private var settings = AppSettings.shared
    let groupKind: BestShotGroupKind
    
    private var modeText: String {
        settings.bestShotScoringMode == "portrait" ? "Portrait/People" : "Sport/Action"
    }
    
    private var groupText: String {
        switch groupKind {
        case .selection:
            return "Auswahl"
        case .burst:
            return "Burst"
        case .compareStrip:
            return "Vergleich (nächste Fotos)"
        }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Smart Culling – AI BEST")
                .font(DesignSystem.Fonts.semibold(size: 14))
                .foregroundColor(DesignSystem.Colors.text)
            
            HStack(spacing: 10) {
                Text("Gruppe: \(groupText)")
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text2)
                Spacer(minLength: 0)
                Text("Modus: \(modeText)")
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text2)
            }
            
            Divider()
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Was bedeutet „AI BEST“?")
                    .font(DesignSystem.Fonts.medium(size: 12))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Text("AI BEST ist ein Vorschlag der App (lokal/offline), basierend auf Schärfe + Motiv‑Prominenz (Sport) bzw. zusätzlich Gesicht (Portrait).")
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text2)
            }
            
            VStack(alignment: .leading, spacing: 8) {
                Text("Was macht „BEST → Pick“?")
                    .font(DesignSystem.Fonts.medium(size: 12))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Text("Setzt den AI‑BEST Shot auf Pick (P) und setzt den Rest auf Unflag (U). Es wird nichts gelöscht – nur Markierungen werden gesetzt.")
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text2)
            }
            
            if !groupKind.isActionable {
                Divider()
                Text("Hinweis: In „Vergleich“ (Fallback: nächste Fotos) ist AI BEST deaktiviert. Nutze „Burst auswählen“ oder markiere mehrere Bilder für eine echte Serie/Auswahl.")
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text2)
            }
            
            Divider()
            
            Text("Shortcuts: P = Pick • X = Reject • U = Unflag")
                .font(.system(size: 11, weight: .medium))
                .foregroundColor(DesignSystem.Colors.text3)
        }
        .padding(14)
        .frame(width: 420)
        .lightroomSidebarTheme()
        .background(DesignSystem.Colors.background2)
    }
}

/// Compare/Culling Mode (Lightroom-like): Hauptfoto + Vergleichs-Strip rechts.
struct CompareModeView: View {
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    @State private var bestShotID: UUID?
    
    private var mainPhoto: PhotoItem? { store.currentPhoto }
    private let burstMaxCount: Int = 12
    private let burstWindowSeconds: TimeInterval = 0.8
    
    /// Selected photos in current order (filteredPhotos preserves sorting).
    private var selectedOrdered: [PhotoItem] {
        store.filteredPhotos.filter { store.selectedPhotoIDs.contains($0.id) }
    }
    
    private func bestShotGroup(for main: PhotoItem) -> BestShotGroup? {
        let selectedOthers = selectedOrdered.filter { $0.id != main.id }
        if !selectedOthers.isEmpty {
            let shownOthers = Array(selectedOthers.prefix(12))
            return BestShotGroup(
                kind: .selection(totalSelected: selectedOrdered.count, shown: 1 + shownOthers.count),
                main: main,
                others: shownOthers
            )
        }
        
        // Smart Culling: Burst-Group anhand Aufnahmedatum (sehr nützlich bei Sport/Serien).
        let burstAll = burstGroup(around: main, in: store.filteredPhotos, maxCount: burstMaxCount, windowSeconds: burstWindowSeconds)
        let burstOthers = burstAll.filter { $0.id != main.id }
        if !burstOthers.isEmpty {
            let shownOthers = Array(burstOthers.prefix(burstMaxCount))
            return BestShotGroup(
                kind: .burst(totalBurst: burstAll.count, shown: 1 + shownOthers.count),
                main: main,
                others: shownOthers
            )
        }
        
        // Fallback: wenn keine Mehrfachauswahl aktiv ist, nimm die nächsten Fotos als "Compare Strip".
        // Wichtig: Für "BEST → Pick" ist das KEINE echte Serie (wäre verwirrend/gefährlich).
        if let idx = store.currentPhotoIndexInFiltered {
            let next = Array(store.filteredPhotos.dropFirst(idx + 1).prefix(12))
            if !next.isEmpty {
                return BestShotGroup(
                    kind: .compareStrip(shown: 1 + next.count),
                    main: main,
                    others: next
                )
            }
        }
        
        return nil
    }
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            if let main = mainPhoto {
                if let group = bestShotGroup(for: main) {
                    let candidates = group.others
                    let groupForBestShot = group.all
                    
                    ComparisonView(
                        mainPhoto: main,
                        comparisonPhotos: candidates,
                        bestShotID: bestShotID,
                        store: store
                    )
                    .task(id: BestShotTaskID(kind: group.kind, ids: groupForBestShot.map(\.id))) {
                        // Nur echte Serien/Auswahlen scoren – Compare-Fallback ist rein visuell.
                        guard group.kind.isActionable else {
                            await MainActor.run { self.bestShotID = nil }
                            return
                        }
                        await updateBestShot(for: groupForBestShot)
                    }
                    .overlay(alignment: .topLeading) {
                        CompareTopOverlay(
                            store: store,
                            groupKind: group.kind,
                            bestShotID: bestShotID,
                            groupIDs: groupForBestShot.map(\.id),
                            onSelectBurst: { selectBurst(around: main) }
                        )
                        .padding(10)
                    }
                } else {
                    CompareEmptyStateView(
                        canSelectBurst: burstGroup(around: main, in: store.filteredPhotos, maxCount: burstMaxCount, windowSeconds: burstWindowSeconds).count > 1,
                        onSelectBurst: { selectBurst(around: main) }
                    )
                }
            } else {
                VStack(spacing: 10) {
                    Text("Compare")
                        .font(DesignSystem.Fonts.semibold(size: 18))
                        .foregroundColor(.white)
                    Text("Wähle ein Foto aus, um zu vergleichen.")
                        .font(DesignSystem.Fonts.regular(size: 12))
                        .foregroundColor(.white.opacity(0.75))
                    
                    Button("Zur Grid‑Ansicht") {
                        uiState.viewMode = .grid
                    }
                    .buttonStyle(.borderedProminent)
                }
            }
        }
    }
    
    private func selectBurst(around main: PhotoItem) {
        let burst = burstGroup(around: main, in: store.filteredPhotos, maxCount: burstMaxCount, windowSeconds: burstWindowSeconds)
        guard burst.count > 1 else { return }
        uiState.selectionMode = true
        store.selectedPhotoIDs = Set(burst.map(\.id))
        store.currentPhotoID = main.id
    }
    
    private func updateBestShot(for photos: [PhotoItem]) async {
        // MVP: nur für kleine Gruppen (Burst/Compare Strip)
        guard photos.count >= 2 else {
            await MainActor.run { self.bestShotID = photos.first?.id }
            return
        }
        
        let refs = photos.map { BestShotService.PhotoRef(id: $0.id, url: $0.url) }
        let best = await BestShotService.shared.bestPhotoID(in: refs)
        await MainActor.run { self.bestShotID = best }
    }
}

private struct CompareTopOverlay: View {
    @ObservedObject var store: PhotoStore
    let groupKind: BestShotGroupKind
    let bestShotID: UUID?
    let groupIDs: [UUID]
    let onSelectBurst: () -> Void
    
    @State private var showHelpPopover: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                groupBadge
                legendBadge
                
                Button {
                    showHelpPopover.toggle()
                } label: {
                    Image(systemName: "info.circle")
                }
                .buttonStyle(LightroomSmallButtonStyle())
                .help("Erklärung: AI BEST / BEST → Pick")
                .popover(isPresented: $showHelpPopover, arrowEdge: .bottom) {
                    BestShotHelpPopover(groupKind: groupKind)
                }
            }
            
            HStack(spacing: 8) {
                if groupKind.isActionable {
                    Button(action: cleanupSeries) {
                        Label("BEST → Pick", systemImage: "crown.fill")
                            .font(DesignSystem.Fonts.medium(size: 12))
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(bestShotID == nil || groupIDs.count < 2)
                    .help("AI‑BEST wird als Pick markiert, Rest wird auf Unflag gesetzt")
                    
                    Button(action: jumpToBest) {
                        Label("AI BEST zeigen", systemImage: "eye")
                            .font(DesignSystem.Fonts.medium(size: 12))
                    }
                    .buttonStyle(.bordered)
                    .disabled(bestShotID == nil)
                    .help("Springt zum AI‑BEST Bild in dieser Gruppe")
                    
                    Menu {
                        Button("Nur BEST als Pick (Rest unverändert)") {
                            pickBestOnly()
                        }
                        
                        Divider()
                        
                        Button("Rest als Reject…") { confirmAndRejectRest() }
                            .disabled(groupIDs.count < 2)
                    } label: {
                        Label("Mehr…", systemImage: "ellipsis.circle")
                            .font(DesignSystem.Fonts.medium(size: 12))
                    }
                    .menuStyle(.borderlessButton)
                    .disabled(bestShotID == nil)
                    .help("Weitere Best‑Shot Aktionen")
                } else {
                    hintBadge
                }
                
                Button(action: onSelectBurst) {
                    Label("Burst auswählen", systemImage: "bolt.fill")
                        .font(DesignSystem.Fonts.medium(size: 12))
                }
                .buttonStyle(.bordered)
                .help("Wählt ähnliche Shots rund um das aktuelle Foto (Burst/Serie) aus")
            }
        }
    }
    
    private var groupBadge: some View {
        HStack(spacing: 6) {
            Image(systemName: groupKind.icon)
                .font(.system(size: 11, weight: .semibold))
                .foregroundColor(.white.opacity(0.9))
            Text("\(groupKind.title) • \(groupKind.detailText)")
                .font(DesignSystem.Fonts.medium(size: 11))
                .foregroundColor(.white)
        }
        .lineLimit(1)
        .minimumScaleFactor(0.85)
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(Color.black.opacity(0.55))
        .clipShape(Capsule())
        .overlay(Capsule().stroke(Color.white.opacity(0.10), lineWidth: 1))
    }
    
    private var legendBadge: some View {
        Text("AI BEST = Vorschlag • Pick = Markierung")
            .font(DesignSystem.Fonts.regular(size: 11))
            .foregroundColor(.white.opacity(0.80))
            .lineLimit(1)
            .minimumScaleFactor(0.80)
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(Color.black.opacity(0.40))
            .clipShape(Capsule())
            .overlay(Capsule().stroke(Color.white.opacity(0.08), lineWidth: 1))
    }
    
    private var hintBadge: some View {
        Text("Tipp: ⚡︎ Burst auswählen oder mehrere Bilder markieren → dann kannst du BEST → Pick anwenden.")
            .font(DesignSystem.Fonts.regular(size: 11))
            .foregroundColor(.white.opacity(0.85))
            .lineLimit(2)
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(Color.black.opacity(0.40))
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .overlay(RoundedRectangle(cornerRadius: 10).stroke(Color.white.opacity(0.08), lineWidth: 1))
    }
    
    private func cleanupSeries() {
        applyPickBurst(restStatus: .unflagged)
        jumpToBest()
    }
    
    private func pickBestOnly() {
        guard let id = bestShotID else { return }
        store.setPickStatus(.pick, for: id, autoAdvance: false)
        jumpToBest()
    }
    
    private func jumpToBest() {
        guard let id = bestShotID else { return }
        store.currentPhotoID = id
        switch groupKind {
        case .selection:
            // Multi-Select: Auswahl behalten, aber BEST fokussieren.
            store.selectedPhotoIDs.insert(id)
        case .burst:
            // Single-Select: konsistent bleiben.
            store.selectedPhotoIDs = [id]
        case .compareStrip:
            break
        }
    }
    
    private func applyPickBurst(restStatus: PickStatus) {
        guard let best = bestShotID else { return }
        guard groupIDs.count >= 2 else { return }
        
        store.applyPickBurst(bestID: best, groupIDs: groupIDs, restStatus: restStatus)
    }
    
    private func confirmAndRejectRest() {
        guard let best = bestShotID else { return }
        guard groupIDs.count >= 2 else { return }
        
        let restCount = max(0, groupIDs.count - 1)
        let alert = NSAlert()
        alert.messageText = "Burst aufräumen – Rest als Reject?"
        alert.informativeText = "BEST wird als Pick markiert.\n\(restCount) weiteres Bild(er) werden als Reject markiert.\n\nTipp: Du kannst Rejects später gesammelt löschen."
        alert.alertStyle = .warning
        alert.addButton(withTitle: "Reject setzen")
        alert.addButton(withTitle: "Abbrechen")
        
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        store.applyPickBurst(bestID: best, groupIDs: groupIDs, restStatus: .reject)
        jumpToBest()
    }
}

private struct CompareEmptyStateView: View {
    @EnvironmentObject var uiState: UIState
    let canSelectBurst: Bool
    let onSelectBurst: () -> Void
    
    var body: some View {
        VStack(spacing: 12) {
            Text("Compare / Culling")
                .font(DesignSystem.Fonts.semibold(size: 18))
                .foregroundColor(.white)
            
            Text("Tipp: Aktiviere „Mehrfachauswahl“ und wähle mindestens 2 Fotos aus.\nDann kannst du rechts schnell durch ähnliche Shots klicken.")
                .font(DesignSystem.Fonts.regular(size: 12))
                .foregroundColor(.white.opacity(0.75))
                .multilineTextAlignment(.center)
            
            HStack(spacing: 10) {
                Button("Mehrfachauswahl aktivieren") {
                    uiState.selectionMode = true
                }
                .buttonStyle(.borderedProminent)
                
                if canSelectBurst {
                    Button("Burst auswählen") {
                        onSelectBurst()
                    }
                    .buttonStyle(.bordered)
                }
                
                Button("Zur Grid‑Ansicht") {
                    uiState.viewMode = .grid
                }
                .buttonStyle(.bordered)
            }
        }
        .padding(24)
    }
}

/// Survey Mode (Lightroom-like): mehrere ausgewählte Fotos groß vergleichen.
struct SurveyModeView: View {
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    @State private var bestShotID: UUID?
    
    private var selectedOrdered: [PhotoItem] {
        store.filteredPhotos.filter { store.selectedPhotoIDs.contains($0.id) }
    }
    
    private var columnsCount: Int {
        let n = selectedOrdered.count
        if n <= 1 { return 1 }
        if n == 2 { return 2 }
        if n <= 4 { return 2 }
        if n <= 9 { return 3 }
        return 4
    }
    
    private var grid: [GridItem] {
        Array(repeating: GridItem(.flexible(minimum: 180, maximum: 1000), spacing: 8), count: columnsCount)
    }
    
    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            
            if selectedOrdered.count <= 1 {
                SurveyEmptyStateView(
                    canSelectBurst: (store.currentPhoto != nil) && burstGroup(around: store.currentPhoto!, in: store.filteredPhotos, maxCount: 12, windowSeconds: 0.8).count > 1,
                    onSelectBurst: {
                        if let main = store.currentPhoto {
                            let burst = burstGroup(around: main, in: store.filteredPhotos, maxCount: 12, windowSeconds: 0.8)
                            guard burst.count > 1 else { return }
                            uiState.selectionMode = true
                            store.selectedPhotoIDs = Set(burst.map(\.id))
                            store.currentPhotoID = main.id
                        }
                    }
                )
            } else {
                ScrollView {
                    LazyVGrid(columns: grid, alignment: .center, spacing: 8) {
                        ForEach(selectedOrdered) { photo in
                            SurveyPhotoCell(
                                photo: photo,
                                store: store,
                                isActive: store.currentPhotoID == photo.id,
                                isBest: bestShotID == photo.id
                            )
                            .aspectRatio(1.5, contentMode: .fit)
                            .contentShape(Rectangle())
                            .onTapGesture {
                                let modifiers = NSEvent.modifierFlags
                                store.selectPhoto(photo, withModifiers: modifiers)
                            }
                            .contextMenu {
                                Button("In Detail anzeigen") {
                                    store.selectPhoto(photo, withModifiers: [])
                                    uiState.viewMode = .detail
                                }
                            }
                        }
                    }
                    .padding(10)
                }
                .focusable()
                .task(id: selectedOrdered.map(\.id)) {
                    await updateBestShotForSurvey()
                }
                .overlay(alignment: .topLeading) {
                    SurveyTopOverlay(
                        store: store,
                        bestShotID: bestShotID,
                        groupIDs: selectedOrdered.map(\.id)
                    )
                    .padding(10)
                }
                .onKeyPress(.space) {
                    uiState.viewMode = .detail
                    return .handled
                }
                .onKeyPress("g") {
                    uiState.viewMode = .grid
                    return .handled
                }
            }
        }
    }
    
    private func updateBestShotForSurvey() async {
        // MVP: nur, wenn Auswahl nicht riesig ist (sonst wäre es zu teuer).
        let list = selectedOrdered
        guard list.count >= 2 else {
            await MainActor.run { self.bestShotID = list.first?.id }
            return
        }
        guard list.count <= 24 else {
            await MainActor.run { self.bestShotID = nil }
            return
        }
        
        let refs = list.map { BestShotService.PhotoRef(id: $0.id, url: $0.url) }
        let best = await BestShotService.shared.bestPhotoID(in: refs)
        await MainActor.run { self.bestShotID = best }
    }
}

private struct SurveyEmptyStateView: View {
    @EnvironmentObject var uiState: UIState
    let canSelectBurst: Bool
    let onSelectBurst: () -> Void
    
    var body: some View {
        VStack(spacing: 12) {
            Text("Survey")
                .font(DesignSystem.Fonts.semibold(size: 18))
                .foregroundColor(.white)
            
            Text("Tipp: Aktiviere „Mehrfachauswahl“ und wähle mindestens 2 Fotos aus.\nDann kannst du die Serie groß vergleichen.")
                .font(DesignSystem.Fonts.regular(size: 12))
                .foregroundColor(.white.opacity(0.75))
                .multilineTextAlignment(.center)
            
            HStack(spacing: 10) {
                Button("Mehrfachauswahl aktivieren") { uiState.selectionMode = true }
                    .buttonStyle(.borderedProminent)
                
                if canSelectBurst {
                    Button("Burst auswählen") { onSelectBurst() }
                        .buttonStyle(.bordered)
                }
                
                Button("Zur Grid‑Ansicht") { uiState.viewMode = .grid }
                    .buttonStyle(.bordered)
            }
        }
        .padding(24)
    }
}

private struct SurveyTopOverlay: View {
    @ObservedObject var store: PhotoStore
    let bestShotID: UUID?
    let groupIDs: [UUID]
    
    @State private var showHelpPopover: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                HStack(spacing: 6) {
                    Image(systemName: "checkmark.circle")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(.white)
                    Text("Auswahl • \(groupIDs.count)")
                        .font(DesignSystem.Fonts.semibold(size: 11))
                        .foregroundColor(.white)
                        .shadow(color: .black.opacity(0.8), radius: 2, x: 0, y: 1)
                }
                .lineLimit(1)
                .minimumScaleFactor(0.85)
                .padding(.horizontal, 10)
                .padding(.vertical, 6)
                .background(Color.black.opacity(0.90))
                .clipShape(Capsule())
                .overlay(Capsule().stroke(Color.white.opacity(0.30), lineWidth: 1.5))
                .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                
                Text("AI BEST = Vorschlag • Pick = Markierung")
                    .font(DesignSystem.Fonts.semibold(size: 11))
                    .foregroundColor(.white)
                    .shadow(color: .black.opacity(0.9), radius: 3, x: 0, y: 1.5)
                    .lineLimit(1)
                    .minimumScaleFactor(0.80)
                    .padding(.horizontal, 10)
                    .padding(.vertical, 6)
                    .background(Color.black.opacity(0.90))
                .clipShape(Capsule())
                .overlay(Capsule().stroke(Color.white.opacity(0.30), lineWidth: 1.5))
                .shadow(color: Color.black.opacity(0.5), radius: 4, x: 0, y: 2)
                
                Button {
                    showHelpPopover.toggle()
                } label: {
                    Image(systemName: "info.circle")
                }
                .buttonStyle(LightroomSmallButtonStyle())
                .help("Erklärung: AI BEST / BEST → Pick")
                .popover(isPresented: $showHelpPopover, arrowEdge: .bottom) {
                    BestShotHelpPopover(groupKind: .selection(totalSelected: groupIDs.count, shown: groupIDs.count))
                }
            }
            
            HStack(spacing: 8) {
                Button(action: cleanupSelection) {
                    Label("BEST → Pick", systemImage: "crown.fill")
                        .font(DesignSystem.Fonts.semibold(size: 12))
                        .foregroundColor(.white)
                }
                .buttonStyle(.borderedProminent)
                .disabled(bestShotID == nil || groupIDs.count < 2)
                .help("AI‑BEST wird als Pick markiert, Rest wird auf Unflag gesetzt")
                
                Button(action: jumpToBest) {
                    Label("AI BEST zeigen", systemImage: "eye")
                        .font(DesignSystem.Fonts.semibold(size: 12))
                }
                .buttonStyle(.bordered)
                .disabled(bestShotID == nil)
                .help("Springt zum AI‑BEST Bild in dieser Auswahl")
                
                Menu {
                    Button("Nur BEST als Pick (Rest unverändert)") { pickBestOnly() }
                    
                    Divider()
                    
                    Button("Rest als Reject…") { confirmAndRejectRest() }
                        .disabled(groupIDs.count < 2)
                } label: {
                    Label("Mehr…", systemImage: "ellipsis.circle")
                        .font(DesignSystem.Fonts.semibold(size: 12))
                }
                .menuStyle(.borderlessButton)
                .disabled(bestShotID == nil)
                .help("Weitere Best‑Shot Aktionen")
            }
        }
    }
    
    private func cleanupSelection() {
        applyPickBurst(restStatus: .unflagged)
        jumpToBest()
    }
    
    private func pickBestOnly() {
        guard let id = bestShotID else { return }
        store.setPickStatus(.pick, for: id, autoAdvance: false)
        jumpToBest()
    }
    
    private func jumpToBest() {
        guard let id = bestShotID else { return }
        store.currentPhotoID = id
        store.selectedPhotoIDs.insert(id)
    }
    
    private func applyPickBurst(restStatus: PickStatus) {
        guard let best = bestShotID else { return }
        guard groupIDs.count >= 2 else { return }
        store.applyPickBurst(bestID: best, groupIDs: groupIDs, restStatus: restStatus)
    }
    
    private func confirmAndRejectRest() {
        guard let best = bestShotID else { return }
        guard groupIDs.count >= 2 else { return }
        
        let restCount = max(0, groupIDs.count - 1)
        let alert = NSAlert()
        alert.messageText = "Auswahl aufräumen – Rest als Reject?"
        alert.informativeText = "BEST wird als Pick markiert.\n\(restCount) weiteres Bild(er) werden als Reject markiert.\n\nTipp: Du kannst Rejects später gesammelt löschen."
        alert.alertStyle = .warning
        alert.addButton(withTitle: "Reject setzen")
        alert.addButton(withTitle: "Abbrechen")
        
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        store.applyPickBurst(bestID: best, groupIDs: groupIDs, restStatus: .reject)
        jumpToBest()
    }
}

private struct SurveyPhotoCell: View {
    @ObservedObject var photo: PhotoItem
    @ObservedObject var store: PhotoStore
    let isActive: Bool
    let isBest: Bool
    
    var body: some View {
        ZStack {
            // Medium preview is a sweet spot for fast survey browsing.
            AsyncThumbnailView(photo: photo, previewSize: .medium, interpolation: .high)
                .cornerRadius(8)
            
            PhotoBadgesOverlay(photo: photo, style: .grid, bestOf: store.bestOfOverlayInfo(for: photo.id))
            
            if isBest {
                BestShotBadge()
                    .padding(10)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            }
            
            if photo.pickStatus == .pick {
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color(photo.pickStatus.displayColor).opacity(0.95), lineWidth: 3)
                    .shadow(color: Color(photo.pickStatus.displayColor).opacity(0.35), radius: 10, x: 0, y: 0)
                    .padding(2)
            }
            
            if isBest {
                RoundedRectangle(cornerRadius: 10)
                    .stroke(DesignSystem.Colors.star.opacity(0.95), lineWidth: 3)
                    .shadow(color: DesignSystem.Colors.star.opacity(0.20), radius: 10, x: 0, y: 0)
                    .padding(8)
            }
            
            if isActive {
                RoundedRectangle(cornerRadius: 10)
                    .stroke(DesignSystem.Colors.accent, lineWidth: 3)
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.white.opacity(0.18), lineWidth: 1)
                    .shadow(color: DesignSystem.Colors.accent.opacity(0.35), radius: 10, x: 0, y: 0)
            } else if store.selectedPhotoIDs.contains(photo.id) {
                RoundedRectangle(cornerRadius: 10)
                    .stroke(Color.white.opacity(0.10), lineWidth: 1)
            }
        }
    }
}

struct ComparisonView: View {
    let mainPhoto: PhotoItem
    let comparisonPhotos: [PhotoItem]
    let bestShotID: UUID?
    @ObservedObject var store: PhotoStore
    
    var body: some View {
        HStack(spacing: 4) {
            // Hauptfoto (groß, zoom/pan wie in Detail)
            CompareMainPhotoCell(photo: mainPhoto, store: store, isBest: bestShotID == mainPhoto.id)
                .frame(maxWidth: .infinity)
            
            // Vergleichsfotos
            VStack(spacing: 4) {
                ForEach(comparisonPhotos) { photo in
                    PhotoComparisonCell(photo: photo, store: store, isMain: false, isBest: bestShotID == photo.id)
                        .onTapGesture {
                            let modifiers = NSEvent.modifierFlags
                            store.selectPhoto(photo, withModifiers: modifiers)
                        }
                }
            }
            .frame(width: 200)
        }
        .background(Color.black)
    }
}

// MARK: - Smart Culling helpers

private func burstGroup(
    around main: PhotoItem,
    in list: [PhotoItem],
    maxCount: Int,
    windowSeconds: TimeInterval
) -> [PhotoItem] {
    guard maxCount >= 2 else { return [main] }
    guard let baseDate = main.iptcMetadata?.date else { return [main] }
    
    // Nutze eine Date-sortierte Liste, unabhängig von aktueller UI-Sortierung.
    let sorted = list.sorted { (a, b) in
        let da = a.iptcMetadata?.date ?? Date.distantPast
        let db = b.iptcMetadata?.date ?? Date.distantPast
        if da != db { return da > db }
        return a.fileName < b.fileName
    }
    guard let idx = sorted.firstIndex(where: { $0.id == main.id }) else { return [main] }
    
    func date(_ p: PhotoItem) -> Date? { p.iptcMetadata?.date }
    
    var left = idx
    var right = idx
    
    // Expand left/right by adjacency, stop when time jumps too much.
    while left > 0, (right - left + 1) < maxCount {
        guard let d0 = date(sorted[left]), let dPrev = date(sorted[left - 1]) else { break }
        if abs(dPrev.timeIntervalSince(d0)) <= windowSeconds {
            left -= 1
        } else {
            break
        }
    }
    
    while right < sorted.count - 1, (right - left + 1) < maxCount {
        guard let d0 = date(sorted[right]), let dNext = date(sorted[right + 1]) else { break }
        if abs(dNext.timeIntervalSince(d0)) <= windowSeconds {
            right += 1
        } else {
            break
        }
    }
    
    var group = Array(sorted[left...right])
    
    // If burst is tiny but there are still close photos within window to base date, include them (best-effort).
    if group.count < 2 {
        let extra = sorted.filter { p in
            guard p.id != main.id, let d = p.iptcMetadata?.date else { return false }
            return abs(d.timeIntervalSince(baseDate)) <= windowSeconds
        }
        group = [main] + extra.prefix(max(0, maxCount - 1))
    }
    
    // Ensure main is included.
    if !group.contains(where: { $0.id == main.id }) {
        group.insert(main, at: 0)
    }
    return Array(group.prefix(maxCount))
}

private struct CompareMainPhotoCell: View {
    let photo: PhotoItem
    @ObservedObject var store: PhotoStore
    let isBest: Bool
    @State private var preview: NSImage?
    @State private var loadTask: Task<Void, Never>?
    
    var body: some View {
        ZStack {
            PhotoDetailView(photo: photo, store: store, image: preview)
            
            PhotoBadgesOverlay(photo: photo, style: .grid, bestOf: store.bestOfOverlayInfo(for: photo.id))
                .padding(10)
            
            if isBest {
                BestShotBadge()
                    .padding(10)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            }
            
            if photo.pickStatus == .pick {
                Rectangle()
                    .stroke(Color(photo.pickStatus.displayColor).opacity(0.95), lineWidth: 3)
                    .shadow(color: Color(photo.pickStatus.displayColor).opacity(0.30), radius: 10, x: 0, y: 0)
                    .padding(6)
            }
            
            if isBest {
                Rectangle()
                    .stroke(DesignSystem.Colors.star.opacity(0.95), lineWidth: 3)
                    .shadow(color: DesignSystem.Colors.star.opacity(0.18), radius: 10, x: 0, y: 0)
                    .padding(12)
            }
            
            if store.currentPhotoID == photo.id {
                Rectangle()
                    .stroke(Color.accentColor, lineWidth: 3)
                    .padding(2)
            }
        }
        .onAppear { loadPreview(clear: true) }
        .onChange(of: photo.id) { _, _ in loadPreview(clear: true) }
        .onReceive(NotificationCenter.default.publisher(for: .smartImageLoaderDidUpdate)) { note in
            guard let urlStr = note.userInfo?["url"] as? String,
                  let maxDim = note.userInfo?["maxDim"] as? Int else { return }
            guard urlStr == photo.url.absoluteString else { return }
            // Wenn PhotoKit später ein "final" liefert, refreshen wir ohne Flicker.
            guard maxDim == Int(PreviewSize.large.maxDimension) || maxDim == Int(PreviewSize.medium.maxDimension) else { return }
            loadPreview(clear: false)
        }
        .contentShape(Rectangle())
        .onTapGesture {
            let modifiers = NSEvent.modifierFlags
            store.selectPhoto(photo, withModifiers: modifiers)
        }
    }
    
    private func loadPreview(clear: Bool) {
        loadTask?.cancel()
        if clear { preview = nil }
        
        let url = photo.url
        loadTask = Task(priority: .userInitiated) {
            // Progressive: erst 2K (schnell), dann 4K (schärfer) – klappt auch für Photo Library (PhotoKit).
            let medium = await SmartImageLoader.shared.loadImage(url: url, previewSize: .medium)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                if self.photo.url == url, let medium {
                    self.preview = medium
                }
            }
            
            let large = await SmartImageLoader.shared.loadImage(url: url, previewSize: .large)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                if self.photo.url == url, let large {
                    self.preview = large
                }
            }
        }
    }
}

struct PhotoComparisonCell: View {
    let photo: PhotoItem
    @ObservedObject var store: PhotoStore
    let isMain: Bool
    let isBest: Bool
    @State private var thumbnail: NSImage?
    @State private var loadTask: Task<Void, Never>?
    
    var body: some View {
        ZStack(alignment: .topTrailing) {
            if let thumb = thumbnail {
                Image(nsImage: thumb)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            } else {
                Rectangle()
                    .fill(Color.gray.opacity(0.2))
                    .overlay(ProgressView())
            }
            
            PhotoBadgesOverlay(photo: photo, style: .grid, bestOf: store.bestOfOverlayInfo(for: photo.id))
                .padding(6)
            
            if isBest {
                BestShotBadge()
                    .padding(6)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            }
            
            if photo.pickStatus == .pick {
                Rectangle()
                    .stroke(Color(photo.pickStatus.displayColor).opacity(0.95), lineWidth: 3)
                    .shadow(color: Color(photo.pickStatus.displayColor).opacity(0.28), radius: 8, x: 0, y: 0)
                    .padding(2)
            }
            
            if isBest {
                Rectangle()
                    .stroke(DesignSystem.Colors.star.opacity(0.95), lineWidth: 3)
                    .shadow(color: DesignSystem.Colors.star.opacity(0.16), radius: 8, x: 0, y: 0)
                    .padding(8)
            }
            
            // Selection Indicator
            if store.currentPhotoID == photo.id {
                Rectangle()
                    .stroke(Color.accentColor, lineWidth: isMain ? 4 : 2)
                    .padding(2)
            }
        }
        .frame(maxHeight: isMain ? .infinity : 200)
        .onAppear { loadThumbnail(clear: true) }
        .onChange(of: photo.id) { _, _ in loadThumbnail(clear: true) }
        .onReceive(NotificationCenter.default.publisher(for: .smartImageLoaderDidUpdate)) { note in
            guard let urlStr = note.userInfo?["url"] as? String,
                  let maxDim = note.userInfo?["maxDim"] as? Int else { return }
            guard urlStr == photo.url.absoluteString else { return }
            guard maxDim == Int(PreviewSize.strip.maxDimension) else { return }
            loadThumbnail(clear: false)
        }
    }
    
    private func loadThumbnail(clear: Bool) {
        loadTask?.cancel()
        if clear { thumbnail = nil }
        
        let url = photo.url
        loadTask = Task(priority: .userInitiated) {
            let thumb = await SmartImageLoader.shared.loadImage(url: url, previewSize: .strip)
            guard !Task.isCancelled else { return }
            await MainActor.run {
                if self.photo.url == url {
                    self.thumbnail = thumb
                }
            }
        }
    }
}

private struct BestShotBadge: View {
    var body: some View {
        HStack(spacing: 5) {
            Image(systemName: "crown.fill")
                .font(.system(size: 10, weight: .semibold))
            Text("AI BEST")
                .font(.system(size: 10, weight: .bold))
                .tracking(0.8)
                .shadow(color: .black.opacity(0.6), radius: 2, x: 0, y: 1)
        }
        .foregroundColor(.white)
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(DesignSystem.Colors.accent.opacity(0.95))
        .clipShape(Capsule())
        .overlay(
            Capsule()
                .stroke(Color.white.opacity(0.25), lineWidth: 1)
        )
        .shadow(color: Color.black.opacity(0.50), radius: 8, x: 0, y: 2)
    }
}

