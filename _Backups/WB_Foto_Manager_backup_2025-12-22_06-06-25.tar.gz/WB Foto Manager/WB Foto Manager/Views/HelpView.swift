//
//  HelpView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 16.12.2025.
//

import SwiftUI

struct HelpView: View {
    @Environment(\.dismiss) private var dismiss
    @EnvironmentObject var uiState: UIState
    @State private var selectedSection: HelpSection? = .overview
    
    enum HelpSection: String, CaseIterable {
        case overview = "Übersicht"
        case basics = "Grundlagen"
        case culling = "Culling & Bewertung"
        case editing = "Bildbearbeitung"
        case cropping = "Zuschneiden & Rotation"
        case presets = "Presets & Stil-Profile"
        case export = "Export & Upload"
        case watermark = "Wasserzeichen"
        case jobPresets = "Job/Projekt-Presets"
        case ingest = "Ingest/Import"
        case iptc = "IPTC-Metadaten"
        case smartCollections = "Smart Collections"
        case workflows = "Workflow-Beispiele"
        case shortcuts = "Tastenkürzel"
    }
    
    var body: some View {
        ZStack {
            DesignSystem.Colors.background3
                .ignoresSafeArea()
            
            HStack(spacing: 0) {
                // Sidebar mit Sektionen
                sidebar
                    .frame(width: 220)
                    .background(DesignSystem.Colors.background4)
                
                Divider()
                    .background(DesignSystem.Colors.border)
                
                // Hauptinhalt
                ScrollView {
                    VStack(alignment: .leading, spacing: DesignSystem.Spacing.large) {
                        if let section = selectedSection {
                            sectionContent(for: section)
                        }
                    }
                    .padding(DesignSystem.Spacing.xlarge)
                }
                .frame(maxWidth: .infinity)
                .background(DesignSystem.Colors.background2)
            }
        }
        .frame(width: 1000, height: 700)
        .lightroomSidebarTheme()
    }
    
    private var sidebar: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Header
            VStack(alignment: .leading, spacing: 4) {
                Text("Hilfe & Anleitung")
                    .font(DesignSystem.Fonts.bold(size: 18))
                    .foregroundColor(DesignSystem.Colors.text)
                    .padding(.horizontal, DesignSystem.Spacing.medium)
                    .padding(.top, DesignSystem.Spacing.large)
                
                Text("Betriebsanleitung")
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text3)
                    .padding(.horizontal, DesignSystem.Spacing.medium)
                    .padding(.bottom, DesignSystem.Spacing.medium)
            }
            
            Divider()
                .background(DesignSystem.Colors.border)
            
            // Sektionen-Liste
            ScrollView {
                VStack(alignment: .leading, spacing: 2) {
                    ForEach(HelpSection.allCases, id: \.self) { section in
                        Button(action: {
                            selectedSection = section
                        }) {
                            HStack {
                                Image(systemName: iconForSection(section))
                                    .font(.system(size: 14))
                                    .foregroundColor(selectedSection == section ? DesignSystem.Colors.accent : DesignSystem.Colors.text3)
                                    .frame(width: 20)
                                
                                Text(section.rawValue)
                                    .font(DesignSystem.Fonts.medium(size: 13))
                                    .foregroundColor(selectedSection == section ? DesignSystem.Colors.text : DesignSystem.Colors.text2)
                                
                                Spacer()
                            }
                            .padding(.horizontal, DesignSystem.Spacing.medium)
                            .padding(.vertical, DesignSystem.Spacing.small)
                            .background(selectedSection == section ? DesignSystem.Colors.accent.opacity(0.15) : Color.clear)
                            .cornerRadius(6)
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(.vertical, DesignSystem.Spacing.small)
            }
            
            Spacer()
            
            Divider()
                .background(DesignSystem.Colors.border)
            
            // Footer
            Button(action: { dismiss() }) {
                HStack {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 14))
                    Text("Schließen")
                        .font(DesignSystem.Fonts.medium(size: 13))
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, DesignSystem.Spacing.small)
            }
            .buttonStyle(LightroomSecondaryButtonStyle())
            .padding(.horizontal, DesignSystem.Spacing.medium)
            .padding(.bottom, DesignSystem.Spacing.medium)
        }
    }
    
    @ViewBuilder
    private func sectionContent(for section: HelpSection) -> some View {
        switch section {
        case .overview:
            overviewContent
        case .basics:
            basicsContent
        case .culling:
            cullingContent
        case .editing:
            editingContent
        case .cropping:
            croppingContent
        case .presets:
            presetsContent
        case .export:
            exportContent
        case .watermark:
            watermarkContent
        case .jobPresets:
            jobPresetsContent
        case .ingest:
            ingestContent
        case .iptc:
            iptcContent
        case .smartCollections:
            smartCollectionsContent
        case .workflows:
            workflowsContent
        case .shortcuts:
            shortcutsContent
        }
    }
    
    // MARK: - Section Icons
    private func iconForSection(_ section: HelpSection) -> String {
        switch section {
        case .overview: return "info.circle"
        case .basics: return "book"
        case .culling: return "star.fill"
        case .editing: return "slider.horizontal.3"
        case .cropping: return "crop"
        case .presets: return "square.stack.3d.up"
        case .export: return "square.and.arrow.up"
        case .watermark: return "text.badge.plus"
        case .jobPresets: return "folder.badge.gearshape"
        case .ingest: return "sdcard"
        case .iptc: return "doc.text"
        case .smartCollections: return "tray.2"
        case .workflows: return "flowchart"
        case .shortcuts: return "keyboard"
        }
    }
    
    // MARK: - Content Sections
    
    private var overviewContent: some View {
        VStack(alignment: .leading, spacing: DesignSystem.Spacing.large) {
            HelpSectionHeader(title: "Übersicht", icon: "info.circle")
            
            HelpParagraph {
                Text("Der **WB Foto Manager** ist eine professionelle macOS-Anwendung für die Verwaltung, Bearbeitung und den Export von Fotos, speziell optimiert für Sportfotografie. Die App kombiniert Culling-Funktionen (Bewertung und Auswahl), Bildbearbeitung, IPTC-Metadaten-Verwaltung und Export-Workflows in einer benutzerfreundlichen Oberfläche.")
            }
            
            HelpSubsection(title: "Hauptfunktionen") {
                HelpBulletPoint(icon: "folder", text: "Ordner-Verwaltung mit Finder-ähnlicher Sidebar")
                HelpBulletPoint(icon: "star", text: "Schnelles Culling mit Rating, Pick/Reject und Color Labels")
                HelpBulletPoint(icon: "slider.horizontal.3", text: "Professionelle Bildbearbeitung mit Presets")
                HelpBulletPoint(icon: "chart.bar", text: "Histogramm mit RGB-Kanälen und Clipping-Warnungen")
                HelpBulletPoint(icon: "square.and.arrow.up", text: "Export zu verschiedenen Zielen (Ordner, SFTP, S3, HTTP)")
                HelpBulletPoint(icon: "eye", text: "Export-Vorschau vor dem Export")
                HelpBulletPoint(icon: "doc.text", text: "IPTC-Metadaten-Verwaltung für Agenturen")
                HelpBulletPoint(icon: "tray.2", text: "Smart Collections mit EXIF-basierten Filtern")
                HelpBulletPoint(icon: "sdcard", text: "Ingest/Import-Modus für SD-Karten (RAW+JPG)")
                HelpBulletPoint(icon: "folder.badge.gearshape", text: "Job/Projekt-Presets für wiederkehrende Workflows")
            }
            
            HelpSubsection(title: "Zielgruppe") {
                HelpParagraph {
                    Text("Die App ist speziell für **Sportfotografen** entwickelt, die:")
                }
                HelpBulletPoint(text: "Große Mengen von Fotos schnell bewerten müssen (Culling)")
                HelpBulletPoint(text: "Professionelle Bildbearbeitung benötigen")
                HelpBulletPoint(text: "IPTC-Metadaten für Agenturen verwalten müssen")
                HelpBulletPoint(text: "Verschiedene Export-Formate für verschiedene Zwecke benötigen")
                HelpBulletPoint(text: "Einen effizienten Workflow für Sportveranstaltungen brauchen")
            }
        }
    }
    
    private var basicsContent: some View {
        VStack(alignment: .leading, spacing: DesignSystem.Spacing.large) {
            HelpSectionHeader(title: "Grundlagen", icon: "book")
            
            HelpSubsection(title: "Ordner öffnen") {
                HelpParagraph {
                    Text("Um mit der Arbeit zu beginnen, öffnen Sie einen Ordner mit Fotos:")
                }
                HelpBulletPoint(text: "Klicken Sie auf **\"Ordner öffnen...\"** in der linken Sidebar oder im Menü")
                HelpBulletPoint(text: "Wählen Sie einen Ordner aus dem Dateisystem aus")
                HelpBulletPoint(text: "Die App lädt alle unterstützten Bildformate (JPEG, PNG, HEIC, RAW)")
                HelpBulletPoint(text: "Zuletzt geöffnete Ordner werden in der Sidebar gespeichert")
            }
            
            HelpSubsection(title: "Navigation") {
                HelpParagraph {
                    Text("Navigieren Sie durch Ihre Fotos mit:")
                }
                HelpBulletPoint(icon: "arrow.left", text: "**← / →**: Vorheriges / nächstes Foto")
                HelpBulletPoint(icon: "arrow.up", text: "**↑ / ↓**: In Grid-Ansicht (4 Fotos pro Schritt)")
                HelpBulletPoint(icon: "space", text: "**Leertaste**: Zur Detailansicht (aus Grid)")
                HelpBulletPoint(icon: "grid", text: "**⌃⌘2**: Grid-Ansicht")
                HelpBulletPoint(icon: "square.split.2x1", text: "**⌃⌘3**: Compare / Culling Ansicht")
                HelpBulletPoint(icon: "square.grid.3x3", text: "**⌃⌘4**: Survey Ansicht")
            }
            
            HelpSubsection(title: "Ansichtsmodi") {
                HelpBulletPoint(icon: "photo", text: "**Detail-Ansicht**: Großes Bild mit Zoom (1.0x - 5.0x)")
                HelpBulletPoint(icon: "square.grid.2x2", text: "**Grid-Ansicht**: Rasteransicht mit Miniaturansichten")
                HelpBulletPoint(icon: "square.split.2x1", text: "**Compare-Ansicht**: Zwei Fotos nebeneinander für Culling")
                HelpBulletPoint(icon: "square.grid.3x3", text: "**Survey-Ansicht**: Mehrere Fotos gleichzeitig vergleichen")
            }
            
            HelpSubsection(title: "Layout anpassen") {
                HelpBulletPoint(text: "**⌘\\**: Sidebar links ein/aus")
                HelpBulletPoint(text: "**⌥⌘\\**: Sidebar rechts ein/aus")
                HelpBulletPoint(text: "**⌥⌘F**: Focus-Mode (alle Sidebars ausblenden)")
                HelpBulletPoint(text: "**⌥⌘T**: Topbar ein/aus")
                HelpBulletPoint(text: "**⌥⌘Y**: Filmstreifen ein/aus")
            }
            
            HelpSubsection(title: "Filter & Suche") {
                HelpParagraph {
                    Text("Filtern Sie Fotos nach verschiedenen Kriterien:")
                }
                HelpBulletPoint(text: "**Rating-Filter**: Nach Sterne-Bewertung filtern")
                HelpBulletPoint(text: "**Color Label-Filter**: Nach farbigen Labels filtern")
                HelpBulletPoint(text: "**Pick/Reject-Filter**: Nur Picks oder Rejects anzeigen")
                HelpBulletPoint(text: "**Text-Suche**: Suche in Dateinamen, IPTC-Keywords und AI-Tags")
                HelpBulletPoint(text: "**EXIF-Filter**: Nach Kamera, Objektiv, Brennweite, ISO, Blende, Verschlusszeit")
                HelpBulletPoint(text: "EXIF-Filter werden automatisch geladen, sobald Metadaten verfügbar sind")
            }
        }
    }
    
    private var cullingContent: some View {
        VStack(alignment: .leading, spacing: DesignSystem.Spacing.large) {
            HelpSectionHeader(title: "Culling & Bewertung", icon: "star.fill")
            
            HelpSubsection(title: "Rating (Sterne)") {
                HelpParagraph {
                    Text("Bewerten Sie Fotos mit 1-5 Sternen:")
                }
                HelpBulletPoint(text: "**1-5**: Rating setzen (Tastatur)")
                HelpBulletPoint(text: "**0**: Rating entfernen")
                HelpBulletPoint(text: "Ratings werden in den Bild-Metadaten gespeichert")
            }
            
            HelpSubsection(title: "Pick / Reject") {
                HelpParagraph {
                    Text("Markieren Sie Fotos als Pick (behalten) oder Reject (löschen):")
                }
                HelpBulletPoint(text: "**P**: Als Pick markieren")
                HelpBulletPoint(text: "**X**: Als Reject markieren")
                HelpBulletPoint(text: "**U**: Markierung entfernen")
                HelpBulletPoint(text: "**⌘P**: Nur Picks anzeigen")
                HelpBulletPoint(text: "**⌘X**: Nur Rejects anzeigen")
            }
            
            HelpSubsection(title: "Color Labels") {
                HelpParagraph {
                    Text("Organisieren Sie Fotos mit farbigen Labels:")
                }
                HelpBulletPoint(text: "**6**: Rot toggeln")
                HelpBulletPoint(text: "**7**: Gelb toggeln")
                HelpBulletPoint(text: "**8**: Grün toggeln")
                HelpBulletPoint(text: "**9**: Blau toggeln")
            }
            
            HelpSubsection(title: "Quick Collection") {
                HelpParagraph {
                    Text("Sammeln Sie Fotos temporär in einer Quick Collection:")
                }
                HelpBulletPoint(text: "**B**: Zu Quick Collection hinzufügen/entfernen")
                HelpBulletPoint(text: "**⌘B**: Quick Collection Filter an/aus")
                HelpBulletPoint(text: "**⇧⌘B**: Quick Collection leeren")
            }
            
            HelpSubsection(title: "Culling Queue (Turbo)") {
                HelpParagraph {
                    Text("Schnell durch ungesehene/unbewertete Fotos navigieren:")
                }
                HelpBulletPoint(text: "**⌃⌘N**: Nächstes Unreviewed")
                HelpBulletPoint(text: "**⇧⌃⌘N**: Vorheriges Unreviewed")
                HelpBulletPoint(text: "**⌃⌘R**: Nächstes Unrated")
                HelpBulletPoint(text: "**⌃⌘U**: Nächstes Unflagged")
            }
            
            HelpSubsection(title: "Mehrfachauswahl") {
                HelpParagraph {
                    Text("Wählen Sie mehrere Fotos für Batch-Operationen aus:")
                }
                HelpBulletPoint(text: "**⌘A**: Alle sichtbaren Fotos auswählen")
                HelpBulletPoint(text: "**⌘ + Klick**: Einzelne Fotos auswählen/abwählen")
                HelpBulletPoint(text: "**⇧ + Klick**: Bereich auswählen")
            }
            
            HelpSubsection(title: "Batch-Rating") {
                HelpParagraph {
                    Text("Bewerten Sie mehrere Fotos gleichzeitig:")
                }
                HelpBulletPoint(text: "Wählen Sie mehrere Fotos aus (⌘A oder Mehrfachauswahl)")
                HelpBulletPoint(text: "**⌘0-5**: Rating für Auswahl setzen (0 = entfernen, 1-5 = Sterne)")
                HelpBulletPoint(text: "Oder verwenden Sie das **Batch Rating**-Menü in der Toolbar")
                HelpBulletPoint(text: "Ratings werden für alle ausgewählten Fotos gesetzt")
            }
        }
    }
    
    private var editingContent: some View {
        VStack(alignment: .leading, spacing: DesignSystem.Spacing.large) {
            HelpSectionHeader(title: "Bildbearbeitung", icon: "slider.horizontal.3")
            
            HelpSubsection(title: "Anpassungen") {
                HelpParagraph {
                    Text("Die rechte Sidebar enthält alle Bildbearbeitungs-Tools:")
                }
                HelpBulletPoint(text: "**Exposure**: Helligkeit anpassen")
                HelpBulletPoint(text: "**Kontrast**: Kontrast erhöhen/verringern")
                HelpBulletPoint(text: "**Temperatur**: Farbtemperatur (warm/kalt)")
                HelpBulletPoint(text: "**Tönung**: Grüntönung/Magentatönung")
                HelpBulletPoint(text: "**Sättigung**: Farbsättigung")
                HelpBulletPoint(text: "**Lichter / Schatten**: Helle/dunkle Bereiche anpassen")
                HelpBulletPoint(text: "**Weiß / Schwarz**: Weißpunkt/Schwarzpunkt setzen")
                HelpBulletPoint(text: "**Klarheit**: Struktur und Details verstärken")
                HelpBulletPoint(text: "**Vibrance**: Selektive Sättigung")
            }
            
            HelpSubsection(title: "Auto-Adjustments") {
                HelpParagraph {
                    Text("Lassen Sie die App automatisch optimale Einstellungen berechnen:")
                }
                HelpBulletPoint(text: "**⌥⌘A**: Auto-Adjustments auf aktuelles Foto anwenden")
                HelpBulletPoint(text: "**⇧⌥⌘A**: Auto-Adjustments auf Auswahl anwenden")
                HelpBulletPoint(text: "Kombiniert mit Stil-Profil, wenn aktiviert")
            }
            
            HelpSubsection(title: "Vorher/Nachher") {
                HelpParagraph {
                    Text("Vergleichen Sie das Original mit der bearbeiteten Version:")
                }
                HelpBulletPoint(text: "**⌥⌘B**: Before/After umschalten")
                HelpBulletPoint(text: "Slider auf dem Bild für interaktiven Vergleich")
            }
            
            HelpSubsection(title: "Undo/Redo") {
                HelpBulletPoint(text: "**⌘Z**: Rückgängig")
                HelpBulletPoint(text: "**⇧⌘Z**: Wiederholen")
                HelpBulletPoint(text: "Jedes Foto hat seine eigene Undo-Historie")
            }
            
            HelpSubsection(title: "Einstellungen kopieren/einfügen") {
                HelpBulletPoint(text: "**⇧⌘C**: Einstellungen vom aktuellen Foto kopieren")
                HelpBulletPoint(text: "**⇧⌘V**: Einstellungen auf aktuelles Foto einfügen")
                HelpBulletPoint(text: "**⌥⌘S**: Einstellungen synchronisieren (auf Auswahl anwenden)")
            }
            
            HelpSubsection(title: "Histogramm") {
                HelpParagraph {
                    Text("Das Histogramm zeigt die Tonwertverteilung des Bildes:")
                }
                HelpBulletPoint(text: "Verfügbar in der rechten Sidebar (Histogramm-Tab)")
                HelpBulletPoint(text: "**Kanal-Auswahl**: Luminanz, Rot, Grün, Blau oder RGB (alle Kanäle gleichzeitig)")
                HelpBulletPoint(text: "**RGB-Modus**: Zeigt alle drei Farbkanäle überlagert an")
                HelpBulletPoint(text: "**Clipping-Warnungen**: Zeigt Bereiche, die über- oder unterbelichtet sind")
                HelpBulletPoint(text: "**Reset-Button**: Setzt alle Tone-Anpassungen zurück (Belichtung, Lichter, Schatten, etc.)")
                HelpBulletPoint(text: "**Interaktive Anpassung**: Ziehen Sie im Histogramm, um Tone-Werte direkt anzupassen")
            }
        }
    }
    
    private var croppingContent: some View {
        VStack(alignment: .leading, spacing: DesignSystem.Spacing.large) {
            HelpSectionHeader(title: "Zuschneiden & Rotation", icon: "crop")
            
            HelpSubsection(title: "Zuschneiden") {
                HelpParagraph {
                    Text("Schneiden Sie Fotos mit interaktiven Handles zu:")
                }
                HelpBulletPoint(text: "Öffnen Sie das Crop-Panel in der rechten Sidebar")
                HelpBulletPoint(text: "Ziehen Sie die Ecken oder Kanten des Zuschneide-Rahmens")
                HelpBulletPoint(text: "Verschieben Sie den Rahmen durch Ziehen in der Mitte")
                HelpBulletPoint(text: "Verwenden Sie vordefinierte Seitenverhältnisse (1:1, 4:3, 16:9, etc.)")
            }
            
            HelpSubsection(title: "Seitenverhältnisse") {
                HelpParagraph {
                    Text("Wählen Sie ein Seitenverhältnis aus der Liste:")
                }
                HelpBulletPoint(text: "**Frei**: Beliebiges Seitenverhältnis")
                HelpBulletPoint(text: "**1:1**: Quadratisch")
                HelpBulletPoint(text: "**4:3**: Klassisches Fotoformat")
                HelpBulletPoint(text: "**16:9**: Breitformat")
                HelpBulletPoint(text: "**3:2**: Standard DSLR-Format")
                HelpBulletPoint(text: "Weitere Formate verfügbar")
            }
            
            HelpSubsection(title: "Rotation") {
                HelpParagraph {
                    Text("Drehen Sie Fotos um 90° oder beliebig:")
                }
                HelpBulletPoint(text: "**⌘R**: 90° im Uhrzeigersinn drehen")
                HelpBulletPoint(text: "**⇧⌘R**: 90° gegen Uhrzeigersinn drehen")
                HelpBulletPoint(text: "Manuelle Rotation mit Slider (-180° bis +180°)")
            }
            
            HelpSubsection(title: "Content-Aware Crop") {
                HelpParagraph {
                    Text("Automatisches Zuschneiden basierend auf Bildinhalt (optional):")
                }
                HelpBulletPoint(text: "**Gesichtserkennung**: Automatisches Cropping auf Gesichter")
                HelpBulletPoint(text: "**Zentrum**: Cropping auf Bildmitte mit Skalierung")
                HelpBulletPoint(text: "Kann in den Einstellungen aktiviert/deaktiviert werden")
            }
        }
    }
    
    private var presetsContent: some View {
        VStack(alignment: .leading, spacing: DesignSystem.Spacing.large) {
            HelpSectionHeader(title: "Presets & Stil-Profile", icon: "square.stack.3d.up")
            
            HelpSubsection(title: "Anpassungs-Presets") {
                HelpParagraph {
                    Text("Speichern Sie häufig verwendete Anpassungen als Presets:")
                }
                HelpBulletPoint(text: "Klicken Sie auf **+** in der Presets-Sektion")
                HelpBulletPoint(text: "Oder verwenden Sie den **+** Button in der Anpassungen-Sidebar")
                HelpBulletPoint(text: "Geben Sie einen Namen und optional eine Gruppe ein")
                HelpBulletPoint(text: "Presets können per Hover-Vorschau getestet werden")
            }
            
            HelpSubsection(title: "Stil-Profile") {
                HelpParagraph {
                    Text("Stil-Profile sind vordefinierte Look-Presets für verschiedene Situationen:")
                }
                HelpBulletPoint(text: "Klicken Sie auf **\"Stil-Profil (Pinsel)\"** in der rechten Sidebar")
                HelpBulletPoint(text: "Wählen Sie ein Profil aus der Liste")
                HelpBulletPoint(text: "Zuletzt verwendete Profile erscheinen oben")
                HelpBulletPoint(text: "Hover über ein Profil zeigt eine Vorschau")
                HelpBulletPoint(text: "Profile können aktiviert/deaktiviert werden")
            }
            
            HelpSubsection(title: "Preset-Gruppen") {
                HelpParagraph {
                    Text("Organisieren Sie Presets in Gruppen:")
                }
                HelpBulletPoint(text: "Erstellen Sie Gruppen für verschiedene Kategorien")
                HelpBulletPoint(text: "Gruppen können in der Presets-Sektion erstellt werden")
            }
        }
    }
    
    private var exportContent: some View {
        VStack(alignment: .leading, spacing: DesignSystem.Spacing.large) {
            HelpSectionHeader(title: "Export & Upload", icon: "square.and.arrow.up")
            
            HelpSubsection(title: "Quick Export") {
                HelpParagraph {
                    Text("Schneller Export mit gespeicherten Einstellungen:")
                }
                HelpBulletPoint(text: "**⌘E**: Quick Export (aktuelles Foto oder Auswahl)")
                HelpBulletPoint(text: "Verwendet das gespeicherte Quick Export Preset")
                HelpBulletPoint(text: "Exportiert in den gespeicherten Zielordner")
            }
            
            HelpSubsection(title: "Export-Presets") {
                HelpParagraph {
                    Text("Erstellen Sie Presets für verschiedene Export-Zwecke:")
                }
                HelpBulletPoint(text: "Dimensionen (max. Breite/Höhe)")
                HelpBulletPoint(text: "Qualität (JPEG-Komprimierung)")
                HelpBulletPoint(text: "Format (JPEG, PNG)")
                HelpBulletPoint(text: "Wasserzeichen (optional)")
                HelpBulletPoint(text: "**Dateiname-Templates**: Dynamische Dateinamen mit Variablen")
            }
            
            HelpSubsection(title: "Export-Vorschau") {
                HelpParagraph {
                    Text("Sehen Sie vor dem Export, wie das exportierte Foto aussehen wird:")
                }
                HelpBulletPoint(text: "Die Vorschau zeigt das Foto mit allen Anpassungen, Crops und Wasserzeichen")
                HelpBulletPoint(text: "Automatische Aktualisierung bei Änderung des Presets")
                HelpBulletPoint(text: "Hilft dabei, das richtige Preset zu wählen")
            }
            
            HelpSubsection(title: "Export-Templates (Dateinamen)") {
                HelpParagraph {
                    Text("Erstellen Sie dynamische Dateinamen für Exporte:")
                }
                HelpBulletPoint(text: "Verwenden Sie Variablen wie `{originalname}`, `{date}`, `{rating}`, etc.")
                HelpBulletPoint(text: "EXIF-Variablen: `{camera}`, `{lens}`, `{focal}`, `{iso}`")
                HelpBulletPoint(text: "Batch-Export: `{index}` für fortlaufende Nummerierung")
                HelpBulletPoint(text: "Templates können pro Preset oder global gesetzt werden")
                HelpBulletPoint(text: "Hilfe-Button zeigt alle verfügbaren Variablen")
            }
            
            HelpSubsection(title: "Upload-Ziele") {
                HelpParagraph {
                    Text("Exportieren Sie direkt zu verschiedenen Zielen:")
                }
                HelpBulletPoint(text: "**Lokaler Ordner**: Standard-Export")
                HelpBulletPoint(text: "**SFTP**: Sichere Übertragung per SSH")
                HelpBulletPoint(text: "**FTP**: Klassischer FTP-Upload")
                HelpBulletPoint(text: "**S3**: Amazon S3 oder kompatible Services")
                HelpBulletPoint(text: "**HTTP/API**: Upload zu Web-Services")
                HelpBulletPoint(text: "**Pictrs**: Pictrs-kompatible Uploads")
            }
            
            HelpSubsection(title: "Batch Export") {
                HelpParagraph {
                    Text("Exportieren Sie mehrere Fotos gleichzeitig:")
                }
                HelpBulletPoint(text: "**⇧⌘B**: Batch Export öffnen")
                HelpBulletPoint(text: "Wählen Sie Fotos aus oder verwenden Sie Filter")
                HelpBulletPoint(text: "Wählen Sie Export-Preset und Ziel")
                HelpBulletPoint(text: "Export-Queue zeigt den Fortschritt")
            }
        }
    }
    
    private var watermarkContent: some View {
        VStack(alignment: .leading, spacing: DesignSystem.Spacing.large) {
            HelpSectionHeader(title: "Wasserzeichen", icon: "text.badge.plus")
            
            HelpSubsection(title: "Übersicht") {
                HelpParagraph {
                    Text("Fügen Sie Wasserzeichen zu Ihren Fotos hinzu:")
                }
                HelpBulletPoint(text: "**Text-Wasserzeichen**: Anpassbarer Text")
                HelpBulletPoint(text: "**Logo-Wasserzeichen**: Bild-Logo")
                HelpBulletPoint(text: "**Kombiniert**: Text + Logo zusammen")
            }
            
            HelpSubsection(title: "Konfiguration") {
                HelpParagraph {
                    Text("Konfigurieren Sie Wasserzeichen in den Einstellungen:")
                }
                HelpBulletPoint(text: "**Position**: Oben Links/Rechts, Unten Links/Rechts, Mitte")
                HelpBulletPoint(text: "**Größe**: Relativ zur Bildgröße (5%-50%)")
                HelpBulletPoint(text: "**Text-Größe**: Relativ zur Bildgröße")
                HelpBulletPoint(text: "**Logo-Bibliothek**: Mehrere Logos verwalten")
                HelpBulletPoint(text: "**Vorschau**: Wasserzeichen in Preview sichtbar (optional)")
            }
            
            HelpSubsection(title: "Verwendung") {
                HelpParagraph {
                    Text("Wasserzeichen werden beim Export angewendet:")
                }
                HelpBulletPoint(text: "Aktivieren Sie Wasserzeichen in den Export-Einstellungen")
                HelpBulletPoint(text: "Wählen Sie ein Wasserzeichen-Preset")
                HelpBulletPoint(text: "Wasserzeichen wird automatisch auf alle exportierten Fotos angewendet")
            }
        }
    }
    
    private var jobPresetsContent: some View {
        VStack(alignment: .leading, spacing: DesignSystem.Spacing.large) {
            HelpSectionHeader(title: "Job/Projekt-Presets", icon: "folder.badge.gearshape")
            
            HelpSubsection(title: "Übersicht") {
                HelpParagraph {
                    Text("Job-Presets speichern alle Workflow-Einstellungen für einen Ordner:")
                }
                HelpBulletPoint(text: "Quick Export Preset + Zielordner")
                HelpBulletPoint(text: "Stil-Profil")
                HelpBulletPoint(text: "Job-spezifische Upload-Ziele")
            }
            
            HelpSubsection(title: "Preset speichern") {
                HelpParagraph {
                    Text("Speichern Sie die aktuellen Einstellungen als Job-Preset:")
                }
                HelpBulletPoint(text: "Öffnen Sie den Activity Center (Button in der Topbar)")
                HelpBulletPoint(text: "Klicken Sie auf **\"Speichern\"** in der Job-Preset-Karte")
                HelpBulletPoint(text: "Das Preset wird für den aktuellen Ordner gespeichert")
            }
            
            HelpSubsection(title: "Automatisches Laden") {
                HelpParagraph {
                    Text("Wenn Sie einen Ordner öffnen, der ein Job-Preset hat:")
                }
                HelpBulletPoint(text: "Das Preset wird automatisch geladen")
                HelpBulletPoint(text: "Quick Export Preset und Ziel werden gesetzt")
                HelpBulletPoint(text: "Stil-Profil wird angewendet")
                HelpBulletPoint(text: "Upload-Ziele werden gefiltert (wenn aktiviert)")
            }
            
            HelpSubsection(title: "Preset aktualisieren") {
                HelpParagraph {
                    Text("Aktualisieren Sie ein bestehendes Preset:")
                }
                HelpBulletPoint(text: "Ändern Sie die gewünschten Einstellungen")
                HelpBulletPoint(text: "Klicken Sie auf **\"Aktualisieren\"** im Activity Center")
                HelpBulletPoint(text: "⚠️ Wichtig: Presets werden NUR manuell gespeichert (nicht automatisch)")
            }
        }
    }
    
    private var ingestContent: some View {
        VStack(alignment: .leading, spacing: DesignSystem.Spacing.large) {
            HelpSectionHeader(title: "Ingest/Import", icon: "sdcard")
            
            HelpSubsection(title: "Übersicht") {
                HelpParagraph {
                    Text("Der Ingest-Modus ist speziell für Sportfotografie optimiert:")
                }
                HelpBulletPoint(text: "Kopiert RAW+JPG Dateien von SD-Karte")
                HelpBulletPoint(text: "Öffnet automatisch nur den JPG-Ordner für schnelles Culling")
                HelpBulletPoint(text: "RAW-Dateien bleiben im separaten Ordner verfügbar")
            }
            
            HelpSubsection(title: "Import starten") {
                HelpParagraph {
                    Text("So starten Sie einen Import:")
                }
                HelpBulletPoint(text: "**⌘I**: Ingest/Import öffnen")
                HelpBulletPoint(text: "Oder: Menü > Import > \"Importieren...\"")
                HelpBulletPoint(text: "Wählen Sie die SD-Karte als Quelle")
                HelpBulletPoint(text: "Wählen Sie einen Zielordner")
                HelpBulletPoint(text: "Geben Sie einen Job-Namen ein")
            }
            
            HelpSubsection(title: "Ordnerstruktur") {
                HelpParagraph {
                    Text("Die App erstellt folgende Struktur:")
                }
                HelpBulletPoint(text: "**Job-Name/**: Hauptordner")
                HelpBulletPoint(text: "**Job-Name/JPG/**: JPG-Dateien (wird automatisch geöffnet)")
                HelpBulletPoint(text: "**Job-Name/RAW/**: RAW-Dateien")
            }
            
            HelpSubsection(title: "Workflow") {
                HelpParagraph {
                    Text("Nach dem Import:")
                }
                HelpBulletPoint(text: "Der JPG-Ordner wird automatisch geöffnet")
                HelpBulletPoint(text: "Schnelles Culling mit JPGs (schneller)")
                HelpBulletPoint(text: "Export/SFTP der ausgewählten Fotos")
                HelpBulletPoint(text: "Bei Bedarf: RAW-Dateien für finale Bearbeitung öffnen")
            }
        }
    }
    
    private var iptcContent: some View {
        VStack(alignment: .leading, spacing: DesignSystem.Spacing.large) {
            HelpSectionHeader(title: "IPTC-Metadaten", icon: "doc.text")
            
            HelpSubsection(title: "Übersicht") {
                HelpParagraph {
                    Text("IPTC-Metadaten sind wichtig für die Übergabe an Agenturen:")
                }
                HelpBulletPoint(text: "Copyright-Informationen")
                HelpBulletPoint(text: "Keywords und Beschreibungen")
                HelpBulletPoint(text: "Kontaktinformationen")
                HelpBulletPoint(text: "Lizenz-Informationen")
            }
            
            HelpSubsection(title: "IPTC-Templates") {
                HelpParagraph {
                    Text("Erstellen Sie wiederverwendbare Templates:")
                }
                HelpBulletPoint(text: "Öffnen Sie das IPTC-Panel in der Topbar")
                HelpBulletPoint(text: "Erstellen Sie Templates mit Token-System")
                HelpBulletPoint(text: "Templates können dynamische Werte enthalten")
            }
            
            HelpSubsection(title: "IPTC-Draft") {
                HelpParagraph {
                    Text("Vorbereiten Sie Metadaten für mehrere Fotos:")
                }
                HelpBulletPoint(text: "Erstellen Sie einen IPTC-Draft")
                HelpBulletPoint(text: "Wenden Sie den Draft auf Auswahl an")
                HelpBulletPoint(text: "Metadaten werden in die Bilddateien geschrieben")
            }
            
            HelpSubsection(title: "Auto-Save Metadaten") {
                HelpParagraph {
                    Text("Automatisches Speichern von Metadaten in Bilddateien:")
                }
                HelpBulletPoint(text: "In den Einstellungen kann **Auto-Save Metadaten** aktiviert werden")
                HelpBulletPoint(text: "IPTC-Metadaten werden automatisch in die Bilddateien geschrieben")
                HelpBulletPoint(text: "Achtung: Nur bei Dateiformaten, die Metadaten unterstützen (JPEG, PNG, HEIC)")
                HelpBulletPoint(text: "RAW-Dateien verwenden weiterhin lokale Persistenz")
            }
        }
    }
    
    private var smartCollectionsContent: some View {
        VStack(alignment: .leading, spacing: DesignSystem.Spacing.large) {
            HelpSectionHeader(title: "Smart Collections", icon: "tray.2")
            
            HelpSubsection(title: "Übersicht") {
                HelpParagraph {
                    Text("Smart Collections sind dynamische Sammlungen, die automatisch Fotos basierend auf Kriterien zusammenfassen:")
                }
                HelpBulletPoint(text: "Fotos werden automatisch hinzugefügt/entfernt")
                HelpBulletPoint(text: "Basierend auf Rating, Tags, Metadaten, etc.")
                HelpBulletPoint(text: "Aktualisieren sich automatisch")
            }
            
            HelpSubsection(title: "Erstellen") {
                HelpParagraph {
                    Text("Erstellen Sie eine neue Smart Collection:")
                }
                HelpBulletPoint(text: "Öffnen Sie \"Smart Collections verwalten...\" im Menü")
                HelpBulletPoint(text: "Klicken Sie auf **+\"** um eine neue Collection zu erstellen")
                HelpBulletPoint(text: "Definieren Sie Kriterien (Rating, Tags, Datum, etc.)")
                HelpBulletPoint(text: "Die Collection zeigt automatisch passende Fotos")
            }
            
            HelpSubsection(title: "Kriterien") {
                HelpParagraph {
                    Text("Verwenden Sie verschiedene Kriterien für Smart Collections:")
                }
                HelpBulletPoint(text: "**Rating**: Mindestens X Sterne oder Bereich")
                HelpBulletPoint(text: "**Pick/Reject**: Nur Picks, nur Rejects oder Unflagged")
                HelpBulletPoint(text: "**Color Labels**: Enthält bestimmte Color Labels")
                HelpBulletPoint(text: "**Quick Collection**: In oder nicht in Quick Collection")
                HelpBulletPoint(text: "**Adjustments**: Mit oder ohne Bildbearbeitung")
                HelpBulletPoint(text: "**Crop**: Mit oder ohne Zuschnitt")
            }
            
            HelpSubsection(title: "EXIF-basierte Kriterien") {
                HelpParagraph {
                    Text("Filtern Sie nach Kameradaten und Aufnahmeeinstellungen:")
                }
                HelpBulletPoint(text: "**Kamera-Hersteller**: z.B. Canon, Nikon, Sony")
                HelpBulletPoint(text: "**Kamera-Modell**: z.B. EOS R5, D850")
                HelpBulletPoint(text: "**Objektiv**: z.B. 24-70mm, 70-200mm")
                HelpBulletPoint(text: "**Brennweite**: Bereich in mm (z.B. 24-85mm)")
                HelpBulletPoint(text: "**ISO**: Bereich (z.B. 400-1600)")
                HelpBulletPoint(text: "**Blende**: Bereich (z.B. f/2.8-f/8)")
                HelpBulletPoint(text: "**Verschlusszeit**: Bereich (z.B. 1/250s-1/30s)")
                HelpBulletPoint(text: "Alle Kriterien werden mit UND kombiniert (alle müssen erfüllt sein)")
            }
        }
    }
    
    private var workflowsContent: some View {
        VStack(alignment: .leading, spacing: DesignSystem.Spacing.large) {
            HelpSectionHeader(title: "Workflow-Beispiele", icon: "flowchart")
            
            HelpSubsection(title: "Eishockey-Workflow") {
                HelpParagraph {
                    Text("Typischer Workflow für Eishockey-Fotografie:")
                }
                HelpBulletPoint(text: "1. **Import**: SD-Karte → Job-Ordner (RAW+JPG)")
                HelpBulletPoint(text: "2. **Culling**: JPG-Ordner öffnen, schnell durch Fotos navigieren")
                HelpBulletPoint(text: "3. **Bewertung**: Rating vergeben (1-5), Picks markieren")
                HelpBulletPoint(text: "4. **Bearbeitung**: Stil-Profil anwenden, ggf. anpassen")
                HelpBulletPoint(text: "5. **Export**: Quick Export zu SFTP/Web-Upload")
                HelpBulletPoint(text: "6. **Job-Preset**: Für nächsten Job speichern")
            }
            
            HelpSubsection(title: "Portrait-Workflow") {
                HelpParagraph {
                    Text("Workflow für Portrait-Fotografie:")
                }
                HelpBulletPoint(text: "1. **Ordner öffnen**: Portrait-Session laden")
                HelpBulletPoint(text: "2. **Culling**: Compare-Ansicht für ähnliche Posen")
                HelpBulletPoint(text: "3. **Bearbeitung**: Presets für verschiedene Looks")
                HelpBulletPoint(text: "4. **IPTC**: Metadaten für Agentur vorbereiten")
                HelpBulletPoint(text: "5. **Export**: Verschiedene Formate für verschiedene Zwecke")
            }
            
            HelpSubsection(title: "Batch-Processing") {
                HelpParagraph {
                    Text("Mehrere Fotos gleichzeitig bearbeiten:")
                }
                HelpBulletPoint(text: "1. **Auswahl**: Mehrere Fotos auswählen (⌘A oder Multi-Select)")
                HelpBulletPoint(text: "2. **Synchronisieren**: Einstellungen von einem Foto auf andere übertragen")
                HelpBulletPoint(text: "3. **Auto**: Auto-Adjustments auf Auswahl anwenden")
                HelpBulletPoint(text: "4. **Batch Export**: Alle auf einmal exportieren")
            }
        }
    }
    
    private var shortcutsContent: some View {
        VStack(alignment: .leading, spacing: DesignSystem.Spacing.large) {
            HelpSectionHeader(title: "Tastenkürzel", icon: "keyboard")
            
            HelpParagraph {
                Text("Eine vollständige Liste aller Tastenkürzel finden Sie in der separaten Tastenkürzel-Ansicht.")
            }
            
            Button(action: {
                dismiss()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                    uiState.activeSheet = .shortcutsHelp
                }
            }) {
                HStack {
                    Image(systemName: "keyboard")
                    Text("Tastenkürzel öffnen")
                }
            }
            .buttonStyle(LightroomPrimaryButtonStyle())
        }
    }
}

// MARK: - Helper Views

private struct HelpSectionHeader: View {
    let title: String
    let icon: String
    
    var body: some View {
        HStack(spacing: DesignSystem.Spacing.medium) {
            Image(systemName: icon)
                .font(.system(size: 24))
                .foregroundColor(DesignSystem.Colors.accent)
            
            Text(title)
                .font(DesignSystem.Fonts.bold(size: 24))
                .foregroundColor(DesignSystem.Colors.text)
        }
    }
}

private struct HelpSubsection<Content: View>: View {
    let title: String
    @ViewBuilder let content: Content
    
    var body: some View {
        VStack(alignment: .leading, spacing: DesignSystem.Spacing.medium) {
            Text(title)
                .font(DesignSystem.Fonts.semibold(size: 18))
                .foregroundColor(DesignSystem.Colors.text)
            
            content
        }
        .padding(DesignSystem.Spacing.large)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.large)
        .overlay(
            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.large)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
    }
}

private struct HelpParagraph<Content: View>: View {
    @ViewBuilder let content: Content
    
    var body: some View {
        content
            .font(DesignSystem.Fonts.regular(size: 14))
            .foregroundColor(DesignSystem.Colors.text2)
            .lineSpacing(4)
    }
}

private struct HelpBulletPoint: View {
    var icon: String? = nil
    let text: String
    
    var body: some View {
        HStack(alignment: .top, spacing: DesignSystem.Spacing.small) {
            if let icon = icon {
                Image(systemName: icon)
                    .font(.system(size: 12))
                    .foregroundColor(DesignSystem.Colors.accent)
                    .frame(width: 16)
            } else {
                Circle()
                    .fill(DesignSystem.Colors.accent)
                    .frame(width: 6, height: 6)
                    .padding(.top, 6)
                    .padding(.leading, 5)
            }
            
            Text(.init(text))
                .font(DesignSystem.Fonts.regular(size: 14))
                .foregroundColor(DesignSystem.Colors.text2)
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.vertical, 2)
    }
}

