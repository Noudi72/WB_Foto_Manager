//
//  AsyncThumbnailView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI

struct AsyncThumbnailView: View {
    let photo: PhotoItem
    let previewSize: PreviewSize
    let interpolation: Image.Interpolation
    
    @State private var image: NSImage?
    
    init(photo: PhotoItem, previewSize: PreviewSize, interpolation: Image.Interpolation = .medium) {
        self.photo = photo
        self.previewSize = previewSize
        self.interpolation = interpolation
    }
    
    var body: some View {
        Group {
            if let img = image {
                Image(nsImage: img)
                    .interpolation(interpolation)
                    .resizable()
                    .aspectRatio(contentMode: .fill)
            } else {
                // Show a placeholder, but also show a progress ring
                // that reflects the overall preview generation progress.
                ZStack {
                    Rectangle().fill(DesignSystem.Colors.background3)
                    ProgressView()
                        .progressViewStyle(.circular)
                        .controlSize(.small)
                        .frame(width: 14, height: 14)
                }
            }
        }
        .clipped()
        .onAppear(perform: loadImage)
        .onChange(of: photo.id) { _, _ in
            loadImage()
        }
        .onReceive(NotificationCenter.default.publisher(for: .smartImageLoaderDidUpdate)) { note in
            guard let urlStr = note.userInfo?["url"] as? String,
                  let maxDim = note.userInfo?["maxDim"] as? Int else { return }
            guard urlStr == photo.url.absoluteString else { return }
            guard maxDim == Int(previewSize.maxDimension) else { return }
            loadImage()
        }
    }
    
    private func loadImage() {
        image = nil
        Task(priority: .userInitiated) {
            let loaded = await SmartImageLoader.shared.loadImage(url: photo.url, previewSize: previewSize)
            
            await MainActor.run {
                self.image = loaded
            }
        }
    }
}
