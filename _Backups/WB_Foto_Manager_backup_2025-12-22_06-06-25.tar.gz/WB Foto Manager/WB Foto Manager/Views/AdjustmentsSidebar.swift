//
//  AdjustmentsSidebar.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import Combine

struct AdjustmentsSidebar: View {
    @ObservedObject var store: PhotoStore
    @State private var selectedTab: AdjustmentTab = .adjustments
    @StateObject private var settings = AppSettings.shared
    @State private var showStyleProfilePopover: Bool = false
    @State private var showSavePresetPopover: Bool = false
    
    enum AdjustmentTab: String, CaseIterable {
        case adjustments = "Anpassungen"
        case masking = "Masken"
        case presets = "Presets"
        case crop = "Zuschnitt"
        case histogram = "Histogram"
        case iptc = "IPTC"
        case watermark = "Wasserzeichen"
    }
    
    var body: some View {
        let isCompact = settings.adjustmentsSidebarCompactMode
        HStack(spacing: 0) {
            // Vertikale Tab-Leiste (links)
            VStack(spacing: 4) {
                ForEach(AdjustmentTab.allCases, id: \.self) { tab in
                    SidebarTabButton(
                        tab: tab,
                        iconName: iconForTab(tab),
                        isSelected: selectedTab == tab,
                        isCompact: isCompact,
                        action: { selectedTab = tab }
                    )
                }
                Spacer()
            }
            .frame(width: isCompact ? 40 : 44)
            .padding(.vertical, isCompact ? 6 : 8)
            .background(DesignSystem.Colors.background4)
            .overlay(
                // Subtiler Separator statt auffälliger Border
                Rectangle()
                    .fill(Color(NSColor.separatorColor).opacity(0.3))
                    .frame(width: 0.5),
                alignment: .trailing
            )
            
            // Content (rechts)
            VStack(spacing: 0) {
                // Header
                HStack(spacing: 8) {
                    Image(systemName: iconForTab(selectedTab))
                        .font(DesignSystem.Fonts.medium(size: 14))
                        .foregroundColor(DesignSystem.Colors.text)
                        .frame(width: 18)
                    
                    Text(selectedTab.rawValue.uppercased())
                        .font(DesignSystem.Fonts.semibold(size: 11))
                        .foregroundColor(DesignSystem.Colors.text)
                        .tracking(0.5)
                        .lineLimit(1)
                        .fixedSize(horizontal: false, vertical: true)
                        .minimumScaleFactor(0.8)
                    
                    Spacer()
                    
                    // Preset speichern (Quick Workflow): direkt aus "Anpassungen" heraus
                    if selectedTab == .adjustments {
                        Button {
                            // Popovers sollen sich nicht überlappen
                            showStyleProfilePopover = false
                            showSavePresetPopover.toggle()
                        } label: {
                            Image(systemName: "plus")
                                .font(.system(size: 13, weight: .semibold))
                                .foregroundColor(DesignSystem.Colors.text)
                                .frame(width: 28, height: 24)
                                .background(DesignSystem.Colors.background4)
                                .overlay(
                                    RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                                        .stroke(DesignSystem.Colors.border, lineWidth: 1)
                                )
                                .cornerRadius(DesignSystem.CornerRadius.small)
                        }
                        .buttonStyle(.plain)
                        .help("Aktuelle Einstellungen als Preset speichern…")
                        .disabled(store.currentPhoto == nil)
                        .popover(isPresented: $showSavePresetPopover, arrowEdge: .top) {
                            SaveAdjustmentPresetPopover(store: store, isPresented: $showSavePresetPopover)
                        }
                    }
                    
                    // Stil‑Profil: Popover mit Hover‑Preview (Delta wie Auto+Style), direkt im Workflow.
                    Button {
                        showSavePresetPopover = false
                        showStyleProfilePopover.toggle()
                    } label: {
                        Image(systemName: settings.autoUsesStyleProfile ? "paintbrush.pointed.fill" : "paintbrush.pointed")
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundColor(DesignSystem.Colors.text)
                            .frame(width: 28, height: 24)
                            .background(DesignSystem.Colors.background4)
                            .overlay(
                                RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
                            )
                            .cornerRadius(DesignSystem.CornerRadius.small)
                    }
                    .buttonStyle(.plain)
                    .help(styleMenuHelp)
                    .popover(isPresented: $showStyleProfilePopover, arrowEdge: .top) {
                        StyleProfilePickerPopover(store: store)
                    }
                }
                .padding(.horizontal, DesignSystem.Spacing.medium)
                .padding(.vertical, isCompact ? 6 : 8)
                .background(DesignSystem.Colors.background4)
                .overlay(
                    Rectangle()
                        .fill(DesignSystem.Colors.border)
                        .frame(height: 1),
                    alignment: .bottom
                )
                
                // Best‑of Inspector (nur wenn Best‑of Sort aktiv ist)
                if let id = store.currentPhotoID,
                   let info = store.bestOfOverlayInfo(for: id) {
                    BestOfInspectorRow(info: info)
                        .padding(.horizontal, DesignSystem.Spacing.medium)
                        .padding(.vertical, 8)
                        .background(DesignSystem.Colors.background4)
                        .overlay(
                            Rectangle()
                                .fill(DesignSystem.Colors.border)
                                .frame(height: 1),
                            alignment: .bottom
                        )
                }
                
                // Content
                ScrollView {
                    switch selectedTab {
                    case .presets:
                        PresetsPanel(store: store)
                    case .adjustments:
                        AdjustmentsPanel(store: store)
                    case .masking:
                        MaskingPanel(store: store)
                    case .crop:
                        CropPanel(store: store)
                    case .histogram:
                        HistogramPanel(store: store)
                    case .iptc:
                        IPTCPanel(store: store)
                    case .watermark:
                        WatermarkPreviewPanel(store: store)
                    }
                }
            }
        }
        .background(DesignSystem.Colors.background3)
        .frame(minWidth: 160)
        .overlay(
            Rectangle()
                .fill(DesignSystem.Colors.border)
                .frame(width: 1),
            alignment: .leading
        )
        // Wichtig: erzwingt ein lesbares Dark-Theme auch dann, wenn macOS im Light-Mode läuft.
        .lightroomSidebarTheme()
        .controlSize(isCompact ? .mini : .small)
    }
    
    private var styleMenuHelp: String {
        if settings.autoUsesStyleProfile {
            if let id = UUID(uuidString: settings.autoStylePresetID),
               let preset = store.adjustmentPresets.first(where: { $0.id == id }) {
                return "Stil‑Profil aktiv: \(preset.name)"
            }
            return "Stil‑Profil aktiv"
        }
        return "Stil‑Profil (Auto + Look)"
    }
    
    private func iconForTab(_ tab: AdjustmentTab) -> String {
        switch tab {
        case .adjustments: return "slider.horizontal.3"
        case .masking: return "circle.lefthalf.filled"
        case .presets: return "star.circle"
        case .crop: return "crop"
        case .histogram: return "chart.bar"
        case .iptc: return "doc.text"
        case .watermark: return "signature"
        }
    }
}

private struct BestOfInspectorRow: View {
    let info: BestOfOverlayInfo
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack(spacing: 8) {
                Image(systemName: "crown.fill")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.star)
                
                Text("Best‑of \(info.score0to100)")
                    .font(DesignSystem.Fonts.semibold(size: 12))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Spacer(minLength: 0)
                
                Text(info.miniHintText)
                    .font(DesignSystem.Fonts.regular(size: 11))
                    .foregroundColor(DesignSystem.Colors.text3)
                    .lineLimit(1)
            }
            
            ZStack(alignment: .leading) {
                RoundedRectangle(cornerRadius: 3)
                    .fill(DesignSystem.Colors.border.opacity(0.75))
                    .frame(height: 6)
                
                RoundedRectangle(cornerRadius: 3)
                    .fill(DesignSystem.Colors.star.opacity(0.95))
                    .frame(width: max(0, min(1, CGFloat(info.scoreFraction))) * 220, height: 6)
            }
            .frame(width: 220)
            
            HStack(spacing: 10) {
                Text("Auflösung \(info.resolution0to100)%")
                    .font(DesignSystem.Fonts.regular(size: 11))
                    .foregroundColor(DesignSystem.Colors.text3)
                Text("Schärfe \(info.sharpness0to100)%")
                    .font(DesignSystem.Fonts.regular(size: 11))
                    .foregroundColor(DesignSystem.Colors.text3)
                
                if info.usedFastQuality {
                    Text("Fast")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor(DesignSystem.Colors.text4)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(DesignSystem.Colors.background3)
                        .cornerRadius(6)
                }
                
                Spacer(minLength: 0)
            }
        }
        .padding(10)
        .background(DesignSystem.Colors.background3.opacity(0.35))
        .cornerRadius(10)
        .overlay(
            RoundedRectangle(cornerRadius: 10)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
        .help("Best‑of Score erklärt: Auflösung + Schärfe (relativ im aktuellen Scope)")
    }
}

struct WatermarkPreviewPanel: View {
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    private var presetsWithWatermark: [ExportPreset] {
        store.exportPresets.filter { $0.watermarkSettings != nil }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Wasserzeichen Vorschau")
                .font(DesignSystem.Fonts.semibold(size: 14))
                .foregroundColor(DesignSystem.Colors.text)
                .padding(.horizontal, DesignSystem.Spacing.medium)
                .padding(.top, 6)
            
            Toggle("In Vorschau anzeigen", isOn: $uiState.watermarkPreviewEnabled)
                .padding(.horizontal, DesignSystem.Spacing.medium)
                .tint(DesignSystem.Colors.accent)
            
            if uiState.watermarkPreviewEnabled {
                if presetsWithWatermark.isEmpty {
                    Text("Kein Export-Preset mit Wasserzeichen konfiguriert.")
                        .font(DesignSystem.Fonts.regular(size: 12))
                        .foregroundColor(DesignSystem.Colors.text)
                        .padding(.horizontal, DesignSystem.Spacing.medium)
                    
                    Button("Export-Presets öffnen…") {
                        uiState.activeSheet = .export
                    }
                    .buttonStyle(LightroomSecondaryButtonStyle())
                    .padding(.horizontal, DesignSystem.Spacing.medium)
                } else {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Preset")
                            .font(DesignSystem.Fonts.regular(size: 11))
                            .foregroundColor(DesignSystem.Colors.text)
                        
                        Menu {
                            Button("Automatisch") { uiState.watermarkPreviewPresetID = nil }
                            Divider()
                            ForEach(presetsWithWatermark) { preset in
                                Button(preset.name) { uiState.watermarkPreviewPresetID = preset.id }
                            }
                        } label: {
                            HStack(spacing: 8) {
                                Text(watermarkPresetTitle)
                                    .font(DesignSystem.Fonts.medium(size: 12))
                                    .foregroundColor(DesignSystem.Colors.text)
                                    .lineLimit(1)
                                
                                Spacer(minLength: 6)
                                
                                Image(systemName: "chevron.down")
                                    .font(.system(size: 10, weight: .semibold))
                                    .foregroundColor(DesignSystem.Colors.text2)
                            }
                            .padding(.vertical, 7)
                            .padding(.horizontal, 10)
                            .background(DesignSystem.Colors.background3)
                            .overlay(
                                RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
                            )
                            .cornerRadius(DesignSystem.CornerRadius.small)
                        }
                        .buttonStyle(.plain)
                        
                        if let settings = effectiveWatermarkSettings() {
                            WatermarkSettingsSummary(settings: settings)
                            
                            Divider()
                                .padding(.vertical, 8)
                            
                            // Skalierung
                            WatermarkScaleControls(
                                settings: settings,
                                store: store,
                                watermarkPreviewPresetID: uiState.watermarkPreviewPresetID
                            )
                        }
                    }
                    .padding(.horizontal, DesignSystem.Spacing.medium)
                    .padding(.vertical, 10)
                    .background(DesignSystem.Colors.background4)
                    .cornerRadius(DesignSystem.CornerRadius.small)
                    .overlay(
                        RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                            .stroke(DesignSystem.Colors.border, lineWidth: 1)
                    )
                    .padding(.horizontal, DesignSystem.Spacing.medium)
                }
            }
            
            Spacer(minLength: 0)
        }
        .padding(.bottom, DesignSystem.Spacing.medium)
    }
    
    private func effectiveWatermarkSettings() -> WatermarkSettings? {
        guard uiState.watermarkPreviewEnabled else { return nil }
        if let id = uiState.watermarkPreviewPresetID,
           let preset = store.exportPresets.first(where: { $0.id == id }) {
            return preset.watermarkSettings
        }
        return presetsWithWatermark.first?.watermarkSettings
    }

    private var watermarkPresetTitle: String {
        if let id = uiState.watermarkPreviewPresetID,
           let preset = store.exportPresets.first(where: { $0.id == id }) {
            return preset.name
        }
        return "Automatisch"
    }
}

struct WatermarkScaleControls: View {
    let settings: WatermarkSettings
    @ObservedObject var store: PhotoStore
    let watermarkPreviewPresetID: UUID?
    
    private var currentPreset: ExportPreset? {
        if let id = watermarkPreviewPresetID {
            return store.exportPresets.first(where: { $0.id == id })
        }
        return store.exportPresets.first(where: { $0.watermarkSettings != nil })
    }
    
    private var currentSize: Double {
        currentPreset?.watermarkSettings?.size ?? settings.size
    }
    
    private var currentOpacity: Double {
        currentPreset?.watermarkSettings?.opacity ?? settings.opacity
    }

    private var currentPosition: WatermarkPosition {
        currentPreset?.watermarkSettings?.position ?? settings.position
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Position")
                .font(DesignSystem.Fonts.regular(size: 11))
                .foregroundColor(DesignSystem.Colors.text)
                .padding(.bottom, 2)

            WatermarkPositionGrid(selected: currentPosition) { newPosition in
                updateWatermarkPosition(newPosition)
            }
            .padding(.bottom, 6)

            Text("Größe")
                .font(DesignSystem.Fonts.regular(size: 11))
                .foregroundColor(DesignSystem.Colors.text)
            
            HStack(spacing: 8) {
                Text("\(Int(currentSize * 100))%")
                    .font(DesignSystem.Fonts.medium(size: 11))
                    .foregroundColor(DesignSystem.Colors.text)
                    .frame(width: 40, alignment: .leading)
                    .monospacedDigit()
                
                Slider(value: Binding(
                    get: { currentSize },
                    set: { newSize in
                        updateWatermarkSize(newSize)
                    }
                ), in: 0.05...0.5, step: 0.01)
                .tint(DesignSystem.Colors.accent)
            }
            
            // Opacity
            Text("Deckkraft")
                .font(DesignSystem.Fonts.regular(size: 11))
                .foregroundColor(DesignSystem.Colors.text)
                .padding(.top, 4)
            
            HStack(spacing: 8) {
                Text("\(Int(currentOpacity * 100))%")
                    .font(DesignSystem.Fonts.medium(size: 11))
                    .foregroundColor(DesignSystem.Colors.text)
                    .frame(width: 40, alignment: .leading)
                    .monospacedDigit()
                
                Slider(value: Binding(
                    get: { currentOpacity },
                    set: { newOpacity in
                        updateWatermarkOpacity(newOpacity)
                    }
                ), in: 0.1...1.0, step: 0.05)
                .tint(DesignSystem.Colors.accent)
            }
        }
    }
    
    private func updateWatermarkSize(_ newSize: Double) {
        // Update im Export-Preset
        if let id = watermarkPreviewPresetID,
           let presetIndex = store.exportPresets.firstIndex(where: { $0.id == id }) {
            if store.exportPresets[presetIndex].watermarkSettings == nil {
                store.exportPresets[presetIndex].watermarkSettings = settings
            }
            store.exportPresets[presetIndex].watermarkSettings?.size = newSize
        } else if let firstPresetIndex = store.exportPresets.firstIndex(where: { $0.watermarkSettings != nil }) {
            store.exportPresets[firstPresetIndex].watermarkSettings?.size = newSize
        }
        
        // Persistieren (sonst springt es nach App‑Neustart wieder zurück)
        store.saveExportPresets()
        
        // Trigger Preview Update
        NotificationCenter.default.post(
            name: NSNotification.Name("WatermarkSettingsChanged"),
            object: nil
        )
    }
    
    private func updateWatermarkOpacity(_ newOpacity: Double) {
        // Update im Export-Preset
        if let id = watermarkPreviewPresetID,
           let presetIndex = store.exportPresets.firstIndex(where: { $0.id == id }) {
            if store.exportPresets[presetIndex].watermarkSettings == nil {
                store.exportPresets[presetIndex].watermarkSettings = settings
            }
            store.exportPresets[presetIndex].watermarkSettings?.opacity = newOpacity
        } else if let firstPresetIndex = store.exportPresets.firstIndex(where: { $0.watermarkSettings != nil }) {
            store.exportPresets[firstPresetIndex].watermarkSettings?.opacity = newOpacity
        }
        
        store.saveExportPresets()
        
        // Trigger Preview Update
        NotificationCenter.default.post(
            name: NSNotification.Name("WatermarkSettingsChanged"),
            object: nil
        )
    }

    private func updateWatermarkPosition(_ newPosition: WatermarkPosition) {
        if let id = watermarkPreviewPresetID,
           let presetIndex = store.exportPresets.firstIndex(where: { $0.id == id }) {
            if store.exportPresets[presetIndex].watermarkSettings == nil {
                store.exportPresets[presetIndex].watermarkSettings = settings
            }
            store.exportPresets[presetIndex].watermarkSettings?.position = newPosition
        } else if let firstPresetIndex = store.exportPresets.firstIndex(where: { $0.watermarkSettings != nil }) {
            store.exportPresets[firstPresetIndex].watermarkSettings?.position = newPosition
        }
        
        store.saveExportPresets()

        NotificationCenter.default.post(
            name: NSNotification.Name("WatermarkSettingsChanged"),
            object: nil
        )
    }
}

struct WatermarkPositionGrid: View {
    let selected: WatermarkPosition
    let onSelect: (WatermarkPosition) -> Void

    private let columns: [GridItem] = Array(repeating: GridItem(.fixed(26), spacing: 8), count: 3)
    private let positions: [WatermarkPosition] = [
        .topLeft, .topCenter, .topRight,
        .centerLeft, .center, .centerRight,
        .bottomLeft, .bottomCenter, .bottomRight
    ]

    var body: some View {
        LazyVGrid(columns: columns, alignment: .leading, spacing: 8) {
            ForEach(positions, id: \.self) { pos in
                Button(action: { onSelect(pos) }) {
                    Image(systemName: icon(for: pos))
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(DesignSystem.Colors.text)
                        .frame(width: 26, height: 22)
                        .background(background(for: pos))
                        .overlay(
                            RoundedRectangle(cornerRadius: 4)
                                .stroke(DesignSystem.Colors.border, lineWidth: 1)
                        )
                        .cornerRadius(4)
                }
                .buttonStyle(.plain)
                .help(positionName(pos))
            }
        }
    }

    private func background(for pos: WatermarkPosition) -> Color {
        (pos == selected) ? DesignSystem.Colors.accent.opacity(0.25) : DesignSystem.Colors.background3
    }

    private func icon(for pos: WatermarkPosition) -> String {
        switch pos {
        case .topLeft: return "arrow.up.left"
        case .topCenter: return "arrow.up"
        case .topRight: return "arrow.up.right"
        case .centerLeft: return "arrow.left"
        case .center: return "circle"
        case .centerRight: return "arrow.right"
        case .bottomLeft: return "arrow.down.left"
        case .bottomCenter: return "arrow.down"
        case .bottomRight: return "arrow.down.right"
        }
    }

    private func positionName(_ pos: WatermarkPosition) -> String {
        switch pos {
        case .topLeft: return "Oben links"
        case .topCenter: return "Oben"
        case .topRight: return "Oben rechts"
        case .centerLeft: return "Mitte links"
        case .center: return "Mitte"
        case .centerRight: return "Mitte rechts"
        case .bottomLeft: return "Unten links"
        case .bottomCenter: return "Unten"
        case .bottomRight: return "Unten rechts"
        }
    }
}

struct WatermarkSettingsSummary: View {
    let settings: WatermarkSettings
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack(spacing: 8) {
                Label(typeText, systemImage: "seal")
                Spacer()
                Text("\(Int(settings.opacity * 100))%")
                    .monospacedDigit()
            }
            .font(DesignSystem.Fonts.regular(size: 11))
            .foregroundColor(DesignSystem.Colors.text)
            
            HStack(spacing: 8) {
                Label(positionText, systemImage: "arrow.up.left.and.arrow.down.right")
                Spacer()
                Text("\(Int(settings.size * 100))%")
                    .monospacedDigit()
            }
            .font(DesignSystem.Fonts.regular(size: 11))
            .foregroundColor(DesignSystem.Colors.text)
            
            if let text = settings.text, (settings.type == .text || settings.type == .both) {
                Text(text)
                    .font(DesignSystem.Fonts.regular(size: 11))
                    .foregroundColor(DesignSystem.Colors.text)
                    .lineLimit(2)
            }
        }
        .padding(.top, 4)
    }
    
    private var typeText: String {
        switch settings.type {
        case .text: return "Text"
        case .logo: return "Logo"
        case .both: return "Text + Logo"
        }
    }
    
    private var positionText: String {
        switch settings.position {
        case .topLeft: return "Oben links"
        case .topCenter: return "Oben"
        case .topRight: return "Oben rechts"
        case .centerLeft: return "Mitte links"
        case .center: return "Mitte"
        case .centerRight: return "Mitte rechts"
        case .bottomLeft: return "Unten links"
        case .bottomCenter: return "Unten"
        case .bottomRight: return "Unten rechts"
        }
    }
}

struct SidebarTabButton: View {
    let tab: AdjustmentsSidebar.AdjustmentTab
    let iconName: String
    let isSelected: Bool
    let isCompact: Bool
    let action: () -> Void
    
    @State private var isHovering = false
    
    var body: some View {
        Button(action: action) {
            ZStack(alignment: .leading) {
                RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                    .fill(backgroundColor)
                
                if isSelected {
                    RoundedRectangle(cornerRadius: 2)
                        .fill(DesignSystem.Colors.accent)
                        .frame(width: 3)
                        .padding(.vertical, 8)
                        .padding(.leading, 4)
                }
                
                Image(systemName: iconName)
                    .font(DesignSystem.Fonts.medium(size: isCompact ? 14 : 16))
                    .foregroundColor(isSelected ? Color.white : DesignSystem.Colors.text2)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .frame(width: isCompact ? 40 : 44, height: isCompact ? 40 : 44)
        }
        .buttonStyle(.plain)
        .help(tab.rawValue)
        .accessibilityLabel(tab.rawValue)
        .onHover { hovering in
            isHovering = hovering
        }
    }
    
    private var backgroundColor: Color {
        if isSelected {
            return DesignSystem.Colors.accent.opacity(0.25)
        }
        if isHovering {
            return DesignSystem.Colors.background3
        }
        return Color.clear
    }
}

// PresetsPanel wurde in eine separate Datei verschoben

struct AdjustmentsPanel: View {
    @ObservedObject var store: PhotoStore
    @StateObject private var settings = AppSettings.shared
    @State private var isBasicExpanded: Bool = true
    @State private var isAdvancedExpanded: Bool = true
    @State private var isDetailsExpanded: Bool = false
    @State private var isOpticsExpanded: Bool = false
    @State private var isHistoryExpanded: Bool = false
    
    var body: some View {
        let isCompact = settings.adjustmentsSidebarCompactMode
        VStack(alignment: .leading, spacing: isCompact ? 6 : 8) {
            if let photo = store.currentPhoto {
                // Wichtig: PhotoItem muss observed werden, sonst aktualisieren sich Slider/Value-Labels nicht zuverlässig.
                AdjustmentsPanelContent(
                    photo: photo,
                    isBasicExpanded: $isBasicExpanded,
                    isAdvancedExpanded: $isAdvancedExpanded,
                    isDetailsExpanded: $isDetailsExpanded,
                    isOpticsExpanded: $isOpticsExpanded,
                    isHistoryExpanded: $isHistoryExpanded
                )
            } else {
                Text("Kein Foto ausgewählt")
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text)
                    .padding(.horizontal, DesignSystem.Spacing.medium)
                    .padding(.vertical, DesignSystem.Spacing.large)
            }
        }
        .padding(.vertical, isCompact ? 4 : 6)
    }
}

private struct AdjustmentsPanelContent: View {
    @ObservedObject var photo: PhotoItem
    @Binding var isBasicExpanded: Bool
    @Binding var isAdvancedExpanded: Bool
    @Binding var isDetailsExpanded: Bool
    @Binding var isOpticsExpanded: Bool
    @Binding var isHistoryExpanded: Bool
    @EnvironmentObject var store: PhotoStore
    @StateObject private var settings = AppSettings.shared
    
    private func adjustmentBinding(_ keyPath: WritableKeyPath<PhotoAdjustments, Double>) -> Binding<Double> {
        Binding(
            get: { photo.adjustments[keyPath: keyPath] },
            set: { newValue in
                // Wichtig: @Published bei Structs triggert sonst oft nicht bei nested mutations.
                var copy = photo.adjustments
                copy[keyPath: keyPath] = newValue
                photo.adjustments = copy
            }
        )
    }
    
    var body: some View {
        let isCompact = settings.adjustmentsSidebarCompactMode
        VStack(alignment: .leading, spacing: isCompact ? 6 : DesignSystem.Spacing.small) {
            SidebarPanelSection(title: "Basis", isExpanded: $isBasicExpanded) {
                AdjustmentSlider(title: "Belichtung", value: adjustmentBinding(\.exposure), range: -2.0...2.0, unit: "EV", photo: photo)
                AdjustmentSlider(title: "Kontrast", value: adjustmentBinding(\.contrast), range: 0.5...1.8, unit: "x", defaultValue: 1.0, photo: photo)
                AdjustmentSlider(title: "Temperatur", value: adjustmentBinding(\.temperature), range: -3000...3000, unit: "K", photo: photo)
                AdjustmentSlider(title: "Tint", value: adjustmentBinding(\.tint), range: -80...80, photo: photo)
                AdjustmentSlider(title: "Klarheit", value: adjustmentBinding(\.clarity), range: 0.0...1.0, photo: photo)
                AdjustmentSlider(title: "Vibrance", value: adjustmentBinding(\.vibrance), range: -0.6...1.0, photo: photo)
            }
            
            SidebarPanelSection(title: "Erweitert", isExpanded: $isAdvancedExpanded) {
                AdjustmentSlider(title: "Highlights", value: adjustmentBinding(\.highlights), range: -100...100, photo: photo)
                AdjustmentSlider(title: "Shadows", value: adjustmentBinding(\.shadows), range: -100...100, photo: photo)
                AdjustmentSlider(title: "Whites", value: adjustmentBinding(\.whites), range: -100...100, photo: photo)
                AdjustmentSlider(title: "Blacks", value: adjustmentBinding(\.blacks), range: -100...100, photo: photo)
                AdjustmentSlider(title: "Saturation", value: adjustmentBinding(\.saturation), range: -100...100, photo: photo)
                AdjustmentSlider(title: "Dehaze", value: adjustmentBinding(\.dehaze), range: -100...100, photo: photo)
                AdjustmentSlider(title: "Texture", value: adjustmentBinding(\.texture), range: -100...100, photo: photo)
            }

            SidebarPanelSection(title: "Details", isExpanded: $isDetailsExpanded) {
                AdjustmentSlider(title: "Rauschreduzierung", value: adjustmentBinding(\.noiseReduction), range: 0...100, unit: "", photo: photo)
                AdjustmentSlider(title: "Schärfen", value: adjustmentBinding(\.sharpening), range: 0...100, unit: "", photo: photo)
            }

            SidebarPanelSection(title: "Optik", isExpanded: $isOpticsExpanded) {
                LensProfilePanel(photo: photo)
                
                Divider()
                    .opacity(0.6)
                    .padding(.horizontal, isCompact ? DesignSystem.Spacing.small : DesignSystem.Spacing.medium)
                
                AdjustmentSlider(title: "Verzeichnung", value: adjustmentBinding(\.lensDistortion), range: -100...100, unit: "", photo: photo)
                AdjustmentSlider(title: "Vignette", value: adjustmentBinding(\.vignette), range: -100...100, unit: "", photo: photo)
                AdjustmentSlider(title: "Chromatische Aberration", value: adjustmentBinding(\.chromaticAberration), range: 0...100, unit: "", photo: photo)
            }
            
            // Action Buttons
            HStack(spacing: isCompact ? 6 : 8) {
                Button(action: { applyAutoEnhancement() }) {
                    Label("Auto", systemImage: "wand.and.stars")
                        .font(DesignSystem.Fonts.medium(size: isCompact ? 11 : 12))
                        .foregroundColor(Color.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, isCompact ? 6 : 8)
                        .background(DesignSystem.Colors.accent)
                        .cornerRadius(DesignSystem.CornerRadius.small)
                }
                .buttonStyle(.plain)
                
                Button("Reset") {
                    store.registerUndoPoint(for: photo)
                    var copy = photo.adjustments
                    copy.reset()
                    photo.adjustments = copy
                    updateImage()
                }
                .font(DesignSystem.Fonts.medium(size: isCompact ? 11 : 12))
                .foregroundColor(DesignSystem.Colors.text)
                .frame(maxWidth: .infinity)
                .padding(.vertical, isCompact ? 6 : 8)
                .background(DesignSystem.Colors.background4)
                .cornerRadius(DesignSystem.CornerRadius.small)
                .buttonStyle(.plain)
            }
            .padding(.horizontal, isCompact ? DesignSystem.Spacing.small : DesignSystem.Spacing.medium)
            .padding(.top, isCompact ? 4 : 6)
            
            SidebarPanelSection(title: "History", isExpanded: $isHistoryExpanded) {
                HistoryPanel(photo: photo)
            }
        }
    }
    
    private func applyAutoEnhancement() {
        Task {
            if let adjustments = await store.buildAutoAdjustments(for: photo) {
                await MainActor.run {
                    store.registerUndoPoint(for: photo)
                    photo.adjustments = adjustments
                    updateImage()
                }
            }
        }
    }
    
    private func updateImage() {
        // Triggere Bildaktualisierung sofort (DetailView beobachtet PhotoItem nicht direkt)
        photo.objectWillChange.send()
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id]
        )
    }
}

/// Lightroom-ähnlicher Panel-Block (Header + collapsible Content)
struct SidebarPanelSection<Content: View>: View {
    let title: String
    @Binding var isExpanded: Bool
    @ViewBuilder let content: Content
    @StateObject private var settings = AppSettings.shared
    
    var body: some View {
        let isCompact = settings.adjustmentsSidebarCompactMode
        VStack(spacing: 0) {
            Button(action: { withAnimation(.easeOut(duration: 0.15)) { isExpanded.toggle() } }) {
                HStack(spacing: isCompact ? 6 : 8) {
                    Image(systemName: isExpanded ? "chevron.down" : "chevron.right")
                        .font(.system(size: isCompact ? 9 : 10, weight: .semibold))
                        .foregroundColor(DesignSystem.Colors.text2)
                        .frame(width: isCompact ? 12 : 14)
                    
                    Text(title)
                        .font(DesignSystem.Fonts.semibold(size: isCompact ? 11 : 12))
                        .foregroundColor(DesignSystem.Colors.text)
                        .lineLimit(1)
                        .truncationMode(.tail)
                        .minimumScaleFactor(0.85)
                        .layoutPriority(1)
                    
                    Spacer()
                }
                .padding(.horizontal, isCompact ? 6 : DesignSystem.Spacing.medium)
                .padding(.vertical, isCompact ? 3 : 6)
                .background(DesignSystem.Colors.background4)
            }
            .buttonStyle(.plain)
            
            if isExpanded {
                VStack(alignment: .leading, spacing: isCompact ? 2 : 4) {
                    content
                }
                .padding(.vertical, isCompact ? 3 : 6)
            }
        }
        .background(DesignSystem.Colors.background3)
        .overlay(
            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
        .cornerRadius(DesignSystem.CornerRadius.small)
        .padding(.horizontal, isCompact ? 6 : DesignSystem.Spacing.medium)
    }
}

struct HistogramPanel: View {
    @ObservedObject var store: PhotoStore
    @State private var ciImage: CIImage?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if let photo = store.currentPhoto,
               let image = (ciImage ?? photo.loadFullImage()) {
                HistogramView(
                    image: histogramImage(for: photo, original: image),
                    toneAdjustments: Binding(
                        get: { photo.adjustments },
                        set: { newValue in photo.adjustments = newValue }
                    ),
                    onRequestImageUpdate: {
                        // Debounced Trigger aus HistogramView → hier nur reprocess anstossen
                        NotificationCenter.default.post(
                            name: NSNotification.Name("PhotoAdjustmentsChanged"),
                            object: nil,
                            userInfo: ["photoID": photo.id]
                        )
                    },
                    onBeginToneEdit: {
                        store.beginEditSession(for: photo)
                    },
                    onEndToneEdit: {
                        store.endEditSession(for: photo)
                    }
                )
            } else {
                HStack(spacing: 10) {
                    ProgressView()
                        .controlSize(.small)
                        .tint(DesignSystem.Colors.text2)
                    Text(store.currentPhoto == nil ? "Kein Foto ausgewählt" : "Bild wird geladen…")
                        .foregroundColor(DesignSystem.Colors.text2)
                }
                .padding()
            }
        }
        .padding(.vertical)
        .onAppear { loadCIImageIfNeeded() }
        .onChange(of: store.currentPhotoID) { _, _ in loadCIImageIfNeeded() }
    }

    private func histogramImage(for photo: PhotoItem, original: CIImage) -> CIImage {
        // Histogramm soll die aktuelle Bearbeitung widerspiegeln (wie Lightroom)
        let engine = EditEngine.shared
        var processed = original
        if let adjusted = engine.applyAdjustments(to: processed, adjustments: photo.adjustments) {
            processed = adjusted
        }
        processed = engine.applyCropAndRotation(
            to: processed,
            cropRect: photo.cropRect,
            rotation: photo.rotation
        )
        return processed
    }
    
    private func loadCIImageIfNeeded() {
        ciImage = nil
        guard let photo = store.currentPhoto else { return }
        Task {
            let img = await photo.loadFullImageAsync()
            await MainActor.run {
                self.ciImage = img
            }
        }
    }
}

struct AdjustmentSection<Content: View>: View {
    let title: String
    @ViewBuilder let content: Content
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(DesignSystem.Fonts.semibold(size: 12))
                .foregroundColor(DesignSystem.Colors.text2)
                .lineLimit(1)
                .truncationMode(.tail)
                .minimumScaleFactor(0.85)
                .layoutPriority(1)
                .padding(.horizontal, DesignSystem.Spacing.medium)
                .padding(.top, 2)
            
            content
        }
    }
}

struct AdjustmentSlider: View {
    let title: String
    @Binding var value: Double
    let range: ClosedRange<Double>
    let unit: String?
    let defaultValue: Double
    var photo: PhotoItem?
    @State private var debounceTask: Task<Void, Never>?
    @State private var historyEndTask: Task<Void, Never>?
    @EnvironmentObject var store: PhotoStore
    @StateObject private var settings = AppSettings.shared
    
    init(title: String, value: Binding<Double>, range: ClosedRange<Double>, unit: String? = nil, defaultValue: Double = 0.0, photo: PhotoItem? = nil) {
        self.title = title
        self._value = value
        self.range = range
        self.unit = unit
        self.defaultValue = defaultValue
        self.photo = photo
    }
    
    var body: some View {
        let isCompact = settings.adjustmentsSidebarCompactMode
        let hPad: CGFloat = isCompact ? 6 : DesignSystem.Spacing.medium
        VStack(alignment: .leading, spacing: isCompact ? 2 : 3) {
            // Zeile 1: Titel + Reset + Wert (kein Umbruch)
            HStack(spacing: isCompact ? 6 : 8) {
                Text(title)
                    .font(DesignSystem.Fonts.medium(size: isCompact ? 11 : 12))
                    .foregroundColor(DesignSystem.Colors.text)
                    .lineLimit(1)
                    .truncationMode(.tail)
                    .minimumScaleFactor(0.85)
                    .layoutPriority(1)
                
                Spacer(minLength: 6)
                
                AdjustmentNudgeButton(systemName: "arrow.counterclockwise", isEnabled: canReset) {
                    resetToDefault()
                }
                .help("Regler zurücksetzen")
                
                Text(formattedValue)
                    .font(DesignSystem.Fonts.regular(size: isCompact ? 10 : 11))
                    .foregroundColor(DesignSystem.Colors.text2)
                    .monospacedDigit()
                    .frame(minWidth: 52, alignment: .trailing)
            }
            .padding(.horizontal, hPad)
            
            // Zeile 2: +/- neben Slider (spart Horizontal‑Platz)
            HStack(spacing: isCompact ? 6 : 8) {
                AdjustmentNudgeButton(systemName: "minus") {
                    nudge(-fineStep)
                }
                
                Slider(value: $value, in: range) { editing in
                    if !editing {
                        historyEndTask?.cancel()
                        if let photo = photo {
                            store.endEditSession(for: photo)
                        }
                        // Wenn Slider losgelassen wird, aktualisiere Bild sofort
                        updateImage()
                    } else {
                        if let photo = photo {
                            store.beginEditSession(for: photo)
                        }
                        // Während des Ziehens: Debounce für Performance
                        debounceTask?.cancel()
                        debounceTask = Task { @MainActor in
                            try? await Task.sleep(nanoseconds: 100_000_000) // 0.1s für schnellere Reaktion
                            updateImage()
                        }
                    }
                }
                .onChange(of: value) { _, _ in
                    // Sofortige Aktualisierung bei Wertänderung
                    debounceTask?.cancel()
                    debounceTask = Task { @MainActor in
                        try? await Task.sleep(nanoseconds: 100_000_000)
                        updateImage()
                    }
                }
                .tint(DesignSystem.Colors.accent)
                .frame(maxWidth: .infinity)
                
                AdjustmentNudgeButton(systemName: "plus") {
                    nudge(fineStep)
                }
            }
            .padding(.horizontal, hPad)
        }
        .padding(.vertical, isCompact ? 1 : 3)
    }
    
    private var fineStep: Double {
        switch title {
        case "Belichtung":
            return 0.05
        case "Kontrast":
            return 0.02
        case "Temperatur":
            return 50
        case "Tint":
            return 1
        case "Klarheit":
            return 0.02
        case "Vibrance":
            return 0.02
        default:
            let span = abs(range.upperBound - range.lowerBound)
            if span <= 3 { return 0.05 }
            if span <= 10 { return 0.1 }
            if span <= 200 { return 1 }
            return 10
        }
    }
    
    private var formattedValue: String {
        let suffix = unit ?? ""
        let decimals: Int
        if abs(fineStep) >= 1.0 {
            decimals = 0
        } else if abs(fineStep) < 0.1 {
            decimals = 2
        } else {
            decimals = 1
        }
        return "\(value.formatted(.number.precision(.fractionLength(decimals))))\(suffix)"
    }
    
    private func nudge(_ delta: Double) {
        debounceTask?.cancel()
        historyEndTask?.cancel()
        
        if let photo = photo {
            store.beginEditSession(for: photo)
            historyEndTask = Task { @MainActor in
                try? await Task.sleep(nanoseconds: 350_000_000) // group rapid nudges
                store.endEditSession(for: photo)
            }
        }
        
        let newValue = min(range.upperBound, max(range.lowerBound, value + delta))
        value = newValue
        
        // Sofort re-rendern (Fine-Tuning)
        updateImage()
    }
    
    private var canReset: Bool {
        abs(value - defaultValue) > 0.000_1
    }
    
    private func resetToDefault() {
        debounceTask?.cancel()
        historyEndTask?.cancel()
        
        if let photo = photo {
            store.registerUndoPoint(for: photo)
        }
        
        value = defaultValue
        updateImage()
    }
    
    private func updateImage() {
        // Triggere Bildaktualisierung durch Änderung der adjustments
        guard let photo = photo else { return }
        
        // Notify PhotoStore dass sich das Bild geändert hat
        photo.objectWillChange.send()
        
        // Trigger DetailView to reprocess - mit Photo ID
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id]
        )
    }
}

struct AdjustmentNudgeButton: View {
    let systemName: String
    var isEnabled: Bool = true
    let action: () -> Void
    
    @State private var isHovering = false
    @StateObject private var settings = AppSettings.shared
    
    var body: some View {
        let isCompact = settings.adjustmentsSidebarCompactMode
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: isCompact ? 10 : 11, weight: .semibold))
                .foregroundColor(isEnabled ? DesignSystem.Colors.text : DesignSystem.Colors.text4)
                .frame(width: isCompact ? 16 : 22, height: isCompact ? 16 : 22)
                .background(isHovering ? DesignSystem.Colors.background4 : Color.clear)
                .cornerRadius(isCompact ? 2 : 4)
                .contentShape(Rectangle())
        }
        .buttonStyle(.borderless)
        .disabled(!isEnabled)
        .onHover { hovering in
            isHovering = hovering
        }
    }
}

private struct HistoryPanel: View {
    @ObservedObject var photo: PhotoItem
    @EnvironmentObject var store: PhotoStore
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            HStack(spacing: 8) {
                HistoryIconButton(
                    systemName: "arrow.uturn.left",
                    help: "Undo",
                    isEnabled: store.canUndo(photo: photo)
                ) {
                    store.undoCurrent()
                }
                
                HistoryIconButton(
                    systemName: "arrow.uturn.right",
                    help: "Redo",
                    isEnabled: store.canRedo(photo: photo)
                ) {
                    store.redoCurrent()
                }
                
                HistoryIconButton(
                    systemName: "camera",
                    help: "Snapshot erstellen",
                    isEnabled: true
                ) {
                    store.createSnapshot(for: photo)
                }
            }
            
            let snapshots = store.snapshots(for: photo)
            if snapshots.isEmpty {
                Text("Keine Snapshots vorhanden.")
                    .font(DesignSystem.Fonts.regular(size: 11))
                    .foregroundColor(DesignSystem.Colors.text2)
            } else {
                VStack(alignment: .leading, spacing: 6) {
                    ForEach(snapshots) { snapshot in
                        SnapshotRow(photo: photo, snapshot: snapshot)
                    }
                }
            }
        }
        .padding(.horizontal, DesignSystem.Spacing.medium)
    }
}

private struct HistoryIconButton: View {
    let systemName: String
    let help: String
    let isEnabled: Bool
    let action: () -> Void
    
    @State private var isHovering = false
    
    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(isEnabled ? DesignSystem.Colors.text : DesignSystem.Colors.text4)
                .frame(width: 34, height: 30)
                .background(isHovering ? DesignSystem.Colors.background3 : DesignSystem.Colors.background4)
                .overlay(
                    RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                        .stroke(DesignSystem.Colors.border, lineWidth: 1)
                )
                .cornerRadius(DesignSystem.CornerRadius.small)
                .contentShape(Rectangle())
        }
        .buttonStyle(.plain)
        .disabled(!isEnabled)
        .help(help)
        .onHover { hovering in
            isHovering = hovering
        }
    }
}

private struct SnapshotRow: View {
    @ObservedObject var photo: PhotoItem
    let snapshot: EditSnapshot
    @EnvironmentObject var store: PhotoStore
    
    var body: some View {
        HStack(spacing: 8) {
            VStack(alignment: .leading, spacing: 1) {
                Text(snapshot.name)
                    .font(DesignSystem.Fonts.medium(size: 11))
                    .foregroundColor(DesignSystem.Colors.text2)
                    .lineLimit(1)
                
                Text(snapshot.createdAt, style: .time)
                    .font(DesignSystem.Fonts.regular(size: 10))
                    .foregroundColor(DesignSystem.Colors.text4)
            }
            
            Spacer()
            
            Button("Anwenden") {
                store.applySnapshot(snapshot, to: photo)
            }
            .buttonStyle(LightroomSecondaryButtonStyle())
        }
        .padding(.vertical, 4)
        .contextMenu {
            Button("Anwenden") { store.applySnapshot(snapshot, to: photo) }
            Divider()
            Button("Löschen") { store.deleteSnapshot(snapshot, for: photo) }
        }
    }
}

struct WatermarkPanel: View {
    @ObservedObject var store: PhotoStore
    @State private var showWatermarkEditor = false
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                if let photo = store.currentPhoto {
                    Text("Watermark")
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(Color(white: 0.95))
                        .padding(.horizontal, 12)
                        .padding(.top, 12)
                    
                    // Watermark Toggle
                    Toggle("Watermark aktivieren", isOn: Binding(
                        get: { photo.adjustments.hasAdjustments }, // Placeholder
                        set: { _ in }
                    ))
                    .padding(.horizontal, 12)
                    
                    Divider()
                        .padding(.vertical, 8)
                    
                    // Watermark Settings
                    VStack(alignment: .leading, spacing: 12) {
                        Text("Typ")
                            .font(DesignSystem.Fonts.medium(size: 12))
                            .foregroundColor(DesignSystem.Colors.text)
                            .padding(.horizontal, 12)
                        
                        Picker("", selection: .constant(WatermarkType.text)) {
                            Text("Text").tag(WatermarkType.text)
                            Text("Logo").tag(WatermarkType.logo)
                        }
                        .pickerStyle(.segmented)
                        .padding(.horizontal, 12)
                        
                        Text("Position")
                            .font(DesignSystem.Fonts.medium(size: 12))
                            .foregroundColor(DesignSystem.Colors.text)
                            .padding(.horizontal, 12)
                            .padding(.top, 8)
                        
                        // Position Grid
                        LazyVGrid(columns: Array(repeating: GridItem(.flexible()), count: 3), spacing: 4) {
                            ForEach([WatermarkPosition.topLeft, .topCenter, .topRight,
                                    .centerLeft, .center, .centerRight,
                                    .bottomLeft, .bottomCenter, .bottomRight], id: \.self) { position in
                                Button(action: {}) {
                                    Text(positionName(position))
                                        .font(DesignSystem.Fonts.regular(size: 12))
                                        .foregroundColor(DesignSystem.Colors.text)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 6)
                                        .background(DesignSystem.Colors.background4)
                                        .cornerRadius(4)
                                }
                                .buttonStyle(.plain)
                            }
                        }
                        .padding(.horizontal, 12)
                        
                        Button("Watermark bearbeiten...") {
                            showWatermarkEditor = true
                        }
                        .buttonStyle(.borderedProminent)
                        .padding(.horizontal, 12)
                        .padding(.top, 8)
                    }
                } else {
                    Text("Kein Foto ausgewählt")
                        .font(DesignSystem.Fonts.regular(size: 12))
                        .foregroundColor(DesignSystem.Colors.text)
                        .padding()
                }
            }
        }
        .sheet(isPresented: $showWatermarkEditor) {
            WatermarkEditorView(store: store)
        }
    }
    
    private func positionName(_ position: WatermarkPosition) -> String {
        switch position {
        case .topLeft: return "↖"
        case .topCenter: return "↑"
        case .topRight: return "↗"
        case .centerLeft: return "←"
        case .center: return "⊙"
        case .centerRight: return "→"
        case .bottomLeft: return "↙"
        case .bottomCenter: return "↓"
        case .bottomRight: return "↘"
        }
    }
}

struct WatermarkEditorView: View {
    @ObservedObject var store: PhotoStore
    @Environment(\.dismiss) var dismiss
    @State private var watermarkText = ""
    @State private var fontSize: Double = 24
    @State private var opacity: Double = 0.8
    @State private var selectedPosition: WatermarkPosition = .bottomRight
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Watermark bearbeiten")
                .font(.headline)
            
            Form {
                Section("Text") {
                    TextField("Watermark Text", text: $watermarkText)
                    
                    VStack(alignment: .leading) {
                        Text("Schriftgröße: \(Int(fontSize))")
                        Slider(value: $fontSize, in: 12...72)
                    }
                    
                    VStack(alignment: .leading) {
                        Text("Deckkraft: \(Int(opacity * 100))%")
                        Slider(value: $opacity, in: 0.1...1.0)
                    }
                }
                
                Section("Position") {
                    Picker("Position", selection: $selectedPosition) {
                        Text("Oben Links").tag(WatermarkPosition.topLeft)
                        Text("Oben Mitte").tag(WatermarkPosition.topCenter)
                        Text("Oben Rechts").tag(WatermarkPosition.topRight)
                        Text("Mitte Links").tag(WatermarkPosition.centerLeft)
                        Text("Mitte").tag(WatermarkPosition.center)
                        Text("Mitte Rechts").tag(WatermarkPosition.centerRight)
                        Text("Unten Links").tag(WatermarkPosition.bottomLeft)
                        Text("Unten Mitte").tag(WatermarkPosition.bottomCenter)
                        Text("Unten Rechts").tag(WatermarkPosition.bottomRight)
                    }
                }
            }
            .formStyle(.grouped)
            
            HStack {
                Button("Abbrechen") {
                    dismiss()
                }
                Button("Anwenden") {
                    // Watermark anwenden
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .padding()
        .frame(width: 500, height: 400)
    }
}

struct CropPanel: View {
    @ObservedObject var store: PhotoStore
    @State private var showCropView = false
    @State private var showCropHint = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            if let photo = store.currentPhoto {
                Text("Zuschnitt & Rotation")
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text)
                    .padding(.horizontal)
                
                // Rotation
                VStack(alignment: .leading, spacing: 8) {
                    Text("Rotation: \(Int(photo.rotation))°")
                        .font(DesignSystem.Fonts.medium(size: 12))
                        .foregroundColor(DesignSystem.Colors.text)
                    
                    Slider(value: Binding(
                        get: { photo.rotation },
                        set: { newValue in photo.rotation = newValue }
                    ), in: -180...180, step: 1, onEditingChanged: { editing in
                        if editing {
                            store.beginEditSession(for: photo)
                        } else {
                            store.endEditSession(for: photo)
                            notifyEditChanged(photo)
                        }
                    })
                    
                    HStack {
                        Button("-90°") {
                            store.registerUndoPoint(for: photo)
                            photo.rotation = max(-180, photo.rotation - 90)
                            notifyEditChanged(photo)
                        }
                        .buttonStyle(LightroomSmallButtonStyle())
                        
                        Button("Reset") {
                            store.registerUndoPoint(for: photo)
                            photo.rotation = 0
                            notifyEditChanged(photo)
                        }
                        .buttonStyle(LightroomSmallButtonStyle())
                        
                        Button("+90°") {
                            store.registerUndoPoint(for: photo)
                            photo.rotation = min(180, photo.rotation + 90)
                            notifyEditChanged(photo)
                        }
                        .buttonStyle(LightroomSmallButtonStyle())
                    }
                }
                .padding(.horizontal)
                
                // Crop Button
                Button(action: {
                    showCropView = true
                }) {
                    HStack {
                        Image(systemName: "crop")
                        Text("Interaktiv zuschneiden")
                    }
                    .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .padding(.horizontal, DesignSystem.Spacing.medium)
                .help("Tipp: Im Crop-Fenster kannst du Seitenverhältnis wählen, Crop-Griffe ziehen und mit +/-90° drehen.")
                
                if photo.cropRect != nil {
                    Button("Crop entfernen") {
                        store.registerUndoPoint(for: photo)
                        photo.cropRect = nil
                        notifyEditChanged(photo)
                    }
                    .buttonStyle(LightroomSecondaryButtonStyle())
                    .padding(.horizontal, DesignSystem.Spacing.medium)
                }
            } else {
                Text("Kein Foto ausgewählt")
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text2)
                    .padding()
            }
        }
        .padding(.vertical)
        .sheet(isPresented: $showCropView) {
            if let photo = store.currentPhoto {
                CropView(photo: photo, store: store)
            }
        }
    }
    
    private func notifyEditChanged(_ photo: PhotoItem) {
        // Persist crop/rotation im Edit-Katalog (wir hängen an der gleichen Notification wie Adjustments)
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id]
        )
    }
    
}

