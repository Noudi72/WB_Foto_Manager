//
//  ExportPanel.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit
import UniformTypeIdentifiers

struct ExportPanel: View {
    @ObservedObject var store: PhotoStore
    @State private var selectedPreset: ExportPreset?
    @State private var selectedOutputDirectory: URL?
    @State private var isExporting = false
    @State private var exportProgress: Double = 0.0
    @State private var showPresetManagement = false
    @State private var previewImage: NSImage?
    @State private var isGeneratingPreview = false
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Export")
                    .font(.headline)
                
                Spacer()
                
                Button(action: {
                    showPresetManagement = true
                }) {
                    Image(systemName: "gearshape")
                }
                .help("Presets verwalten")
            }
            
            // Preset Selection
            Picker("Preset", selection: $selectedPreset) {
                Text("Kein Preset").tag(ExportPreset?.none)
                ForEach(store.exportPresets) { preset in
                    Text(preset.name).tag(ExportPreset?.some(preset))
                }
            }
            .pickerStyle(.menu)
            .onChange(of: selectedPreset) { _, _ in
                generatePreview()
            }
            
            if let preset = selectedPreset {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Dimension: \(preset.maxDimension == 99999 ? "Original" : "\(preset.maxDimension)px")")
                    Text("Qualität: \(Int(preset.quality * 100))%")
                    Text("Format: \(preset.format.rawValue)")
                    Text("Wasserzeichen: \(preset.watermarkSettings != nil ? "Ja" : "Nein")")
                }
                .font(.caption)
                .foregroundColor(.secondary)
            }
            
            Divider()
            
            // Export-Vorschau
            if let photo = store.currentPhoto {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Vorschau")
                        .font(.subheadline)
                        .fontWeight(.semibold)
                    
                    if isGeneratingPreview {
                        HStack {
                            ProgressView()
                                .controlSize(.small)
                            Text("Vorschau wird generiert...")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        .frame(height: 200)
                    } else if let preview = previewImage {
                        Image(nsImage: preview)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(maxHeight: 300)
                            .cornerRadius(4)
                            .shadow(radius: 2)
                    } else {
                        Text("Keine Vorschau verfügbar")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .frame(height: 200)
                    }
                }
                
                Divider()
            }
            
            // Export-Ordner Hinweis (wird im SavePanel ausgewählt)
            VStack(alignment: .leading, spacing: 8) {
                Text("Zielordner")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                
                if let directory = selectedOutputDirectory {
                    Text(directory.path)
                        .font(.caption)
                        .foregroundColor(.primary)
                        .lineLimit(1)
                        .truncationMode(.middle)
                    
                    Button("Ändern...") {
                        selectedOutputDirectory = nil
                        export()
                    }
                    .disabled(isExporting)
                } else {
                    Text("Wird beim Export ausgewählt")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
            }
            
            if isExporting {
                ProgressView(value: exportProgress)
            }
            
            HStack {
                Button("Abbrechen") {
                    dismiss()
                }
                
                Spacer()
                
                Button("Exportieren") {
                    export()
                }
                .buttonStyle(.borderedProminent)
                .disabled(selectedPreset == nil || isExporting)
            }
        }
        .padding()
        .frame(width: 400)
        .sheet(isPresented: $showPresetManagement) {
            ExportPresetManagementView(store: store)
        }
        .onAppear {
            generatePreview()
        }
        .onChange(of: store.currentPhotoID) { _, _ in
            generatePreview()
        }
    }
    
    private func generatePreview() {
        guard let photo = store.currentPhoto,
              let preset = selectedPreset else {
            previewImage = nil
            return
        }
        
        isGeneratingPreview = true
        previewImage = nil
        
        Task {
            let preview = await ExportService.shared.generatePreview(photo: photo, preset: preset)
            await MainActor.run {
                self.previewImage = preview
                self.isGeneratingPreview = false
            }
        }
    }
    
    private func export() {
        guard let preset = selectedPreset,
              let photo = store.currentPhoto else {
            return
        }
        
        isExporting = true
        
        // Verwende Template für Dateinamen (Preset-spezifisch oder global)
        let template = preset.filenameTemplate ?? AppSettings.shared.filenameTemplate
        let baseName = FilenameTemplateService.shared.generateFilename(
            template: template,
            photo: photo,
            preset: preset
        )
        let fileExtension = preset.format.fileExtension
        let suggestedFileName = "\(baseName).\(fileExtension)"
        
        let savePanel = NSSavePanel()
        savePanel.allowedContentTypes = [.jpeg, .png]
        savePanel.nameFieldStringValue = suggestedFileName
        
        // Setze aktuellen Ordner als Startpunkt, falls vorhanden
        if let currentDir = selectedOutputDirectory {
            savePanel.directoryURL = currentDir
        }
        
        savePanel.begin { response in
            if response == .OK, let url = savePanel.url {
                // Speichere Ordner für nächstes Mal
                selectedOutputDirectory = url.deletingLastPathComponent()
                
                Task {
                    do {
                        try await ExportService.shared.export(
                            photo: photo,
                            preset: preset,
                            to: url,
                            uploadTargets: store.effectiveUploadTargetsForExport
                        ) { progress in
                            DispatchQueue.main.async {
                                self.exportProgress = progress
                            }
                        }
                        
                        DispatchQueue.main.async {
                            self.isExporting = false
                            self.dismiss()
                        }
                    } catch {
                        print("Export error: \(error)")
                        DispatchQueue.main.async {
                            self.isExporting = false
                        }
                    }
                }
            } else {
                isExporting = false
            }
        }
    }
}

extension ExportPreset {
    static var none: ExportPreset? { nil }
}

