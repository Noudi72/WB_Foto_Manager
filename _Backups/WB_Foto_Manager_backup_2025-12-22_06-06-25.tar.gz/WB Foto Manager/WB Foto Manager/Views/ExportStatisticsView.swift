//
//  ExportStatisticsView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 20.12.2025.
//

import SwiftUI
import AppKit

struct ExportStatisticsView: View {
    @StateObject private var statsManager = ExportStatisticsManager.shared
    @ObservedObject var store: PhotoStore
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Export-Statistiken")
                    .font(.headline)
                
                Spacer()
                
                Button("Schließen") {
                    dismiss()
                }
                .buttonStyle(LightroomSecondaryButtonStyle())
            }
            
            // Gesamt-Statistiken
            VStack(alignment: .leading, spacing: 12) {
                Text("Gesamt")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                HStack(spacing: 24) {
                    StatCard(title: "Exports", value: "\(statsManager.totalExports)")
                    StatCard(title: "Erfolgreich", value: "\(statsManager.successfulExports.count)", color: .green)
                    StatCard(title: "Fehlgeschlagen", value: "\(statsManager.failedExports.count)", color: .red)
                    StatCard(title: "Fotos exportiert", value: "\(statsManager.totalPhotosExported)")
                    StatCard(title: "Gesamtgröße", value: String(format: "%.2f MB", statsManager.totalSizeMB))
                    StatCard(title: "Ø Export-Zeit", value: String(format: "%.1f s", statsManager.averageExportTime))
                }
            }
            .padding()
            .background(DesignSystem.Colors.background4)
            .cornerRadius(8)
            
            Divider()
            
            // Einzelne Exports
            if statsManager.statistics.isEmpty {
                Text("Noch keine Exports durchgeführt")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                    .frame(maxWidth: .infinity, alignment: .center)
                    .padding()
            } else {
                ScrollView {
                    VStack(alignment: .leading, spacing: 8) {
                        ForEach(statsManager.statistics) { stat in
                            ExportStatRow(stat: stat, store: store, statsManager: statsManager)
                        }
                    }
                }
            }
            
            HStack {
                Spacer()
                
                Button("Statistiken löschen") {
                    statsManager.clearStatistics()
                }
                .buttonStyle(LightroomSecondaryButtonStyle())
                .disabled(statsManager.statistics.isEmpty)
            }
        }
        .padding()
        .frame(width: 900, height: 600)
    }
}

private struct StatCard: View {
    let title: String
    let value: String
    var color: Color? = nil
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
            Text(value)
                .font(.headline)
                .foregroundColor(color ?? DesignSystem.Colors.text)
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(DesignSystem.Colors.background3)
        .cornerRadius(6)
    }
}

private struct ExportStatRow: View {
    let stat: ExportStatistics
    @ObservedObject var store: PhotoStore
    @ObservedObject var statsManager: ExportStatisticsManager
    @State private var isRetrying = false
    
    var body: some View {
        HStack {
            // Status-Badge
            HStack(spacing: 8) {
                Image(systemName: stat.effectiveStatus == .success ? "checkmark.circle.fill" : "xmark.circle.fill")
                    .foregroundColor(stat.effectiveStatus == .success ? .green : .red)
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(formatDate(stat.date))
                        .font(.headline)
                    
                    if let presetName = stat.presetName {
                        Text("Preset: \(presetName)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    if stat.effectiveStatus == .failed, let errorMessage = stat.errorMessage {
                        Text(errorMessage)
                            .font(.caption)
                            .foregroundColor(.red)
                            .lineLimit(2)
                    }
                }
            }
            
            Spacer()
            
            if stat.effectiveStatus == .success {
                VStack(alignment: .trailing, spacing: 4) {
                    Text("\(stat.photoCount) Fotos")
                        .font(.subheadline)
                    
                    if stat.totalSizeMB > 0 {
                        Text(String(format: "%.2f MB", stat.totalSizeMB))
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                
                VStack(alignment: .trailing, spacing: 4) {
                    if stat.durationSeconds > 0 {
                        Text(String(format: "%.1f s", stat.durationSeconds))
                            .font(.subheadline)
                        
                        Text(String(format: "%.1f Fotos/s", stat.photosPerSecond))
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
                .frame(width: 100)
            } else {
                VStack(alignment: .trailing, spacing: 4) {
                    Text("\(stat.photoCount) Fotos")
                        .font(.subheadline)
                        .foregroundColor(.red)
                    
                    Text("Fehlgeschlagen")
                        .font(.caption)
                        .foregroundColor(.red)
                }
            }
            
            // Action Buttons
            HStack(spacing: 8) {
                if let outputDirectory = stat.outputDirectory, !outputDirectory.isEmpty {
                    Button(action: {
                        let url = URL(fileURLWithPath: outputDirectory)
                        NSWorkspace.shared.open(url)
                    }) {
                        Image(systemName: "folder")
                            .font(.system(size: 14))
                    }
                    .buttonStyle(.plain)
                    .help("Ordner im Finder öffnen")
                }
                
                if stat.effectiveStatus == .failed, canRetry {
                    Button(action: retryExport) {
                        if isRetrying {
                            ProgressView()
                                .controlSize(.small)
                        } else {
                            Text("Wiederholen")
                        }
                    }
                    .buttonStyle(LightroomSecondaryButtonStyle())
                    .disabled(isRetrying)
                    .help("Export wiederholen")
                }
            }
        }
        .padding()
        .background(stat.effectiveStatus == .failed ? DesignSystem.Colors.background4.opacity(0.5) : DesignSystem.Colors.background4)
        .overlay(
            RoundedRectangle(cornerRadius: 6)
                .stroke(stat.effectiveStatus == .failed ? Color.red.opacity(0.3) : Color.clear, lineWidth: 1)
        )
        .cornerRadius(6)
    }
    
    private var canRetry: Bool {
        stat.photoIDs != nil && !stat.photoIDs!.isEmpty && stat.presetID != nil && stat.outputDirectory != nil
    }
    
    private func retryExport() {
        guard canRetry else { return }
        guard let presetID = stat.presetID,
              let preset = store.exportPresets.first(where: { $0.id == presetID }) else {
            return
        }
        
        guard let photoIDs = stat.photoIDs,
              let outputDirectory = stat.outputDirectory else {
            return
        }
        
        let photos = store.photos.filter { photoIDs.contains($0.id) }
        guard !photos.isEmpty else { return }
        
        let outputURL = URL(fileURLWithPath: outputDirectory)
        
        isRetrying = true
        
        Task {
            do {
                _ = try await ExportService.shared.exportBatch(
                    photos: photos,
                    preset: preset,
                    outputDirectory: outputURL,
                    uploadTargets: store.effectiveUploadTargetsForExport
                ) { _, _ in }
                
                await MainActor.run {
                    isRetrying = false
                }
            } catch {
                // Fehler beim Retry wird als neuer fehlgeschlagener Export gespeichert
                await MainActor.run {
                    let failedStat = ExportStatistics.failed(
                        photoCount: photos.count,
                        errorMessage: error.localizedDescription,
                        presetName: preset.name,
                        outputDirectory: outputDirectory,
                        photoIDs: photoIDs,
                        presetID: presetID
                    )
                    statsManager.addStatistics(failedStat)
                    isRetrying = false
                }
            }
        }
    }
    
    private func formatDate(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
}

