//
//  FinderLikeSidebar.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit
import Foundation
import Darwin

struct FinderLikeSidebar: View {
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @StateObject private var settings = AppSettings.shared
    @State private var expandedFolders: Set<UUID> = []
    @State private var rootFolders: [FolderItem] = []
    @State private var cloudLocations: [FolderItem] = []
    @State private var photosLibraries: [FolderItem] = []
    @State private var recents: [FolderItem] = []
    
    /// In der Sandbox zeigt `NSHomeDirectory()` oft auf den Container. Für Finder-ähnliche Pfade
    /// brauchen wir den echten User-Home-Pfad (z.B. /Users/<name>).
    private var userHomeURL: URL {
        if let pw = getpwuid(getuid()), let dir = pw.pointee.pw_dir {
            return URL(fileURLWithPath: String(cString: dir))
        }
        if let home = NSHomeDirectoryForUser(NSUserName()) {
            return URL(fileURLWithPath: home)
        }
        // Fallback ohne fileExists(), da Sandbox fileExists() manchmal "false" liefert.
        return URL(fileURLWithPath: "/Users").appendingPathComponent(NSUserName())
    }
    
    private var isCompact: Bool { settings.finderSidebarCompactMode }
    private var headerHPadding: CGFloat { isCompact ? 6 : DesignSystem.Spacing.medium }
    private var headerVPadding: CGFloat { isCompact ? 3 : DesignSystem.Spacing.small }
    
    var body: some View {
        VStack(spacing: 0) {
            // Header mit "Ordner öffnen" Button
            HStack(spacing: DesignSystem.Spacing.small) {
                Text("Ordner")
                    .font(DesignSystem.Fonts.semibold(size: isCompact ? 12 : 13))
                    .foregroundColor(DesignSystem.Colors.text)
                Spacer()
                Button(action: openFolder) {
                    Image(systemName: "folder.badge.plus")
                        .font(DesignSystem.Fonts.medium(size: isCompact ? 12 : 13))
                        .foregroundColor(DesignSystem.Colors.text2)
                        .frame(width: isCompact ? 22 : 24, height: isCompact ? 22 : 24)
                        .background(DesignSystem.Colors.background4)
                        .cornerRadius(DesignSystem.CornerRadius.small)
                }
                .buttonStyle(.plain)
                .help("Ordner öffnen...")
            }
            .padding(.horizontal, headerHPadding)
            .padding(.vertical, headerVPadding)
            .background(DesignSystem.Colors.background3)
            .border(width: 1, edges: [.bottom], color: DesignSystem.Colors.border)
            
            // Hierarchische Ordner-Liste (Finder-Stil)
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 0) {
                    // Favoriten (wie im Finder)
                    if !favorites.isEmpty {
                        SectionHeader(title: "Favoriten", isCompact: isCompact)
                        ForEach(favorites) { folder in
                            FolderTreeRow(
                                folder: folder,
                                level: 0,
                                isExpanded: expandedFolders.contains(folder.id),
                                isCompact: isCompact,
                                showIcons: settings.showSidebarIcons,
                                store: store,
                                expandedFolders: $expandedFolders,
                                onRemoveFavorite: { url in
                                    removeFromFavorites(url)
                                },
                                onRemoveRecent: nil,
                                onOpenFolder: { url in
                                    addToRecents(url)
                                }
                            )
                        }
                    }

                    // Zuletzt geöffnet (wie Finder "Zuletzt benutzt")
                    if !recents.isEmpty {
                        SectionHeader(title: "Zuletzt geöffnet", isCompact: isCompact)
                        ForEach(recents) { folder in
                            FolderTreeRow(
                                folder: folder,
                                level: 0,
                                isExpanded: expandedFolders.contains(folder.id),
                                isCompact: isCompact,
                                showIcons: settings.showSidebarIcons,
                                store: store,
                                expandedFolders: $expandedFolders,
                                onRemoveFavorite: nil,
                                onRemoveRecent: { url in
                                    removeFromRecents(url)
                                },
                                onOpenFolder: { url in
                                    addToRecents(url)
                                }
                            )
                        }
                    }
                    
                    // Smart Collections
                    if !store.smartCollections.isEmpty {
                        SectionHeader(title: "Smart Collections", isCompact: isCompact)
                        ForEach(store.smartCollections.filter { $0.isVisible }) { collection in
                            SmartCollectionSidebarRow(
                                collection: collection,
                                photoCount: store.filterPhotos(by: collection).count,
                                isSelected: uiState.activeSmartCollectionID == collection.id,
                                isCompact: isCompact,
                                showIcons: settings.showSidebarIcons
                            )
                        }
                    }
                    
                    // Orte (wie im Finder)
                    SectionHeader(title: "Orte", isCompact: isCompact)
                    
                    // Standard-Ordner
                    ForEach(standardFolders) { folder in
                        FolderTreeRow(
                            folder: folder,
                            level: 0,
                            isExpanded: expandedFolders.contains(folder.id),
                            isCompact: isCompact,
                            showIcons: settings.showSidebarIcons,
                            store: store,
                            expandedFolders: $expandedFolders,
                            onRemoveFavorite: nil,
                            onRemoveRecent: nil,
                            onOpenFolder: { url in
                                addToRecents(url)
                            }
                        )
                    }

                    // Fotos-Mediatheken (aus ~/Pictures/*.photoslibrary)
                    if !photosLibraries.isEmpty {
                        ForEach(photosLibraries) { folder in
                            FolderTreeRow(
                                folder: folder,
                                level: 0,
                                isExpanded: expandedFolders.contains(folder.id),
                                isCompact: isCompact,
                                showIcons: settings.showSidebarIcons,
                                store: store,
                                expandedFolders: $expandedFolders,
                                onRemoveFavorite: nil,
                                onRemoveRecent: nil,
                                onOpenFolder: { url in
                                    addToRecents(url)
                                }
                            )
                        }
                    }

                // Cloud-Provider (Finder-ähnlich unter "Orte": iCloud Drive / OneDrive)
                if !cloudLocations.isEmpty {
                    ForEach(cloudLocations) { folder in
                        FolderTreeRow(
                            folder: folder,
                            level: 0,
                            isExpanded: expandedFolders.contains(folder.id),
                            isCompact: isCompact,
                            showIcons: settings.showSidebarIcons,
                            store: store,
                            expandedFolders: $expandedFolders,
                            onRemoveFavorite: nil,
                            onRemoveRecent: nil,
                            onOpenFolder: { url in
                                addToRecents(url)
                            }
                        )
                    }
                }
                    
                    // Home-Ordner (alle Ordner vom MacBook)
                    if !homeFolders.isEmpty {
                        ForEach(homeFolders) { folder in
                            FolderTreeRow(
                                folder: folder,
                                level: 0,
                                isExpanded: expandedFolders.contains(folder.id),
                                isCompact: isCompact,
                                showIcons: settings.showSidebarIcons,
                                store: store,
                                expandedFolders: $expandedFolders,
                                onRemoveFavorite: nil,
                                onRemoveRecent: nil,
                                onOpenFolder: { url in
                                    addToRecents(url)
                                }
                            )
                        }
                    }
                    
                    // Volumes (externe Laufwerke, iCloud, OneDrive, etc.)
                    if !volumes.isEmpty {
                        ForEach(volumes) { folder in
                            FolderTreeRow(
                                folder: folder,
                                level: 0,
                                isExpanded: expandedFolders.contains(folder.id),
                                isCompact: isCompact,
                                showIcons: settings.showSidebarIcons,
                                store: store,
                                expandedFolders: $expandedFolders,
                                onRemoveFavorite: nil,
                                onRemoveRecent: nil,
                                onOpenFolder: { url in
                                    addToRecents(url)
                                }
                            )
                        }
                    }
                }
                .padding(.vertical, isCompact ? 1 : 4)
            }
        }
        .background(DesignSystem.Colors.background3)
        // Wichtig: erzwingt ein lesbares Dark-Theme auch dann, wenn macOS im Light-Mode läuft.
        .lightroomSidebarTheme()
        .controlSize(isCompact ? .mini : .small)
        .onAppear {
            loadVolumes()
            loadCloudLocations()
            loadPhotosLibraries()
            loadFavorites()
            loadRecents()
            loadHomeFolders()
        }
        .onReceive(NotificationCenter.default.publisher(for: NSNotification.Name("SidebarFoldersUpdated"))) { _ in
            loadFavorites()
            loadRecents()
            loadPhotosLibraries()
        }
        .onChange(of: store.currentFolder) { _, newFolder in
            if let url = newFolder {
                addToRecents(url)
            }
        }
        .onReceive(NotificationCenter.default.publisher(for: NSWorkspace.didMountNotification)) { _ in
            loadVolumes()
            loadCloudLocations()
            loadPhotosLibraries()
        }
        .onReceive(NotificationCenter.default.publisher(for: NSWorkspace.didUnmountNotification)) { _ in
            loadVolumes()
            loadCloudLocations()
            loadPhotosLibraries()
        }
    }
    
    private var standardFolders: [FolderItem] {
        // In der App-Sandbox liefern FileManager.urls(for: ...) oft Container-Pfade (~/Library/Containers/...).
        // Für Finder-ähnliche Navigation wollen wir die echten User-Ordner anzeigen.
        let home = userHomeURL
        return [
            FolderItem(url: home, name: "Home", type: .standard(.home)),
            FolderItem(url: home.appendingPathComponent("Desktop"), name: "Desktop", type: .standard(.desktop)),
            FolderItem(url: home.appendingPathComponent("Downloads"), name: "Downloads", type: .standard(.downloads)),
            FolderItem(url: home.appendingPathComponent("Pictures"), name: "Pictures", type: .standard(.pictures))
        ]
    }
    
    @State private var volumes: [FolderItem] = []
    @State private var favorites: [FolderItem] = []
    @State private var homeFolders: [FolderItem] = []
    
    private func openFolder() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = false
        panel.title = "Ordner auswählen"
        panel.prompt = "Öffnen"
        panel.message = "Wählen Sie einen Ordner mit Bildern aus"
        panel.treatsFilePackagesAsDirectories = true // erlaubt auch *.photoslibrary
        
        // Wichtig: Erlaube Zugriff auf alle Volumes
        panel.directoryURL = nil // Startet im Standard-Verzeichnis
        
        let response = panel.runModal()
        if response == .OK, let url = panel.url {
            // Erstelle Security-Scoped Bookmark für persistente Zugriffe
            saveBookmark(for: url)
            
            store.loadPhotos(from: url)
            addToFavorites(url)
            addToRecents(url)
        }
    }
    
    private func saveBookmark(for url: URL) {
        do {
            let bookmarkData = try url.bookmarkData(
                options: [.withSecurityScope],
                includingResourceValuesForKeys: nil,
                relativeTo: nil
            )
            
            // Speichere Bookmark
            var bookmarks = UserDefaults.standard.dictionary(forKey: "folderBookmarks") ?? [:]
            bookmarks[url.path] = bookmarkData
            UserDefaults.standard.set(bookmarks, forKey: "folderBookmarks")

            // Sidebar-Listen refreshen (Cloud/Photos/Recents etc.)
            NotificationCenter.default.post(name: NSNotification.Name("SidebarFoldersUpdated"), object: nil)
        } catch {
            print("Fehler beim Speichern des Bookmarks: \(error)")
        }
    }
    
    private func loadVolumes() {
        let fileManager = FileManager.default
        let volumeURLs = fileManager.mountedVolumeURLs(includingResourceValuesForKeys: [.volumeNameKey, .volumeIsRemovableKey], options: []) ?? []
        
        var foundVolumes: [FolderItem] = []
        
        // 1. Lade normale Volumes (externe Laufwerke, etc.)
        for url in volumeURLs {
            guard let resourceValues = try? url.resourceValues(forKeys: [.volumeNameKey, .volumeIsRemovableKey]),
                  let name = resourceValues.volumeName else {
                continue
            }
            
            // FILTERE SIMULATOREN RAUS!
            if name.contains("Simulator") || name.contains("iOS") || name.contains("WatchOS") || name.contains("tvOS") {
                continue
            }

            // Cloud-Provider nicht als "Volume" doppelt anzeigen (die zeigen wir unter "Orte")
            let lower = name.lowercased()
            if lower.contains("onedrive") || lower.contains("icloud") {
                continue
            }
            
            // Zeige ALLE Volumes in /Volumes/ (inkl. OneDrive, externe SSDs, etc.)
            if url.path.contains("/Volumes/") && !url.path.contains("/System/Volumes/") {
                if !name.lowercased().contains("simulator") {
                    let children = loadSubfolders(for: url)
                    foundVolumes.append(FolderItem(url: url, name: name, type: .volume, children: children))
                }
            }
        }
        
        volumes = foundVolumes
    }

    private func loadCloudLocations() {
        let fileManager = FileManager.default
        let homeURL = userHomeURL
        var found: [FolderItem] = []

        // 1) iCloud Drive (klassischer Pfad) – immer anzeigen (auch wenn Sandbox fileExists blockt)
        let iCloudDriveURL = homeURL.appendingPathComponent("Library/Mobile Documents/com~apple~CloudDocs")
        let iCloudChildren = FileManager.default.isReadableFile(atPath: iCloudDriveURL.path) ? loadSubfolders(for: iCloudDriveURL) : []
        found.append(FolderItem(url: iCloudDriveURL, name: "iCloud Drive", type: .volume, children: iCloudChildren))

        // 2) FileProvider/CloudStorage (OneDrive, iCloud etc.)
        let cloudStorageURL = homeURL.appendingPathComponent("Library/CloudStorage")
        var didFindOneDrive = false
        do {
            let contents = try fileManager.contentsOfDirectory(
                at: cloudStorageURL,
                includingPropertiesForKeys: [.isDirectoryKey],
                options: [.skipsHiddenFiles]
            )

            for url in contents {
                guard let resourceValues = try? url.resourceValues(forKeys: [.isDirectoryKey]),
                      resourceValues.isDirectory == true else {
                    continue
                }

                let rawName = url.lastPathComponent
                let lower = rawName.lowercased()

                if lower.contains("onedrive") || lower.contains("microsoft") {
                    didFindOneDrive = true
                    let children = FileManager.default.isReadableFile(atPath: url.path) ? loadSubfolders(for: url) : []
                    // Wenn mehrere OneDrive-Instanzen existieren (Business/Personal), zeige den Ordnernamen.
                    let display = rawName.lowercased().contains("onedrive") ? rawName : "OneDrive"
                    found.append(FolderItem(url: url, name: display, type: .volume, children: children))
                } else if lower.contains("icloud") {
                    // Nur ergänzen, wenn iCloud nicht bereits über den Standardpfad drin ist
                    if !found.contains(where: { $0.name == "iCloud Drive" }) {
                        let children = FileManager.default.isReadableFile(atPath: url.path) ? loadSubfolders(for: url) : []
                        found.append(FolderItem(url: url, name: "iCloud Drive", type: .volume, children: children))
                    }
                }
            }
        } catch {
            // Wenn die Sandbox den Ordner nicht lesen darf, zeigen wir trotzdem einen sinnvollen OneDrive-Eintrag
            // (der Klick löst dann den Permission-Dialog im richtigen Ordner aus).
            didFindOneDrive = false
        }

        if !didFindOneDrive {
            // Häufigster deutscher OneDrive-Name
            let oneDriveGuess = cloudStorageURL.appendingPathComponent("OneDrive-Persönlich")
            found.append(FolderItem(url: oneDriveGuess, name: "OneDrive", type: .volume, children: []))
        }

        // Stabil sortieren (iCloud zuerst, dann OneDrive/Rest)
        cloudLocations = found.sorted { lhs, rhs in
            if lhs.name == "iCloud Drive" { return true }
            if rhs.name == "iCloud Drive" { return false }
            return lhs.name.localizedCaseInsensitiveCompare(rhs.name) == .orderedAscending
        }
    }
    
    private func loadHomeFolders() {
        let fileManager = FileManager.default
        let home = userHomeURL
        
        // Lade alle Ordner im Home-Verzeichnis (wie im Finder sichtbar)
        guard let contents = try? fileManager.contentsOfDirectory(
            at: home,
            includingPropertiesForKeys: [.isDirectoryKey, .isHiddenKey],
            options: [.skipsHiddenFiles]
        ) else {
            homeFolders = []
            return
        }
        
        var folders: [FolderItem] = []
        
        for url in contents {
            guard let resourceValues = try? url.resourceValues(forKeys: [.isDirectoryKey, .isHiddenKey]),
                  resourceValues.isDirectory == true,
                  resourceValues.isHidden != true else {
                continue
            }
            
            // Überspringe Standard-Ordner, die bereits oben angezeigt werden
            let name = url.lastPathComponent
            if ["Desktop", "Documents", "Downloads", "Pictures"].contains(name) {
                continue
            }

            // Wunsch: System-/Noise-Ordner nicht anzeigen
            let lower = name.lowercased()
            if lower == "systemdata" || lower == "tmp" {
                continue
            }
            
            // Überspringe System-Ordner
            if name.hasPrefix(".") || name == "Library" {
                continue
            }
            
            let children = loadSubfolders(for: url)
            folders.append(FolderItem(url: url, name: name, type: .regular, children: children))
        }
        
        // Sortiere alphabetisch
        homeFolders = folders.sorted { $0.name < $1.name }
    }

    private func loadPhotosLibraries() {
        let fileManager = FileManager.default
        let picturesURL = userHomeURL.appendingPathComponent("Pictures")
        let contents = (try? fileManager.contentsOfDirectory(
            at: picturesURL,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [.skipsHiddenFiles]
        )) ?? []

        var found: [FolderItem] = []
        for url in contents {
            guard url.pathExtension.lowercased() == "photoslibrary" else { continue }
            guard let values = try? url.resourceValues(forKeys: [.isDirectoryKey]),
                  values.isDirectory == true else { continue }

            let displayName = url.deletingPathExtension().lastPathComponent
            found.append(FolderItem(url: url, name: displayName, type: .standard(.photosLibrary)))
        }

        // Fallback: Standard-Pfad immer anzeigen (auch wenn Sandbox den Ordner nicht lesen darf)
        if found.isEmpty {
            let defaultPhotosLibrary = picturesURL.appendingPathComponent("Photos Library.photoslibrary")
            found.append(FolderItem(url: defaultPhotosLibrary, name: "Photos Library", type: .standard(.photosLibrary)))
        }

        photosLibraries = found.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }
    
    private func loadSubfolders(for parentURL: URL) -> [FolderItem] {
        let fileManager = FileManager.default
        guard let enumerator = fileManager.enumerator(
            at: parentURL,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [.skipsHiddenFiles, .skipsSubdirectoryDescendants],
            errorHandler: nil
        ) else {
            return []
        }
        
        var subfolders: [FolderItem] = []
        for case let url as URL in enumerator {
            guard let resourceValues = try? url.resourceValues(forKeys: [.isDirectoryKey]),
                  resourceValues.isDirectory == true else {
                continue
            }
            
            // Lade nur direkte Unterordner (max. 1 Level tief für Performance)
            subfolders.append(FolderItem(url: url, name: url.lastPathComponent, type: .regular))
        }
        
        return subfolders.sorted { $0.name < $1.name }
    }
    
    private func loadFavorites() {
        if let favoritePaths = UserDefaults.standard.stringArray(forKey: "favoriteFolders") {
            favorites = favoritePaths.compactMap { path in
                let url = URL(fileURLWithPath: path)
                guard FileManager.default.fileExists(atPath: path) else { return nil }
                let children = loadSubfolders(for: url)
                return FolderItem(url: url, name: url.lastPathComponent, type: .favorite, children: children)
            }
        }
    }
    
    private func addToFavorites(_ url: URL) {
        // Entferne Duplikate
        favorites.removeAll { $0.url == url }
        
        // Füge am Anfang hinzu
        let children = loadSubfolders(for: url)
        let folder = FolderItem(url: url, name: url.lastPathComponent, type: .favorite, children: children)
        favorites.insert(folder, at: 0)
        
        // Begrenze auf 10
        if favorites.count > 10 {
            favorites = Array(favorites.prefix(10))
        }
        
        // Speichere in UserDefaults
        let paths = favorites.map { $0.url.path }
        UserDefaults.standard.set(paths, forKey: "favoriteFolders")
    }
    
    private func removeFromFavorites(_ url: URL) {
        favorites.removeAll { $0.url == url }
        
        // Speichere in UserDefaults
        let paths = favorites.map { $0.url.path }
        UserDefaults.standard.set(paths, forKey: "favoriteFolders")
    }

    // MARK: - Zuletzt geöffnet (Recents)

    private func loadRecents() {
        guard let recentPaths = UserDefaults.standard.stringArray(forKey: "recentFolders") else {
            recents = []
            return
        }
        var seen = Set<String>()
        recents = recentPaths.compactMap { path in
            let url = normalizeSpecialURL(URL(fileURLWithPath: path))
            // Wunsch: bestimmte "System"-Ordner nicht anzeigen
            let name = url.lastPathComponent
            let lower = name.lowercased()
            if name == "Documents" || lower == "systemdata" || lower == "tmp" {
                return nil
            }
            // Dedupe nach Normalisierung
            let key = url.standardizedFileURL.path
            guard !seen.contains(key) else { return nil }
            seen.insert(key)
            // In der Sandbox kann fileExists/readable false liefern, obwohl der Pfad real existiert.
            // Für "Zuletzt geöffnet" zeigen wir Einträge trotzdem an; beim Klick holen wir Permission nach.
            let children = FileManager.default.isReadableFile(atPath: url.path) ? loadSubfolders(for: url) : []
            return FolderItem(url: url, name: url.lastPathComponent, type: .recent, children: children)
        }
    }

    private func addToRecents(_ url: URL) {
        let standardized = normalizeSpecialURL(url.standardizedFileURL)
        recents.removeAll { $0.url.standardizedFileURL.path == standardized.path }

        let children = FileManager.default.isReadableFile(atPath: standardized.path) ? loadSubfolders(for: standardized) : []
        let item = FolderItem(url: standardized, name: standardized.lastPathComponent, type: .recent, children: children)
        recents.insert(item, at: 0)

        // Begrenze auf 12 (Finder-ähnlich, aber kompakt)
        if recents.count > 12 {
            recents = Array(recents.prefix(12))
        }

        let paths = recents.map { $0.url.path }
        UserDefaults.standard.set(paths, forKey: "recentFolders")
    }

    private func removeFromRecents(_ url: URL) {
        let standardized = normalizeSpecialURL(url.standardizedFileURL)
        recents.removeAll { $0.url.standardizedFileURL.path == standardized.path }
        let paths = recents.map { $0.url.path }
        UserDefaults.standard.set(paths, forKey: "recentFolders")
    }

    /// Verhindert, dass interne Photos-Library Unterordner (resources/database/…) in Recents landen.
    /// Wir normalisieren auf die *.photoslibrary Root.
    private func normalizePhotosLibraryURL(_ url: URL) -> URL {
        let components = url.standardizedFileURL.pathComponents
        if let idx = components.firstIndex(where: { $0.lowercased().hasSuffix(".photoslibrary") }) {
            let rootParts = components.prefix(idx + 1)
            let rootPath = NSString.path(withComponents: Array(rootParts))
            return URL(fileURLWithPath: rootPath)
        }
        return url
    }

    /// Migriert alte Sandbox-Container-Pfade (z.B. ~/Library/Containers/.../Data/Pictures)
    /// auf den echten User-Pfad (/Users/<name>/Pictures), damit "Pictures" wirklich Bilder lädt.
    private func normalizeSandboxStandardFolderURL(_ url: URL) -> URL {
        let standardized = url.standardizedFileURL
        let containerHome = FileManager.default.homeDirectoryForCurrentUser.standardizedFileURL
        let containerComponents = containerHome.pathComponents
        let urlComponents = standardized.pathComponents

        guard urlComponents.count >= containerComponents.count,
              zip(urlComponents.prefix(containerComponents.count), containerComponents).allSatisfy({ $0 == $1 }) else {
            return url
        }

        // Nur die direkten Standard-Ordner mappen (nicht beliebige Pfade).
        let relativeComponents = Array(urlComponents.dropFirst(containerComponents.count))
        guard let first = relativeComponents.first else { return userHomeURL }

        if ["Pictures", "Downloads", "Desktop", "Documents"].contains(first) {
            var out = userHomeURL
            for comp in relativeComponents {
                out.appendPathComponent(comp)
            }
            return out
        }

        return url
    }

    private func normalizeSpecialURL(_ url: URL) -> URL {
        normalizePhotosLibraryURL(normalizeSandboxStandardFolderURL(url))
    }
}

struct SectionHeader: View {
    let title: String
    let isCompact: Bool
    
    var body: some View {
        Text(title.uppercased())
            .font(DesignSystem.Fonts.semibold(size: 11))
            .foregroundColor(DesignSystem.Colors.text)
            .tracking(0.5)
            .padding(.horizontal, isCompact ? 6 : DesignSystem.Spacing.medium)
            .padding(.vertical, isCompact ? 2 : DesignSystem.Spacing.small)
    }
}

struct FolderTreeRow: View {
    let folder: FolderItem
    let level: Int
    @State var isExpanded: Bool
    let isCompact: Bool
    let showIcons: Bool
    @ObservedObject var store: PhotoStore
    @Binding var expandedFolders: Set<UUID>
    @State private var children: [FolderItem] = []
    @State private var isHovering = false
    var onRemoveFavorite: ((URL) -> Void)? = nil
    var onRemoveRecent: ((URL) -> Void)? = nil
    var onOpenFolder: ((URL) -> Void)? = nil
    
    var body: some View {
        let rowHPad: CGFloat = isCompact ? 6 : 8
        let rowVPad: CGFloat = isCompact ? 2 : 4
        let indentW: CGFloat = isCompact ? 10 : 16
        let labelSize: CGFloat = isCompact ? 11 : 13
        let iconSize: CGFloat = isCompact ? 12 : 14
        let iconW: CGFloat = isCompact ? 14 : 18
        let chevronSize: CGFloat = isCompact ? 8 : 10
        let chevronW: CGFloat = isCompact ? 9 : 12
        
        VStack(alignment: .leading, spacing: 0) {
            Button(action: {
                if !folder.children.isEmpty {
                    isExpanded.toggle()
                    if isExpanded {
                        expandedFolders.insert(folder.id)
                        loadChildrenIfNeeded()
                    } else {
                        expandedFolders.remove(folder.id)
                    }
                } else {
                    // Lade Bilder aus diesem Ordner (Sandbox-safe)
                    if let resolved = resolvedBookmarkURL(for: folder.url) {
                        store.loadPhotos(from: resolved)
                        onOpenFolder?(resolved)
                        return
                    }
                    
                    // Wenn der Pfad direkt lesbar ist (z.B. ohne Sandbox oder für Container-Ordner), lade direkt.
                    if FileManager.default.isReadableFile(atPath: folder.url.path) {
                        store.loadPhotos(from: folder.url)
                        onOpenFolder?(folder.url)
                        return
                    }
                    
                    // Sonst Permission via OpenPanel einholen (User-selected folder access).
                    requestAccessAndLoad(startingAt: folder.url)
                }
            }) {
                HStack(spacing: isCompact ? 2 : 4) {
                    // Einrückung
                    ForEach(0..<level, id: \.self) { _ in
                        Rectangle()
                            .fill(Color.clear)
                            .frame(width: indentW)
                    }
                    
                    // Expand/Collapse Icon
                    if !folder.children.isEmpty {
                        Image(systemName: isExpanded ? "chevron.down" : "chevron.right")
                            .font(.system(size: chevronSize))
                            .foregroundColor(DesignSystem.Colors.text)
                            .frame(width: chevronW)
                    } else {
                        Rectangle()
                            .fill(Color.clear)
                            .frame(width: chevronW)
                    }
                    
                    // Folder Icon
                    if showIcons {
                        Image(systemName: folder.type.icon)
                            .font(DesignSystem.Fonts.regular(size: iconSize))
                            .foregroundColor(isSelected ? DesignSystem.Colors.accent : DesignSystem.Colors.text)
                            .frame(width: iconW)
                    }
                    
                    // Folder Name
                    Text(folder.name)
                        .font(DesignSystem.Fonts.regular(size: labelSize))
                        .foregroundColor(isSelected ? DesignSystem.Colors.text : DesignSystem.Colors.text)
                        .lineLimit(1)
                    
                    Spacer()
                }
                .padding(.horizontal, rowHPad)
                .padding(.vertical, rowVPad)
            }
            .buttonStyle(.plain)
            .background(
                Group {
                    if isSelected {
                        DesignSystem.Colors.accent.opacity(0.15)
                    } else if isHovering {
                        DesignSystem.Colors.background4
                    } else {
                        Color.clear
                    }
                }
            )
            .contentShape(Rectangle())
            .onHover { hovering in
                isHovering = hovering
            }
            .contextMenu {
                if folder.type == .favorite {
                    Button("Aus Favoriten entfernen") {
                        onRemoveFavorite?(folder.url)
                    }
                }
                if folder.type == .recent {
                    Button("Aus „Zuletzt geöffnet“ entfernen") {
                        onRemoveRecent?(folder.url)
                    }
                }
            }
            
            // Unterordner (wenn expanded)
            if isExpanded {
                ForEach(children.isEmpty ? folder.children : children) { child in
                    FolderTreeRow(
                        folder: child,
                        level: level + 1,
                        isExpanded: expandedFolders.contains(child.id),
                        isCompact: isCompact,
                        showIcons: showIcons,
                        store: store,
                        expandedFolders: $expandedFolders,
                        onRemoveFavorite: onRemoveFavorite,
                        onRemoveRecent: onRemoveRecent,
                        onOpenFolder: onOpenFolder
                    )
                }
            }
        }
    }
    
    private var isSelected: Bool {
        guard let current = store.currentFolder else { return false }
        return current.standardizedFileURL.path == folder.url.standardizedFileURL.path
    }
    
    private func loadChildrenIfNeeded() {
        // Wenn bereits geladen, nichts tun
        if !children.isEmpty {
            return
        }
        
        // Wenn folder.children bereits vorhanden, verwende diese
        if !folder.children.isEmpty {
            children = folder.children
            return
        }
        
        // Wichtig für Swift Concurrency: Werte vor dem Detached-Task capturen,
        // damit wir keine MainActor-isolierten View-Properties im Background lesen müssen.
        let parentURL = folder.url
        
        // Lade Unterordner dynamisch
        Task.detached(priority: .utility) {
            let fileManager = FileManager.default
            
            // Prüfe ob Ordner existiert
            var isDirectory: ObjCBool = false
            guard fileManager.fileExists(atPath: parentURL.path, isDirectory: &isDirectory),
                  isDirectory.boolValue else {
                return
            }
            
            // Lade nur direkte Unterordner (nicht rekursiv)
            guard let contents = try? fileManager.contentsOfDirectory(
                at: parentURL,
                includingPropertiesForKeys: [.isDirectoryKey],
                options: [.skipsHiddenFiles]
            ) else {
                return
            }
            
            var subfolderURLs: [URL] = []
            for url in contents {
                guard let resourceValues = try? url.resourceValues(forKeys: [.isDirectoryKey]),
                      resourceValues.isDirectory == true else {
                    continue
                }
                
                subfolderURLs.append(url)
            }
            
            let sortedURLs = subfolderURLs.sorted { $0.lastPathComponent < $1.lastPathComponent }
            
            await MainActor.run {
                self.children = sortedURLs.map { FolderItem(url: $0, name: $0.lastPathComponent, type: .regular) }
            }
        }
    }
    
    private func resolvedBookmarkURL(for url: URL) -> URL? {
        guard let bookmarks = UserDefaults.standard.dictionary(forKey: "folderBookmarks"),
              let bookmarkData = bookmarks[url.path] as? Data else {
            return nil
        }
        
        var isStale = false
        guard let resolvedURL = try? URL(
            resolvingBookmarkData: bookmarkData,
            options: [.withSecurityScope],
            relativeTo: nil,
            bookmarkDataIsStale: &isStale
        ) else {
            return nil
        }
        
        // Falls stale, speichern wir es beim nächsten erfolgreichen Zugriff neu.
        return resolvedURL
    }
    
    private func saveBookmark(for url: URL) {
        do {
            let bookmarkData = try url.bookmarkData(
                options: [.withSecurityScope],
                includingResourceValuesForKeys: nil,
                relativeTo: nil
            )
            var bookmarks = UserDefaults.standard.dictionary(forKey: "folderBookmarks") ?? [:]
            bookmarks[url.path] = bookmarkData
            UserDefaults.standard.set(bookmarks, forKey: "folderBookmarks")
            NotificationCenter.default.post(name: NSNotification.Name("SidebarFoldersUpdated"), object: nil)
        } catch {
            print("Fehler beim Speichern des Bookmarks: \(error)")
        }
    }
    
    private func requestAccessAndLoad(startingAt url: URL) {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = false
        panel.prompt = "Zugriff erlauben"
        panel.message = "Damit WB Foto Manager auf diesen Ordner zugreifen kann, bitte den Ordner auswählen."
        panel.treatsFilePackagesAsDirectories = (url.pathExtension.lowercased() == "photoslibrary")
        
        // Starte im Parent, damit der Ordner leicht auswählbar ist.
        // (Auch wenn Sandbox fileExists blockt, ist der Pfad für den User hilfreich.)
        panel.directoryURL = url.deletingLastPathComponent()
        
        if panel.runModal() == .OK, let selected = panel.url {
            saveBookmark(for: selected)
            store.loadPhotos(from: selected)
            onOpenFolder?(selected)
        }
    }
}

struct SmartCollectionSidebarRow: View {
    let collection: SmartCollection
    let photoCount: Int
    let isSelected: Bool
    let isCompact: Bool
    let showIcons: Bool
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    var body: some View {
        HStack(spacing: DesignSystem.Spacing.small) {
            if showIcons {
                Image(systemName: "sparkles")
                    .font(.system(size: isCompact ? 10 : 11))
                    .foregroundColor(DesignSystem.Colors.accent)
                    .frame(width: isCompact ? 14 : 16)
            }
            
            VStack(alignment: .leading, spacing: 1) {
                Text(collection.name)
                    .font(DesignSystem.Fonts.regular(size: isCompact ? 11 : 12))
                    .foregroundColor(DesignSystem.Colors.text)
                    .lineLimit(1)
                
                Text("\(photoCount)")
                    .font(DesignSystem.Fonts.regular(size: isCompact ? 9 : 10))
                    .foregroundColor(DesignSystem.Colors.text2)
            }
            
            Spacer()
        }
        .padding(.horizontal, isCompact ? 6 : DesignSystem.Spacing.medium)
        .padding(.vertical, isCompact ? 2 : DesignSystem.Spacing.tiny)
        .background(isSelected ? DesignSystem.Colors.accent.opacity(0.18) : Color.clear)
        .contentShape(Rectangle())
        .onTapGesture {
            // Toggle Smart Collection
            if uiState.activeSmartCollectionID == collection.id {
                uiState.activeSmartCollectionID = nil
            } else {
                uiState.activeSmartCollectionID = collection.id
            }
        }
        .contextMenu {
            Button("Verwalten…") {
                uiState.activeSheet = .smartCollections
            }
            
            Button("Löschen") {
                store.deleteSmartCollection(collection)
                if uiState.activeSmartCollectionID == collection.id {
                    uiState.activeSmartCollectionID = nil
                }
            }
        }
    }
}

