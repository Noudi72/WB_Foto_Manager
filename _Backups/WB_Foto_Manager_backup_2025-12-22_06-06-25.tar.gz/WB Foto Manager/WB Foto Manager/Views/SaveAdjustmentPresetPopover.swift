//
//  SaveAdjustmentPresetPopover.swift
//  WB Foto Manager
//
//  Quick workflow: adjust photo until it looks right → save as preset (without losing visual context).
//

import SwiftUI

struct SaveAdjustmentPresetPopover: View {
    @ObservedObject var store: PhotoStore
    @Binding var isPresented: Bool
    
    @StateObject private var settings = AppSettings.shared
    @FocusState private var nameFocused: Bool
    
    @State private var name: String = ""
    @State private var group: String = ""
    @State private var capturedAdjustments: PhotoAdjustments = PhotoAdjustments()
    @State private var didCapture: Bool = false
    
    var body: some View {
        let isCompact = settings.adjustmentsSidebarCompactMode
        
        VStack(alignment: .leading, spacing: isCompact ? 8 : 10) {
            HStack {
                Text("Preset speichern")
                    .font(DesignSystem.Fonts.semibold(size: 14))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Spacer()
                
                Button {
                    isPresented = false
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(DesignSystem.Colors.text2)
                        .frame(width: 24, height: 24)
                        .background(DesignSystem.Colors.background4)
                        .cornerRadius(DesignSystem.CornerRadius.small)
                        .overlay(
                            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                                .stroke(DesignSystem.Colors.border, lineWidth: 1)
                        )
                }
                .buttonStyle(.plain)
                .help("Schließen")
            }
            
            Text("Speichert die aktuellen Einstellungen des Fotos als Preset.")
                .font(DesignSystem.Fonts.regular(size: isCompact ? 10 : 11))
                .foregroundColor(DesignSystem.Colors.text3)
            
            Divider().opacity(0.7)
            
            VStack(alignment: .leading, spacing: 6) {
                Text("NAME")
                    .font(DesignSystem.Fonts.semibold(size: 11))
                    .foregroundColor(DesignSystem.Colors.text2)
                    .tracking(0.6)
                
                TextField("Preset Name", text: $name)
                    .textFieldStyle(.roundedBorder)
                    .focused($nameFocused)
            }
            
            VStack(alignment: .leading, spacing: 6) {
                Text("KATEGORIE (OPTIONAL)")
                    .font(DesignSystem.Fonts.semibold(size: 11))
                    .foregroundColor(DesignSystem.Colors.text2)
                    .tracking(0.6)
                
                HStack(spacing: 8) {
                    TextField("z.B. \"Eishockey\"", text: $group)
                        .textFieldStyle(.roundedBorder)
                    
                    Menu {
                        Button("—") { group = "" }
                        Divider()
                        ForEach(store.presetGroups, id: \.self) { g in
                            Button(g) { group = g }
                        }
                    } label: {
                        Image(systemName: "chevron.down")
                            .font(.system(size: 12, weight: .semibold))
                            .foregroundColor(DesignSystem.Colors.text2)
                            .frame(width: 28, height: 28)
                            .background(DesignSystem.Colors.background4)
                            .cornerRadius(DesignSystem.CornerRadius.small)
                            .overlay(
                                RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
                            )
                    }
                    .menuStyle(.borderlessButton)
                    .help("Kategorie auswählen")
                }
            }
            
            HStack {
                Button("Abbrechen") {
                    isPresented = false
                }
                .buttonStyle(LightroomSecondaryButtonStyle())
                
                Spacer()
                
                Button("Speichern") {
                    savePreset()
                }
                .buttonStyle(.borderedProminent)
                .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || store.currentPhoto == nil)
            }
            .padding(.top, 2)
        }
        .padding(isCompact ? 10 : 14)
        .frame(width: isCompact ? 360 : 400)
        .background(DesignSystem.Colors.background2)
        .lightroomSidebarTheme()
        .controlSize(isCompact ? .mini : .small)
        .onAppear {
            captureIfNeeded()
            DispatchQueue.main.async { self.nameFocused = true }
        }
        .onChange(of: isPresented) { _, newValue in
            // Wenn Popover erneut geöffnet wird, immer frisch capturen (damit es "was ich gerade sehe" ist).
            if newValue {
                didCapture = false
                captureIfNeeded()
                DispatchQueue.main.async { self.nameFocused = true }
            }
        }
    }
    
    private func captureIfNeeded() {
        guard !didCapture else { return }
        if let photo = store.currentPhoto {
            capturedAdjustments = photo.adjustments
        }
        didCapture = true
    }
    
    private func savePreset() {
        guard let _ = store.currentPhoto else { return }
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmedName.isEmpty else { return }
        
        let trimmedGroup = group.trimmingCharacters(in: .whitespacesAndNewlines)
        let preset = AdjustmentPreset(
            name: trimmedName,
            group: trimmedGroup.isEmpty ? nil : trimmedGroup,
            adjustments: capturedAdjustments
        )
        
        store.addAdjustmentPreset(preset)
        isPresented = false
        
        // Reset fields for next time
        name = ""
        group = ""
        didCapture = false
    }
}


