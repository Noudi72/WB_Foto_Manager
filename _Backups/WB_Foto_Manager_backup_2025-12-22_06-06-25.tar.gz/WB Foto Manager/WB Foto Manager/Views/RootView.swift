//
//  RootView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit

struct RootView: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @StateObject private var settings = AppSettings.shared
    
    // Persistente Sidebar-Breiten (Finder-like)
    @AppStorage("leftSidebarWidthV1") private var leftSidebarWidth: Double = 180
    @AppStorage("rightSidebarWidthV1") private var rightSidebarWidth: Double = 180
    
    private let minLeftSidebarWidth: Double = 160
    private let maxLeftSidebarWidth: Double = 320
    private let minRightSidebarWidth: Double = 160
    private let maxRightSidebarWidth: Double = 360
    
    private var isLeftSidebarVisible: Bool {
        !uiState.isFocusMode && (uiState.showLeftSidebar || settings.sidebarAlwaysVisible)
    }
    private var isRightSidebarVisible: Bool {
        !uiState.isFocusMode && uiState.showRightSidebar
    }
    
    var body: some View {
        let leftW = min(maxLeftSidebarWidth, max(minLeftSidebarWidth, leftSidebarWidth))
        let rightW = min(maxRightSidebarWidth, max(minRightSidebarWidth, rightSidebarWidth))
        
        HStack(spacing: 0) {
            if isLeftSidebarVisible {
                FinderLikeSidebar(store: store)
                    .frame(width: CGFloat(leftW))
                    .zIndex(1) // Sidebar unter Topbar
                
                SidebarResizeHandle(
                    width: $leftSidebarWidth,
                    minWidth: minLeftSidebarWidth,
                    maxWidth: maxLeftSidebarWidth,
                    invertDrag: false
                )
            }
            
            MainContentView()
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                .zIndex(10) // MainContent (inkl. TopTabBar) über Sidebar
            
            if isRightSidebarVisible {
                SidebarResizeHandle(
                    width: $rightSidebarWidth,
                    minWidth: minRightSidebarWidth,
                    maxWidth: maxRightSidebarWidth,
                    invertDrag: true
                )
                
                AdjustmentsSidebar(store: store)
                    .frame(width: CGFloat(rightW))
                    .allowsHitTesting(true)
                    .contentShape(Rectangle())
                    .zIndex(1) // Sidebar unter Topbar
            }
        }
        .background(DesignSystem.Colors.background)
        .toolbar {
            // Custom LabelStyle für kleinere Icons in der Toolbar
            ToolbarItem(placement: .navigation) {
                Button(action: {
                    // Wenn "immer sichtbar" aktiv ist, soll die Sidebar nicht ausgeblendet werden.
                    if settings.sidebarAlwaysVisible {
                        uiState.showLeftSidebar = true
                    } else {
                        uiState.showLeftSidebar.toggle()
                    }
                }) {
                    Label("Sidebar links", systemImage: "sidebar.left")
                }
                .disabled(settings.sidebarAlwaysVisible)
                .help(settings.sidebarAlwaysVisible ? "Sidebar ist in den Einstellungen als 'immer sichtbar' aktiviert" : "Sidebar ein-/ausblenden")
            }
            
            ToolbarItem(placement: .automatic) {
                Button(action: { uiState.isFocusMode.toggle() }) {
                    Label("Focus‑Mode", systemImage: uiState.isFocusMode ? "arrow.down.right.and.arrow.up.left" : "arrow.up.left.and.arrow.down.right")
                }
                .help(uiState.isFocusMode ? "Focus‑Mode verlassen (⌥⌘F)" : "Focus‑Mode (⌥⌘F)")
            }
            
            ToolbarItem(placement: .automatic) {
                Menu {
                    Toggle("Topbar anzeigen", isOn: $uiState.showTopBar)
                        .disabled(uiState.isFocusMode)
                    
                    Toggle("Filmstreifen anzeigen", isOn: $uiState.showFilmstrip)
                        .disabled(uiState.isFocusMode)
                } label: {
                    Label("Layout", systemImage: "rectangle.3.offgrid")
                }
                .help("Layout: Topbar/Filmstreifen ein-/ausblenden (ausserhalb Focus‑Mode)")
            }

            // Titlebar Quick Actions (Workflow wie in Lightroom: wichtige Aktionen ohne Menü)
            ToolbarItemGroup(placement: .automatic) {
                Button(action: openFolderFromTitlebar) {
                    Label("Ordner öffnen", systemImage: "folder.badge.plus")
                        .labelStyle(IconOnlyLabelStyle())
                }
                .help("Ordner öffnen…")
                
                // Status-Badge: Picks/Rejects/Total
                StatusBadgeView(store: store)
                    .disabled(store.filteredPhotos.isEmpty)

                Button(action: {
                    uiState.selectionMode.toggle()
                    if !uiState.selectionMode {
                        store.clearSelectionToCurrent()
                    }
                }) {
                    Label(uiState.selectionMode ? "Mehrfachauswahl aktiv" : "Mehrfachauswahl", systemImage: uiState.selectionMode ? "checkmark.circle.fill" : "checkmark.circle")
                }
                .help(uiState.selectionMode ? "Mehrfachauswahl aktiv" : "Mehrfachauswahl")
                .disabled(store.filteredPhotos.isEmpty)

                Menu {
                    Button("Einstellungen kopieren") {
                        store.copyAdjustmentsFromCurrent()
                    }
                    .disabled(store.currentPhoto == nil)

                    Button("Einstellungen einfügen") {
                        store.pasteAdjustmentsToCurrent()
                    }
                    .disabled(store.currentPhoto == nil || store.copiedAdjustments == nil)

                    Button("Einstellungen auf Auswahl einfügen (\(store.selectedPhotoIDs.count))") {
                        store.pasteAdjustmentsToSelection()
                    }
                    .disabled(store.copiedAdjustments == nil || store.selectedPhotoIDs.isEmpty)

                    Divider()

                    Button("Synchronisieren…") {
                        uiState.activeSheet = .syncAdjustments
                    }
                    .disabled(store.selectedPhotoIDs.count <= 1 || store.currentPhoto == nil)

                    Button("Auswahl löschen") {
                        store.clearSelectionToCurrent()
                        uiState.selectionMode = false
                    }
                    .disabled(store.selectedPhotoIDs.count <= 1)
                } label: {
                    Label("Copy/Paste/Sync", systemImage: "doc.on.doc")
                }
                .help("Einstellungen (Copy/Paste/Sync)")
                .disabled(store.currentPhoto == nil && store.copiedAdjustments == nil)
                
                // Batch-Rating Menu
                Menu {
                    let selectionCount = store.selectedPhotoIDs.isEmpty ? 0 : store.selectedPhotoIDs.count
                    let selectionText = selectionCount > 0 ? " (\(selectionCount))" : ""
                    
                    Button("Rating löschen\(selectionText)") {
                        store.setRatingForSelection(0)
                    }
                    .disabled(store.selectedPhotoIDs.isEmpty && store.currentPhoto == nil)
                    
                    Divider()
                    
                    ForEach(1...5, id: \.self) { rating in
                        Button("\(rating) Stern\(rating == 1 ? "" : "e")\(selectionText)") {
                            store.setRatingForSelection(rating)
                        }
                        .disabled(store.selectedPhotoIDs.isEmpty && store.currentPhoto == nil)
                    }
                } label: {
                    Label("Batch Rating", systemImage: "star.fill")
                }
                .help("Rating auf Auswahl setzen")
                .disabled(store.selectedPhotoIDs.isEmpty && store.currentPhoto == nil)

                Menu {
                    Button(store.isQuickExporting ? "Quick Export abbrechen" : "Quick Export (⌘E)") {
                        if store.isQuickExporting {
                            store.cancelQuickExport()
                        } else if store.selectedPhotoIDs.count > 1 {
                            store.quickExportSelection()
                        } else {
                            store.quickExportCurrent()
                        }
                    }
                    .disabled(store.currentPhoto == nil && store.selectedPhotoIDs.isEmpty)
                    
                    Button("Quick Export – Picks im Scope") {
                        store.quickExportPicksInScope()
                    }
                    
                    Divider()
                    
                    Button("Exportieren…") { uiState.activeSheet = .export }
                        .disabled(store.currentPhoto == nil)
                    
                    Button("Batch Export…") { uiState.activeSheet = .batchExport }
                        .disabled(store.filteredPhotos.isEmpty)
                    
                    Divider()
                    
                    Button("Kopie speichern unter…") {
                        if let photo = store.currentPhoto {
                            SaveService.shared.saveCopyAs(photo: photo)
                        }
                    }
                    .disabled(store.currentPhoto == nil)
                    
                    Button("Original speichern…") {
                        if let photo = store.currentPhoto {
                            SaveService.shared.saveOriginal(photo: photo)
                        }
                    }
                    .disabled(store.currentPhoto == nil)
                    
                    Divider()
                    
                    Button("Quick Export Einstellungen…") {
                        uiState.activeSheet = .settings
                    }
                } label: {
                    Label("Export", systemImage: "square.and.arrow.up")
                }
                .help("Exportieren / Speichern…")
                
                Button(action: {
                    if store.isQuickExporting {
                        store.cancelQuickExport()
                        return
                    }
                    if store.selectedPhotoIDs.count > 1 {
                        store.quickExportSelection()
                    } else {
                        store.quickExportCurrent()
                    }
                }) {
                    ZStack {
                        Label("Quick", systemImage: "bolt.fill")
                        
                        if store.isQuickExporting {
                            ProgressView(value: store.quickExportProgress)
                                .progressViewStyle(.circular)
                                .tint(DesignSystem.Colors.accent)
                                .scaleEffect(0.75)
                                .frame(width: 20, height: 20)
                        }
                    }
                }
                .help(quickExportHelpText)
                .disabled(store.currentPhoto == nil && store.selectedPhotoIDs.isEmpty)

                Button(action: {
                    if store.isAITaggingRunning {
                        store.cancelAITagging()
                        return
                    }
                    if store.selectedPhotoIDs.count > 1 {
                        // Multi-select workflow: generiere für alle ausgewählten Fotos.
                        store.startAITagsForSelection()
                    } else {
                        store.startAITagsForCurrent()
                    }
                }) {
                    ZStack {
                        Label("AI Keywords", systemImage: "sparkles")
                        
                        if store.isAITaggingRunning {
                            ProgressView(value: store.aiTaggingProgress)
                                .progressViewStyle(.circular)
                                .tint(DesignSystem.Colors.accent)
                                .scaleEffect(0.75)
                                .frame(width: 20, height: 20)
                                .offset(x: 0, y: 0)
                        }
                    }
                }
                .help(aiKeywordsHelpText)
                .disabled(store.currentPhoto == nil)

                Button(action: { uiState.activeSheet = .settings }) {
                    Label("Einstellungen", systemImage: "gearshape")
                }
                .help("Einstellungen")

                Menu {
                    Button("Ingest / Import (SD‑Karte)…") { uiState.activeSheet = .ingestImport }
                        .keyboardShortcut("i", modifiers: [.command])
                    
                    Divider()
                    
                    Button("Upload-Ziele verwalten…") { uiState.activeSheet = .uploadSettings }
                    Button("Export-Queue Einstellungen…") { uiState.activeSheet = .exportQueueSettings }
                    Divider()
                    Button("Backup & Wiederherstellung…") { uiState.activeSheet = .backupRestore }
                } label: {
                    Label("Mehr", systemImage: "ellipsis.circle")
                }
                .help("Weitere Aktionen")
            }
            
            ToolbarItem(placement: .primaryAction) {
                Button(action: { uiState.showRightSidebar.toggle() }) {
                    Label("Sidebar rechts", systemImage: "sidebar.right")
                }
            }
        }
        .onAppear {
            store.setup(uiState: uiState)
            
            // Clamp persisted widths (safety)
            leftSidebarWidth = min(maxLeftSidebarWidth, max(minLeftSidebarWidth, leftSidebarWidth))
            rightSidebarWidth = min(maxRightSidebarWidth, max(minRightSidebarWidth, rightSidebarWidth))
            
            // Kein Auto-Load von ~/Pictures: In der Sandbox fehlt ohne User-Interaktion die Permission.
            // Der User soll bewusst einen Ordner über Sidebar / "Ordner öffnen…" auswählen.
            if settings.sidebarAlwaysVisible {
                uiState.showLeftSidebar = true
            }
        }
        .sheet(item: $uiState.activeSheet) { route in
            switch route {
            case .settings:
                SettingsView(store: store)
            case .export:
                ExportPanel(store: store)
            case .batchExport:
                BatchExportView(store: store)
            case .uploadSettings:
                UploadSettingsView(store: store)
            case .exportQueueSettings:
                ExportQueueSettingsView(store: store)
            case .backupRestore:
                BackupRestoreView(store: store)
            case .ingestImport:
                IngestImportView(store: store)
                    .environmentObject(uiState)
            case .syncAdjustments:
                SyncAdjustmentsView()
            case .surveyView:
                Text("Survey-View (Coming Soon)")
                    .font(.title)
                    .frame(width: 800, height: 600)
            case .smartCollections:
                SmartCollectionView()
                    .environmentObject(store)
            case .shortcutsHelp:
                ShortcutsHelpView()
                    .environmentObject(store)
            case .help:
                HelpView()
                    .environmentObject(uiState)
            case .duplicateDetection:
                DuplicateDetectionView(store: store)
            case .exportStatistics:
                ExportStatisticsView(store: store)
            }
        }
    }

    private var aiKeywordsHelpText: String {
        if store.isAITaggingRunning {
            let done = store.aiTaggingProcessedCount
            let total = max(1, store.aiTaggingTotalCount)
            return "AI Keywords laufen… \(done)/\(total) • Klick zum Abbrechen"
        }
        if store.selectedPhotoIDs.count > 1 {
            return "AI Keywords für Auswahl generieren (\(store.selectedPhotoIDs.count))"
        }
        return "AI Keywords generieren"
    }
    
    private var quickExportHelpText: String {
        if store.isQuickExporting {
            let pct = Int((store.quickExportProgress * 100.0).rounded())
            return "Quick Export läuft… \(pct)% • Klick zum Abbrechen"
        }
        
        let presetName: String? = {
            guard let id = store.quickExportPresetID else { return nil }
            return store.exportPresets.first(where: { $0.id == id })?.name
        }()
        
        let dirName = store.quickExportDirectory?.lastPathComponent
        
        if presetName == nil || dirName == nil {
            return "Quick Export (⌘E) • Bitte konfigurieren: Einstellungen → Export → Quick Export"
        }
        
        return "Quick Export (⌘E): \(presetName!) → \(dirName!)"
    }

    // MARK: - Titlebar: Ordner öffnen (gleiches Verhalten wie in Finder-Sidebar)
    private func openFolderFromTitlebar() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = false
        panel.title = "Ordner auswählen"
        panel.prompt = "Öffnen"
        panel.message = "Wählen Sie einen Ordner mit Bildern aus"
        panel.directoryURL = nil

        if panel.runModal() == .OK, let url = panel.url {
            saveBookmark(for: url)
            store.loadPhotos(from: url)
            addPathToUserDefaultsList(key: "favoriteFolders", url: url, limit: 10)
            addPathToUserDefaultsList(key: "recentFolders", url: url, limit: 12)
            NotificationCenter.default.post(name: NSNotification.Name("SidebarFoldersUpdated"), object: nil)
        }
    }

    private func saveBookmark(for url: URL) {
        do {
            let bookmarkData = try url.bookmarkData(
                options: [.withSecurityScope],
                includingResourceValuesForKeys: nil,
                relativeTo: nil
            )
            var bookmarks = UserDefaults.standard.dictionary(forKey: "folderBookmarks") ?? [:]
            bookmarks[url.path] = bookmarkData
            UserDefaults.standard.set(bookmarks, forKey: "folderBookmarks")
        } catch {
            print("Fehler beim Speichern des Bookmarks: \(error)")
        }
    }

    private func addPathToUserDefaultsList(key: String, url: URL, limit: Int) {
        var paths = UserDefaults.standard.stringArray(forKey: key) ?? []
        let standardized = url.standardizedFileURL.path
        paths.removeAll { URL(fileURLWithPath: $0).standardizedFileURL.path == standardized }
        paths.insert(url.path, at: 0)
        if paths.count > limit {
            paths = Array(paths.prefix(limit))
        }
        UserDefaults.standard.set(paths, forKey: key)
    }
}

struct MainContentView: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @AppStorage("filmstripHeightV1") private var filmstripHeight: Double = 132
    
    var body: some View {
        ZStack(alignment: .topLeading) {
            // Content-Bereich (unter TopTabBar)
            VStack(spacing: 0) {
                // Platzhalter für TopTabBar, damit Content nicht darüber gezeichnet wird
                if !uiState.isFocusMode, uiState.showTopBar {
                    Spacer()
                        .frame(height: 48)
                }
                
                ZStack(alignment: .topLeading) {
                    switch uiState.viewMode {
                    case .detail:
                        DetailView(store: store)
                    case .grid:
                        // Pass the filtered photos to the GridView
                        GridView(photos: store.filteredPhotos, store: store)
                    case .compare:
                        CompareModeView(store: store)
                    case .survey:
                        SurveyModeView(store: store)
                    }
                    
                    if uiState.isFocusMode {
                        FocusModeOverlay(isEnabled: $uiState.isFocusMode)
                            .padding(10)
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
                
                if uiState.viewMode == .detail && !uiState.isFocusMode && uiState.showFilmstrip {
                    FilmstripResizeHandle(height: $filmstripHeight)
                    // Pass the filtered photos to the FilmstripView
                    FilmstripView(photos: store.filteredPhotos, store: store)
                        .frame(height: filmstripHeight)
                }
            }
            .background(DesignSystem.Colors.background)
            
            // TopTabBar über allem anderen
            if !uiState.isFocusMode, uiState.showTopBar {
                VStack {
                    TopTabBar()
                        .zIndex(100) // TopTabBar immer über Sidebars
                    Spacer()
                }
            }
        }
        .onKeyPress(.escape) {
            if uiState.isFocusMode {
                uiState.isFocusMode = false
                return .handled
            }
            return .ignored
        }
    }
}

private struct FocusModeOverlay: View {
    @Binding var isEnabled: Bool
    
    var body: some View {
        HStack(spacing: 10) {
            Image(systemName: "arrow.down.right.and.arrow.up.left")
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(.white)
            
            Text("Focus‑Mode")
                .font(DesignSystem.Fonts.semibold(size: 12))
                .foregroundColor(.white)
            
            Text("Esc")
                .font(.system(size: 11, weight: .bold, design: .monospaced))
                .foregroundColor(Color.white.opacity(0.85))
                .padding(.horizontal, 6)
                .padding(.vertical, 2)
                .background(Color.white.opacity(0.10))
                .cornerRadius(6)
            
            Spacer(minLength: 0)
            
            Button("Beenden") { isEnabled = false }
                .buttonStyle(LightroomSecondaryButtonStyle())
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(Color.black.opacity(0.55))
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .overlay(
            RoundedRectangle(cornerRadius: 12)
                .stroke(Color.white.opacity(0.10), lineWidth: 1)
        )
        .shadow(color: Color.black.opacity(0.35), radius: 10, x: 0, y: 4)
        .help("Focus‑Mode: Sidebars/Filmstrip/Topbar ausgeblendet • Esc oder Klick zum Beenden")
    }
}

/// Vertikale "Splitter"-Leiste, um Sidebar-Breiten per Drag zu ändern.
/// - Note: Width wird in AppStorage persistiert (RootView).
struct SidebarResizeHandle: View {
    @Binding var width: Double
    let minWidth: Double
    let maxWidth: Double
    /// true = Drag nach rechts verkleinert die Sidebar (rechter Divider), false = Drag nach rechts vergrössert (linker Divider)
    let invertDrag: Bool
    
    @State private var startWidth: Double? = nil
    @State private var isHovering: Bool = false
    @State private var isDragging: Bool = false
    
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .center) {
                // Hintergrund für Hit-Test (breiter Bereich für einfaches Ziehen)
                Rectangle()
                    .fill(Color.clear)
                    .frame(width: 8)
                    .contentShape(Rectangle())
                
                // Sichtbarer blauer Indikator in der Mitte (nicht über die ganze Höhe)
                VStack {
                    Spacer()
                    
                    // Kleiner blauer Griff in der Mitte
                    RoundedRectangle(cornerRadius: 2)
                        .fill(DesignSystem.Colors.accent.opacity(isDragging ? 0.8 : (isHovering ? 0.6 : 0.4)))
                        .frame(width: 3, height: 40)
                    
                    Spacer()
                }
                .frame(width: 8)
            }
        }
        .frame(width: 8)
        .contentShape(Rectangle())
        .allowsHitTesting(true)
        .onHover { hovering in
            if !isDragging {
                isHovering = hovering
                if hovering {
                    NSCursor.resizeLeftRight.push()
                } else {
                    NSCursor.pop()
                }
            }
        }
        .simultaneousGesture(
            DragGesture(minimumDistance: 0)
                .onChanged { value in
                    if !isDragging {
                        isDragging = true
                        startWidth = width
                        NSCursor.resizeLeftRight.push()
                    }
                    
                    guard let base = startWidth else { return }
                    let delta = value.translation.width
                    let proposed = base + (invertDrag ? -delta : delta)
                    width = min(maxWidth, max(minWidth, proposed))
                }
                .onEnded { _ in
                    isDragging = false
                    isHovering = false
                    startWidth = nil
                    NSCursor.pop()
                }
        )
        .accessibilityLabel("Sidebar Breite anpassen")
        .zIndex(100) // Sicherstellen, dass das Handle über anderen Inhalten liegt
    }
}

/// Horizontale "Splitter"-Leiste, um die Filmstrip-Höhe wie in Lightroom/Sidebars per Drag zu ändern.
/// - Note: Height wird in AppStorage persistiert.
struct FilmstripResizeHandle: View {
    @Binding var height: Double
    @State private var startHeight: Double? = nil
    @State private var isHovering: Bool = false
    
    private let minHeight: Double = 92
    private let maxHeight: Double = 320
    
    var body: some View {
        ZStack {
            Rectangle()
                .fill(DesignSystem.Colors.border)
                .frame(height: 1)
            
            RoundedRectangle(cornerRadius: 2)
                .fill(DesignSystem.Colors.text4.opacity(isHovering ? 0.75 : 0.45))
                .frame(width: 44, height: 3)
        }
        .frame(height: 10)
        .background(DesignSystem.Colors.background4)
        .contentShape(Rectangle())
        .onHover { hovering in
            isHovering = hovering
            if hovering {
                NSCursor.resizeUpDown.push()
            } else {
                NSCursor.pop()
            }
        }
        .gesture(
            DragGesture(minimumDistance: 0)
                .onChanged { value in
                    if startHeight == nil { startHeight = height }
                    let base = startHeight ?? height
                    // Drag up => Filmstrip grösser (mehr Höhe)
                    let proposed = base - value.translation.height
                    height = min(maxHeight, max(minHeight, proposed))
                }
                .onEnded { _ in
                    startHeight = nil
                }
        )
        .accessibilityLabel("Filmstreifen Höhe anpassen")
    }
}

struct TopTabBar: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @ObservedObject private var settings = AppSettings.shared
    
    var body: some View {
        ZStack {
            // Responsive Topbar (kleines Fenster + Sidebar): fällt stufenweise zurück, statt zu "quetschen".
            if settings.preferWorkflowTopbar {
                // Workflow-Modus: Immer die minimale Workflow-Variante
                topBarMinimalWorkflow
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
            } else {
                // Standard-Modus: Responsive Fallback (Workflow-Variante ist NICHT enthalten)
                ViewThatFits(in: .horizontal) {
                    topBarFull
                    topBarCompact
                    topBarMinimal
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
        }
        .frame(height: 48)
        .background(DesignSystem.Colors.background2)
        .overlay(
            Rectangle()
                .frame(height: 1)
                .foregroundColor(DesignSystem.Colors.border),
            alignment: .bottom
        )
    }
    
    // MARK: - Variants (Responsive)
    
    private var topBarFull: some View {
        HStack(spacing: 0) {
            ViewModeButtons()
                .padding(.leading, DesignSystem.Spacing.medium)
            
            SearchFieldView(maxWidth: 320, minTextFieldWidth: 160)
                .padding(.leading, DesignSystem.Spacing.small)
            
            separator
            
            ratingAndLabelsInline
            
            RatingSortQuickButtons()
                .padding(.trailing, DesignSystem.Spacing.small)
                .help("Schnell sortieren nach Rating")
            
            BestOfTopBarButton(compact: false)
                .padding(.trailing, DesignSystem.Spacing.small)
            
            SortMenuButton()
                .padding(.trailing, DesignSystem.Spacing.small)
            
            FolderStatusView()
                .padding(.leading, DesignSystem.Spacing.small)
            
            Spacer()
            
            ActionButtons()
                .padding(.trailing, DesignSystem.Spacing.medium)
        }
    }
    
    private var topBarCompact: some View {
        HStack(spacing: 0) {
            ViewModeButtons()
                .padding(.leading, DesignSystem.Spacing.small)
            
            SearchFieldView(maxWidth: 220, minTextFieldWidth: 120, placeholder: "Suchen…")
                .padding(.leading, 6)
            
            separator
            
            ratingAndLabelsInline
            
            BestOfTopBarButton(compact: true)
                .padding(.trailing, 6)
            
            // Schnellzugriff-Sortierung mit wichtigsten Optionen
            QuickSortButton()
                .padding(.trailing, 6)
            
            // RatingSortQuickButtons fällt in Compact weg (ist auch im Sort-Menü verfügbar)
            SortMenuButton()
                .padding(.trailing, 6)
            
            FolderStatusCompactButton()
                .padding(.leading, 6)
            
            Spacer(minLength: 8)
            
            ActionButtons()
                .padding(.trailing, DesignSystem.Spacing.small)
        }
    }
    
    private var topBarMinimal: some View {
        HStack(spacing: 0) {
            ViewModeButtons()
                .padding(.leading, DesignSystem.Spacing.small)
            
            SearchPopoverButton()
                .padding(.leading, 6)
            
            separator
            
            BestOfTopBarButton(compact: true)
                .padding(.trailing, 6)
            
            QuickSortButton()
                .padding(.trailing, 6)
            
            FilterMenuButton()
                .padding(.trailing, 6)
            
            SortMenuButton()
                .padding(.trailing, 6)
            
            FolderStatusCompactButton()
                .padding(.leading, 6)
            
            Spacer(minLength: 8)
            
            ActionButtons()
                .padding(.trailing, DesignSystem.Spacing.small)
        }
    }

    /// Minimal-Variante mit Workflow-Priorität:
    /// - Rating + Farb‑Tags bleiben sichtbar (Sportfotografie!)
    /// - Actions werden kompakter dargestellt, damit es auch in kleinen Fenstern passt.
    private var topBarMinimalWorkflow: some View {
        HStack(spacing: 0) {
            ViewModeButtons()
                .padding(.leading, DesignSystem.Spacing.small)
            
            SearchPopoverButton()
                .padding(.leading, 6)
            
            separator
            
            ratingAndLabelsInlineCompact
                .padding(.trailing, 6)
            
            BestOfTopBarButton(compact: true)
                .padding(.trailing, 6)
            
            QuickSortButton()
                .padding(.trailing, 6)
            
            FilterMenuButton()
                .padding(.trailing, 6)
            
            Spacer(minLength: 8)
            
            ActionButtonsWorkflowMinimal()
                .padding(.trailing, DesignSystem.Spacing.small)
        }
    }
    
    private var separator: some View {
        Rectangle()
            .fill(DesignSystem.Colors.border)
            .frame(width: 1, height: 32)
            .padding(.horizontal, 8)
    }
    
    @ViewBuilder
    private var ratingAndLabelsInline: some View {
        if uiState.viewMode == .grid {
            RatingFilterView()
                .padding(.trailing, 6)
                .help("Filter nach Rating (Grid)")
            
            ColorTagFilterView()
                .padding(.trailing, 6)
                .help("Filter nach Farb-Tag (Grid)")
        } else {
            RatingSetView()
                .padding(.trailing, 6)
                .help("Rating für aktuelles Foto setzen (1–5)")
            
            ColorTagSetView()
                .padding(.trailing, 6)
                .help("Farb-Tag für aktuelles Foto setzen (6–9)")
        }
    }
    
    @ViewBuilder
    private var ratingAndLabelsInlineCompact: some View {
        if uiState.viewMode == .grid {
            RatingFilterCompactView()
                .help("Rating‑Filter (Grid)")
            
            ColorTagFilterCompactView()
                .help("Filter nach Farb-Tag (Grid)")
        } else {
            RatingSetCompactView()
                .help("Rating setzen (1–5) • 0 = löschen")
            
            ColorTagSetCompactView()
                .help("Farb-Tag setzen (6–9)")
        }
    }
}

/// Kompakt: Rating setzen (aktuelles Foto) – spart Platz für kleine Fenster.
private struct RatingSetCompactView: View {
    @EnvironmentObject var store: PhotoStore
    
    private var currentRating: Int { store.currentPhoto?.rating ?? 0 }
    private var canRate: Bool { store.currentPhotoID != nil }
    
    var body: some View {
        HStack(spacing: 2) {
            Button(action: { setRating(0, autoAdvance: false) }) {
                Text("0")
                    .font(.system(size: 10, weight: .bold, design: .monospaced))
                    .foregroundColor(currentRating == 0 ? DesignSystem.Colors.text2 : DesignSystem.Colors.text4)
                    .frame(width: 18, height: 22)
            }
            .buttonStyle(.plain)
            .disabled(!canRate)
            .help("Rating löschen (0)")
            
            ForEach(1...5, id: \.self) { r in
                Button(action: { setRating(r) }) {
                    Image(systemName: (currentRating >= r) ? "star.fill" : "star")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor((currentRating >= r) ? DesignSystem.Colors.star : DesignSystem.Colors.text3)
                        .frame(width: 20, height: 22)
                }
                .buttonStyle(.plain)
                .disabled(!canRate)
            }
        }
        .padding(.horizontal, 4)
        .padding(.vertical, 3)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
    
    private func setRating(_ rating: Int, autoAdvance: Bool = true) {
        guard let id = store.currentPhotoID else { return }
        store.setRating(rating, for: id, autoAdvance: autoAdvance)
    }
}

/// Kompakt: Farb-Tags setzen (aktuelles Foto) – spart Platz für kleine Fenster.
private struct ColorTagSetCompactView: View {
    @EnvironmentObject var store: PhotoStore
    
    private let tags: [ColorTag] = [.red, .yellow, .green, .blue]
    private var current: Set<ColorTag> { store.currentPhoto?.colorTags ?? [] }
    private var canTag: Bool { store.currentPhotoID != nil }
    
    var body: some View {
        HStack(spacing: 2) {
            ForEach(tags, id: \.self) { tag in
                Button(action: { toggle(tag) }) {
                    Circle()
                        .fill(Color(tag.color).opacity(current.contains(tag) ? 1.0 : 0.25))
                        .frame(width: 10, height: 10)
                        .overlay(
                            Circle()
                                .stroke(Color.white.opacity(current.contains(tag) ? 0.8 : 0.35), lineWidth: 0.6)
                        )
                        .frame(width: 20, height: 22)
                }
                .buttonStyle(.plain)
                .disabled(!canTag)
                .help("\(tag.displayName)")
            }
        }
        .padding(.horizontal, 4)
        .padding(.vertical, 3)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
    
    private func toggle(_ tag: ColorTag) {
        guard let id = store.currentPhotoID else { return }
        store.toggleColorTag(tag, for: id)
    }
}

/// Kompakt: Rating filtern (Grid) – spart Platz.
private struct RatingFilterCompactView: View {
    @EnvironmentObject var uiState: UIState
    
    var body: some View {
        HStack(spacing: 2) {
            Button("Alle") { uiState.ratingFilter = nil }
                .font(.system(size: 10, weight: .semibold))
                .foregroundColor(uiState.ratingFilter == nil ? Color.white : DesignSystem.Colors.text4)
                .frame(width: 34, height: 22)
                .background(uiState.ratingFilter == nil ? DesignSystem.Colors.background3.opacity(0.35) : Color.clear)
                .cornerRadius(6)
                .buttonStyle(.plain)
            
            ForEach(1...5, id: \.self) { r in
                Button(action: { uiState.ratingFilter = (uiState.ratingFilter == r) ? nil : r }) {
                    Image(systemName: (uiState.ratingFilter ?? 0) >= r ? "star.fill" : "star")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundColor((uiState.ratingFilter ?? 0) >= r ? DesignSystem.Colors.star : DesignSystem.Colors.text3)
                        .frame(width: 18, height: 22)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 4)
        .padding(.vertical, 3)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
}

/// Kompakt: Farb‑Tag filtern (Grid) – spart Platz.
private struct ColorTagFilterCompactView: View {
    @EnvironmentObject var uiState: UIState
    
    private let tags: [ColorTag] = [.red, .yellow, .green, .blue]
    
    var body: some View {
        HStack(spacing: 2) {
            Button("Alle") { uiState.colorTagFilter = nil }
                .font(.system(size: 10, weight: .semibold))
                .foregroundColor(uiState.colorTagFilter == nil ? Color.white : DesignSystem.Colors.text4)
                .frame(width: 34, height: 22)
                .background(uiState.colorTagFilter == nil ? DesignSystem.Colors.background3.opacity(0.35) : Color.clear)
                .cornerRadius(6)
                .buttonStyle(.plain)
            
            ForEach(tags, id: \.self) { tag in
                Button(action: { uiState.colorTagFilter = (uiState.colorTagFilter == tag) ? nil : tag }) {
                    Circle()
                        .fill(Color(tag.color).opacity(uiState.colorTagFilter == tag ? 1.0 : 0.35))
                        .frame(width: 10, height: 10)
                        .overlay(
                            Circle()
                                .stroke(Color.white.opacity(0.55), lineWidth: 0.5)
                        )
                        .frame(width: 20, height: 22)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 4)
        .padding(.vertical, 3)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
}

/// Kompakt: weniger Icons rechts, damit Rating/Tags links Platz haben.
struct ActionButtonsWorkflowMinimal: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    var body: some View {
        HStack(spacing: 6) {
            // Vorher/Nachher (Slider im Bild)
            TopBarIconButton(
                systemName: "circle.lefthalf.filled",
                help: "Vorher/Nachher umschalten (Y)",
                isActive: uiState.showBeforeAfter,
                action: { uiState.showBeforeAfter.toggle() }
            )
            .disabled(uiState.viewMode != .detail || store.currentPhoto == nil)
            
            // Turbo Navigation
            CullingQueueMenuButton()
            
            // Duplikate suchen
            TopBarIconButton(
                systemName: "doc.on.doc",
                help: "Duplikate suchen",
                action: { uiState.activeSheet = .duplicateDetection }
            )
            .disabled(store.photos.isEmpty)
            
            // Gesichter erkennen
            
            // Export (vereinheitlicht)
            UnifiedExportMenuButton()
            
            // Status / Activity Center (Exports/Uploads/Indexing)
            ActivityCenterButton()
        }
    }
}

struct ViewModeButtons: View {
    @EnvironmentObject var uiState: UIState

    var body: some View {
        HStack(spacing: 2) {
            ViewModeButton(imageName: "photo", mode: .detail, currentMode: $uiState.viewMode)
            ViewModeButton(imageName: "square.grid.2x2", mode: .grid, currentMode: $uiState.viewMode)
            ViewModeButton(imageName: "rectangle.split.2x1", mode: .compare, currentMode: $uiState.viewMode)
            ViewModeButton(imageName: "rectangle.grid.2x2", mode: .survey, currentMode: $uiState.viewMode)
        }
        .padding(4)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
}

struct ViewModeButton: View {
    let imageName: String
    let mode: ViewMode
    @Binding var currentMode: ViewMode

    var isSelected: Bool {
        currentMode == mode
    }

    var body: some View {
        Button(action: { currentMode = mode }) {
            Image(systemName: imageName)
                .font(DesignSystem.Fonts.medium(size: 14))
                .foregroundColor(isSelected ? Color.white : DesignSystem.Colors.text2)
                .frame(width: 36, height: 32)
                .background(isSelected ? DesignSystem.Colors.accent : Color.clear)
                .cornerRadius(DesignSystem.CornerRadius.small)
        }
        .buttonStyle(.plain)
        .help(helpText)
    }
    
    private var helpText: String {
        switch mode {
        case .detail: return "Detail-Ansicht"
        case .grid: return "Grid-Ansicht"
        case .compare: return "Compare / Culling"
        case .survey: return "Survey"
        }
    }
}

struct RatingFilterView: View {
    @EnvironmentObject var uiState: UIState

    var body: some View {
        HStack(spacing: 4) {
            RatingFilterButton(rating: 0, currentFilter: $uiState.ratingFilter)
            
            Rectangle()
                .fill(DesignSystem.Colors.border2)
                .frame(width: 1, height: 20)
                .padding(.horizontal, 4)
            
            ForEach(1...5, id: \.self) { rating in
                RatingFilterButton(rating: rating, currentFilter: $uiState.ratingFilter)
            }
        }
        .padding(4)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
}

/// Rating setzen (für aktuelles Foto) – mouse-friendly.
/// Wichtig: Nicht mit Rating-Filter verwechseln (der ist im Grid).
struct RatingSetView: View {
    @EnvironmentObject var store: PhotoStore
    
    private var currentRating: Int { store.currentPhoto?.rating ?? 0 }
    private var canRate: Bool { store.currentPhotoID != nil }
    
    var body: some View {
        HStack(spacing: 4) {
            Button(action: { setRating(0, autoAdvance: false) }) {
                HStack(spacing: 4) {
                    Text("0")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(currentRating == 0 ? DesignSystem.Colors.text2 : DesignSystem.Colors.text3)
                        .monospacedDigit()
                    Image(systemName: "star")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(currentRating == 0 ? DesignSystem.Colors.text3 : DesignSystem.Colors.text4)
                }
                .frame(width: 34, height: 24)
                .background(DesignSystem.Colors.background3.opacity(currentRating == 0 ? 0.35 : 0.0))
                .cornerRadius(6)
            }
            .buttonStyle(.plain)
            .disabled(!canRate)
            .help("Rating löschen (0)")
            
            Rectangle()
                .fill(DesignSystem.Colors.border2)
                .frame(width: 1, height: 20)
                .padding(.horizontal, 4)
            
            ForEach(1...5, id: \.self) { r in
                Button(action: { setRating(r) }) {
                    Image(systemName: (currentRating >= r) ? "star.fill" : "star")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor((currentRating >= r) ? DesignSystem.Colors.star : DesignSystem.Colors.text3)
                        .frame(width: 24, height: 24)
                }
                .buttonStyle(.plain)
                .disabled(!canRate)
                .help("\(r) Stern\(r == 1 ? "" : "e")")
            }
        }
        .padding(4)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
    
    private func setRating(_ rating: Int, autoAdvance: Bool = true) {
        guard let id = store.currentPhotoID else { return }
        store.setRating(rating, for: id, autoAdvance: autoAdvance)
    }
}

/// Farb-Tags filtern (Grid) – Lightroom-like.
struct ColorTagFilterView: View {
    @EnvironmentObject var uiState: UIState
    
    private let tags: [ColorTag] = [.red, .yellow, .green, .blue]
    
    var body: some View {
        HStack(spacing: 4) {
            Button(action: { uiState.colorTagFilter = nil }) {
                Text("Alle")
                    .font(DesignSystem.Fonts.medium(size: 11))
                    .foregroundColor(uiState.colorTagFilter == nil ? Color.white : DesignSystem.Colors.text3)
                    .frame(width: 44, height: 24)
                    .background(uiState.colorTagFilter == nil ? DesignSystem.Colors.background : Color.clear)
                    .cornerRadius(6)
            }
            .buttonStyle(.plain)
            
            Rectangle()
                .fill(DesignSystem.Colors.border2)
                .frame(width: 1, height: 20)
                .padding(.horizontal, 4)
            
            ForEach(tags, id: \.self) { tag in
                Button(action: {
                    uiState.colorTagFilter = (uiState.colorTagFilter == tag) ? nil : tag
                }) {
                    Circle()
                        .fill(Color(tag.color).opacity(uiState.colorTagFilter == tag ? 1.0 : 0.35))
                        .frame(width: 12, height: 12)
                        .overlay(
                            Circle()
                                .stroke(Color.white.opacity(0.70), lineWidth: 0.5)
                        )
                        .frame(width: 24, height: 24)
                        .background(uiState.colorTagFilter == tag ? DesignSystem.Colors.background : Color.clear)
                        .cornerRadius(6)
                }
                .buttonStyle(.plain)
                .help(tag.displayName)
            }
        }
        .padding(4)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
}

/// Farb-Tags setzen (aktuelles Foto) – mouse-friendly, zusätzlich zu 6–9.
struct ColorTagSetView: View {
    @EnvironmentObject var store: PhotoStore
    
    private let tags: [ColorTag] = [.red, .yellow, .green, .blue]
    private var current: Set<ColorTag> { store.currentPhoto?.colorTags ?? [] }
    private var canTag: Bool { store.currentPhotoID != nil }
    
    var body: some View {
        HStack(spacing: 4) {
            ForEach(tags, id: \.self) { tag in
                Button(action: { toggle(tag) }) {
                    Circle()
                        .fill(Color(tag.color).opacity(current.contains(tag) ? 1.0 : 0.25))
                        .frame(width: 12, height: 12)
                        .overlay(
                            Circle()
                                .stroke(Color.white.opacity(current.contains(tag) ? 0.85 : 0.45), lineWidth: 0.6)
                        )
                        .frame(width: 24, height: 24)
                        .background(current.contains(tag) ? DesignSystem.Colors.background3.opacity(0.35) : Color.clear)
                        .cornerRadius(6)
                }
                .buttonStyle(.plain)
                .disabled(!canTag)
                .help("\(tag.displayName) (\(tagKeyboardHint(tag)))")
            }
        }
        .padding(4)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
    
    private func toggle(_ tag: ColorTag) {
        guard let id = store.currentPhotoID else { return }
        store.toggleColorTag(tag, for: id)
    }
    
    private func tagKeyboardHint(_ tag: ColorTag) -> String {
        switch tag {
        case .red: return "6"
        case .yellow: return "7"
        case .green: return "8"
        case .blue: return "9"
        default: return ""
        }
    }
}

/// Ein-Klick Sortierung nach Rating (hoch→tief / tief→hoch).
/// Toggle: Wenn bereits aktiv, geht's zurück auf Aufnahmedatum (neueste).
struct RatingSortQuickButtons: View {
    @EnvironmentObject var uiState: UIState
    
    private var isDesc: Bool { uiState.sortMode == .ratingDesc }
    private var isAsc: Bool { uiState.sortMode == .ratingAsc }
    
    var body: some View {
        HStack(spacing: 2) {
            sortButton(
                title: "★↓",
                isActive: isDesc,
                onTap: { toggle(.ratingDesc) }
            )
            sortButton(
                title: "★↑",
                isActive: isAsc,
                onTap: { toggle(.ratingAsc) }
            )
        }
        .padding(4)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
    
    private func toggle(_ mode: PhotoSortMode) {
        if uiState.sortMode == mode {
            uiState.sortMode = .captureDateDesc
        } else {
            uiState.sortMode = mode
        }
    }
    
    private func sortButton(title: String, isActive: Bool, onTap: @escaping () -> Void) -> some View {
        Button(action: onTap) {
            Text(title)
                .font(.system(size: 11, weight: .bold))
                .foregroundColor(isActive ? Color.white : DesignSystem.Colors.text3)
                .frame(width: 34, height: 24)
                .background(isActive ? DesignSystem.Colors.accent.opacity(0.28) : DesignSystem.Colors.background3)
                .cornerRadius(6)
                .overlay(
                    RoundedRectangle(cornerRadius: 6)
                        .stroke(isActive ? DesignSystem.Colors.accent.opacity(0.55) : DesignSystem.Colors.border, lineWidth: 1)
                )
        }
        .buttonStyle(.plain)
    }
}

/// One‑click Best‑of Workflow für Redaktion/Delivery:
/// analysiert sichtbare Serie (oder Auswahl), markiert Top‑Shots als Picks und sortiert beste zuerst.
struct BestOfTopBarButton: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    var compact: Bool = false
    
    private var isActive: Bool {
        uiState.sortMode == .bestOfDesc || uiState.sortMode == .bestOfAsc
    }
    
    private var helpText: String {
        if store.isBestOfRunning {
            let done = store.bestOfProcessedCount
            let total = max(1, store.bestOfTotalCount)
            let name = store.bestOfCurrentName.trimmingCharacters(in: .whitespacesAndNewlines)
            if name.isEmpty {
                return "Best‑of läuft… \(done)/\(total) • Klick zum Abbrechen"
            }
            return "Best‑of läuft… \(done)/\(total) • \(name) • Klick zum Abbrechen"
        }
        if store.selectedPhotoIDs.count > 1 {
            return "Best‑of für Auswahl (\(store.selectedPhotoIDs.count)) – markiert Top‑Picks und sortiert"
        }
        return "Best‑of für sichtbare Serie – markiert Top‑Picks und sortiert"
    }
    
    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 6) {
                Image(systemName: "crown.fill")
                    .font(.system(size: compact ? 11 : 12, weight: .semibold))
                    .foregroundColor(isActive ? Color.white : DesignSystem.Colors.text2)
                
                if !compact {
                    Text("Best‑of")
                        .font(DesignSystem.Fonts.medium(size: 12))
                        .foregroundColor(isActive ? Color.white : DesignSystem.Colors.text2)
                }
                
                if store.isBestOfRunning {
                    ProgressView(value: store.bestOfProgress)
                        .progressViewStyle(.circular)
                        .tint(isActive ? Color.white : DesignSystem.Colors.accent)
                        .controlSize(.small)
                        .frame(width: 14, height: 14)
                }
            }
            .padding(.horizontal, compact ? 8 : 12)
            .frame(height: compact ? 28 : 30)
            .background(isActive ? DesignSystem.Colors.accent : DesignSystem.Colors.background3)
            .cornerRadius(6)
            .overlay(
                RoundedRectangle(cornerRadius: 6)
                    .stroke(isActive ? DesignSystem.Colors.accent.opacity(0.8) : DesignSystem.Colors.border, lineWidth: isActive ? 1.5 : 1)
            )
        }
        .buttonStyle(.plain)
        .help(helpText)
    }
    
    private func onTap() {
        if store.isBestOfRunning {
            store.cancelBestOf()
            // Setze Sortierung zurück auf Standard
            uiState.sortMode = .captureDateDesc
            return
        }
        
        // Toggle: Wenn BestOF bereits aktiv, deaktiviere es
        if isActive {
            uiState.sortMode = .captureDateDesc
            return
        }
        
        // Starte BestOF
        store.startBestOfWorkflow()
    }
}

struct SortMenuButton: View {
    @EnvironmentObject var uiState: UIState
    @State private var isHovering = false
    
    private var isTopPicksActive: Bool {
        uiState.pickStatusFilter == .pick
    }
    
    private var hasActiveFilters: Bool {
        uiState.pickStatusFilter != nil ||
        uiState.ratingFilter != nil ||
        uiState.colorTagFilter != nil ||
        !uiState.searchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
        uiState.exifCameraMakeFilter != nil ||
        uiState.exifCameraModelFilter != nil ||
        uiState.exifLensModelFilter != nil ||
        uiState.exifFocalLengthMinFilter != nil ||
        uiState.exifFocalLengthMaxFilter != nil ||
        uiState.exifISOMinFilter != nil ||
        uiState.exifISOMaxFilter != nil ||
        uiState.exifApertureMinFilter != nil ||
        uiState.exifApertureMaxFilter != nil ||
        uiState.exifShutterSpeedMinFilter != nil ||
        uiState.exifShutterSpeedMaxFilter != nil
    }
    
    private func resetAllFilters() {
        uiState.pickStatusFilter = nil
        uiState.ratingFilter = nil
        uiState.colorTagFilter = nil
        uiState.searchQuery = ""
        uiState.exifCameraMakeFilter = nil
        uiState.exifCameraModelFilter = nil
        uiState.exifLensModelFilter = nil
        uiState.exifFocalLengthMinFilter = nil
        uiState.exifFocalLengthMaxFilter = nil
        uiState.exifISOMinFilter = nil
        uiState.exifISOMaxFilter = nil
        uiState.exifApertureMinFilter = nil
        uiState.exifApertureMaxFilter = nil
        uiState.exifShutterSpeedMinFilter = nil
        uiState.exifShutterSpeedMaxFilter = nil
    }
    
    var body: some View {
        Menu {
            Picker("Sortierung", selection: $uiState.sortMode) {
                ForEach(PhotoSortMode.allCases, id: \.self) { mode in
                    Text(mode.title).tag(mode)
                }
            }
            
            Divider()
            
            Button(action: {
                if isTopPicksActive {
                    uiState.pickStatusFilter = nil
                } else {
                    uiState.pickStatusFilter = .pick
                }
            }) {
                HStack {
                    if isTopPicksActive {
                        Image(systemName: "checkmark")
                            .foregroundColor(DesignSystem.Colors.accent)
                    }
                    Text("Nur Top Picks anzeigen")
                }
            }
            
            // Filter zurücksetzen Button (immer verfügbar, auch wenn keine Ergebnisse)
            if hasActiveFilters {
                Divider()
                
                Button(action: {
                    resetAllFilters()
                }) {
                    HStack {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundColor(DesignSystem.Colors.text3)
                        Text("Alle Filter zurücksetzen")
                    }
                }
            }
        } label: {
            HStack(spacing: 4) {
                Image(systemName: iconName)
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Image(systemName: "chevron.down")
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text3)
            }
            .frame(width: 44, height: 32)
            .background(isTopPicksActive ? DesignSystem.Colors.accent.opacity(0.25) : backgroundColor)
            .cornerRadius(DesignSystem.CornerRadius.small)
            .overlay(
                RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
            )
        }
        .menuStyle(.borderlessButton)
        .help(isTopPicksActive ? "Sortieren: \(uiState.sortMode.title) • Nur Top Picks" : "Sortieren: \(uiState.sortMode.title)")
        .onHover { hovering in
            isHovering = hovering
        }
    }
    
    private var backgroundColor: Color {
        // Etwas heller als #1A1A1A, damit es auf der Topbar nicht wie ein "schwarzer Block" wirkt.
        if isHovering { return DesignSystem.Colors.background4 }
        return DesignSystem.Colors.background3
    }
    
    private var iconName: String {
        switch uiState.sortMode {
        case .captureDateDesc, .captureDateAsc:
            return "clock"
        case .fileNameAsc:
            return "textformat.abc"
        case .ratingDesc, .ratingAsc:
            return "star"
        case .resolutionDesc, .resolutionAsc:
            return "ruler"
        case .bestOfDesc, .bestOfAsc:
            return "crown"
        }
    }
}

/// Schnellzugriff-Sortierung: Wichtigste Sortierfunktionen auf einen Klick
struct QuickSortButton: View {
    @EnvironmentObject var uiState: UIState
    @State private var isHovering = false
    
    var body: some View {
        Menu {
            Button(action: {
                uiState.sortMode = .captureDateDesc
            }) {
                HStack {
                    if uiState.sortMode == .captureDateDesc {
                        Image(systemName: "checkmark")
                            .foregroundColor(DesignSystem.Colors.accent)
                    }
                    Text("Aufnahmedatum (neueste)")
                }
            }
            
            Button(action: {
                uiState.sortMode = .ratingDesc
            }) {
                HStack {
                    if uiState.sortMode == .ratingDesc {
                        Image(systemName: "checkmark")
                            .foregroundColor(DesignSystem.Colors.accent)
                    }
                    Text("Rating (hoch→tief)")
                }
            }
            
            Button(action: {
                uiState.sortMode = .bestOfDesc
            }) {
                HStack {
                    if uiState.sortMode == .bestOfDesc {
                        Image(systemName: "checkmark")
                            .foregroundColor(DesignSystem.Colors.accent)
                    }
                    Text("Best-of")
                }
            }
            
            Divider()
            
            Button(action: {
                // Alle Filter zurücksetzen
                uiState.pickStatusFilter = nil
                uiState.ratingFilter = nil
                uiState.colorTagFilter = nil
                uiState.searchQuery = ""
                uiState.exifCameraMakeFilter = nil
                uiState.exifCameraModelFilter = nil
                uiState.exifLensModelFilter = nil
                uiState.exifFocalLengthMinFilter = nil
                uiState.exifFocalLengthMaxFilter = nil
                uiState.exifISOMinFilter = nil
                uiState.exifISOMaxFilter = nil
                uiState.exifApertureMinFilter = nil
                uiState.exifApertureMaxFilter = nil
                uiState.exifShutterSpeedMinFilter = nil
                uiState.exifShutterSpeedMaxFilter = nil
            }) {
                HStack {
                    Image(systemName: "eye.fill")
                    Text("Alle anzeigen")
                }
            }
        } label: {
            HStack(spacing: 4) {
                Image(systemName: "arrow.up.arrow.down")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Image(systemName: "chevron.down")
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text3)
            }
            .frame(width: 44, height: 32)
            .background(backgroundColor)
            .cornerRadius(DesignSystem.CornerRadius.small)
            .overlay(
                RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
            )
        }
        .menuStyle(.borderlessButton)
        .help("Schnellzugriff Sortierung")
        .onHover { hovering in
            isHovering = hovering
        }
    }
    
    private var backgroundColor: Color {
        if isHovering { return DesignSystem.Colors.background4 }
        return DesignSystem.Colors.background3
    }
}

struct SearchFieldView: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @FocusState private var isFocused: Bool
    
    var maxWidth: CGFloat = 320
    var minTextFieldWidth: CGFloat = 120
    var placeholder: String = "Suchen (Dateiname, Caption, Keywords, AI)"
    
    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "magnifyingglass")
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(DesignSystem.Colors.text3)
            
            TextField(placeholder, text: $uiState.searchQuery)
                .textFieldStyle(.plain)
                .font(DesignSystem.Fonts.medium(size: 12))
                .foregroundColor(DesignSystem.Colors.text2)
                .focused($isFocused)
                .frame(minWidth: minTextFieldWidth)

            Button {
                if uiState.aiSearchEnabled, store.isAISearchRunning {
                    // "Soft cancel": AI aus → Index Task wird abgebrochen.
                    uiState.aiSearchEnabled = false
                } else {
                    uiState.aiSearchEnabled.toggle()
                }
            } label: {
                HStack(spacing: 4) {
                    Image(systemName: "sparkles")
                        .font(.system(size: 11, weight: .semibold))
                    
                    Text("AI")
                        .font(.system(size: 11, weight: .bold))
                    
                    if store.isAISearchRunning {
                        ProgressView()
                            .controlSize(.mini)
                            .frame(width: 10, height: 10)
                        
                        Text("\(store.aiSearchProcessedCount)/\(max(1, store.aiSearchTotalCount))")
                            .font(.system(size: 10, weight: .bold, design: .monospaced))
                            .foregroundColor(DesignSystem.Colors.text2)
                    }
                }
                .foregroundColor(uiState.aiSearchEnabled ? DesignSystem.Colors.accent : DesignSystem.Colors.text3)
                .padding(.horizontal, 8)
                .padding(.vertical, 4)
                .background(uiState.aiSearchEnabled ? DesignSystem.Colors.accent.opacity(0.18) : DesignSystem.Colors.background3)
                .cornerRadius(7)
                .overlay(
                    RoundedRectangle(cornerRadius: 7)
                        .stroke(uiState.aiSearchEnabled ? DesignSystem.Colors.accent.opacity(0.35) : DesignSystem.Colors.border, lineWidth: 1)
                )
            }
            .buttonStyle(.plain)
            .help(aiSearchHelpText)
            
            if !uiState.searchQuery.isEmpty {
                Button {
                    uiState.searchQuery = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(DesignSystem.Colors.text3)
                }
                .buttonStyle(.plain)
                .help("Suche löschen")
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
        .overlay(
            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
        .frame(maxWidth: maxWidth)
        .onChange(of: uiState.focusSearchField) { _, focus in
            guard focus else { return }
            isFocused = true
            DispatchQueue.main.async {
                uiState.focusSearchField = false
            }
        }
    }
    
    private var aiSearchHelpText: String {
        if uiState.aiSearchEnabled {
            if store.isAISearchRunning {
                let done = store.aiSearchProcessedCount
                let total = max(1, store.aiSearchTotalCount)
                return "AI‑Suche indexiert lokal… \(done)/\(total) • Klick zum Stoppen"
            }
            return "AI‑Suche aktiv (lokale Vision‑Tags) • Tipp: „Hund“, „Portrait“, „Himmel“, „Landschaft“, „Eishockey“…"
        }
        return "AI‑Suche deaktiviert • Aktivieren für Inhalte‑Suche (Hund/Portrait/Eishockey…) – läuft lokal, keine Cloud"
    }
}

struct RatingFilterButton: View {
    let rating: Int
    @Binding var currentFilter: Int?
    
    var isSelected: Bool {
        currentFilter == (rating == 0 ? nil : rating)
    }

    var body: some View {
        Button(action: {
            currentFilter = (rating == 0 ? nil : rating)
        }) {
            if rating == 0 {
                Text("Alle")
                    .font(DesignSystem.Fonts.medium(size: 11))
                    .foregroundColor(isSelected ? Color.white : DesignSystem.Colors.text3)
                    .frame(width: 44, height: 24)
            } else {
                HStack(spacing: 3) {
                    Image(systemName: "star.fill")
                        .font(.system(size: 11, weight: .semibold))
                        .foregroundColor(isSelected ? DesignSystem.Colors.star : DesignSystem.Colors.text3)
                    Text("\(rating)")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(isSelected ? Color.white : DesignSystem.Colors.text3)
                        .monospacedDigit()
                }
                .frame(width: 32, height: 24)
            }
        }
        .buttonStyle(.plain)
        .background(isSelected ? DesignSystem.Colors.background : Color.clear)
        .cornerRadius(DesignSystem.CornerRadius.small)
    }
}


struct ActionButtons: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @StateObject private var settings = AppSettings.shared

    var body: some View {
        HStack(spacing: 6) {
            TopBarIconButton(
                systemName: "arrow.uturn.left",
                help: "Undo (⌘Z)",
                action: { store.undoCurrent() }
            )
            .disabled(!store.canUndoCurrent)
            
            TopBarIconButton(
                systemName: "arrow.uturn.right",
                help: "Redo (⇧⌘Z)",
                action: { store.redoCurrent() }
            )
            .disabled(!store.canRedoCurrent)
            
            TopBarIconButton(
                systemName: "rectangle.split.2x1",
                help: "Before/After umschalten",
                isActive: uiState.showBeforeAfter,
                action: { uiState.showBeforeAfter.toggle() }
            )
            .disabled(uiState.viewMode != .detail || store.currentPhoto == nil)
            
            AutoMenuButton(
                help: settings.autoUsesStyleProfile ? "Auto (+ Stil‑Profil)" : "Auto‑Verbesserung",
                applyAutoCurrent: applyAutoEnhancement
            )

            CullingQueueMenuButton()

            BatchActionsMenuButton()

            TopBarIconButton(
                systemName: "doc.on.doc",
                help: "Duplikate suchen",
                action: { uiState.activeSheet = .duplicateDetection }
            )
            .disabled(store.photos.isEmpty)

            UnifiedExportMenuButton()
            
            ActivityCenterButton()
        }
    }
    
    private func applyAutoEnhancement() {
        guard let photo = store.currentPhoto else { return }
        Task {
            if let adjustments = await store.buildAutoAdjustments(for: photo) {
                await MainActor.run {
                    store.registerUndoPoint(for: photo)
                    photo.adjustments = adjustments
                    // Trigger DetailView reprocess (wir verlassen uns auf Notification statt auf onChange-Spam)
                    NotificationCenter.default.post(
                        name: NSNotification.Name("PhotoAdjustmentsChanged"),
                        object: nil,
                        userInfo: ["photoID": photo.id]
                    )
                }
            }
        }
    }
    
}

private struct AutoMenuButton: View {
    @EnvironmentObject var store: PhotoStore
    @StateObject private var settings = AppSettings.shared
    @State private var isHovering = false
    
    let help: String
    let applyAutoCurrent: () -> Void
    
    var body: some View {
        Menu {
            Section("Auto") {
                Button(settings.autoUsesStyleProfile ? "Auto (+ Stil‑Profil) – aktuelles Foto" : "Auto – aktuelles Foto") {
                    applyAutoCurrent()
                }
                .disabled(store.currentPhoto == nil || store.isBatchAutoRunning)
                
                Button("Auto auf Auswahl anwenden (\(store.selectedPhotoIDs.count))") {
                    store.applyAutoToSelection()
                }
                .disabled(store.selectedPhotoIDs.isEmpty || store.isBatchAutoRunning)
                
                if store.isBatchAutoRunning {
                    Divider()
                    Button("Abbrechen") {
                        store.cancelBatchAuto()
                    }
                }
            }
            
            Divider()
            
            Toggle("Auto nutzt Stil‑Profil", isOn: $settings.autoUsesStyleProfile)
        } label: {
            ZStack {
                Image(systemName: "wand.and.stars")
                    .font(DesignSystem.Fonts.medium(size: 14))
                    .foregroundColor(DesignSystem.Colors.text)
                    .frame(width: 32, height: 32)
                    .background(backgroundColor)
                    .overlay(
                        RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                            .stroke(DesignSystem.Colors.border, lineWidth: 1)
                    )
                    .cornerRadius(DesignSystem.CornerRadius.small)
                
                if store.isBatchAutoRunning {
                    ProgressView(value: store.batchAutoProgress)
                        .progressViewStyle(.circular)
                        .tint(DesignSystem.Colors.accent)
                        .scaleEffect(0.75)
                        .frame(width: 20, height: 20)
                }
            }
        }
        .menuStyle(.borderlessButton)
        .help(autoHelpText)
        .onHover { hovering in
            isHovering = hovering
        }
    }
    
    private var backgroundColor: Color {
        if isHovering { return DesignSystem.Colors.background4 }
        return DesignSystem.Colors.background3
    }
    
    private var autoHelpText: String {
        if store.isBatchAutoRunning {
            let done = store.batchAutoProcessedCount
            let total = max(1, store.batchAutoTotalCount)
            let name = store.batchAutoCurrentName.isEmpty ? "" : " • \(store.batchAutoCurrentName)"
            return "Auto läuft… \(done)/\(total)\(name)"
        }
        return help
    }
}

private struct CullingQueueMenuButton: View {
    @EnvironmentObject var store: PhotoStore
    @State private var isHovering = false
    
    var body: some View {
        Menu {
            Section("Culling‑Queue (Turbo)") {
                Button("Nächstes Unreviewed") { store.selectNextUnreviewed() }
                    .keyboardShortcut("n", modifiers: [.control, .command])
                
                Button("Vorheriges Unreviewed") { store.selectPreviousUnreviewed() }
                    .keyboardShortcut("n", modifiers: [.control, .command, .shift])
                
                Divider()
                
                Button("Nächstes Unrated") { store.selectNextUnrated() }
                    .keyboardShortcut("r", modifiers: [.control, .command])
                
                Button("Vorheriges Unrated") { store.selectPreviousUnrated() }
                    .keyboardShortcut("r", modifiers: [.control, .command, .shift])
                
                Divider()
                
                Button("Nächstes Unflagged") { store.selectNextUnflagged() }
                    .keyboardShortcut("u", modifiers: [.control, .command])
                
                Button("Vorheriges Unflagged") { store.selectPreviousUnflagged() }
                    .keyboardShortcut("u", modifiers: [.control, .command, .shift])
            }
        } label: {
            Image(systemName: "bolt.horizontal.circle")
                .font(DesignSystem.Fonts.medium(size: 14))
                .foregroundColor(DesignSystem.Colors.text)
                .frame(width: 32, height: 32)
                .background(backgroundColor)
                .overlay(
                    RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                        .stroke(DesignSystem.Colors.border, lineWidth: 1)
                )
                .cornerRadius(DesignSystem.CornerRadius.small)
        }
        .menuStyle(.borderlessButton)
        .help("Turbo‑Navigation: ⌃⌘N (Unreviewed) • ⌃⌘R (Unrated) • ⌃⌘U (Unflagged)")
        .onHover { hovering in
            isHovering = hovering
        }
    }
    
    private var backgroundColor: Color {
        if isHovering { return DesignSystem.Colors.background4 }
        return DesignSystem.Colors.background3
    }
}

private struct BatchActionsMenuButton: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @State private var isHovering = false
    @State private var showKeywordsSheet = false
    
    private var selectionCount: Int { store.selectedPhotoIDs.count }
    private var isMulti: Bool { store.selectedPhotoIDs.count > 1 }
    private var hasSelectionOrCurrent: Bool { !store.selectedPhotoIDs.isEmpty || store.currentPhoto != nil }
    
    var body: some View {
        Menu {
            Section("Auswahl") {
                if isMulti {
                    Text("\(selectionCount) Fotos ausgewählt")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.secondary)
                } else if store.currentPhoto != nil {
                    Text("Aktuelles Foto")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.secondary)
                } else {
                    Text("Kein Foto ausgewählt")
                        .font(.system(size: 11, weight: .medium))
                        .foregroundStyle(.secondary)
                }
                
                if !uiState.selectionMode && !isMulti {
                    Button("Mehrfachauswahl aktivieren") {
                        uiState.selectionMode = true
                    }
                }
            }
            
            Divider()
            
            Section(isMulti ? "Batch Aktionen" : "Aktionen") {
                Menu(isMulti ? "Rating setzen" : "Rating setzen") {
                    Button("0 ★") { store.setRatingForSelection(0) }.disabled(!hasSelectionOrCurrent)
                    Divider()
                    Button("1 ★") { store.setRatingForSelection(1) }.disabled(!hasSelectionOrCurrent)
                    Button("2 ★") { store.setRatingForSelection(2) }.disabled(!hasSelectionOrCurrent)
                    Button("3 ★") { store.setRatingForSelection(3) }.disabled(!hasSelectionOrCurrent)
                    Button("4 ★") { store.setRatingForSelection(4) }.disabled(!hasSelectionOrCurrent)
                    Button("5 ★") { store.setRatingForSelection(5) }.disabled(!hasSelectionOrCurrent)
                }
                
                Menu("Pick / Reject") {
                    Button("Als Pick markieren") { store.setPickStatusForSelection(.pick) }.disabled(!hasSelectionOrCurrent)
                    Button("Als Reject markieren") { store.setPickStatusForSelection(.reject) }.disabled(!hasSelectionOrCurrent)
                    Divider()
                    Button("Unflagged (Markierung entfernen)") { store.setPickStatusForSelection(.unflagged) }.disabled(!hasSelectionOrCurrent)
                }
                
                Menu("Farb-Tags") {
                    ForEach(ColorTag.allCases, id: \.self) { tag in
                        Button {
                            store.toggleColorTagForSelection(tag)
                        } label: {
                            HStack(spacing: 8) {
                                Circle()
                                    .fill(Color(nsColor: tag.color))
                                    .frame(width: 10, height: 10)
                                Text(tag.displayName)
                            }
                        }
                        .disabled(!hasSelectionOrCurrent)
                    }
                }
                
                Button("Keywords hinzufügen…") {
                    showKeywordsSheet = true
                }
                .disabled(!isMulti)
                
                Divider()
                
                Button("Auswahl löschen") {
                    store.clearSelectionToCurrent()
                    uiState.selectionMode = false
                }
                .disabled(store.selectedPhotoIDs.count <= 1)
            }
        } label: {
            Image(systemName: "square.stack.3d.up")
                .font(DesignSystem.Fonts.medium(size: 14))
                .foregroundColor(DesignSystem.Colors.text)
                .frame(width: 32, height: 32)
                .background(backgroundColor)
                .overlay(
                    RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                        .stroke(DesignSystem.Colors.border, lineWidth: 1)
                )
                .cornerRadius(DesignSystem.CornerRadius.small)
        }
        .menuStyle(.borderlessButton)
        .help("Batch‑Aktionen für Auswahl: Rating, Pick/Reject, Farb‑Tags, Keywords")
        .onHover { hovering in
            isHovering = hovering
        }
        .sheet(isPresented: $showKeywordsSheet) {
            BatchKeywordsSheet()
                .environmentObject(store)
        }
    }
    
    private var backgroundColor: Color {
        if isHovering { return DesignSystem.Colors.background4 }
        return DesignSystem.Colors.background3
    }
}

private struct BatchKeywordsSheet: View {
    @EnvironmentObject var store: PhotoStore
    @Environment(\.dismiss) private var dismiss
    
    @State private var text: String = ""
    @FocusState private var isFocused: Bool
    
    private var selectionCount: Int { store.selectedPhotoIDs.count }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Keywords hinzufügen")
                        .font(DesignSystem.Fonts.semibold(size: 16))
                        .foregroundColor(DesignSystem.Colors.text)
                    
                    Text("\(selectionCount) Foto(s) ausgewählt • Bestehende Keywords bleiben erhalten")
                        .font(DesignSystem.Fonts.regular(size: 11))
                        .foregroundColor(DesignSystem.Colors.text3)
                }
                
                Spacer()
                
                Button("Schließen") { dismiss() }
                    .buttonStyle(LightroomSecondaryButtonStyle())
            }
            
            TextEditor(text: $text)
                .focused($isFocused)
                .font(DesignSystem.Fonts.regular(size: 12))
                .foregroundColor(DesignSystem.Colors.text)
                .scrollContentBackground(.hidden)
                .frame(height: 90)
                .padding(8)
                .background(DesignSystem.Colors.background3)
                .overlay(
                    RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                        .stroke(DesignSystem.Colors.border, lineWidth: 1)
                )
                .cornerRadius(DesignSystem.CornerRadius.small)
            
            Text("Trenne Keywords mit Komma, Semikolon oder Zeilenumbruch.")
                .font(DesignSystem.Fonts.regular(size: 10))
                .foregroundColor(DesignSystem.Colors.text4)
            
            HStack {
                Button("Abbrechen") { dismiss() }
                    .buttonStyle(LightroomSecondaryButtonStyle())
                
                Spacer()
                
                Button("Hinzufügen") {
                    store.addKeywordsToSelection(from: text)
                    dismiss()
                }
                .buttonStyle(.borderedProminent)
                .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || selectionCount < 2)
            }
        }
        .padding(14)
        .frame(width: 520)
        .background(DesignSystem.Colors.background)
        .lightroomSidebarTheme()
        .onAppear { isFocused = true }
    }
}

private struct UnifiedExportMenuButton: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @StateObject private var settings = AppSettings.shared
    @State private var isHovering = false
    
    private var hasPicksInScope: Bool {
        let scope: [PhotoItem] = {
            if store.selectedPhotoIDs.count > 1 {
                return store.photos.filter { store.selectedPhotoIDs.contains($0.id) }
            }
            return store.filteredPhotos
        }()
        return scope.contains { $0.pickStatus == .pick }
    }
    
    var body: some View {
        Menu {
            Section("Quick Export") {
                Button("Quick Export (aktuelles Foto)") {
                    store.quickExportCurrent()
                }
                .disabled(store.currentPhoto == nil || store.isQuickExporting)
                
                Button("Quick Export (Auswahl)") {
                    store.quickExportSelection()
                }
                .disabled(store.selectedPhotoIDs.isEmpty || store.isQuickExporting)
                
                Button("Picks exportieren") {
                    store.quickExportPicksInScope()
                }
                .disabled(!hasPicksInScope || store.isQuickExporting)
            }
            
            Divider()
            
            Section("Redaktion / Delivery") {
                Button("Best‑of \(settings.bestOfPickCount) → Picks + Export") {
                    store.startBestOfAndExportTopPicks()
                }
                .disabled(store.isBestOfRunning || store.isQuickExporting)
                
                if store.isBestOfRunning {
                    Divider()
                    Button("Best‑of abbrechen") { store.cancelBestOf() }
                }
            }
            
            Divider()
            
            Section("Export") {
                Button("Exportieren…") {
                    uiState.activeSheet = .export
                }
                Button("Batch Export…") {
                    uiState.activeSheet = .batchExport
                }
            }
            
            Divider()
            
            Section("Quick Export Setup") {
                Menu("Preset") {
                    Button("Keines") { store.setQuickExportPreset(nil) }
                    Divider()
                    ForEach(store.exportPresets) { preset in
                        Button(preset.name) { store.setQuickExportPreset(preset) }
                    }
                }
                
                Button("Zielordner wählen…") {
                    store.chooseQuickExportDirectory()
                }
            }
        } label: {
            ZStack {
                // Button
                Image(systemName: "square.and.arrow.up")
                    .font(DesignSystem.Fonts.medium(size: 14))
                    .foregroundColor(DesignSystem.Colors.text)
                    .frame(width: 32, height: 32)
                    .background(backgroundColor)
                    .overlay(
                        RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                            .stroke(DesignSystem.Colors.border, lineWidth: 1)
                    )
                    .cornerRadius(DesignSystem.CornerRadius.small)
                
                // Progress overlay
                if store.isQuickExporting {
                    ProgressView(value: store.quickExportProgress)
                        .progressViewStyle(.circular)
                        .tint(DesignSystem.Colors.accent)
                        .scaleEffect(0.75)
                        .frame(width: 20, height: 20)
                } else if store.isBestOfRunning {
                    ProgressView(value: store.bestOfProgress)
                        .progressViewStyle(.circular)
                        .tint(DesignSystem.Colors.accent)
                        .scaleEffect(0.75)
                        .frame(width: 20, height: 20)
                } else if store.isExportQueueRunning {
                    ProgressView(value: store.exportQueueProgress)
                        .progressViewStyle(.circular)
                        .tint(DesignSystem.Colors.accent)
                        .scaleEffect(0.75)
                        .frame(width: 20, height: 20)
                }
                
                // Export‑Queue enabled indicator
                if store.exportQueueEnabled {
                    Circle()
                        .fill(DesignSystem.Colors.accent)
                        .frame(width: 7, height: 7)
                        .offset(x: 11, y: -11)
                }
            }
        }
        .menuStyle(.borderlessButton)
        .help(exportHelpText)
        .onHover { hovering in
            isHovering = hovering
        }
    }
    
    private var backgroundColor: Color {
        if isHovering { return DesignSystem.Colors.background4 }
        return DesignSystem.Colors.background3
    }
    
    private var exportHelpText: String {
        if store.isQuickExporting {
            return "Quick Export läuft…"
        }
        if store.isBestOfRunning {
            let done = store.bestOfProcessedCount
            let total = max(1, store.bestOfTotalCount)
            return "Best‑of läuft… \(done)/\(total)"
        }
        if store.isExportQueueRunning {
            let done = store.exportQueueProcessedCount
            let total = max(1, store.exportQueueTotalCount)
            let name = store.exportQueueCurrentName.isEmpty ? "" : " • \(store.exportQueueCurrentName)"
            return "Export‑Queue läuft… \(done)/\(total)\(name)"
        }
        return "Export / Quick Export / Best-of"
    }
}

// MARK: - Button Styles & View Modifiers

struct TopBarIconButton: View {
    let systemName: String
    let help: String
    var isActive: Bool = false
    let action: () -> Void
    
    @State private var isHovering = false
    
    var body: some View {
        Button(action: action) {
            Image(systemName: systemName)
                .font(DesignSystem.Fonts.medium(size: 14))
                .foregroundColor(isActive ? Color.white : DesignSystem.Colors.text)
                .frame(width: 32, height: 32)
                .background(backgroundColor)
                .overlay(
                    RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                        .stroke(DesignSystem.Colors.border, lineWidth: 1)
                )
                .cornerRadius(DesignSystem.CornerRadius.small)
        }
        .buttonStyle(.plain)
        .help(help)
        .onHover { hovering in
            isHovering = hovering
        }
    }
    
    private var backgroundColor: Color {
        if isActive {
            return DesignSystem.Colors.accent.opacity(0.25)
        }
        if isHovering {
            return DesignSystem.Colors.background4
        }
        // Standard: leicht abgesetzt, damit Buttons auf der Topbar gut sichtbar sind (ohne wie "schwarze Klötze" zu wirken).
        return DesignSystem.Colors.background3
    }
}

struct FolderStatusView: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    var body: some View {
        HStack(spacing: 8) {
            if store.isLoadingPhotos {
                ProgressView()
                    .tint(DesignSystem.Colors.text2)
                    .controlSize(.small)
                    .frame(width: 14, height: 14)
            }
            
            Image(systemName: "folder")
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(DesignSystem.Colors.text3)
            
            Text(folderTitle)
                .font(DesignSystem.Fonts.medium(size: 12))
                .foregroundColor(DesignSystem.Colors.text2)
                .lineLimit(1)
                .truncationMode(.middle)
            
            if totalCount > 0 {
                Text("•")
                    .foregroundColor(DesignSystem.Colors.text4)
                
                Text("\(currentIndex)/\(totalCount)")
                    .font(DesignSystem.Fonts.medium(size: 12))
                    .foregroundColor(DesignSystem.Colors.text3)
                    .monospacedDigit()
            }
            
            if hasActiveFilters {
                Text("•")
                    .foregroundColor(DesignSystem.Colors.text4)
                
                ActiveFilterChipsInline()
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 6)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(DesignSystem.CornerRadius.small)
        .overlay(
            RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
        .frame(maxWidth: 720, alignment: .leading)
    }
    
    private var folderTitle: String {
        store.currentFolder?.lastPathComponent ?? "Kein Ordner"
    }
    
    private var totalCount: Int {
        store.filteredPhotos.count
    }
    
    private var currentIndex: Int {
        guard let idx = store.currentPhotoIndexInFiltered else { return 0 }
        return idx + 1
    }
    
    private var hasActiveFilters: Bool {
        uiState.activeSmartCollectionID != nil ||
        !uiState.searchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
        uiState.ratingFilter != nil ||
        uiState.pickStatusFilter != nil ||
        uiState.colorTagFilter != nil ||
        uiState.showQuickCollectionOnly
    }
}

struct ActiveFilterChipsInline: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    var body: some View {
        HStack(spacing: 6) {
            if let smartID = uiState.activeSmartCollectionID,
               let collection = store.smartCollections.first(where: { $0.id == smartID }) {
                FilterChip(title: collection.name, systemImage: "sparkles") {
                    uiState.activeSmartCollectionID = nil
                }
            }
            
            let q = uiState.searchQuery.trimmingCharacters(in: .whitespacesAndNewlines)
            if !q.isEmpty {
                FilterChip(title: "Suche: \(q)", systemImage: "magnifyingglass") {
                    uiState.searchQuery = ""
                }
            }
            
            if let rating = uiState.ratingFilter {
                FilterChip(title: "★ \(rating)", systemImage: "star.fill") {
                    uiState.ratingFilter = nil
                }
            }
            
            if let pick = uiState.pickStatusFilter {
                FilterChip(
                    title: pick == .pick ? "Pick" : "Reject",
                    systemImage: pick == .pick ? "flag.fill" : "xmark.circle.fill"
                ) {
                    uiState.pickStatusFilter = nil
                }
            }
            
            if let tag = uiState.colorTagFilter {
                FilterChip(
                    title: "Label: \(tag.displayName)",
                    dotColor: Color(tag.color)
                ) {
                    uiState.colorTagFilter = nil
                }
            }
            
            if uiState.showQuickCollectionOnly {
                FilterChip(title: "Quick Collection", systemImage: "bookmark.fill") {
                    uiState.showQuickCollectionOnly = false
                }
            }
        }
        .lineLimit(1)
    }
}

struct FilterChip: View {
    let title: String
    var systemImage: String? = nil
    var dotColor: Color? = nil
    let onClear: () -> Void
    
    var body: some View {
        HStack(spacing: 6) {
            if let systemImage {
                Image(systemName: systemImage)
                    .font(.system(size: 10, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text2)
            }
            
            if let dotColor {
                Circle()
                    .fill(dotColor)
                    .frame(width: 8, height: 8)
                    .overlay(
                        Circle().stroke(Color.white.opacity(0.75), lineWidth: 0.5)
                    )
            }
            
            Text(title)
                .font(DesignSystem.Fonts.medium(size: 11))
                .foregroundColor(DesignSystem.Colors.text2)
                .lineLimit(1)
            
            Button(action: onClear) {
                Image(systemName: "xmark")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundColor(DesignSystem.Colors.text3)
                    .padding(2)
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(DesignSystem.Colors.background3.opacity(0.65))
        .clipShape(RoundedRectangle(cornerRadius: 6))
        .overlay(
            RoundedRectangle(cornerRadius: 6)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
    }
}

// MARK: - Topbar Compact Helpers

/// Kompakte Suche (Popover), wenn die Topbar wenig Platz hat.
struct SearchPopoverButton: View {
    @EnvironmentObject var uiState: UIState
    @State private var show: Bool = false
    @State private var isHovering: Bool = false
    
    var body: some View {
        Button {
            show.toggle()
            DispatchQueue.main.async {
                uiState.focusSearchField = true
            }
        } label: {
            Image(systemName: "magnifyingglass")
                .font(DesignSystem.Fonts.medium(size: 14))
                .foregroundColor(DesignSystem.Colors.text)
                .frame(width: 32, height: 32)
                .background(isHovering ? DesignSystem.Colors.background4 : DesignSystem.Colors.background3)
                .cornerRadius(DesignSystem.CornerRadius.small)
                .overlay(
                    RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                        .stroke(DesignSystem.Colors.border, lineWidth: 1)
                )
        }
        .buttonStyle(.plain)
        .help("Suchen (⌘F)")
        .onHover { hovering in
            isHovering = hovering
        }
        .popover(isPresented: $show, arrowEdge: .top) {
            VStack(alignment: .leading, spacing: 10) {
                Text("Suche")
                    .font(DesignSystem.Fonts.semibold(size: 13))
                    .foregroundColor(DesignSystem.Colors.text2)
                
                SearchFieldView(maxWidth: 420, minTextFieldWidth: 240)
            }
            .padding(12)
            .frame(width: 460)
            .background(DesignSystem.Colors.background2)
            .onAppear {
                DispatchQueue.main.async {
                    uiState.focusSearchField = true
                }
            }
        }
    }
}

/// Kompakter Ordner/Status Button (Popover mit Details).
struct FolderStatusCompactButton: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @State private var show: Bool = false
    @State private var isHovering: Bool = false
    
    var body: some View {
        Button {
            show.toggle()
        } label: {
            HStack(spacing: 6) {
                if store.isLoadingPhotos {
                    ProgressView()
                        .tint(DesignSystem.Colors.text2)
                        .controlSize(.small)
                        .frame(width: 14, height: 14)
                }
                
                Image(systemName: "folder")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text3)
                
                if totalCount > 0 {
                    Text("\(currentIndex)/\(totalCount)")
                        .font(DesignSystem.Fonts.medium(size: 12))
                        .foregroundColor(DesignSystem.Colors.text2)
                        .monospacedDigit()
                } else {
                    Text("—")
                        .font(DesignSystem.Fonts.medium(size: 12))
                        .foregroundColor(DesignSystem.Colors.text3)
                }
                
                if hasActiveFilters {
                    Image(systemName: "line.3.horizontal.decrease.circle.fill")
                        .font(.system(size: 12, weight: .semibold))
                        .foregroundColor(DesignSystem.Colors.accent)
                }
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 6)
            .background(isHovering ? DesignSystem.Colors.background4 : DesignSystem.Colors.background3)
            .cornerRadius(DesignSystem.CornerRadius.small)
            .overlay(
                RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
        .help("Ordner/Status anzeigen")
        .onHover { hovering in
            isHovering = hovering
        }
        .popover(isPresented: $show, arrowEdge: .top) {
            VStack(alignment: .leading, spacing: 10) {
                Text("Status")
                    .font(DesignSystem.Fonts.semibold(size: 13))
                    .foregroundColor(DesignSystem.Colors.text2)
                
                FolderStatusView()
            }
            .padding(12)
            .frame(width: 520)
            .background(DesignSystem.Colors.background2)
        }
    }
    
    private var totalCount: Int {
        store.filteredPhotos.count
    }
    
    private var currentIndex: Int {
        guard let idx = store.currentPhotoIndexInFiltered else { return 0 }
        return idx + 1
    }
    
    private var hasActiveFilters: Bool {
        uiState.activeSmartCollectionID != nil ||
        !uiState.searchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
        uiState.ratingFilter != nil ||
        uiState.pickStatusFilter != nil ||
        uiState.colorTagFilter != nil ||
        uiState.showQuickCollectionOnly
    }
}

/// Alles was viel Platz braucht (Rating/Labels/Sort) als Menü, für sehr kleine Fenster.
struct FilterMenuButton: View {
    @EnvironmentObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    @State private var isHovering: Bool = false
    
    private let tags: [ColorTag] = [.red, .yellow, .green, .blue]
    
    var body: some View {
        Menu {
            if uiState.viewMode == .grid {
                Section("Rating‑Filter") {
                    Button("Alle") { uiState.ratingFilter = nil }
                    Divider()
                    ForEach(1...5, id: \.self) { r in
                        Button("\(r) Stern\(r == 1 ? "" : "e")") { uiState.ratingFilter = r }
                    }
                }
                
                Section("Farb‑Label‑Filter") {
                    Button("Alle") { uiState.colorTagFilter = nil }
                    Divider()
                    ForEach(tags, id: \.self) { tag in
                        Button(tag.displayName) { uiState.colorTagFilter = tag }
                    }
                }
            } else {
                Section("Rating setzen") {
                    Button("0 (löschen)") {
                        if let id = store.currentPhotoID {
                            store.setRating(0, for: id, autoAdvance: false)
                        }
                    }
                    Divider()
                    ForEach(1...5, id: \.self) { r in
                        Button("\(r) Stern\(r == 1 ? "" : "e")") {
                            if let id = store.currentPhotoID {
                                store.setRating(r, for: id)
                            }
                        }
                    }
                }
                
                Section("Farb‑Label") {
                    ForEach(tags, id: \.self) { tag in
                        Button(tag.displayName) {
                            if let id = store.currentPhotoID {
                                store.toggleColorTag(tag, for: id)
                            }
                        }
                    }
                }
            }
            
            Divider()
            
            Section("EXIF‑Filter") {
                Menu("Kamera‑Hersteller") {
                    Button("Alle") { uiState.exifCameraMakeFilter = nil }
                    Divider()
                    // Lade verfügbare Hersteller aus allen Fotos
                    let makes = Set(store.photos.compactMap { $0.exifMeta?.cameraMake }.filter { !$0.isEmpty }).sorted()
                    if makes.isEmpty {
                        Text("Lade EXIF-Daten…")
                            .foregroundColor(.secondary)
                            .font(.caption)
                    } else {
                        ForEach(makes, id: \.self) { make in
                            Button(make) { uiState.exifCameraMakeFilter = make }
                        }
                    }
                }
                
                Menu("Kamera‑Modell") {
                    Button("Alle") { uiState.exifCameraModelFilter = nil }
                    Divider()
                    let models = Set(store.photos.compactMap { $0.exifMeta?.cameraModel }.filter { !$0.isEmpty }).sorted()
                    if models.isEmpty {
                        Text("Lade EXIF-Daten…")
                            .foregroundColor(.secondary)
                            .font(.caption)
                    } else {
                        ForEach(models, id: \.self) { model in
                            Button(model) { uiState.exifCameraModelFilter = model }
                        }
                    }
                }
                
                Menu("Objektiv") {
                    Button("Alle") { uiState.exifLensModelFilter = nil }
                    Divider()
                    let lenses = Set(store.photos.compactMap { $0.exifMeta?.lensModel }.filter { !$0.isEmpty }).sorted()
                    if lenses.isEmpty {
                        Text("Lade EXIF-Daten…")
                            .foregroundColor(.secondary)
                            .font(.caption)
                    } else {
                        ForEach(lenses, id: \.self) { lens in
                            Button(lens) { uiState.exifLensModelFilter = lens }
                        }
                    }
                }
                
                Menu("Brennweite") {
                    Button("Alle") {
                        uiState.exifFocalLengthMinFilter = nil
                        uiState.exifFocalLengthMaxFilter = nil
                    }
                    Divider()
                    Button("Weitwinkel (< 24mm)") {
                        uiState.exifFocalLengthMinFilter = nil
                        uiState.exifFocalLengthMaxFilter = 24
                    }
                    Button("Standard (24–85mm)") {
                        uiState.exifFocalLengthMinFilter = 24
                        uiState.exifFocalLengthMaxFilter = 85
                    }
                    Button("Tele (> 85mm)") {
                        uiState.exifFocalLengthMinFilter = 85
                        uiState.exifFocalLengthMaxFilter = nil
                    }
                }
                
                Menu("ISO") {
                    Button("Alle") {
                        uiState.exifISOMinFilter = nil
                        uiState.exifISOMaxFilter = nil
                    }
                    Divider()
                    Button("Niedrig (≤ 400)") {
                        uiState.exifISOMinFilter = nil
                        uiState.exifISOMaxFilter = 400
                    }
                    Button("Mittel (400–1600)") {
                        uiState.exifISOMinFilter = 400
                        uiState.exifISOMaxFilter = 1600
                    }
                    Button("Hoch (> 1600)") {
                        uiState.exifISOMinFilter = 1600
                        uiState.exifISOMaxFilter = nil
                    }
                }
                
                Menu("Blende") {
                    Button("Alle") {
                        uiState.exifApertureMinFilter = nil
                        uiState.exifApertureMaxFilter = nil
                    }
                    Divider()
                    Button("Offen (≤ f/2.8)") {
                        uiState.exifApertureMinFilter = nil
                        uiState.exifApertureMaxFilter = 2.8
                    }
                    Button("Mittel (f/2.8–f/8)") {
                        uiState.exifApertureMinFilter = 2.8
                        uiState.exifApertureMaxFilter = 8.0
                    }
                    Button("Geschlossen (> f/8)") {
                        uiState.exifApertureMinFilter = 8.0
                        uiState.exifApertureMaxFilter = nil
                    }
                }
                
                Menu("Verschlusszeit") {
                    Button("Alle") {
                        uiState.exifShutterSpeedMinFilter = nil
                        uiState.exifShutterSpeedMaxFilter = nil
                    }
                    Divider()
                    Button("Schnell (≤ 1/250s)") {
                        uiState.exifShutterSpeedMinFilter = nil
                        uiState.exifShutterSpeedMaxFilter = 1.0/250.0
                    }
                    Button("Mittel (1/250s–1/30s)") {
                        uiState.exifShutterSpeedMinFilter = 1.0/250.0
                        uiState.exifShutterSpeedMaxFilter = 1.0/30.0
                    }
                    Button("Lang (> 1/30s)") {
                        uiState.exifShutterSpeedMinFilter = 1.0/30.0
                        uiState.exifShutterSpeedMaxFilter = nil
                    }
                }
            }
            
            Divider()
            
            Section("Best‑of") {
                if store.isBestOfRunning {
                    Button("Best‑of abbrechen") { store.cancelBestOf() }
                } else {
                    Button("Best‑of ausführen (Picks markieren)") { store.startBestOfWorkflow() }
                }
            }
            
            Divider()
            
            Section("Sortieren") {
                Button("Aufnahmedatum – Neueste zuerst") { uiState.sortMode = .captureDateDesc }
                Button("Aufnahmedatum – Älteste zuerst") { uiState.sortMode = .captureDateAsc }
                Button("Dateiname ↑") { uiState.sortMode = .fileNameAsc }
                Divider()
                Button("Rating ↓") { uiState.sortMode = .ratingDesc }
                Button("Rating ↑") { uiState.sortMode = .ratingAsc }
                Divider()
                Button("Auflösung ↓") { uiState.sortMode = .resolutionDesc }
                Button("Auflösung ↑") { uiState.sortMode = .resolutionAsc }
                Divider()
                Button("Best‑of ↓") { uiState.sortMode = .bestOfDesc }
                Button("Best‑of ↑") { uiState.sortMode = .bestOfAsc }
            }
        } label: {
            HStack(spacing: 6) {
                Image(systemName: "slider.horizontal.3")
                    .font(DesignSystem.Fonts.medium(size: 14))
                    .foregroundColor(DesignSystem.Colors.text)
                Image(systemName: "chevron.down")
                    .font(.system(size: 9, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.text3)
            }
            .frame(width: 44, height: 32)
            .background(isHovering ? DesignSystem.Colors.background4 : DesignSystem.Colors.background3)
            .cornerRadius(DesignSystem.CornerRadius.small)
            .overlay(
                RoundedRectangle(cornerRadius: DesignSystem.CornerRadius.small)
                    .stroke(DesignSystem.Colors.border, lineWidth: 1)
            )
        }
        .menuStyle(.borderlessButton)
        .help("Filter & Sort (kompakt)")
        .onHover { hovering in
            isHovering = hovering
        }
    }
}

struct PrimaryActionButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(DesignSystem.Fonts.medium(size: 12))
            .foregroundColor(DesignSystem.Colors.text)
            .padding(.horizontal, DesignSystem.Spacing.medium)
            .padding(.vertical, DesignSystem.Spacing.small - 2)
            .background(DesignSystem.Colors.accent)
            .cornerRadius(DesignSystem.CornerRadius.small)
            .opacity(configuration.isPressed ? 0.8 : 1.0)
    }
}

struct SecondaryActionButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(DesignSystem.Fonts.medium(size: 12))
            .foregroundColor(DesignSystem.Colors.text)
            .padding(.horizontal, DesignSystem.Spacing.medium)
            .padding(.vertical, DesignSystem.Spacing.small - 2)
            .background(DesignSystem.Colors.background3)
            .cornerRadius(DesignSystem.CornerRadius.small)
            .opacity(configuration.isPressed ? 0.8 : 1.0)
    }
}

extension View {
    func border(width: CGFloat, edges: [Edge], color: Color) -> some View {
        overlay(EdgeBorder(width: width, edges: edges).foregroundColor(color))
    }
}

struct EdgeBorder: Shape {
    var width: CGFloat
    var edges: [Edge]

    func path(in rect: CGRect) -> Path {
        var path = Path()
        for edge in edges {
            var x: CGFloat {
                switch edge {
                case .top, .bottom, .leading: return rect.minX
                case .trailing: return rect.maxX - width
                }
            }

            var y: CGFloat {
                switch edge {
                case .top, .leading, .trailing: return rect.minY
                case .bottom: return rect.maxY - width
                }
            }

            var w: CGFloat {
                switch edge {
                case .top, .bottom: return rect.width
                case .leading, .trailing: return width
                }
            }

            var h: CGFloat {
                switch edge {
                case .top, .bottom: return width
                case .leading, .trailing: return rect.height
                }
            }
            path.addPath(Path(CGRect(x: x, y: y, width: w, height: h)))
        }
        return path
    }
}

// MARK: - Status Badge View

private struct StatusBadgeView: View {
    @ObservedObject var store: PhotoStore
    
    private var scopePhotos: [PhotoItem] {
        store.filteredPhotos
    }
    
    private var picksCount: Int {
        scopePhotos.filter { $0.pickStatus == .pick }.count
    }
    
    private var rejectsCount: Int {
        scopePhotos.filter { $0.pickStatus == .reject }.count
    }
    
    private var totalCount: Int {
        scopePhotos.count
    }
    
    var body: some View {
        HStack(spacing: 14) {
            // Picks
            HStack(spacing: 5) {
                Image(systemName: "flag.fill")
                    .font(.system(size: 7))
                    .foregroundColor(.green)
                Text("\(picksCount)")
                    .font(DesignSystem.Fonts.semibold(size: 13))
                    .foregroundColor(DesignSystem.Colors.text)
                    .monospacedDigit()
                    .frame(minWidth: 20, alignment: .leading)
            }
            
            // Rejects
            HStack(spacing: 5) {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 7))
                    .foregroundColor(.red)
                Text("\(rejectsCount)")
                    .font(DesignSystem.Fonts.semibold(size: 13))
                    .foregroundColor(DesignSystem.Colors.text)
                    .monospacedDigit()
                    .frame(minWidth: 20, alignment: .leading)
            }
            
            // Total
            HStack(spacing: 5) {
                Text("•")
                    .font(DesignSystem.Fonts.regular(size: 9))
                    .foregroundColor(DesignSystem.Colors.text3)
                Text("\(totalCount)")
                    .font(DesignSystem.Fonts.semibold(size: 13))
                    .foregroundColor(DesignSystem.Colors.text2)
                    .monospacedDigit()
                    .frame(minWidth: 20, alignment: .leading)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 6)
        .background(DesignSystem.Colors.background4)
        .cornerRadius(6)
        .overlay(
            RoundedRectangle(cornerRadius: 6)
                .stroke(DesignSystem.Colors.border, lineWidth: 1)
        )
        .help("Status: Picks (grün) | Rejects (rot) | Total")
    }
}

// MARK: - Custom Label Styles for Toolbar Icons

/// Zeigt nur das Icon, Text (falls angezeigt) steht darunter (Standard Toolbar-Verhalten)
struct IconOnlyLabelStyle: LabelStyle {
    func makeBody(configuration: Configuration) -> some View {
        // Nur Icon anzeigen, Text wird von der Toolbar automatisch unter dem Icon angezeigt wenn iconAndLabel Modus aktiv ist
        configuration.icon
            .imageScale(.medium)
    }
}

struct SmallerIconLabelStyle: LabelStyle {
    func makeBody(configuration: Configuration) -> some View {
        HStack(spacing: 4) {
            configuration.icon
                .imageScale(.small)
            configuration.title
        }
    }
}


