//
//  SmartCollectionView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 15.12.2025.
//

import SwiftUI

struct SmartCollectionView: View {
    @EnvironmentObject var store: PhotoStore
    @Environment(\.dismiss) private var dismiss
    
    @State private var selectedCollection: SmartCollection?
    @State private var isEditing: Bool = false
    @State private var editingCollection: SmartCollection?
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Text("Smart Collections")
                    .font(DesignSystem.Fonts.semibold(size: 16))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Spacer()
                
                Button(action: {
                    let newCollection = SmartCollection(name: "Neue Smart Collection")
                    editingCollection = newCollection
                    isEditing = true
                }) {
                    HStack(spacing: 4) {
                        Image(systemName: "plus")
                            .font(.system(size: 11, weight: .semibold))
                        Text("Neu")
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 6)
                    .background(DesignSystem.Colors.accent)
                    .foregroundColor(.white)
                    .cornerRadius(6)
                }
                .buttonStyle(.plain)
            }
            .padding(DesignSystem.Spacing.medium)
            .background(DesignSystem.Colors.background2)
            
            Divider()
            
            // List
            ScrollView {
                VStack(spacing: 0) {
                    ForEach(store.smartCollections) { collection in
                        SmartCollectionRow(
                            collection: collection,
                            photoCount: store.filterPhotos(by: collection).count,
                            isSelected: selectedCollection?.id == collection.id
                        )
                        .contentShape(Rectangle())
                        .onTapGesture {
                            selectedCollection = collection
                        }
                        .contextMenu {
                            Button("Bearbeiten") {
                                editingCollection = collection
                                isEditing = true
                            }
                            
                            Button("Löschen") {
                                store.deleteSmartCollection(collection)
                                if selectedCollection?.id == collection.id {
                                    selectedCollection = nil
                                }
                            }
                        }
                        
                        Divider()
                            .padding(.leading, 40)
                    }
                }
            }
        }
        .frame(minWidth: 500, minHeight: 400)
        .background(DesignSystem.Colors.background)
        .lightroomSidebarTheme()
        .sheet(isPresented: $isEditing) {
            if let editing = editingCollection {
                SmartCollectionEditorView(
                    collection: editing,
                    onSave: { updated in
                        if store.smartCollections.contains(where: { $0.id == updated.id }) {
                            store.updateSmartCollection(updated)
                        } else {
                            store.addSmartCollection(updated)
                        }
                        editingCollection = nil
                        isEditing = false
                    },
                    onCancel: {
                        editingCollection = nil
                        isEditing = false
                    }
                )
            }
        }
    }
}

struct SmartCollectionRow: View {
    let collection: SmartCollection
    let photoCount: Int
    let isSelected: Bool
    
    var body: some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: "sparkles")
                .font(.system(size: 12))
                .foregroundColor(DesignSystem.Colors.accent)
                .frame(width: 16)
            
            VStack(alignment: .leading, spacing: 4) {
                Text(collection.name)
                    .font(DesignSystem.Fonts.regular(size: 12))
                    .foregroundColor(DesignSystem.Colors.text)
                
                // Kriterien anzeigen
                if !collection.criteria.isEmpty {
                    VStack(alignment: .leading, spacing: 2) {
                        ForEach(criteriaDescriptions, id: \.self) { desc in
                            Text(desc)
                                .font(DesignSystem.Fonts.regular(size: 9))
                                .foregroundColor(DesignSystem.Colors.text2)
                        }
                    }
                } else {
                    Text("Keine Kriterien definiert")
                        .font(DesignSystem.Fonts.regular(size: 9))
                        .foregroundColor(DesignSystem.Colors.text3)
                        .italic()
                }
                
                Text("\(photoCount) Foto(s)")
                    .font(DesignSystem.Fonts.regular(size: 10))
                    .foregroundColor(DesignSystem.Colors.text2)
                    .padding(.top, 2)
            }
            
            Spacer()
        }
        .padding(.horizontal, DesignSystem.Spacing.small)
        .padding(.vertical, DesignSystem.Spacing.small)
        .background(isSelected ? DesignSystem.Colors.accent.opacity(0.2) : Color.clear)
    }
    
    private var criteriaDescriptions: [String] {
        var descs: [String] = []
        let c = collection.criteria
        
        // Rating
        if let min = c.minRating, let max = c.maxRating {
            if min == max {
                descs.append("Rating: \(min) Sterne")
            } else {
                descs.append("Rating: \(min)-\(max) Sterne")
            }
        } else if let min = c.minRating {
            descs.append("Rating: ≥ \(min) Sterne")
        } else if let max = c.maxRating {
            descs.append("Rating: ≤ \(max) Sterne")
        }
        
        // Pick Status
        if let pickStatus = c.pickStatus {
            switch pickStatus {
            case .pick:
                descs.append("Pick Status: Pick")
            case .reject:
                descs.append("Pick Status: Reject")
            case .unflagged:
                descs.append("Pick Status: Unflagged")
            }
        }
        
        // Color Tags
        if !c.colorTags.isEmpty {
            let tagNames = c.colorTags.map { $0.displayName }.joined(separator: ", ")
            descs.append("Color Tags: \(tagNames)")
        }
        if c.hasColorTag {
            descs.append("Hat Color Label")
        }
        
        // Quick Collection
        if let inQuick = c.isInQuickCollection {
            descs.append(inQuick ? "In Quick Collection" : "Nicht in Quick Collection")
        }
        
        // Adjustments
        if let hasAdj = c.hasAdjustments {
            descs.append(hasAdj ? "Mit Adjustments" : "Ohne Adjustments")
        }
        
        // Crop
        if let hasCrop = c.hasCrop {
            descs.append(hasCrop ? "Mit Zuschnitt" : "Ohne Zuschnitt")
        }
        
        // EXIF-Kriterien
        if let make = c.cameraMake, !make.isEmpty {
            descs.append("Kamera: \(make)")
        }
        if let model = c.cameraModel, !model.isEmpty {
            descs.append("Modell: \(model)")
        }
        if let lens = c.lensModel, !lens.isEmpty {
            descs.append("Objektiv: \(lens)")
        }
        if let minFL = c.minFocalLengthMM, let maxFL = c.maxFocalLengthMM {
            descs.append("Brennweite: \(Int(minFL))-\(Int(maxFL))mm")
        } else if let minFL = c.minFocalLengthMM {
            descs.append("Brennweite: ≥ \(Int(minFL))mm")
        } else if let maxFL = c.maxFocalLengthMM {
            descs.append("Brennweite: ≤ \(Int(maxFL))mm")
        }
        if let minISO = c.minISO, let maxISO = c.maxISO {
            descs.append("ISO: \(minISO)-\(maxISO)")
        } else if let minISO = c.minISO {
            descs.append("ISO: ≥ \(minISO)")
        } else if let maxISO = c.maxISO {
            descs.append("ISO: ≤ \(maxISO)")
        }
        if let minAperture = c.minAperture, let maxAperture = c.maxAperture {
            descs.append("Blende: f/\(String(format: "%.1f", minAperture))-f/\(String(format: "%.1f", maxAperture))")
        } else if let minAperture = c.minAperture {
            descs.append("Blende: ≥ f/\(String(format: "%.1f", minAperture))")
        } else if let maxAperture = c.maxAperture {
            descs.append("Blende: ≤ f/\(String(format: "%.1f", maxAperture))")
        }
        if let minShutter = c.minShutterSpeed, let maxShutter = c.maxShutterSpeed {
            descs.append("Verschlusszeit: \(formatShutterSpeed(minShutter))-\(formatShutterSpeed(maxShutter))")
        } else if let minShutter = c.minShutterSpeed {
            descs.append("Verschlusszeit: ≥ \(formatShutterSpeed(minShutter))")
        } else if let maxShutter = c.maxShutterSpeed {
            descs.append("Verschlusszeit: ≤ \(formatShutterSpeed(maxShutter))")
        }
        
        return descs
    }
    
    private func formatShutterSpeed(_ seconds: Double) -> String {
        if seconds >= 1.0 {
            return String(format: "%.1f", seconds) + "s"
        } else {
            let fraction = 1.0 / seconds
            return "1/\(Int(fraction))s"
        }
    }
}

struct SmartCollectionEditorView: View {
    @State var collection: SmartCollection
    let onSave: (SmartCollection) -> Void
    let onCancel: () -> Void
    
    @State private var minRating: Int = 0
    @State private var maxRating: Int = 0
    @State private var hasMinRating: Bool = false
    @State private var hasMaxRating: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            // Header
            HStack {
                Text("Smart Collection bearbeiten")
                    .font(DesignSystem.Fonts.semibold(size: 18))
                    .foregroundColor(DesignSystem.Colors.text)
                
                Spacer()
            }
            .padding(DesignSystem.Spacing.large)
            .background(DesignSystem.Colors.background2)
            
            Divider()
            
            // Scrollable Content
            ScrollView {
                VStack(alignment: .leading, spacing: DesignSystem.Spacing.large) {
                    // Name
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Name")
                            .font(DesignSystem.Fonts.semibold(size: 12))
                            .foregroundColor(DesignSystem.Colors.text)
                        
                        TextField("Name", text: $collection.name)
                            .textFieldStyle(.roundedBorder)
                    }
                    .padding(.horizontal, DesignSystem.Spacing.large)
                    .padding(.top, DesignSystem.Spacing.large)
                    
                    GroupBox("Filter-Kriterien") {
                        VStack(alignment: .leading, spacing: DesignSystem.Spacing.small) {
                    // Rating
                    HStack {
                        Toggle("Min Rating", isOn: $hasMinRating)
                        if hasMinRating {
                            Picker("", selection: $minRating) {
                                ForEach(1...5, id: \.self) { rating in
                                    Text("\(rating)").tag(rating)
                                }
                            }
                            .frame(width: 60)
                        }
                    }
                    
                    HStack {
                        Toggle("Max Rating", isOn: $hasMaxRating)
                        if hasMaxRating {
                            Picker("", selection: $maxRating) {
                                ForEach(1...5, id: \.self) { rating in
                                    Text("\(rating)").tag(rating)
                                }
                            }
                            .frame(width: 60)
                        }
                    }
                    
                    // Pick Status
                    Picker("Pick Status", selection: Binding(
                        get: { collection.criteria.pickStatus },
                        set: { collection.criteria.pickStatus = $0 }
                    )) {
                        Text("Kein Filter").tag(Optional<PickStatus>(nil))
                        Text("Pick").tag(Optional<PickStatus>(.pick))
                        Text("Reject").tag(Optional<PickStatus>(.reject))
                        Text("Unflagged").tag(Optional<PickStatus>(.unflagged))
                    }
                    
                    // Color Tags
                    Toggle("Hat Color Label", isOn: Binding(
                        get: { collection.criteria.hasColorTag },
                        set: { collection.criteria.hasColorTag = $0 }
                    ))
                    
                    // Quick Collection
                    Picker("Quick Collection", selection: Binding(
                        get: { collection.criteria.isInQuickCollection },
                        set: { collection.criteria.isInQuickCollection = $0 }
                    )) {
                        Text("Kein Filter").tag(Optional<Bool>(nil))
                        Text("In Quick Collection").tag(Optional<Bool>(true))
                        Text("Nicht in Quick Collection").tag(Optional<Bool>(false))
                    }
                    
                    // Adjustments
                    Picker("Adjustments", selection: Binding(
                        get: { collection.criteria.hasAdjustments },
                        set: { collection.criteria.hasAdjustments = $0 }
                    )) {
                        Text("Kein Filter").tag(Optional<Bool>(nil))
                        Text("Mit Adjustments").tag(Optional<Bool>(true))
                        Text("Ohne Adjustments").tag(Optional<Bool>(false))
                    }
                    
                    // Crop
                    Picker("Zuschnitt", selection: Binding(
                        get: { collection.criteria.hasCrop },
                        set: { collection.criteria.hasCrop = $0 }
                    )) {
                        Text("Kein Filter").tag(Optional<Bool>(nil))
                        Text("Mit Zuschnitt").tag(Optional<Bool>(true))
                        Text("Ohne Zuschnitt").tag(Optional<Bool>(false))
                    }
                    
                    Divider()
                        .padding(.vertical, 8)
                    
                    // EXIF-basierte Filter
                    Text("EXIF-Kriterien")
                        .font(DesignSystem.Fonts.semibold(size: 11))
                        .foregroundColor(DesignSystem.Colors.text)
                        .padding(.top, 4)
                    
                    // Camera Make
                    HStack {
                        Text("Kamera-Hersteller:")
                            .frame(width: 140, alignment: .leading)
                        TextField("z.B. Canon, Nikon", text: Binding(
                            get: { collection.criteria.cameraMake ?? "" },
                            set: { collection.criteria.cameraMake = $0.isEmpty ? nil : $0 }
                        ))
                        .textFieldStyle(.roundedBorder)
                    }
                    
                    // Camera Model
                    HStack {
                        Text("Kamera-Modell:")
                            .frame(width: 140, alignment: .leading)
                        TextField("z.B. EOS R5, D850", text: Binding(
                            get: { collection.criteria.cameraModel ?? "" },
                            set: { collection.criteria.cameraModel = $0.isEmpty ? nil : $0 }
                        ))
                        .textFieldStyle(.roundedBorder)
                    }
                    
                    // Lens Model
                    HStack {
                        Text("Objektiv:")
                            .frame(width: 140, alignment: .leading)
                        TextField("z.B. 24-70mm", text: Binding(
                            get: { collection.criteria.lensModel ?? "" },
                            set: { collection.criteria.lensModel = $0.isEmpty ? nil : $0 }
                        ))
                        .textFieldStyle(.roundedBorder)
                    }
                    
                    // Focal Length Range
                    HStack {
                        Text("Brennweite:")
                            .frame(width: 140, alignment: .leading)
                        HStack(spacing: 8) {
                            TextField("Min (mm)", value: Binding(
                                get: { collection.criteria.minFocalLengthMM },
                                set: { collection.criteria.minFocalLengthMM = $0 }
                            ), format: .number.precision(.fractionLength(0)))
                            .textFieldStyle(.roundedBorder)
                            .frame(width: 80)
                            
                            Text("–")
                                .foregroundColor(DesignSystem.Colors.text2)
                            
                            TextField("Max (mm)", value: Binding(
                                get: { collection.criteria.maxFocalLengthMM },
                                set: { collection.criteria.maxFocalLengthMM = $0 }
                            ), format: .number.precision(.fractionLength(0)))
                            .textFieldStyle(.roundedBorder)
                            .frame(width: 80)
                        }
                    }
                    
                    // ISO Range
                    HStack {
                        Text("ISO:")
                            .frame(width: 140, alignment: .leading)
                        HStack(spacing: 8) {
                            TextField("Min", value: Binding(
                                get: { collection.criteria.minISO },
                                set: { collection.criteria.minISO = $0 }
                            ), format: .number)
                            .textFieldStyle(.roundedBorder)
                            .frame(width: 80)
                            
                            Text("–")
                                .foregroundColor(DesignSystem.Colors.text2)
                            
                            TextField("Max", value: Binding(
                                get: { collection.criteria.maxISO },
                                set: { collection.criteria.maxISO = $0 }
                            ), format: .number)
                            .textFieldStyle(.roundedBorder)
                            .frame(width: 80)
                        }
                    }
                    
                    // Aperture Range
                    HStack {
                        Text("Blende:")
                            .frame(width: 140, alignment: .leading)
                        HStack(spacing: 8) {
                            TextField("Min (f/)", value: Binding(
                                get: { collection.criteria.minAperture },
                                set: { collection.criteria.minAperture = $0 }
                            ), format: .number.precision(.fractionLength(1)))
                            .textFieldStyle(.roundedBorder)
                            .frame(width: 80)
                            
                            Text("–")
                                .foregroundColor(DesignSystem.Colors.text2)
                            
                            TextField("Max (f/)", value: Binding(
                                get: { collection.criteria.maxAperture },
                                set: { collection.criteria.maxAperture = $0 }
                            ), format: .number.precision(.fractionLength(1)))
                            .textFieldStyle(.roundedBorder)
                            .frame(width: 80)
                        }
                    }
                    
                    // Shutter Speed Range
                    HStack {
                        Text("Verschlusszeit:")
                            .frame(width: 140, alignment: .leading)
                        HStack(spacing: 8) {
                            TextField("Min (s)", value: Binding(
                                get: { collection.criteria.minShutterSpeed },
                                set: { collection.criteria.minShutterSpeed = $0 }
                            ), format: .number.precision(.fractionLength(3)))
                            .textFieldStyle(.roundedBorder)
                            .frame(width: 80)
                            
                            Text("–")
                                .foregroundColor(DesignSystem.Colors.text2)
                            
                            TextField("Max (s)", value: Binding(
                                get: { collection.criteria.maxShutterSpeed },
                                set: { collection.criteria.maxShutterSpeed = $0 }
                            ), format: .number.precision(.fractionLength(3)))
                            .textFieldStyle(.roundedBorder)
                            .frame(width: 80)
                        }
                    }
                        }
                    }
                    .padding(.horizontal, DesignSystem.Spacing.large)
                }
            }
            
            Divider()
            
            // Footer with buttons
            HStack {
                Button("Abbrechen", action: onCancel)
                    .buttonStyle(LightroomSecondaryButtonStyle())
                    .keyboardShortcut(.cancelAction)
                
                Spacer()
                
                Button("Speichern") {
                    var updated = collection
                    updated.criteria.minRating = hasMinRating ? minRating : nil
                    updated.criteria.maxRating = hasMaxRating ? maxRating : nil
                    onSave(updated)
                }
                .buttonStyle(.borderedProminent)
                .keyboardShortcut(.defaultAction)
            }
            .padding(DesignSystem.Spacing.large)
            .background(DesignSystem.Colors.background2)
        }
        .frame(idealWidth: 800, idealHeight: 700)
        .frame(minWidth: 700, minHeight: 600)
        .background(DesignSystem.Colors.background)
        .lightroomSidebarTheme()
        .onAppear {
            if let min = collection.criteria.minRating {
                hasMinRating = true
                minRating = min
            }
            if let max = collection.criteria.maxRating {
                hasMaxRating = true
                maxRating = max
            }
        }
    }
}

