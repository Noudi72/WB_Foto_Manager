//
//  CropView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit
import CoreImage
import Combine

struct CropView: View {
    let photo: PhotoItem
    @ObservedObject var store: PhotoStore
    @State private var cropRect: CGRect
    @State private var selectedAspectRatio: CropAspectRatio
    @State private var imageSize: CGSize = .zero
    @State private var displayImage: NSImage?
    @State private var imageScale: CGFloat = 1.0
    @State private var imageOffset: CGSize = .zero
    @Environment(\.dismiss) private var dismiss
    @FocusState private var isCanvasFocused: Bool
    @State private var showGrid: Bool = true
    
    // Crop-Handles
    @State private var isDragging: Bool = false
    @State private var dragHandle: CropHandle?
    @State private var dragStartPoint: CGPoint = .zero
    @State private var dragStartCropRect: CGRect = .zero
    
    enum CropHandle {
        case topLeft, topRight, bottomLeft, bottomRight
    }
    
    init(photo: PhotoItem, store: PhotoStore) {
        self.photo = photo
        self.store = store
        // Initialisiere mit bestehendem Crop oder Standard
        if let existingCrop = photo.cropRect {
            _cropRect = State(initialValue: existingCrop)
        } else {
            // Wird in onAppear mit tatsächlicher Bildgröße initialisiert
            _cropRect = State(initialValue: CGRect(x: 0, y: 0, width: 1000, height: 1000))
        }
        _selectedAspectRatio = State(initialValue: CropAspectRatio.commonRatios.first!)
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // Toolbar
            HStack {
                // Aspect Ratio Picker
                Picker("Seitenverhältnis", selection: $selectedAspectRatio) {
                    ForEach(CropAspectRatio.commonRatios) { ratio in
                        Text(ratio.displayLabel)
                            .tag(ratio)
                            .help(ratio.socialHint ?? "")
                    }
                }
                .pickerStyle(.menu)
                .frame(width: 150)
                .onChange(of: selectedAspectRatio) { _, _ in applyAspectRatio() }
                
                Button(action: { showGrid.toggle() }) {
                    Image(systemName: showGrid ? "square.grid.3x3.fill" : "square.grid.3x3")
                }
                .buttonStyle(.borderless)
                .help("Raster (Drittel-Regel) ein/aus")
                
                Spacer()
                
                // Rotation
                HStack {
                    Button(action: { rotate(-90) }) {
                        Image(systemName: "rotate.left")
                    }
                    .help("90° links drehen")
                    
                    Text("\(Int(photo.rotation))°")
                        .frame(width: 50)
                    
                    Button(action: { rotate(90) }) {
                        Image(systemName: "rotate.right")
                    }
                    .help("90° rechts drehen")
                }
                
                Spacer()
                
                Button("Reset") {
                    resetCrop()
                }
                
                Button("Abbrechen") {
                    dismiss()
                }
                
                Button("Anwenden") {
                    applyCrop()
                }
                .buttonStyle(.borderedProminent)
            }
            .padding()
            .background(DesignSystem.Colors.background2)
            
            // Crop Canvas
            GeometryReader { geometry in
                ZStack {
                    // Hintergrund
                    Color.black
                    
                    // Bild
                    if let img = displayImage {
                        Image(nsImage: img)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .scaleEffect(imageScale)
                            .offset(imageOffset)
                            .gesture(
                                MagnificationGesture()
                                    .onChanged { value in
                                        imageScale = value
                                    }
                            )
                            .gesture(
                                DragGesture()
                                    .onChanged { value in
                                        if dragHandle == nil {
                                            imageOffset = value.translation
                                        }
                                    }
                            )
                    } else {
                        ProgressView()
                    }
                    
                    // Crop Overlay
                    // Erst rendern, wenn wir die echte Bildgröße kennen – sonst gibt es NaN/∞ Frames
                    // (Division durch 0 in displayScale) und Xcode warnt: "Invalid frame dimension".
                    if imageSize.width > 0, imageSize.height > 0 {
                        CropOverlay(
                            cropRect: $cropRect,
                            imageSize: imageSize,
                            containerSize: geometry.size,
                            isDragging: $isDragging,
                            dragHandle: $dragHandle,
                            dragStartPoint: $dragStartPoint,
                            dragStartCropRect: $dragStartCropRect,
                            aspectRatio: selectedAspectRatio.ratio,
                            showGrid: showGrid
                        )
                    }
                }
                .contentShape(Rectangle())
                .focusable()
                .focused($isCanvasFocused)
                .onTapGesture { isCanvasFocused = true }
                .onAppear { DispatchQueue.main.async { isCanvasFocused = true } }
                // Pfeiltasten: Crop-Rahmen fein verschieben (⇧ = größere Schritte)
                .onKeyPress(.leftArrow) {
                    let shift = (NSApp.currentEvent?.modifierFlags.contains(.shift) == true)
                    nudgeCrop(dx: -1, dy: 0, shift: shift)
                    return .handled
                }
                .onKeyPress(.rightArrow) {
                    let shift = (NSApp.currentEvent?.modifierFlags.contains(.shift) == true)
                    nudgeCrop(dx: 1, dy: 0, shift: shift)
                    return .handled
                }
                .onKeyPress(.upArrow) {
                    let shift = (NSApp.currentEvent?.modifierFlags.contains(.shift) == true)
                    nudgeCrop(dx: 0, dy: -1, shift: shift)
                    return .handled
                }
                .onKeyPress(.downArrow) {
                    let shift = (NSApp.currentEvent?.modifierFlags.contains(.shift) == true)
                    nudgeCrop(dx: 0, dy: 1, shift: shift)
                    return .handled
                }
            }
        }
        .frame(width: 1000, height: 700)
        .onAppear {
            loadImage()
        }
    }
    
    private func nudgeCrop(dx: CGFloat, dy: CGFloat, shift: Bool) {
        guard imageSize.width > 0, imageSize.height > 0 else { return }
        let step: CGFloat = shift ? 10 : 1
        
        cropRect.origin.x += dx * step
        cropRect.origin.y += dy * step
        
        constrainCropToImage()
    }
    
    private func loadImage() {
        Task { @MainActor in
            let originalImage: CIImage
            if let cached = photo.loadFullImage() {
                originalImage = cached
            } else if let loaded = await photo.loadFullImageAsync() {
                originalImage = loaded
            } else {
                return
            }
            
            // Wende bestehende Adjustments an
            let editEngine = EditEngine.shared
            var processed = originalImage
            
            if photo.adjustments.hasAdjustments {
                if let adjusted = editEngine.applyAdjustments(to: processed, adjustments: photo.adjustments) {
                    processed = adjusted
                }
            }
            
            // Rendere zu NSImage
            let extent = processed.extent
            imageSize = extent.size
            
            // Initialisiere cropRect (UI-Koordinaten: Ursprung oben-links)
            if let existingCIcrop = photo.cropRect {
                cropRect = convertFromCICropRect(existingCIcrop, imageSize: imageSize)
                constrainCropToImage()
            } else {
                cropRect = CGRect(origin: .zero, size: imageSize)
            }
            
            self.displayImage = editEngine.render(processed)
        }
    }
    
    private func applyAspectRatio() {
        guard let ratio = selectedAspectRatio.ratio else {
            return // Frei - keine Einschränkung
        }
        
        let currentWidth = cropRect.width
        let currentHeight = cropRect.height
        let currentCenter = CGPoint(
            x: cropRect.midX,
            y: cropRect.midY
        )
        
        // Berechne neue Größe basierend auf Seitenverhältnis
        var newWidth = currentWidth
        var newHeight = currentWidth / ratio
        
        // Wenn Höhe größer wird, passe Breite an
        if newHeight > currentHeight {
            newHeight = currentHeight
            newWidth = currentHeight * ratio
        }
        
        // Setze neue Crop-Rect mit gleichem Zentrum
        cropRect = CGRect(
            x: currentCenter.x - newWidth / 2,
            y: currentCenter.y - newHeight / 2,
            width: newWidth,
            height: newHeight
        )
        
        // Stelle sicher, dass Crop innerhalb Bildgrenzen bleibt
        constrainCropToImage()
    }
    
    private func constrainCropToImage() {
        let minX: CGFloat = 0
        let minY: CGFloat = 0
        let maxX = imageSize.width
        let maxY = imageSize.height
        
        var newRect = cropRect
        
        // Begrenze auf Bildgrenzen
        if newRect.minX < minX {
            newRect.origin.x = minX
        }
        if newRect.minY < minY {
            newRect.origin.y = minY
        }
        if newRect.maxX > maxX {
            newRect.origin.x = maxX - newRect.width
        }
        if newRect.maxY > maxY {
            newRect.origin.y = maxY - newRect.height
        }
        
        // Stelle sicher, dass Mindestgröße eingehalten wird
        if newRect.width < 50 {
            newRect.size.width = 50
        }
        if newRect.height < 50 {
            newRect.size.height = 50
        }
        
        cropRect = newRect
    }
    
    private func rotate(_ degrees: Double) {
        store.registerUndoPoint(for: photo)
        photo.rotation += degrees
        // Normalisiere auf -180 bis 180
        while photo.rotation > 180 {
            photo.rotation -= 360
        }
        while photo.rotation < -180 {
            photo.rotation += 360
        }
        
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id]
        )
    }
    
    private func resetCrop() {
        store.registerUndoPoint(for: photo)
        cropRect = CGRect(origin: .zero, size: imageSize)
        photo.rotation = 0.0
        selectedAspectRatio = CropAspectRatio.commonRatios.first!
        imageScale = 1.0
        imageOffset = .zero
        
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id]
        )
    }
    
    private func applyCrop() {
        store.registerUndoPoint(for: photo)
        // Speichere im CI-Koordinatensystem (Ursprung unten-links)
        let ciCropRect = convertToCICropRect(cropRect, imageSize: imageSize)
        photo.cropRect = ciCropRect
        
        // Trigger Re-Render im DetailView (PhotoItem wird nicht direkt observed)
        photo.objectWillChange.send()
        store.objectWillChange.send()
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id]
        )
        dismiss()
    }
    
    private func convertToCICropRect(_ viewRect: CGRect, imageSize: CGSize) -> CGRect {
        // viewRect: y=0 ist oben
        // CI rect: y=0 ist unten
        let ciY = imageSize.height - viewRect.origin.y - viewRect.height
        return CGRect(x: viewRect.origin.x, y: ciY, width: viewRect.width, height: viewRect.height)
    }
    
    private func convertFromCICropRect(_ ciRect: CGRect, imageSize: CGSize) -> CGRect {
        // Invertiere Y wieder zurück für UI
        let viewY = imageSize.height - ciRect.origin.y - ciRect.height
        return CGRect(x: ciRect.origin.x, y: viewY, width: ciRect.width, height: ciRect.height)
    }
}

struct CropOverlay: View {
    @Binding var cropRect: CGRect
    let imageSize: CGSize
    let containerSize: CGSize
    @Binding var isDragging: Bool
    @Binding var dragHandle: CropView.CropHandle?
    @Binding var dragStartPoint: CGPoint
    @Binding var dragStartCropRect: CGRect
    let aspectRatio: Double?
    let showGrid: Bool
    
    // Move whole crop rect (pack & verschieben)
    @State private var isMovingRect: Bool = false
    @State private var moveStartRect: CGRect = .zero
    @State private var didPushClosedHandCursor: Bool = false
    
    // Berechne Skalierung und Offset für die Anzeige
    private var displayScale: CGFloat {
        // Wichtig: Vor dem ersten Bild-Load ist imageSize == .zero → Division durch 0 → ∞/NaN
        guard imageSize.width > 0,
              imageSize.height > 0,
              containerSize.width > 0,
              containerSize.height > 0 else {
            return 1
        }
        let imageAspect = imageSize.width / imageSize.height
        let containerAspect = containerSize.width / containerSize.height
        
        let scale: CGFloat
        if imageAspect > containerAspect {
            scale = containerSize.width / imageSize.width
        } else {
            scale = containerSize.height / imageSize.height
        }
        return scale
    }
    
    private var displayOffset: CGSize {
        guard displayScale.isFinite else { return .zero }
        let scaledSize = CGSize(
            width: imageSize.width * displayScale,
            height: imageSize.height * displayScale
        )
        return CGSize(
            width: (containerSize.width - scaledSize.width) / 2,
            height: (containerSize.height - scaledSize.height) / 2
        )
    }
    
    private var displayCropRect: CGRect {
        // Safety: niemals negative oder non-finite Größen an SwiftUI-Frames geben.
        let rect = cropRect.standardized
        let scale = displayScale
        guard scale.isFinite, scale > 0 else { return .zero }
        
        let x = rect.origin.x * scale + displayOffset.width
        let y = rect.origin.y * scale + displayOffset.height
        let w = rect.width * scale
        let h = rect.height * scale
        
        guard x.isFinite, y.isFinite, w.isFinite, h.isFinite else { return .zero }
        // Achtung: SwiftUI warnt bei negativen oder non-finite Frame-Dimensionen.
        // Wir normalisieren deshalb hart auf >= 0.
        return CGRect(
            x: x,
            y: y,
            width: (w > 0) ? w : 0,
            height: (h > 0) ? h : 0
        )
    }
    
    private func safeDim(_ value: CGFloat) -> CGFloat {
        guard value.isFinite, value > 0 else { return 0 }
        return value
    }
    
    private func safeCoord(_ value: CGFloat) -> CGFloat {
        guard value.isFinite else { return 0 }
        return value
    }
    
    var body: some View {
        let rect = displayCropRect
        let w = safeDim(rect.width)
        let h = safeDim(rect.height)
        let midX = safeCoord(rect.midX)
        let midY = safeCoord(rect.midY)
        let minX = safeCoord(rect.minX)
        let minY = safeCoord(rect.minY)
        let maxX = safeCoord(rect.maxX)
        let maxY = safeCoord(rect.maxY)
        
        // Falls Layout/Size (z.B. bei Image-Load) noch nicht stabil ist, nichts zeichnen.
        if w == 0 || h == 0 {
            EmptyView()
        } else {
        ZStack {
            // Dunkler Overlay außerhalb des Crop-Bereichs
            Rectangle()
                .fill(Color.black.opacity(0.5))
                .mask(
                    GeometryReader { geometry in
                        ZStack {
                            Rectangle()
                            Rectangle()
                                .frame(
                                    width: w,
                                    height: h
                                )
                                .position(
                                    x: midX,
                                    y: midY
                                )
                                .blendMode(.destinationOut)
                        }
                    }
                )
                .allowsHitTesting(false)
            
            // Crop-Rahmen
            Rectangle()
                .stroke(Color.white, lineWidth: 2)
                .frame(
                    width: w,
                    height: h
                )
                .position(
                    x: midX,
                    y: midY
                )
                .allowsHitTesting(false)
            
            // Drittel-Raster (Rule of Thirds)
            if showGrid {
                Path { path in
                    let x1 = minX + w / 3
                    let x2 = minX + (w * 2 / 3)
                    let y1 = minY + h / 3
                    let y2 = minY + (h * 2 / 3)
                    
                    path.move(to: CGPoint(x: x1, y: minY))
                    path.addLine(to: CGPoint(x: x1, y: maxY))
                    path.move(to: CGPoint(x: x2, y: minY))
                    path.addLine(to: CGPoint(x: x2, y: maxY))
                    
                    path.move(to: CGPoint(x: minX, y: y1))
                    path.addLine(to: CGPoint(x: maxX, y: y1))
                    path.move(to: CGPoint(x: minX, y: y2))
                    path.addLine(to: CGPoint(x: maxX, y: y2))
                }
                .stroke(
                    Color.white.opacity(0.28),
                    style: StrokeStyle(lineWidth: 1, dash: [4, 4], dashPhase: 0)
                )
                .allowsHitTesting(false)
            }
            
            // Crop-Fenster verschieben (Drag innerhalb des Rahmens)
            Rectangle()
                .fill(Color.clear)
                .frame(width: w, height: h)
                .position(x: midX, y: midY)
                .contentShape(Rectangle())
                .cursor(.openHand)
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { value in
                            let scale = displayScale
                            guard scale.isFinite, scale > 0 else { return }
                            if !isMovingRect {
                                isMovingRect = true
                                moveStartRect = cropRect
                                if !didPushClosedHandCursor {
                                    didPushClosedHandCursor = true
                                    NSCursor.closedHand.push()
                                }
                            }
                            
                            // value.translation ist in Display-Koordinaten → zurück in Image-Koordinaten
                            let dx = value.translation.width / scale
                            let dy = value.translation.height / scale
                            
                            var newRect = moveStartRect
                            newRect.origin.x += dx
                            newRect.origin.y += dy
                            
                            // Begrenze auf Bildgrenzen (Größe bleibt unverändert)
                            newRect.origin.x = max(0, min(newRect.origin.x, imageSize.width - newRect.width))
                            newRect.origin.y = max(0, min(newRect.origin.y, imageSize.height - newRect.height))
                            
                            cropRect = newRect
                        }
                        .onEnded { _ in
                            isMovingRect = false
                            if didPushClosedHandCursor {
                                NSCursor.pop()
                                didPushClosedHandCursor = false
                            }
                        }
                )
                .onDisappear {
                    // Safety: Cursor-Stack nicht "leaken", falls View während Drag verschwindet.
                    if didPushClosedHandCursor {
                        NSCursor.pop()
                        didPushClosedHandCursor = false
                    }
                }
            
            // Handles an den Ecken
            CropHandleView(
                position: .topLeft,
                cropRect: rect,
                onDrag: { delta in
                    handleDrag(handle: .topLeft, delta: delta)
                }
            )
            
            CropHandleView(
                position: .topRight,
                cropRect: rect,
                onDrag: { delta in
                    handleDrag(handle: .topRight, delta: delta)
                }
            )
            
            CropHandleView(
                position: .bottomLeft,
                cropRect: rect,
                onDrag: { delta in
                    handleDrag(handle: .bottomLeft, delta: delta)
                }
            )
            
            CropHandleView(
                position: .bottomRight,
                cropRect: rect,
                onDrag: { delta in
                    handleDrag(handle: .bottomRight, delta: delta)
                }
            )
        }
        }
    }
    
    private func handleDrag(handle: CropView.CropHandle, delta: CGSize) {
        let scale = displayScale
        guard scale.isFinite, scale > 0 else { return }
        var newRect = cropRect
        let scaleDelta = CGSize(
            width: delta.width / scale,
            height: delta.height / scale
        )
        
        switch handle {
        case .topLeft:
            newRect.origin.x += scaleDelta.width
            newRect.origin.y += scaleDelta.height
            newRect.size.width -= scaleDelta.width
            newRect.size.height -= scaleDelta.height
            
        case .topRight:
            newRect.origin.y += scaleDelta.height
            newRect.size.width += scaleDelta.width
            newRect.size.height -= scaleDelta.height
            
        case .bottomLeft:
            newRect.origin.x += scaleDelta.width
            newRect.size.width -= scaleDelta.width
            newRect.size.height += scaleDelta.height
            
        case .bottomRight:
            newRect.size.width += scaleDelta.width
            newRect.size.height += scaleDelta.height
        }
        
        // Wende Seitenverhältnis an wenn gesetzt
        if let ratio = aspectRatio {
            let currentRatio = newRect.width / newRect.height
            if abs(currentRatio - ratio) > 0.01 {
                // Passe an Seitenverhältnis an
                let center = CGPoint(x: newRect.midX, y: newRect.midY)
                let newWidth = newRect.height * ratio
                newRect = CGRect(
                    x: center.x - newWidth / 2,
                    y: newRect.origin.y,
                    width: newWidth,
                    height: newRect.height
                )
            }
        }
        
        // Begrenze auf Bildgrenzen
        newRect.origin.x = max(0, min(newRect.origin.x, imageSize.width - newRect.width))
        newRect.origin.y = max(0, min(newRect.origin.y, imageSize.height - newRect.height))
        newRect.size.width = min(newRect.size.width, imageSize.width - newRect.origin.x)
        newRect.size.height = min(newRect.size.height, imageSize.height - newRect.origin.y)
        
        // Mindestgröße
        if newRect.width >= 50 && newRect.height >= 50 {
            cropRect = newRect
        }
    }
}

struct CropHandleView: View {
    let position: CropView.CropHandle
    let cropRect: CGRect
    let onDrag: (CGSize) -> Void
    
    @State private var isDragging = false
    @State private var dragStart: CGPoint = .zero
    @State private var lastTranslation: CGSize = .zero
    
    private var handlePosition: CGPoint {
        switch position {
        case .topLeft:
            return CGPoint(x: cropRect.minX, y: cropRect.minY)
        case .topRight:
            return CGPoint(x: cropRect.maxX, y: cropRect.minY)
        case .bottomLeft:
            return CGPoint(x: cropRect.minX, y: cropRect.maxY)
        case .bottomRight:
            return CGPoint(x: cropRect.maxX, y: cropRect.maxY)
        }
    }
    
    var body: some View {
        Circle()
            .fill(Color.white)
            .frame(width: 20, height: 20)
            .overlay(
                Circle()
                    .stroke(Color.accentColor, lineWidth: 2)
            )
            .position(handlePosition)
            .onHover { hovering in
                if hovering {
                    NSCursor.crosshair.push()
                } else {
                    NSCursor.pop()
                }
            }
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        if !isDragging {
                            isDragging = true
                            dragStart = value.location
                            lastTranslation = .zero
                        }
                        // Wichtig: value.translation ist seit Drag-Start kumulativ.
                        // Für sauberes, kontrollierbares Ziehen brauchen wir *inkrementelle* Deltas.
                        let incremental = CGSize(
                            width: value.translation.width - lastTranslation.width,
                            height: value.translation.height - lastTranslation.height
                        )
                        lastTranslation = value.translation
                        onDrag(incremental)
                    }
                    .onEnded { _ in
                        isDragging = false
                        lastTranslation = .zero
                    }
            )
    }
}

extension View {
    func cursor(_ cursor: NSCursor) -> some View {
        self.onHover { inside in
            if inside {
                cursor.push()
            } else {
                NSCursor.pop()
            }
        }
    }
}
