//
//  BatchExportView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit
import UniformTypeIdentifiers

struct BatchExportView: View {
    @ObservedObject var store: PhotoStore
    @State private var selectedPreset: ExportPreset?
    @State private var selectedOutputDirectory: URL?
    @State private var isExporting = false
    @State private var exportProgress: Double = 0.0
    @State private var currentPhotoIndex: Int = 0
    @State private var totalPhotos: Int = 0
    @State private var currentPhotoName: String = ""
    @State private var previewImage: NSImage?
    @State private var isGeneratingPreview = false
    @Environment(\.dismiss) private var dismiss
    
    var photosToExport: [PhotoItem] {
        if store.selectedPhotoIDs.isEmpty {
            return store.filteredPhotos
        } else {
            return store.photos.filter { store.selectedPhotoIDs.contains($0.id) }
        }
    }
    
    // Effektives Preset: Entweder das ausgewählte oder ein Standard-"Original"-Preset (kein Watermark, beste Qualität)
    private var effectivePreset: ExportPreset {
        if let preset = selectedPreset {
            return preset
        } else {
            // Original-Export: Keine Größenänderung, Original-Qualität, kein Wasserzeichen
            return ExportPreset(
                name: "Keine (Original)",
                maxDimension: 99999, // Sehr groß, damit keine Größenänderung
                quality: 1.0, // Beste Qualität
                format: .jpeg,
                watermarkSettings: nil,
                uploadTargets: []
            )
        }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Batch Export")
                .font(.headline)
            
            // Preset Selection
            Picker("Preset", selection: $selectedPreset) {
                Text("Kein Preset").tag(ExportPreset?.none)
                ForEach(store.exportPresets) { preset in
                    Text(preset.name).tag(ExportPreset?.some(preset))
                }
            }
            .pickerStyle(.menu)
            .disabled(isExporting)
            .onChange(of: selectedPreset) { _, _ in
                generatePreview()
            }
            
            // Zeige immer Export-Details (auch wenn kein Preset ausgewählt)
            VStack(alignment: .leading, spacing: 8) {
                Text("Dimension: \(effectivePreset.maxDimension == 99999 ? "Original" : "\(effectivePreset.maxDimension)px")")
                Text("Qualität: \(Int(effectivePreset.quality * 100))%")
                Text("Format: \(effectivePreset.format.rawValue)")
                Text("Wasserzeichen: \(effectivePreset.watermarkSettings != nil ? "Ja" : "Nein")")
                Text("Fotos: \(photosToExport.count)")
            }
            .font(.caption)
            .foregroundColor(.secondary)
            
            Divider()
            
            // Export-Vorschau (erste Foto der Auswahl)
            if let firstPhoto = photosToExport.first {
                VStack(alignment: .leading, spacing: 8) {
                    Text("Vorschau (erstes Foto)")
                        .font(.subheadline)
                        .fontWeight(.semibold)
                    
                    if isGeneratingPreview {
                        HStack {
                            ProgressView()
                                .controlSize(.small)
                            Text("Vorschau wird generiert...")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        .frame(height: 200)
                    } else if let preview = previewImage {
                        Image(nsImage: preview)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(maxHeight: 300)
                            .cornerRadius(4)
                            .shadow(radius: 2)
                    } else {
                        Text("Keine Vorschau verfügbar")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .frame(height: 200)
                    }
                }
                
                Divider()
            }
            
            // Export-Ordner Anzeige und Auswahl
            VStack(alignment: .leading, spacing: 8) {
                Text("Zielordner")
                    .font(.subheadline)
                    .fontWeight(.semibold)
                
                HStack {
                    if let directory = selectedOutputDirectory {
                        Text(directory.path)
                            .font(.caption)
                            .foregroundColor(.primary)
                            .lineLimit(1)
                            .truncationMode(.middle)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        Button("Ändern...") {
                            chooseOutputDirectory()
                        }
                        .disabled(isExporting)
                    } else {
                        Text("Nicht ausgewählt")
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                        
                        Button("Auswählen...") {
                            chooseOutputDirectory()
                        }
                        .disabled(isExporting)
                    }
                }
            }
            
            if isExporting {
                VStack(alignment: .leading, spacing: 8) {
                    ProgressView(value: exportProgress)
                    
                    HStack {
                        Text("\(currentPhotoIndex) von \(totalPhotos)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                        
                        Spacer()
                        
                        Text("\(Int(exportProgress * 100))%")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    if !currentPhotoName.isEmpty {
                        Text("Aktuell: \(currentPhotoName)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            }
            
            HStack {
                Button("Abbrechen") {
                    if isExporting {
                        // Cancel export
                        isExporting = false
                    } else {
                        dismiss()
                    }
                }
                
                Spacer()
                
                Button(isExporting ? "Abbrechen" : "Exportieren") {
                    if isExporting {
                        isExporting = false
                    } else {
                        if selectedOutputDirectory == nil {
                            chooseOutputDirectory { directory in
                                if directory != nil {
                                    export(to: directory!)
                                }
                            }
                        } else {
                            export(to: selectedOutputDirectory!)
                        }
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(isExporting || photosToExport.isEmpty)
            }
        }
        .padding()
        .frame(width: 500)
        .onAppear {
            generatePreview()
        }
        .onChange(of: photosToExport.count) { _, _ in
            generatePreview()
        }
    }
    
    private func generatePreview() {
        guard let firstPhoto = photosToExport.first else {
            previewImage = nil
            return
        }
        
        let preset = effectivePreset
        isGeneratingPreview = true
        previewImage = nil
        
        Task {
            let preview = await ExportService.shared.generatePreview(photo: firstPhoto, preset: preset)
            await MainActor.run {
                self.previewImage = preview
                self.isGeneratingPreview = false
            }
        }
    }
    
    private func chooseOutputDirectory(completion: ((URL?) -> Void)? = nil) {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.canCreateDirectories = true
        panel.prompt = "Auswählen"
        panel.message = "Wählen Sie einen Zielordner für den Export"
        
        // Setze aktuellen Ordner als Startpunkt, falls vorhanden
        if let currentDir = selectedOutputDirectory {
            panel.directoryURL = currentDir
        }
        
        panel.begin { response in
            if response == .OK, let url = panel.url {
                selectedOutputDirectory = url
                completion?(url)
            } else {
                completion?(nil)
            }
        }
    }
    
    private func export(to outputDirectory: URL) {
        let photos = photosToExport
        guard !photos.isEmpty else { return }
        
        // Verwende effektives Preset (entweder ausgewählt oder Standard-"Original")
        let preset = effectivePreset
        
        isExporting = true
        totalPhotos = photos.count
        currentPhotoIndex = 0
        exportProgress = 0.0
        
        Task {
            do {
                let stats = try await ExportService.shared.exportBatch(
                    photos: photos,
                    preset: preset,
                    outputDirectory: outputDirectory,
                    uploadTargets: store.effectiveUploadTargetsForExport
                ) { current, total in
                    DispatchQueue.main.async {
                        self.currentPhotoIndex = current
                        self.totalPhotos = total
                        self.exportProgress = Double(current) / Double(total)
                        
                        if current <= photos.count {
                            self.currentPhotoName = photos[current - 1].fileName
                        }
                    }
                }
                
                DispatchQueue.main.async {
                    self.isExporting = false
                    self.dismiss()
                    
                    // Zeige Erfolgsmeldung mit Statistiken
                    let alert = NSAlert()
                    alert.messageText = "Export abgeschlossen"
                    alert.informativeText = """
                    \(stats.photoCount) Fotos wurden erfolgreich exportiert.
                    
                    Zielordner: \(outputDirectory.path)
                    
                    Gesamtgröße: \(String(format: "%.2f", stats.totalSizeMB)) MB
                    Durchschnitt: \(String(format: "%.2f", stats.averageSizeMB)) MB pro Foto
                    Dauer: \(String(format: "%.1f", stats.durationSeconds)) Sekunden
                    Geschwindigkeit: \(String(format: "%.1f", stats.photosPerSecond)) Fotos/Sekunde
                    """
                    alert.alertStyle = .informational
                    alert.addButton(withTitle: "OK")
                    alert.runModal()
                }
            } catch {
                print("Batch export error: \(error)")
                
                // Speichere fehlgeschlagenen Export in Historie
                let failedStat = ExportStatistics.failed(
                    photoCount: photos.count,
                    errorMessage: error.localizedDescription,
                    presetName: preset.name,
                    outputDirectory: outputDirectory.path,
                    photoIDs: photos.map { $0.id },
                    presetID: preset.id
                )
                Task { @MainActor in
                    ExportStatisticsManager.shared.addStatistics(failedStat)
                }
                
                DispatchQueue.main.async {
                    self.isExporting = false
                    
                    let alert = NSAlert()
                    alert.messageText = "Export fehlgeschlagen"
                    alert.informativeText = error.localizedDescription
                    alert.alertStyle = .warning
                    alert.addButton(withTitle: "OK")
                    alert.runModal()
                }
            }
        }
    }
}

