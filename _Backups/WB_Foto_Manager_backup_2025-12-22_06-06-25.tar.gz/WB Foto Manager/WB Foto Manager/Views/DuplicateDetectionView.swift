//
//  DuplicateDetectionView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 20.12.2025.
//

import SwiftUI

struct DuplicateDetectionView: View {
    @ObservedObject var store: PhotoStore
    @Environment(\.dismiss) private var dismiss
    @StateObject private var statsManager = ExportStatisticsManager.shared
    
    @State private var isScanning = false
    @State private var progress: Double = 0.0
    @State private var currentPhotoName: String = ""
    @State private var duplicateGroups: [DuplicateGroup] = []
    @State private var similarityThreshold: Double = 0.9
    @State private var selectedGroup: DuplicateGroup?
    
    var photosToScan: [PhotoItem] {
        if store.selectedPhotoIDs.isEmpty {
            return store.photos
        } else {
            return store.photos.filter { store.selectedPhotoIDs.contains($0.id) }
        }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                Text("Duplikat-Erkennung")
                    .font(.headline)
                
                Spacer()
                
                Button("Schließen") {
                    dismiss()
                }
                .buttonStyle(LightroomSecondaryButtonStyle())
            }
            
            if isScanning {
                VStack(alignment: .leading, spacing: 8) {
                    ProgressView(value: progress)
                    Text("\(Int(progress * 100))%")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    
                    if !currentPhotoName.isEmpty {
                        Text("Aktuell: \(currentPhotoName)")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                }
            } else {
                VStack(alignment: .leading, spacing: 12) {
                    Text("\(photosToScan.count) Foto(s) werden gescannt")
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                    
                    VStack(alignment: .leading, spacing: 12) {
                        HStack {
                            Text("Ähnlichkeitsschwelle:")
                            Slider(value: $similarityThreshold, in: 0.85...1.0, step: 0.01)
                            Text("\(Int(similarityThreshold * 100))%")
                                .frame(width: 50)
                        }
                        
                        Text("Hinweis: Verwendet verbesserte dHash-Algorithmus (16x16) für präzisere Erkennung")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    
                    Button("Duplikate suchen") {
                        scanForDuplicates()
                    }
                    .buttonStyle(LightroomPrimaryButtonStyle())
                    .disabled(photosToScan.isEmpty)
                }
            }
            
            if !duplicateGroups.isEmpty {
                Divider()
                
                Text("\(duplicateGroups.count) Duplikat-Gruppe(n) gefunden")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 12) {
                        ForEach(duplicateGroups) { group in
                            DuplicateGroupCard(
                                group: group,
                                isSelected: selectedGroup?.id == group.id,
                                onSelect: { selectedGroup = group },
                                onDeleteSelected: { selectedPhotos in
                                    deleteSelectedPhotos(from: group, selectedPhotos: selectedPhotos)
                                }
                            )
                        }
                    }
                }
            }
        }
        .padding()
        .frame(width: 800, height: 600)
    }
    
    private func scanForDuplicates() {
        isScanning = true
        progress = 0.0
        duplicateGroups = []
        
        Task {
            let groups = await DuplicateDetectionService.shared.findDuplicates(
                in: photosToScan,
                similarityThreshold: similarityThreshold
            ) { current, total in
                DispatchQueue.main.async {
                    self.progress = Double(current) / Double(total)
                    if current <= photosToScan.count {
                        self.currentPhotoName = photosToScan[current - 1].fileName
                    }
                }
            }
            
            DispatchQueue.main.async {
                self.duplicateGroups = groups
                self.isScanning = false
            }
        }
    }
    
    private func deleteSelectedPhotos(from group: DuplicateGroup, selectedPhotos: Set<UUID>) {
        guard !selectedPhotos.isEmpty else { return }
        
        // Lösche ausgewählte Fotos
        for photoID in selectedPhotos {
            store.photos.removeAll { $0.id == photoID }
        }
        
        // Entferne gelöschte Fotos aus der Gruppe
        let remainingPhotos = group.photos.filter { !selectedPhotos.contains($0.id) }
        
        if remainingPhotos.count <= 1 {
            // Wenn nur noch 1 oder 0 Fotos übrig sind, entferne die Gruppe komplett
            duplicateGroups.removeAll { $0.id == group.id }
        } else {
            // Aktualisiere die Gruppe mit den verbleibenden Fotos
            // Erstelle eine neue Gruppe mit den verbleibenden Fotos
            if let index = duplicateGroups.firstIndex(where: { $0.id == group.id }) {
                // Erstelle neue Gruppe mit neuer ID, da die alte Gruppe immutable ist
                let newGroup = DuplicateGroup(photos: remainingPhotos)
                duplicateGroups[index] = newGroup
            }
        }
    }
}

private struct DuplicateGroupCard: View {
    let group: DuplicateGroup
    let isSelected: Bool
    let onSelect: () -> Void
    let onDeleteSelected: (Set<UUID>) -> Void
    
    @State private var selectedPhotoIDs: Set<UUID> = []
    
    var hasSelection: Bool {
        !selectedPhotoIDs.isEmpty
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack {
                Text("\(group.count) Duplikate")
                    .font(.headline)
                
                Spacer()
                
                if hasSelection {
                    Button("Ausgewählte löschen (\(selectedPhotoIDs.count))") {
                        onDeleteSelected(selectedPhotoIDs)
                        selectedPhotoIDs.removeAll()
                    }
                    .buttonStyle(LightroomPrimaryButtonStyle())
                } else {
                    Button("Alle außer erstem löschen") {
                        // Standard: Alle außer erstem
                        let allExceptFirst = Set(group.photos.dropFirst().map { $0.id })
                        onDeleteSelected(allExceptFirst)
                    }
                    .buttonStyle(LightroomSecondaryButtonStyle())
                }
            }
            
            HStack {
                Button(selectedPhotoIDs.count == group.photos.count ? "Alle abwählen" : "Alle auswählen") {
                    if selectedPhotoIDs.count == group.photos.count {
                        selectedPhotoIDs.removeAll()
                    } else {
                        selectedPhotoIDs = Set(group.photos.map { $0.id })
                    }
                }
                .buttonStyle(.plain)
                .font(.caption)
                .foregroundColor(DesignSystem.Colors.text2)
                
                Spacer()
                
                if hasSelection {
                    Text("\(selectedPhotoIDs.count) von \(group.count) ausgewählt")
                        .font(.caption)
                        .foregroundColor(DesignSystem.Colors.text2)
                }
            }
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    ForEach(group.photos) { photo in
                        let isPhotoSelected = selectedPhotoIDs.contains(photo.id)
                        
                        ZStack(alignment: .topTrailing) {
                            AsyncThumbnailView(photo: photo, previewSize: PreviewSize.thumbnail)
                                .frame(width: 100, height: 100)
                                .cornerRadius(4)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 4)
                                        .stroke(isPhotoSelected ? DesignSystem.Colors.accent : (isSelected ? DesignSystem.Colors.accent.opacity(0.5) : Color.clear), lineWidth: isPhotoSelected ? 3 : 2)
                                )
                                .onTapGesture {
                                    if isPhotoSelected {
                                        selectedPhotoIDs.remove(photo.id)
                                    } else {
                                        selectedPhotoIDs.insert(photo.id)
                                    }
                                }
                            
                            // Checkbox-Indikator
                            if isPhotoSelected {
                                Image(systemName: "checkmark.circle.fill")
                                    .foregroundColor(.white)
                                    .background(
                                        Circle()
                                            .fill(DesignSystem.Colors.accent)
                                    )
                                    .font(.system(size: 20, weight: .bold))
                                    .padding(4)
                            } else {
                                Image(systemName: "circle")
                                    .foregroundColor(.white)
                                    .background(
                                        Circle()
                                            .fill(Color.black.opacity(0.3))
                                    )
                                    .font(.system(size: 20))
                                    .padding(4)
                            }
                        }
                    }
                }
            }
        }
        .padding()
        .background(DesignSystem.Colors.background4)
        .cornerRadius(8)
        .overlay(
            RoundedRectangle(cornerRadius: 8)
                .stroke(isSelected ? DesignSystem.Colors.accent : DesignSystem.Colors.border, lineWidth: 1)
        )
    }
}

