//
//  FilmstripView.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit

struct FilmstripView: View {
    let photos: [PhotoItem]
    @ObservedObject var store: PhotoStore
    @EnvironmentObject var uiState: UIState
    
    // Cmd+Drag Bereichsauswahl
    @State private var dragStartPoint: CGPoint?
    @State private var dragCurrentPoint: CGPoint?
    @State private var isDraggingSelection: Bool = false
    
    var body: some View {
        GeometryReader { geo in
            // Lightroom-like: Filmstrip-Zellen nach Seitenverhältnis (9:16/16:9) – bessere Portrait-Übersicht
            let contentHeight = max(1, geo.size.height)
            let cellHeight = max(72, min(220, contentHeight - 16)) // 8px Top/Bottom Padding
            
            ScrollViewReader { proxy in
                ZStack {
                    ScrollView(.horizontal, showsIndicators: false) {
                        LazyHStack(spacing: 4) {
                            ForEach(photos) { photo in
                                FilmstripPhotoCell(
                                    photo: photo,
                                    store: store,
                                    isCurrent: store.currentPhotoID == photo.id,
                                    isMultiSelected: store.selectedPhotoIDs.contains(photo.id),
                                    showMultiSelectIndicator: uiState.selectionMode,
                                    baseWidth: cellWidth(for: photo, height: cellHeight),
                                    baseHeight: cellHeight
                                )
                                .id(photo.id)
                                .onTapGesture {
                                    // Wenn bereits ein Drag läuft, nicht reagieren
                                    if !isDraggingSelection {
                                        // Wichtig: Fokus aus TextEditor/TextField lösen, damit ⌘A danach wirklich "Fotos auswählen" triggert.
                                        // (FirstResponder-Wechsel ist in SwiftUI manchmal "sticky" → daher endEditing + async)
                                        DispatchQueue.main.async {
                                            let win = NSApp.keyWindow ?? NSApp.mainWindow
                                            win?.endEditing(for: nil)
                                            win?.makeFirstResponder(nil)
                                        }
                                        let modifiers = NSEvent.modifierFlags
                                        store.selectPhoto(photo, withModifiers: modifiers)
                                    }
                                }
                            }
                        }
                        .padding(.horizontal, 4)
                        .padding(.vertical, 8)
                    }
                    .background(DesignSystem.Colors.background4)
                    
                    // Cmd+Drag Bereichsauswahl Visualisierung
                    if isDraggingSelection, let start = dragStartPoint, let current = dragCurrentPoint {
                        DragSelectionRect(startPoint: start, currentPoint: current)
                            .allowsHitTesting(false)
                    }
                }
                .simultaneousGesture(
                    DragGesture(minimumDistance: 5)
                        .onChanged { value in
                            // Nur aktivieren wenn Cmd gedrückt ist
                            if NSEvent.modifierFlags.contains(.command) {
                                if dragStartPoint == nil {
                                    dragStartPoint = value.startLocation
                                    isDraggingSelection = true
                                    uiState.selectionMode = true
                                }
                                dragCurrentPoint = value.location
                                
                                // Fotos innerhalb des Rechtecks finden und auswählen
                                updateSelectionForDragRect(
                                    start: dragStartPoint!,
                                    current: value.location,
                                    photos: photos,
                                    cellHeight: cellHeight,
                                    padding: CGPoint(x: 4, y: 8)
                                )
                            }
                        }
                        .onEnded { _ in
                            if isDraggingSelection {
                                dragStartPoint = nil
                                dragCurrentPoint = nil
                                isDraggingSelection = false
                            }
                        }
                )
                .onChange(of: store.currentPhotoID) { _, newID in
                    if let id = newID {
                        withAnimation {
                            proxy.scrollTo(id, anchor: .center)
                        }
                        
                        // Prefetch Thumbnails rund um das aktuelle Bild (hilft bei iCloud/PhotoKit enorm)
                        if let idx = photos.firstIndex(where: { $0.id == id }) {
                            let start = max(0, idx - 14)
                            let end = min(photos.count - 1, idx + 14)
                            let urls = Array(photos[start...end]).map { $0.url }
                            SmartImageLoader.shared.prefetchThumbnails(urls: urls, count: urls.count)
                        }
                    }
                }
            }
        }
    }
    
    private func cellWidth(for photo: PhotoItem, height: CGFloat) -> CGFloat {
        let aspect = CGFloat(photo.aspectRatio)
        // Lightroom-ähnlich: Sehr schmale Portraits nicht zu winzig, sehr breite Panos nicht zu breit.
        let minW = height * 0.56   // 9:16 ≈ 0.5625
        let maxW = height * 2.2
        return max(minW, min(maxW, height * aspect))
    }
    
    // MARK: - Cmd+Drag Bereichsauswahl
    
    private func updateSelectionForDragRect(start: CGPoint, current: CGPoint, photos: [PhotoItem], cellHeight: CGFloat, padding: CGPoint) {
        // Normalisiere Rechteck (start und current können in beliebiger Reihenfolge sein)
        let minX = min(start.x, current.x)
        let maxX = max(start.x, current.x)
        let minY = min(start.y, current.y)
        let maxY = max(start.y, current.y)
        
        let dragRect = CGRect(x: minX, y: minY, width: maxX - minX, height: maxY - minY)
        var accumulatedX: CGFloat = padding.x
        var selectedIDs = Set<UUID>()
        
        // Durchlaufe alle Fotos im Filmstrip (horizontal)
        for photo in photos {
            let cellWidth = cellWidth(for: photo, height: cellHeight)
            let itemRect = CGRect(
                x: accumulatedX,
                y: padding.y,
                width: cellWidth,
                height: cellHeight
            )
            
            // Prüfe ob das Rechteck sich mit dem Drag-Rechteck überschneidet
            if itemRect.intersects(dragRect) {
                selectedIDs.insert(photo.id)
            }
            
            accumulatedX += cellWidth + 4 // spacing
        }
        
        // Aktualisiere Auswahl: Füge alle Fotos im Rechteck hinzu
        if !selectedIDs.isEmpty {
            if store.selectedPhotoIDs.isEmpty {
                store.selectedPhotoIDs = selectedIDs
            } else {
                store.selectedPhotoIDs.formUnion(selectedIDs)
            }
            // Setze currentPhotoID auf das erste Foto im Rechteck (wenn noch nicht gesetzt)
            if store.currentPhotoID == nil || !selectedIDs.contains(store.currentPhotoID!) {
                store.currentPhotoID = selectedIDs.first
            }
        }
    }
}

// MARK: - Drag Selection Rectangle Visualisierung (für Filmstrip)

private struct DragSelectionRect: View {
    let startPoint: CGPoint
    let currentPoint: CGPoint
    
    private var rect: CGRect {
        let minX = min(startPoint.x, currentPoint.x)
        let maxX = max(startPoint.x, currentPoint.x)
        let minY = min(startPoint.y, currentPoint.y)
        let maxY = max(startPoint.y, currentPoint.y)
        return CGRect(x: minX, y: minY, width: maxX - minX, height: maxY - minY)
    }
    
    var body: some View {
        Rectangle()
            .stroke(DesignSystem.Colors.accent, lineWidth: 2)
            .background(
                Rectangle()
                    .fill(DesignSystem.Colors.accent.opacity(0.15))
            )
            .frame(width: rect.width, height: rect.height)
            .position(x: rect.midX, y: rect.midY)
    }
}

struct FilmstripPhotoCell: View {
    @ObservedObject var photo: PhotoItem
    @ObservedObject var store: PhotoStore
    let isCurrent: Bool
    let isMultiSelected: Bool
    let showMultiSelectIndicator: Bool
    let baseWidth: CGFloat
    let baseHeight: CGFloat
    
    private let renderedMaxDimension: CGFloat = 420
    private let currentScale: CGFloat = 1.10
    
    private var cellWidth: CGFloat { isCurrent ? (baseWidth * currentScale) : baseWidth }
    private var cellHeight: CGFloat { isCurrent ? (baseHeight * currentScale) : baseHeight }
    
    var body: some View {
        ZStack {
            thumbnail
            
            // Multi-Select Indicator (macht Mehrfachauswahl im Filmstrip sofort sichtbar)
            if showMultiSelectIndicator && isMultiSelected {
                Image(systemName: "checkmark.circle.fill")
                    .font(.system(size: isCurrent ? 16 : 14, weight: .semibold))
                    .foregroundColor(DesignSystem.Colors.accent)
                    .padding(5)
                    .background(Color.black.opacity(0.55))
                    .clipShape(Circle())
                    .overlay(
                        Circle()
                            .stroke(Color.white.opacity(0.10), lineWidth: 1)
                    )
                    .shadow(color: Color.black.opacity(0.55), radius: 2, x: 0, y: 1)
                    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
                    .padding(.bottom, 4)
            }
            
            if isCurrent {
                RoundedRectangle(cornerRadius: 6)
                    .stroke(DesignSystem.Colors.accent, lineWidth: 3)
                RoundedRectangle(cornerRadius: 6)
                    .stroke(Color.white.opacity(0.18), lineWidth: 1)
                    .shadow(color: DesignSystem.Colors.accent.opacity(0.35), radius: 8, x: 0, y: 0)
            } else if showMultiSelectIndicator && isMultiSelected {
                RoundedRectangle(cornerRadius: 6)
                    .stroke(DesignSystem.Colors.accent.opacity(0.55), lineWidth: 2)
            }
        }
        .frame(width: cellWidth, height: cellHeight)
        .background(isCurrent ? DesignSystem.Colors.accent.opacity(0.12) : Color.clear)
        .cornerRadius(6)
        .animation(.easeOut(duration: 0.12), value: isCurrent)
    }
    
    private var thumbnail: some View {
        Group {
            if photo.isMaster {
                AsyncThumbnailView(photo: photo, previewSize: .thumbnail, interpolation: .high)
            } else {
                RenderedThumbnailView(photo: photo, maxDimension: renderedMaxDimension, interpolation: .high)
            }
        }
        .cornerRadius(4)
        .overlay(
            PhotoBadgesOverlay(
                photo: photo,
                style: .filmstrip,
                bestOf: store.bestOfOverlayInfo(for: photo.id)
            )
                .zIndex(10) // zuverlässig über dem Thumbnail (bei vielen Items / ScrollView)
        )
    }
}
