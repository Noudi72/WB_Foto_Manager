//
//  BestShotService.swift
//  WB Foto Manager
//
//  Smart Culling MVP: Best-Shot Scoring (sharpness + face prominence)
//

import Foundation
import AppKit
import CoreImage
import Vision

/// Lightweight scorer for "best shot" ranking inside bursts/selections.
/// Uses a fast sharpness metric (edge energy) plus optional subject/face prominence.
actor BestShotService {
    static let shared = BestShotService()
    
    /// Cache is mode-aware (sport vs portrait), otherwise switching the setting would return stale scores.
    private var scoreCache: [String: Double] = [:]
    
    /// For stability/performance we use a software context on a small working image.
    private let ciContext = CIContext(options: [
        .useSoftwareRenderer: true,
        .cacheIntermediates: false,
        .workingColorSpace: NSNull(),
        .outputColorSpace: NSNull()
    ])
    
    /// Fast path for large series: hardware context for sharpness-only scoring.
    private let fastCIContext = CIContext(options: [
        .useSoftwareRenderer: false,
        .cacheIntermediates: false,
        .workingColorSpace: NSNull(),
        .outputColorSpace: NSNull()
    ])
    
    private init() {}
    
    struct PhotoRef: Sendable, Hashable {
        let id: UUID
        let url: URL
    }
    
    enum ScoringMode: String, CaseIterable, Sendable {
        case sport
        case portrait
    }
    
    func clearCache() {
        scoreCache.removeAll(keepingCapacity: true)
    }
    
    func bestPhotoID(in photos: [PhotoRef]) async -> UUID? {
        guard photos.count >= 2 else { return photos.first?.id }
        if Task.isCancelled { return nil }
        
        var bestID: UUID?
        var bestScore: Double = -Double.greatestFiniteMagnitude
        
        // Evaluate sequentially (actor isolation); cached scores make this cheap after first run.
        for p in photos {
            if Task.isCancelled { return nil }
            let s = await score(for: p)
            if s > bestScore {
                bestScore = s
                bestID = p.id
            }
        }
        
        return bestID
    }
    
    func score(for photo: PhotoRef) async -> Double {
        let mode = currentScoringMode()
        let cacheKey = "\(mode.rawValue)|\(photo.id.uuidString)"
        
        if let cached = scoreCache[cacheKey] {
            return cached
        }
        if Task.isCancelled { return 0 }
        
        // Load a preview image (PhotoKit needs .medium to avoid square-crop; files can use .thumbnail for speed).
        let isPhotoKit = PHAssetURL.localIdentifier(from: photo.url) != nil
        let previewSize: PreviewSize = isPhotoKit ? .medium : .thumbnail
        guard let nsImage = await SmartImageLoader.shared.loadImage(url: photo.url, previewSize: previewSize) else {
            scoreCache[cacheKey] = 0
            return 0
        }
        
        // Convert to CGImage on MainActor (AppKit safety).
        let cg: CGImage? = await MainActor.run {
            nsImage.cgImage(forProposedRect: nil, context: nil, hints: nil)
        }
        guard let cgImage = cg else {
            scoreCache[cacheKey] = 0
            return 0
        }
        
        // Compute components.
        let sharp = sharpnessScore(cgImage: cgImage)
        let subject = subjectProminenceScore(cgImage: cgImage)
        
        // Combine: sharpness dominates for sport/action; portraits get a face boost.
        // Typical ranges:
        // - sharp ~0.01..0.20
        // - subject area ~0.00..0.40 (normalized, often ~0.05..0.25)
        // - face area ~0.00..0.20 (normalized)
        let combined: Double
        switch mode {
        case .sport:
            combined = sharp + (subject * 0.12)
        case .portrait:
            let face = faceProminenceScore(cgImage: cgImage)
            combined = sharp + (subject * 0.08) + (face * 0.18)
        }
        
        scoreCache[cacheKey] = combined
        return combined
    }
    
    /// Fast scoring for large sets (hundreds of images): sharpness-only, no Vision.
    /// Good for sports workflows where "technische Qualität" = sharpness.
    func quickScore(for photo: PhotoRef) async -> Double {
        let cacheKey = "quick|\(photo.id.uuidString)"
        if let cached = scoreCache[cacheKey] {
            return cached
        }
        if Task.isCancelled { return 0 }
        
        // PhotoKit: use .strip to avoid square-crop; files: .thumbnail is fastest.
        let isPhotoKit = PHAssetURL.localIdentifier(from: photo.url) != nil
        let previewSize: PreviewSize = isPhotoKit ? .strip : .thumbnail
        
        guard let nsImage = await SmartImageLoader.shared.loadImage(url: photo.url, previewSize: previewSize) else {
            scoreCache[cacheKey] = 0
            return 0
        }
        
        let cg: CGImage? = await MainActor.run {
            nsImage.cgImage(forProposedRect: nil, context: nil, hints: nil)
        }
        guard let cgImage = cg else {
            scoreCache[cacheKey] = 0
            return 0
        }
        
        let sharp = sharpnessScoreFast(cgImage: cgImage)
        scoreCache[cacheKey] = sharp
        return sharp
    }
    
    private func currentScoringMode() -> ScoringMode {
        let raw = UserDefaults.standard.string(forKey: "bestShotScoringMode") ?? ScoringMode.sport.rawValue
        return ScoringMode(rawValue: raw) ?? .sport
    }
    
    // MARK: - Metrics
    
    private func sharpnessScore(cgImage: CGImage) -> Double {
        // Downsample for speed & consistency.
        let ci = CIImage(cgImage: cgImage)
        let extent = ci.extent.integral
        guard extent.width > 1, extent.height > 1 else { return 0 }
        
        let maxDim: CGFloat = 512
        let longest = max(extent.width, extent.height)
        let scale = max(0.01, min(1.0, maxDim / longest))
        
        let scaled = ci
            .transformed(by: CGAffineTransform(scaleX: scale, y: scale))
            .cropped(to: CGRect(origin: .zero, size: CGSize(width: extent.width * scale, height: extent.height * scale)).integral)
        
        // Edge energy (CIEdges gives positive edges; CIAreaAverage gives a stable scalar).
        let gray = scaled.applyingFilter("CIColorControls", parameters: [
            kCIInputSaturationKey: 0.0
        ])
        let edges = gray.applyingFilter("CIEdges", parameters: [
            kCIInputIntensityKey: 1.0
        ])
        let avg = edges.applyingFilter("CIAreaAverage", parameters: [
            kCIInputExtentKey: CIVector(cgRect: edges.extent)
        ])
        
        var pixel = [UInt8](repeating: 0, count: 4)
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        pixel.withUnsafeMutableBytes { ptr in
            guard let base = ptr.baseAddress else { return }
            ciContext.render(
                avg,
                toBitmap: base,
                rowBytes: 4,
                bounds: CGRect(x: 0, y: 0, width: 1, height: 1),
                format: .RGBA8,
                colorSpace: colorSpace
            )
        }
        
        let r = Double(pixel[0]) / 255.0
        let g = Double(pixel[1]) / 255.0
        let b = Double(pixel[2]) / 255.0
        return (r + g + b) / 3.0
    }
    
    private func sharpnessScoreFast(cgImage: CGImage) -> Double {
        // Downsample for speed & consistency.
        let ci = CIImage(cgImage: cgImage)
        let extent = ci.extent.integral
        guard extent.width > 1, extent.height > 1 else { return 0 }
        
        let maxDim: CGFloat = 384
        let longest = max(extent.width, extent.height)
        let scale = max(0.01, min(1.0, maxDim / longest))
        
        let scaled = ci
            .transformed(by: CGAffineTransform(scaleX: scale, y: scale))
            .cropped(to: CGRect(origin: .zero, size: CGSize(width: extent.width * scale, height: extent.height * scale)).integral)
        
        let gray = scaled.applyingFilter("CIColorControls", parameters: [
            kCIInputSaturationKey: 0.0
        ])
        let edges = gray.applyingFilter("CIEdges", parameters: [
            kCIInputIntensityKey: 1.0
        ])
        let avg = edges.applyingFilter("CIAreaAverage", parameters: [
            kCIInputExtentKey: CIVector(cgRect: edges.extent)
        ])
        
        var pixel = [UInt8](repeating: 0, count: 4)
        let colorSpace = CGColorSpaceCreateDeviceRGB()
        pixel.withUnsafeMutableBytes { ptr in
            guard let base = ptr.baseAddress else { return }
            fastCIContext.render(
                avg,
                toBitmap: base,
                rowBytes: 4,
                bounds: CGRect(x: 0, y: 0, width: 1, height: 1),
                format: .RGBA8,
                colorSpace: colorSpace
            )
        }
        
        let r = Double(pixel[0]) / 255.0
        let g = Double(pixel[1]) / 255.0
        let b = Double(pixel[2]) / 255.0
        return (r + g + b) / 3.0
    }
    
    private func faceProminenceScore(cgImage: CGImage) -> Double {
        let request = VNDetectFaceRectanglesRequest()
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        try? handler.perform([request])
        
        guard let faces = request.results, !faces.isEmpty else { return 0 }
        // Use the largest face area as a simple prominence measure (0..1).
        let maxArea = faces
            .map { Double($0.boundingBox.width * $0.boundingBox.height) }
            .max() ?? 0
        return max(0, min(1, maxArea))
    }
    
    private func subjectProminenceScore(cgImage: CGImage) -> Double {
        // Saliency gives us a good proxy for "main subject is clear & prominent",
        // which helps a lot for sport/action where faces may be small or hidden.
        let handler = VNImageRequestHandler(cgImage: cgImage, options: [:])
        
        // 1) Attention-based saliency (usually best for action shots)
        do {
            let request = VNGenerateAttentionBasedSaliencyImageRequest()
            try handler.perform([request])
            if let obs = request.results?.first as? VNSaliencyImageObservation,
               let rects = obs.salientObjects,
               !rects.isEmpty {
                let maxArea = rects
                    .map { Double($0.boundingBox.width * $0.boundingBox.height) }
                    .max() ?? 0
                return max(0, min(1, maxArea))
            }
        } catch {
            // ignore and try objectness
        }
        
        // 2) Objectness-based saliency (fallback; sometimes better for animals / small subjects)
        do {
            let request = VNGenerateObjectnessBasedSaliencyImageRequest()
            try handler.perform([request])
            if let obs = request.results?.first as? VNSaliencyImageObservation,
               let rects = obs.salientObjects,
               !rects.isEmpty {
                let maxArea = rects
                    .map { Double($0.boundingBox.width * $0.boundingBox.height) }
                    .max() ?? 0
                return max(0, min(1, maxArea))
            }
        } catch {
            // ignore
        }
        
        return 0
    }
}


