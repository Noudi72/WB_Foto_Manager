//
//  IPTCMetadataService.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import ImageIO
import CoreImage

/// Service für IPTC-Metadaten-Verwaltung
final class IPTCMetadataService: @unchecked Sendable {
    nonisolated static let shared = IPTCMetadataService()
    
    private init() {}

    // MARK: - Scan helpers (für schnelle Library-Scans, Dedupe, Sort)
    
    struct ScanMeta: Sendable {
        let iptc: IPTCMetadata?
        let exifImageUniqueID: String?
        let pixelWidth: Int?
        let pixelHeight: Int?
    }
    
    /// Lädt IPTC-Metadaten aus einem Bild
    nonisolated func loadMetadata(from url: URL) -> IPTCMetadata? {
        guard let imageSource = CGImageSourceCreateWithURL(url as CFURL, nil),
              let metadata = CGImageSourceCopyPropertiesAtIndex(imageSource, 0, nil) as? [String: Any] else {
            return nil
        }
        return parseIPTC(from: metadata)
    }
    
    /// Lädt IPTC + zusätzliche Scan-Infos (UniqueID, Pixelgröße) in EINEM Pass.
    nonisolated func loadScanMeta(from url: URL) -> ScanMeta {
        guard let imageSource = CGImageSourceCreateWithURL(url as CFURL, nil),
              let metadata = CGImageSourceCopyPropertiesAtIndex(imageSource, 0, nil) as? [String: Any] else {
            return ScanMeta(iptc: nil, exifImageUniqueID: nil, pixelWidth: nil, pixelHeight: nil)
        }
        
        let iptc = parseIPTC(from: metadata)
        
        let exif = metadata[kCGImagePropertyExifDictionary as String] as? [String: Any]
        let uniqueID = exif?[kCGImagePropertyExifImageUniqueID as String] as? String
        
        let wAny = metadata[kCGImagePropertyPixelWidth as String]
        let hAny = metadata[kCGImagePropertyPixelHeight as String]
        let w = (wAny as? Int) ?? (wAny as? Double).map { Int($0) }
        let h = (hAny as? Int) ?? (hAny as? Double).map { Int($0) }
        
        return ScanMeta(iptc: iptc, exifImageUniqueID: uniqueID, pixelWidth: w, pixelHeight: h)
    }
    
    // MARK: - Parsing
    
    private nonisolated func parseIPTC(from metadata: [String: Any]) -> IPTCMetadata {
        var iptc = IPTCMetadata()
        
        // IPTC Dictionary
        if let iptcDict = metadata[kCGImagePropertyIPTCDictionary as String] as? [String: Any] {
            iptc.caption = iptcDict[kCGImagePropertyIPTCCaptionAbstract as String] as? String
            iptc.keywords = iptcDict[kCGImagePropertyIPTCKeywords as String] as? [String] ?? []
            iptc.photographer = iptcDict[kCGImagePropertyIPTCByline as String] as? String
            iptc.copyright = iptcDict[kCGImagePropertyIPTCCopyrightNotice as String] as? String
            // Location wird als SubLocation gespeichert
            iptc.location = iptcDict[kCGImagePropertyIPTCSubLocation as String] as? String
            iptc.city = iptcDict[kCGImagePropertyIPTCCity as String] as? String
            iptc.country = iptcDict[kCGImagePropertyIPTCCountryPrimaryLocationName as String] as? String
            iptc.event = iptcDict["Event" as String] as? String
            iptc.venue = iptcDict["Venue" as String] as? String
        }
        
        // XMP Keywords (dc:subject) – einige Files liefern das als IPTC/XMP-Mix zurück.
        if let xmpKeywords = (metadata["dc:subject" as String] as? [String]) {
            iptc.keywords.append(contentsOf: xmpKeywords)
        } else if let iptcDict = metadata[kCGImagePropertyIPTCDictionary as String] as? [String: Any],
                  let xmpKeywords = iptcDict["dc:subject" as String] as? [String] {
            iptc.keywords.append(contentsOf: xmpKeywords)
        }
        
        // Custom Fields (als JSON in einem speziellen Feld)
        if let iptcDict = metadata[kCGImagePropertyIPTCDictionary as String] as? [String: Any],
           let jsonString = iptcDict["CustomFields" as String] as? String,
           let data = jsonString.data(using: .utf8),
           let dict = try? JSONDecoder().decode([String: String].self, from: data) {
            iptc.customFields = dict
        }
        
        // EXIF/TIFF Date (+ Subsec, falls vorhanden)
        // Wichtig: Sport/Burst -> viele Bilder haben identische Sekunden. Subsec verbessert Sortierung massiv.
        let formatter: DateFormatter = {
            let f = DateFormatter()
            f.locale = Locale(identifier: "en_US_POSIX")
            f.timeZone = TimeZone.current
            f.dateFormat = "yyyy:MM:dd HH:mm:ss"
            return f
        }()
        
        func parseDate(_ raw: String) -> Date? {
            formatter.date(from: raw)
        }
        
        if let exifDict = metadata[kCGImagePropertyExifDictionary as String] as? [String: Any] {
            let dtOriginal = exifDict[kCGImagePropertyExifDateTimeOriginal as String] as? String
            let dtDigitized = exifDict[kCGImagePropertyExifDateTimeDigitized as String] as? String
            let dt = dtOriginal ?? dtDigitized
            
            if let dt, var d = parseDate(dt) {
                // Subsec (string like "123" or "12")
                let subsec = (exifDict[kCGImagePropertyExifSubsecTimeOriginal as String] as? String)
                    ?? (exifDict[kCGImagePropertyExifSubsecTimeDigitized as String] as? String)
                if let subsec, let frac = Double("0.\(subsec.trimmingCharacters(in: .whitespacesAndNewlines))") {
                    d = d.addingTimeInterval(frac)
                }
                iptc.date = d
            }
        }
        
        if iptc.date == nil,
           let tiffDict = metadata[kCGImagePropertyTIFFDictionary as String] as? [String: Any],
           let tiffDT = tiffDict[kCGImagePropertyTIFFDateTime as String] as? String {
            iptc.date = parseDate(tiffDT)
        }
        
        return iptc
    }
    
    /// Schreibt IPTC-Metadaten in ein Bild
    nonisolated func writeMetadata(_ metadata: IPTCMetadata, to url: URL) throws {
        guard let imageSource = CGImageSourceCreateWithURL(url as CFURL, nil),
              let image = CGImageSourceCreateImageAtIndex(imageSource, 0, nil),
              let uti = CGImageSourceGetType(imageSource) else {
            throw NSError(domain: "IPTCMetadataService", code: 1, userInfo: [NSLocalizedDescriptionKey: "Could not read image"])
        }
        
        let mutableData = NSMutableData()
        guard let destination = CGImageDestinationCreateWithData(mutableData, uti, 1, nil) else {
            throw NSError(domain: "IPTCMetadataService", code: 2, userInfo: [NSLocalizedDescriptionKey: "Could not create image destination"])
        }
        
        // Lade bestehende Metadaten
        var existingMetadata = CGImageSourceCopyPropertiesAtIndex(imageSource, 0, nil) as? [String: Any] ?? [:]
        
        // IPTC Dictionary
        var iptcDict: [String: Any] = existingMetadata[kCGImagePropertyIPTCDictionary as String] as? [String: Any] ?? [:]
        
        if let caption = metadata.caption {
            iptcDict[kCGImagePropertyIPTCCaptionAbstract as String] = caption
        }
        if metadata.keywords.isEmpty {
            iptcDict.removeValue(forKey: kCGImagePropertyIPTCKeywords as String)
            iptcDict.removeValue(forKey: "dc:subject" as String)
        } else {
            iptcDict[kCGImagePropertyIPTCKeywords as String] = metadata.keywords
            // XMP Keywords (dc:subject)
            iptcDict["dc:subject" as String] = metadata.keywords
        }
        if let photographer = metadata.photographer {
            iptcDict[kCGImagePropertyIPTCByline as String] = photographer
        }
        if let copyright = metadata.copyright {
            iptcDict[kCGImagePropertyIPTCCopyrightNotice as String] = copyright
        }
        if let location = metadata.location {
            iptcDict[kCGImagePropertyIPTCSubLocation as String] = location
        }
        if let city = metadata.city {
            iptcDict[kCGImagePropertyIPTCCity as String] = city
        }
        if let country = metadata.country {
            iptcDict[kCGImagePropertyIPTCCountryPrimaryLocationName as String] = country
        }
        if let event = metadata.event {
            iptcDict["Event" as String] = event
        }
        if let venue = metadata.venue {
            iptcDict["Venue" as String] = venue
        }
        
        // Custom Fields (als JSON in einem speziellen Feld)
        if !metadata.customFields.isEmpty {
            if let jsonData = try? JSONSerialization.data(withJSONObject: metadata.customFields),
               let jsonString = String(data: jsonData, encoding: .utf8) {
                iptcDict["CustomFields" as String] = jsonString
            }
        }
        
        // Write back IPTC dictionary (incl. CustomFields)
        existingMetadata[kCGImagePropertyIPTCDictionary as String] = iptcDict
        
        // Schreibe Bild mit Metadaten
        CGImageDestinationAddImage(destination, image, existingMetadata as CFDictionary)
        guard CGImageDestinationFinalize(destination) else {
            throw NSError(domain: "IPTCMetadataService", code: 3, userInfo: [NSLocalizedDescriptionKey: "Could not finalize image"])
        }
        
        // Atomare Operation: Schreibe zuerst in temporäre Datei, dann ersetze Original
        let tempURL = url.appendingPathExtension("tmp")
        try mutableData.write(to: tempURL)
        try FileManager.default.replaceItem(at: url, withItemAt: tempURL, backupItemName: nil, options: [], resultingItemURL: nil)
    }
}

