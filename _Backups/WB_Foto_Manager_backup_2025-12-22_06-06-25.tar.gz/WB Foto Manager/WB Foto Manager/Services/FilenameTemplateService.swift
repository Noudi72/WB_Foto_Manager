//
//  FilenameTemplateService.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 18.12.2025.
//

import Foundation

/// Service für Dateinamen-Template-Verarbeitung
final class FilenameTemplateService {
    static let shared = FilenameTemplateService()
    
    private init() {}
    
    /// Generiert einen Dateinamen basierend auf einem Template
    /// - Parameters:
    ///   - template: Template-String mit Variablen wie {originalname}, {preset}, etc.
    ///   - photo: Das Foto für das der Name generiert wird
    ///   - preset: Das Export-Preset
    ///   - index: Optional: Index bei Batch-Export (für {index} Variable)
    /// - Returns: Generierter Dateiname (ohne Extension)
    func generateFilename(template: String, photo: PhotoItem, preset: ExportPreset, index: Int? = nil) -> String {
        var result = template
        
        // {originalname} - Original-Dateiname ohne Extension
        let originalName = (photo.fileName as NSString).deletingPathExtension
        result = result.replacingOccurrences(of: "{originalname}", with: sanitizeFilename(originalName))
        
        // {preset} - Preset-Name
        result = result.replacingOccurrences(of: "{preset}", with: sanitizeFilename(preset.name))
        
        // {date} - Aufnahmedatum (YYYY-MM-DD)
        if let date = photo.iptcMetadata?.date ?? photo.url.creationDate {
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd"
            result = result.replacingOccurrences(of: "{date}", with: formatter.string(from: date))
        } else {
            result = result.replacingOccurrences(of: "{date}", with: "")
        }
        
        // {datetime} - Aufnahmedatum und Zeit (YYYY-MM-DD_HH-MM-SS)
        if let date = photo.iptcMetadata?.date ?? photo.url.creationDate {
            let formatter = DateFormatter()
            formatter.dateFormat = "yyyy-MM-dd_HH-mm-ss"
            result = result.replacingOccurrences(of: "{datetime}", with: formatter.string(from: date))
        } else {
            result = result.replacingOccurrences(of: "{datetime}", with: "")
        }
        
        // {time} - Zeit (HH-MM-SS)
        if let date = photo.iptcMetadata?.date ?? photo.url.creationDate {
            let formatter = DateFormatter()
            formatter.dateFormat = "HH-mm-ss"
            result = result.replacingOccurrences(of: "{time}", with: formatter.string(from: date))
        } else {
            result = result.replacingOccurrences(of: "{time}", with: "")
        }
        
        // {year}, {month}, {day} - Einzelne Datumskomponenten
        if let date = photo.iptcMetadata?.date ?? photo.url.creationDate {
            let calendar = Calendar.current
            let components = calendar.dateComponents([.year, .month, .day], from: date)
            if let year = components.year {
                result = result.replacingOccurrences(of: "{year}", with: String(format: "%04d", year))
            }
            if let month = components.month {
                result = result.replacingOccurrences(of: "{month}", with: String(format: "%02d", month))
            }
            if let day = components.day {
                result = result.replacingOccurrences(of: "{day}", with: String(format: "%02d", day))
            }
        }
        
        // {rating} - Rating (0-5)
        result = result.replacingOccurrences(of: "{rating}", with: "\(photo.rating)")
        
        // {index} - Index bei Batch-Export (mit Padding)
        if let idx = index {
            result = result.replacingOccurrences(of: "{index}", with: String(format: "%04d", idx))
            result = result.replacingOccurrences(of: "{index1}", with: String(format: "%d", idx))
        } else {
            result = result.replacingOccurrences(of: "{index}", with: "")
            result = result.replacingOccurrences(of: "{index1}", with: "")
        }
        
        // {width}x{height} - Bildgröße
        if let width = photo.pixelWidth, let height = photo.pixelHeight {
            result = result.replacingOccurrences(of: "{width}x{height}", with: "\(width)x\(height)")
            result = result.replacingOccurrences(of: "{width}", with: "\(width)")
            result = result.replacingOccurrences(of: "{height}", with: "\(height)")
        }
        
        // {camera} - Kamera-Modell
        if let camera = photo.exifMeta?.cameraModel {
            result = result.replacingOccurrences(of: "{camera}", with: sanitizeFilename(camera))
        } else {
            result = result.replacingOccurrences(of: "{camera}", with: "")
        }
        
        // {lens} - Objektiv-Modell
        if let lens = photo.exifMeta?.lensModel {
            result = result.replacingOccurrences(of: "{lens}", with: sanitizeFilename(lens))
        } else {
            result = result.replacingOccurrences(of: "{lens}", with: "")
        }
        
        // {focal} - Brennweite
        if let focal = photo.exifMeta?.focalLengthMM {
            result = result.replacingOccurrences(of: "{focal}", with: String(format: "%.0fmm", focal))
        } else {
            result = result.replacingOccurrences(of: "{focal}", with: "")
        }
        
        // {iso} - ISO-Wert
        if let iso = photo.exifMeta?.isoSpeed {
            result = result.replacingOccurrences(of: "{iso}", with: "ISO\(iso)")
        } else {
            result = result.replacingOccurrences(of: "{iso}", with: "")
        }
        
        // Entferne doppelte Unterstriche und führende/abschließende Unterstriche
        while result.contains("__") {
            result = result.replacingOccurrences(of: "__", with: "_")
        }
        result = result.trimmingCharacters(in: CharacterSet(charactersIn: "_"))
        
        // Fallback: Wenn Ergebnis leer ist, verwende Original-Name
        if result.isEmpty {
            result = originalName
        }
        
        return result
    }
    
    /// Bereinigt einen String für die Verwendung als Dateiname
    private func sanitizeFilename(_ name: String) -> String {
        // Ersetze ungültige Zeichen für Dateinamen
        let invalidChars = CharacterSet(charactersIn: "/\\?%*|\"<>:")
        let components = name.components(separatedBy: invalidChars)
        let sanitized = components.joined(separator: "_")
        
        // Entferne führende/abschließende Punkte und Leerzeichen
        return sanitized.trimmingCharacters(in: CharacterSet(charactersIn: ". "))
    }
    
    /// Liste aller verfügbaren Template-Variablen (für UI-Hilfe)
    static var availableVariables: [(variable: String, description: String)] {
        [
            ("{originalname}", "Original-Dateiname (ohne Extension)"),
            ("{preset}", "Preset-Name"),
            ("{date}", "Aufnahmedatum (YYYY-MM-DD)"),
            ("{datetime}", "Aufnahmedatum und Zeit (YYYY-MM-DD_HH-MM-SS)"),
            ("{time}", "Zeit (HH-MM-SS)"),
            ("{year}", "Jahr (YYYY)"),
            ("{month}", "Monat (MM)"),
            ("{day}", "Tag (DD)"),
            ("{rating}", "Rating (0-5)"),
            ("{index}", "Index bei Batch-Export (0001, 0002, ...)"),
            ("{index1}", "Index bei Batch-Export (1, 2, ...)"),
            ("{width}x{height}", "Bildgröße (z.B. 1920x1080)"),
            ("{width}", "Bildbreite"),
            ("{height}", "Bildhöhe"),
            ("{camera}", "Kamera-Modell"),
            ("{lens}", "Objektiv-Modell"),
            ("{focal}", "Brennweite (z.B. 50mm)"),
            ("{iso}", "ISO-Wert (z.B. ISO400)")
        ]
    }
}

extension URL {
    var creationDate: Date? {
        (try? resourceValues(forKeys: [.creationDateKey]))?.creationDate
    }
}

