//
//  RenderedThumbnailService.swift
//  WB Foto Manager
//
//  Rendered previews for Virtual Copies (show edits in thumbnails)
//

import Foundation
import AppKit
import CoreImage

/// Renders small previews that include non-destructive edits (adjustments/crop/masks/lens profile),
/// primarily used for Virtual Copy thumbnails.
actor RenderedThumbnailService {
    static let shared = RenderedThumbnailService()
    
    private let cache = NSCache<NSString, NSImage>()
    private var inFlight: [String: Task<NSImage?, Never>] = [:]
    
    private init() {
        cache.countLimit = 300
        cache.totalCostLimit = 256 * 1024 * 1024 // ~256MB
    }
    
    private struct Snapshot: Sendable {
        let id: UUID
        let url: URL
        let adjustments: PhotoAdjustments
        let localMasks: [LocalAdjustmentMask]
        let lensSettings: LensProfileSettings
        let cropRect: CGRect?
        let rotation: Double
        let pixelWidth: Int?
        let pixelHeight: Int?
    }
    
    /// Render a preview for a given photo and target size (maxDimension).
    /// - Note: This is an in-memory cache only.
    func renderedThumbnail(for photo: PhotoItem, maxDimension: CGFloat) async -> NSImage? {
        let snap: Snapshot = await MainActor.run {
            Snapshot(
                id: photo.id,
                url: photo.url,
                adjustments: photo.adjustments,
                localMasks: photo.localMasks,
                lensSettings: photo.lensProfileSettings,
                cropRect: photo.cropRect,
                rotation: photo.rotation,
                pixelWidth: photo.pixelWidth,
                pixelHeight: photo.pixelHeight
            )
        }
        
        let key = cacheKey(for: snap, maxDimension: maxDimension)
        if let cached = cache.object(forKey: key as NSString) {
            return cached
        }
        if let existing = inFlight[key] {
            return await existing.value
        }
        
        let task = Task<NSImage?, Never>(priority: .userInitiated) { [snap] in
            // Base preview sizing:
            // - File URLs: use thumbnail (fast, still sharp enough for small thumbs)
            // - PhotoKit URLs: use medium to avoid square-cropping (thumbnail mode uses aspectFill)
            let isPhotoKit = PHAssetURL.localIdentifier(from: snap.url) != nil
            let basePreview: PreviewSize = isPhotoKit ? .medium : .thumbnail
            
            guard let baseNS = await SmartImageLoader.shared.loadImage(url: snap.url, previewSize: basePreview) else {
                return nil
            }
            guard let baseCG = baseNS.cgImage(forProposedRect: nil, context: nil, hints: nil) else {
                return nil
            }
            
            let baseCI = CIImage(cgImage: baseCG)
            let baseExtent = baseCI.extent
            
            // Lens profile resolve (only if enabled)
            let lensMeta = snap.lensSettings.enabled ? await LensProfileService.shared.lensMeta(for: snap.url) : nil
            let resolvedLensProfile = snap.lensSettings.enabled ? await LensProfileService.shared.resolveProfile(for: snap.url, settings: snap.lensSettings) : nil
            
            return await MainActor.run {
                let engine = EditEngine.shared
                var processed = baseCI
                
                if let adjusted = engine.applyAdjustments(to: processed, adjustments: snap.adjustments) {
                    processed = adjusted
                }
                
                processed = engine.applyLensProfileCorrections(
                    to: processed,
                    settings: snap.lensSettings,
                    profile: resolvedLensProfile,
                    meta: lensMeta
                )
                
                // Scale crop rect to the preview image size (crop is stored in original pixel space).
                let scaledCrop: CGRect? = {
                    guard let crop = snap.cropRect else { return nil }
                    guard let pw = snap.pixelWidth, let ph = snap.pixelHeight, pw > 0, ph > 0 else { return nil }
                    
                    let sx = baseExtent.width / CGFloat(pw)
                    let sy = baseExtent.height / CGFloat(ph)
                    return CGRect(
                        x: crop.origin.x * sx,
                        y: crop.origin.y * sy,
                        width: crop.size.width * sx,
                        height: crop.size.height * sy
                    )
                }()
                
                processed = engine.applyCropAndRotation(to: processed, cropRect: scaledCrop, rotation: snap.rotation)
                
                if let masked = engine.applyLocalMasks(to: processed, masks: snap.localMasks) {
                    processed = masked
                }
                
                // Final render (max size)
                let target = CGSize(width: maxDimension, height: maxDimension)
                return engine.render(processed, size: target)
            }
        }
        
        inFlight[key] = task
        let result = await task.value
        inFlight[key] = nil
        
        if let image = result {
            let cost = Int(maxDimension * maxDimension * 4)
            cache.setObject(image, forKey: key as NSString, cost: cost)
        }
        
        return result
    }
    
    func clearCache() {
        cache.removeAllObjects()
        inFlight.values.forEach { $0.cancel() }
        inFlight.removeAll()
    }
    
    private func cacheKey(for snap: Snapshot, maxDimension: CGFloat) -> String {
        let cropKey: String = {
            guard let c = snap.cropRect else { return "nocrop" }
            // Keep short but deterministic within a session.
            return String(format: "crop_%.2f_%.2f_%.2f_%.2f", c.origin.x, c.origin.y, c.size.width, c.size.height)
        }()
        
        let masksHash = snap.localMasks.hashValue
        return [
            "v1",
            snap.id.uuidString,
            String(Int(maxDimension)),
            String(snap.adjustments.hashValue),
            String(masksHash),
            String(snap.lensSettings.hashValue),
            cropKey,
            String(format: "rot_%.2f", snap.rotation)
        ].joined(separator: "|")
    }
}


