//
//  AutoAdjustmentService.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Foundation
import CoreImage
import CoreGraphics

/// Robuste Auto-Verbesserung (histogrammbasiert, leichtgewichtig, Highlight/Shadow-schonend)
nonisolated final class AutoAdjustmentService {
    static let shared = AutoAdjustmentService()
    private init() {}
    
    // MARK: - Public API
    
    /// Analysiert ein PhotoItem und gibt optimale Adjustments zurück
    func analyzeAndAdjust(photo: PhotoItem) async -> PhotoAdjustments? {
        let image: CIImage
        if let cached = await MainActor.run(body: { photo.loadFullImage() }) {
            image = cached
        } else if let loaded = await photo.loadFullImageAsync() {
            image = loaded
        } else {
            return nil
        }
        // Heavy work off-main (Analyse & Pixel-Loop).
        return await Task.detached(priority: .userInitiated) { [weak self] in
            guard let self else { return nil }
            return self.analyzeAndAdjust(image: image)
        }.value
    }
    
    /// Analysiert ein Bild und gibt robuste Auto-Adjustments zurück (histogrammbasiert, leichtgewichtig)
    func analyzeAndAdjust(image: CIImage) -> PhotoAdjustments {
        guard let basicAnalysis = analyzeLuminanceAndColor(image: image) else {
            return PhotoAdjustments()
        }
        return computeAdjustments(image: image, basicAnalysis: basicAnalysis)
    }
    
    // MARK: - Auto-Adjustments (Fail-Safe, darf Bilder nicht verschlechtern)
    
    private func computeAdjustments(
        image: CIImage,
        basicAnalysis: AnalysisSummary
    ) -> PhotoAdjustments {
        var adjustments = PhotoAdjustments()
        let lum = basicAnalysis.luminance
        let spread = max(0.0001, lum.p95 - lum.p05)
        
        // Zielwerte (konservativ): nicht "style", nur echte Problemfälle korrigieren.
        let targetMid: Double = 0.45
        let targetHighlights: Double = 0.92
        
        // 1) Exposure: Highlights-limitierter Lift, damit Bilder mit dunklem Hintergrund nicht überbelichtet werden.
        let evMid = log2(targetMid / max(lum.p50, 0.01))
        let evHi = log2(targetHighlights / max(lum.p95, 0.01))
        var ev: Double = 0.0
        
        if evMid > 0 {
            // Aufhellen nur soweit, wie es die Highlights zulassen
            ev = min(evMid, evHi)
            // Wenn Highlights bereits "gut" liegen, nicht aufhellen (typisch: dunkler Hintergrund + helles Motiv)
            if lum.p95 >= 0.88 || lum.highlightClip > 0.005 {
                ev = min(ev, 0.08)
            }
            ev = min(ev, 0.50)
        } else if evMid < 0 {
            // Abdunkeln nur moderat und ohne Blacks zu crushen
            // Min. erlaubte EV, damit p05 nicht unter ~0.02 rutscht
            let minP05After: Double = 0.02
            let evShadowLimit = log2(minP05After / max(lum.p05, 0.001))
            ev = max(evMid, evShadowLimit)
            // Wenn schon viele Shadows clippen, nicht weiter abdunkeln
            if lum.shadowClip > 0.08 || lum.p05 < 0.02 {
                ev = max(ev, 0.0)
            }
            ev = max(ev, -0.35)
        }
        
        // Deadzone: kleine Änderungen machen Bilder oft "anders" aber nicht besser
        if abs(ev) < 0.12 { ev = 0.0 }
        adjustments.exposure = clamp(ev, -0.35, 0.50)
        
        // 2) Contrast: nur bei wirklich flachen Bildern leicht anheben
        var contrast: Double = 1.0
        if spread < 0.40 {
            let boost = (0.50 - spread) * 0.6
            contrast = 1.0 + boost
            contrast = clamp(contrast, 1.0, 1.12)
        }
        // Sehr kontrastreiche Bilder nicht "plattziehen" – lieber nichts tun.
        adjustments.contrast = contrast
        
        // 3) Vibrance: nur bei sehr niedriger Sättigung
        let avgSat = basicAnalysis.avgSaturation
        if avgSat < 0.14 {
            let v = (0.18 - avgSat) * 0.8
            adjustments.vibrance = clamp(v, 0.0, 0.12)
        }
        
        // WICHTIG (Fail-safe): keine Auto-WB/Whites/Blacks/Highlights/Shadows/Dehaze/Clarity,
        // da unsere CoreImage-Mappings hier leicht "look" statt Korrektur erzeugen können.
        adjustments.temperature = 0
        adjustments.tint = 0
        adjustments.highlights = 0
        adjustments.shadows = 0
        adjustments.whites = 0
        adjustments.blacks = 0
        adjustments.saturation = 0
        adjustments.dehaze = 0
        adjustments.clarity = 0
        adjustments.texture = 0
        
        return adjustments
    }
    
    // MARK: - Analysis Helpers
    
    private struct LuminanceSummary {
        let p05: Double
        let p25: Double
        let p50: Double
        let p75: Double
        let p95: Double
        let p99: Double
        let highlightClip: Double
        let shadowClip: Double
    }
    
    private struct AnalysisSummary {
        let luminance: LuminanceSummary
        let avgR: Double
        let avgG: Double
        let avgB: Double
        let avgSaturation: Double
    }
    
    private func analyzeLuminanceAndColor(image: CIImage) -> AnalysisSummary? {
        let extent = image.extent.integral
        guard extent.width > 0, extent.height > 0 else { return nil }

        // Downsample auf max 384px Kante (bessere Genauigkeit, immer noch schnell)
        let targetMax: CGFloat = 384
        let maxDim = max(extent.width, extent.height)
        let scale = min(1.0, targetMax / maxDim)
        let scaled = image.transformed(by: CGAffineTransform(scaleX: scale, y: scale))
        let scaledExtent = scaled.extent.integral

        let context = CIContext(options: [.useSoftwareRenderer: false])
        guard let cgImage = context.createCGImage(scaled, from: scaledExtent) else { return nil }

        let width = cgImage.width
        let height = cgImage.height
        let bytesPerPixel = 4
        let bytesPerRow = bytesPerPixel * width

        var pixelData = [UInt8](repeating: 0, count: width * height * bytesPerPixel)
        guard let bitmap = CGContext(
            data: &pixelData,
            width: width,
            height: height,
            bitsPerComponent: 8,
            bytesPerRow: bytesPerRow,
            space: CGColorSpaceCreateDeviceRGB(),
            bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue
        ) else {
            return nil
        }
        bitmap.draw(cgImage, in: CGRect(x: 0, y: 0, width: width, height: height))

        var hist = [Int](repeating: 0, count: 256)
        var highlightCount = 0
        var shadowCount = 0
        var sumR: Double = 0
        var sumG: Double = 0
        var sumB: Double = 0
        var sumSat: Double = 0

        let total = Double(width * height)
        if total <= 0 { return nil }

        for i in stride(from: 0, to: pixelData.count, by: bytesPerPixel) {
            let r = Double(pixelData[i]) / 255.0
            let g = Double(pixelData[i + 1]) / 255.0
            let b = Double(pixelData[i + 2]) / 255.0

            // Luminance (Rec. 709)
            let y = 0.2126 * r + 0.7152 * g + 0.0722 * b
            let bin = min(255, max(0, Int(y * 255.0)))
            hist[bin] += 1

            if y > 0.98 { highlightCount += 1 }
            if y < 0.02 { shadowCount += 1 }

            sumR += r
            sumG += g
            sumB += b

            // Saturation approx (HSV)
            let maxV = max(r, max(g, b))
            let minV = min(r, min(g, b))
            if maxV > 0.0001 {
                sumSat += (maxV - minV) / maxV
            }
        }

        func percentile(_ p: Double) -> Double {
            let target = max(1.0, min(total, total * p))
            var cumulative: Double = 0
            for idx in 0..<hist.count {
                cumulative += Double(hist[idx])
                if cumulative >= target {
                    return Double(idx) / 255.0
                }
            }
            return 1.0
        }

        let lum = LuminanceSummary(
            p05: percentile(0.05),
            p25: percentile(0.25),
            p50: percentile(0.50),
            p75: percentile(0.75),
            p95: percentile(0.95),
            p99: percentile(0.99),
            highlightClip: Double(highlightCount) / total,
            shadowClip: Double(shadowCount) / total
        )

        return AnalysisSummary(
            luminance: lum,
            avgR: sumR / total,
            avgG: sumG / total,
            avgB: sumB / total,
            avgSaturation: sumSat / total
        )
    }
    
    private func clamp(_ value: Double, _ minValue: Double, _ maxValue: Double) -> Double {
        max(minValue, min(maxValue, value))
    }
}
