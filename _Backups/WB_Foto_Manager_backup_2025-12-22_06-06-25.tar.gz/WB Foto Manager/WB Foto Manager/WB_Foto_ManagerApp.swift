//
//  WB_Foto_ManagerApp.swift
//  WB Foto Manager
//
//  Created by Noël Guyaz on 14.12.2025.
//

import SwiftUI
import AppKit
import UniformTypeIdentifiers
import Combine

@main
struct WB_Foto_ManagerApp: App {
    @StateObject private var store = PhotoStore()
    @StateObject private var uiState = UIState()
    @StateObject private var settings = AppSettings.shared
    
    @State private var selectAllKeyMonitor: Any?
    
    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(store)
                .environmentObject(uiState)
                .frame(minWidth: 1200, minHeight: 800)
                .preferredColorScheme(preferredColorScheme(for: settings.theme))
                .onAppear {
                    applyTheme(settings.theme)
                    installSelectAllKeyMonitorIfNeeded()
                    // Force toolbar to show icons + text by default
                    DispatchQueue.main.async {
                        if let window = NSApplication.shared.windows.first(where: { $0.isMainWindow || $0.isKeyWindow }) {
                            window.toolbar?.displayMode = .iconAndLabel
                        }
                    }
                }
                .onChange(of: settings.theme) { _, newTheme in
                    applyTheme(newTheme)
                }
        }
        .defaultSize(width: 1400, height: 900)
        .commands {
            // Edit > Undo/Redo (eigene History pro Foto)
            CommandGroup(replacing: .undoRedo) {
                Button("Rückgängig") {
                    store.undoCurrent()
                }
                .keyboardShortcut("z", modifiers: [.command])
                .disabled(!store.canUndoCurrent)
                
                Button("Wiederholen") {
                    store.redoCurrent()
                }
                .keyboardShortcut("z", modifiers: [.command, .shift])
                .disabled(!store.canRedoCurrent)
            }
            
            CommandGroup(replacing: .newItem) {
                Button("Ordner öffnen...") {
                    openFolder()
                }
                .keyboardShortcut("o", modifiers: .command)
                
                Button("Ingest / Import (SD‑Karte)…") {
                    uiState.activeSheet = .ingestImport
                }
                .keyboardShortcut("i", modifiers: .command)
                
                Divider()
                
                Button("Nächstes Foto") {
                    store.selectNextPhoto()
                }
                .keyboardShortcut(.rightArrow, modifiers: [])
                
                Button("Vorheriges Foto") {
                    store.selectPreviousPhoto()
                }
                .keyboardShortcut(.leftArrow, modifiers: [])
            }

            // File > Save / Save As (normal macOS Workflow)
            CommandGroup(replacing: .saveItem) {
                Button("Speichern") {
                    if let photo = store.currentPhoto {
                        SaveService.shared.saveOriginal(photo: photo)
        }
                }
                .keyboardShortcut("s", modifiers: .command)

                Button("Kopie speichern unter…") {
                    if let photo = store.currentPhoto {
                        SaveService.shared.saveCopyAs(photo: photo)
                    }
                }
                .keyboardShortcut("s", modifiers: [.command, .shift])
            }
            
            CommandGroup(after: .toolbar) {
                // Search
                Button("Suchen") {
                    uiState.focusSearchField = true
                }
                .keyboardShortcut("f", modifiers: [.command])
                
                Button(uiState.isFocusMode ? "Focus‑Mode beenden" : "Focus‑Mode") {
                    uiState.isFocusMode.toggle()
                }
                .keyboardShortcut("f", modifiers: [.command, .option])
                
                Divider()
                
                // Batch Rating Shortcuts
                Button("Rating löschen (0)") {
                    store.setRatingForSelection(0)
                }
                .keyboardShortcut("0", modifiers: [.command])
                
                ForEach(1...5, id: \.self) { rating in
                    Button("\(rating) Stern\(rating == 1 ? "" : "e")") {
                        store.setRatingForSelection(rating)
                    }
                    .keyboardShortcut(KeyEquivalent(Character("\(rating)")), modifiers: [.command])
                }

                Button(uiState.showTopBar ? "Topbar ausblenden" : "Topbar einblenden") {
                    uiState.showTopBar.toggle()
                }
                .keyboardShortcut("t", modifiers: [.command, .option])
                
                Button(uiState.showFilmstrip ? "Filmstreifen ausblenden" : "Filmstreifen einblenden") {
                    uiState.showFilmstrip.toggle()
                }
                .keyboardShortcut("y", modifiers: [.command, .option])

                Button("Tastenkürzel…") {
                    uiState.activeSheet = .shortcutsHelp
                }
                .keyboardShortcut("/", modifiers: [.command])
                
                Divider()
                
                // Culling Queue (Turbo)
                Button("Nächstes Unreviewed") {
                    store.selectNextUnreviewed()
                }
                .keyboardShortcut("n", modifiers: [.control, .command])
                
                Button("Vorheriges Unreviewed") {
                    store.selectPreviousUnreviewed()
                }
                .keyboardShortcut("n", modifiers: [.control, .command, .shift])
                
                Button("Nächstes Unrated") {
                    store.selectNextUnrated()
                }
                .keyboardShortcut("r", modifiers: [.control, .command])
                
                Button("Vorheriges Unrated") {
                    store.selectPreviousUnrated()
                }
                .keyboardShortcut("r", modifiers: [.control, .command, .shift])
                
                Button("Nächstes Unflagged") {
                    store.selectNextUnflagged()
                }
                .keyboardShortcut("u", modifiers: [.control, .command])
                
                Button("Vorheriges Unflagged") {
                    store.selectPreviousUnflagged()
                }
                .keyboardShortcut("u", modifiers: [.control, .command, .shift])
                
                // Rating
                Button("1 Stern") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(1, for: photoID)
                    }
                }
                .keyboardShortcut("1", modifiers: [])
                
                Button("2 Sterne") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(2, for: photoID)
                    }
                }
                .keyboardShortcut("2", modifiers: [])
                
                Button("3 Sterne") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(3, for: photoID)
                    }
                }
                .keyboardShortcut("3", modifiers: [])
                
                Button("4 Sterne") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(4, for: photoID)
                    }
                }
                .keyboardShortcut("4", modifiers: [])
                
                Button("5 Sterne") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(5, for: photoID)
                    }
                }
                .keyboardShortcut("5", modifiers: [])
                
                Button("Rating löschen") {
                    if let photoID = store.currentPhotoID {
                        store.setRating(0, for: photoID)
                    }
                }
                .keyboardShortcut("0", modifiers: [])
                
                Divider()
                
                // Pick/Reject (Lightroom-Style)
                Button("Als Pick markieren") {
                    if let photoID = store.currentPhotoID {
                        store.markAsPick(photoID: photoID)
                    }
                }
                .keyboardShortcut("p", modifiers: [])
                
                Button("Als Reject markieren") {
                    if let photoID = store.currentPhotoID {
                        store.markAsReject(photoID: photoID)
                    }
                }
                .keyboardShortcut("x", modifiers: [])
                
                Button("Markierung entfernen") {
                    if let photoID = store.currentPhotoID {
                        store.unflag(photoID: photoID)
                    }
                }
                .keyboardShortcut("u", modifiers: [])
                
                Divider()
                
                // Quick Collection
                Button("Zu Quick Collection hinzufügen/entfernen") {
                    if let photoID = store.currentPhotoID {
                        store.toggleQuickCollection(for: photoID)
                    }
                }
                .keyboardShortcut("b", modifiers: [])
                
                Button("Quick Collection anzeigen") {
                    uiState.showQuickCollectionOnly.toggle()
                }
                .keyboardShortcut("b", modifiers: [.command])
                
                Button("Quick Collection leeren") {
                    store.clearQuickCollection()
                }
                .keyboardShortcut("b", modifiers: [.command, .shift])
                
                Divider()
                
                // Virtual Copies
                Button("Virtuelle Kopie erstellen") {
                    if let photoID = store.currentPhotoID {
                        store.createVirtualCopy(of: photoID)
                    }
                }
                .keyboardShortcut("'", modifiers: [.command])
                
                Button("Virtuelle Kopie löschen") {
                    if let photoID = store.currentPhotoID,
                       let photo = store.photos.first(where: { $0.id == photoID }),
                       !photo.isMaster {
                        store.deleteVirtualCopy(photoID: photoID)
                    }
                }
                .keyboardShortcut("'", modifiers: [.command, .shift])
                .disabled(store.currentPhoto?.isMaster != false)
                
                Divider()
                
                // Pick Filter
                Button("Nur Picks anzeigen") {
                    uiState.pickStatusFilter = uiState.pickStatusFilter == .pick ? nil : .pick
                }
                .keyboardShortcut("p", modifiers: [.command])
                
                Button("Nur Rejects anzeigen") {
                    uiState.pickStatusFilter = uiState.pickStatusFilter == .reject ? nil : .reject
                }
                .keyboardShortcut("x", modifiers: [.command])
                
                Menu("Nach Color Label filtern") {
                    Button("Rot") {
                        uiState.colorTagFilter = uiState.colorTagFilter == .red ? nil : .red
                    }
                    Button("Gelb") {
                        uiState.colorTagFilter = uiState.colorTagFilter == .yellow ? nil : .yellow
                    }
                    Button("Grün") {
                        uiState.colorTagFilter = uiState.colorTagFilter == .green ? nil : .green
                    }
                    Button("Blau") {
                        uiState.colorTagFilter = uiState.colorTagFilter == .blue ? nil : .blue
                    }
                }
                
                Button("Filter zurücksetzen") {
                    uiState.pickStatusFilter = nil
                    uiState.ratingFilter = nil
                    uiState.searchQuery = ""
                    uiState.colorTagFilter = nil
                    uiState.showQuickCollectionOnly = false
                    uiState.activeSmartCollectionID = nil
                }
                .keyboardShortcut("l", modifiers: [.command])
                
                Divider()
                
                Button("Alle Rejects löschen...") {
                    store.deleteAllRejects()
                }
                .keyboardShortcut(.delete, modifiers: [.command, .shift])
                
                Divider()
                
                // Color Labels
                Menu("Color Label") {
                    Button("Rot (6)") {
                        if let photoID = store.currentPhotoID {
                            store.toggleColorTag(.red, for: photoID)
                        }
                    }
                    .keyboardShortcut("6", modifiers: [])
                    
                    Button("Gelb (7)") {
                        if let photoID = store.currentPhotoID {
                            store.toggleColorTag(.yellow, for: photoID)
                        }
                    }
                    .keyboardShortcut("7", modifiers: [])
                    
                    Button("Grün (8)") {
                        if let photoID = store.currentPhotoID {
                            store.toggleColorTag(.green, for: photoID)
                        }
                    }
                    .keyboardShortcut("8", modifiers: [])
                    
                    Button("Blau (9)") {
                        if let photoID = store.currentPhotoID {
                            store.toggleColorTag(.blue, for: photoID)
                        }
                    }
                    .keyboardShortcut("9", modifiers: [])
                    
                    Divider()
                    
                    Button("Color Label entfernen") {
                        if let photoID = store.currentPhotoID {
                            let photo = store.photos.first(where: { $0.id == photoID })
                            photo?.colorTags.removeAll()
                        }
                    }
                }
                
                Divider()
                
                // Smart Collections
                Button("Smart Collections verwalten...") {
                    uiState.activeSheet = .smartCollections
                }
                
                Button("Duplikate suchen...") {
                    uiState.activeSheet = .duplicateDetection
                }
                .disabled(store.photos.isEmpty)
                
                Divider()
                
                // AI Tagging
                Button("AI Keywords generieren") {
                    Task {
                        await store.generateAITagsForCurrent()
                    }
                }
                .disabled(store.currentPhoto == nil)
                
                Button("AI Keywords für Auswahl generieren") {
                    Task {
                        await store.generateAITagsForSelection { current, total in
                            // Progress könnte hier angezeigt werden
                            print("AI Tagging: \(current)/\(total)")
                        }
                    }
                }
                .disabled(store.selectedPhotoIDs.count < 2)
                
                Divider()
                
                // Export
                Button("Quick Export") {
                    if store.isQuickExporting {
                        store.cancelQuickExport()
                    } else if store.selectedPhotoIDs.count > 1 {
                        store.quickExportSelection()
                    } else {
                        store.quickExportCurrent()
                    }
                }
                .keyboardShortcut("e", modifiers: [.command])
                .disabled(store.currentPhoto == nil && store.selectedPhotoIDs.isEmpty)
                
                Button("Exportieren...") {
                    uiState.activeSheet = .export
                }
                .keyboardShortcut("e", modifiers: [.command, .shift])
                
                Button("Batch Export...") {
                    uiState.activeSheet = .batchExport
                }
                .keyboardShortcut("b", modifiers: [.command, .shift])
                
                Button("Export-Statistiken...") {
                    uiState.activeSheet = .exportStatistics
                }
                
                Divider()
                
                Button("Sidebar links ein/aus") {
                    if AppSettings.shared.sidebarAlwaysVisible {
                        uiState.showLeftSidebar = true
                    } else {
                        uiState.showLeftSidebar.toggle()
                    }
                }
                .keyboardShortcut("\\", modifiers: [.command])
                
                Button("Sidebar rechts ein/aus") {
                    uiState.showRightSidebar.toggle()
                }
                .keyboardShortcut("\\", modifiers: [.command, .option])
            }
            
            CommandGroup(replacing: .textEditing) {
                // Select All (⌘A) – Text selektieren (wenn möglich), sonst alle sichtbaren Fotos auswählen
                Button("Alles auswählen") {
                    handleSelectAll()
                }
                .keyboardShortcut("a", modifiers: [.command])
                
                Divider()
                
                // Bildbearbeitung
                Button(AppSettings.shared.autoUsesStyleProfile ? "Auto (+ Stil‑Profil)" : "Auto") {
                    guard let photo = store.currentPhoto else { return }
                    Task {
                        if let adjustments = await store.buildAutoAdjustments(for: photo) {
                            await MainActor.run {
                                store.registerUndoPoint(for: photo)
                                photo.adjustments = adjustments
                                NotificationCenter.default.post(
                                    name: NSNotification.Name("PhotoAdjustmentsChanged"),
                                    object: nil,
                                    userInfo: ["photoID": photo.id]
                                )
                            }
                        }
                    }
                }
                .keyboardShortcut("a", modifiers: [.command, .option])
                .disabled(store.currentPhoto == nil || store.isBatchAutoRunning)
                
                Button("Auto auf Auswahl anwenden") {
                    store.applyAutoToSelection()
                }
                .keyboardShortcut("a", modifiers: [.command, .option, .shift])
                .disabled(store.selectedPhotoIDs.isEmpty || store.isBatchAutoRunning)
                
                Button("Adjustments zurücksetzen") {
                    resetAdjustments()
                }
                .keyboardShortcut("r", modifiers: [.command, .option])

                Divider()

                // Lightroom-like: Copy/Paste/Sync Adjustments
                Button("Einstellungen kopieren") {
                    store.copyAdjustmentsFromCurrent()
                }
                .keyboardShortcut("c", modifiers: [.command, .shift])
                .disabled(store.currentPhoto == nil)

                Button("Einstellungen einfügen") {
                    store.pasteAdjustmentsToCurrent()
                }
                .keyboardShortcut("v", modifiers: [.command, .shift])
                .disabled(store.currentPhoto == nil || store.copiedAdjustments == nil)

                Button("Einstellungen synchronisieren…") {
                    uiState.activeSheet = .syncAdjustments
                }
                .keyboardShortcut("s", modifiers: [.command, .option])
                .disabled(store.currentPhoto == nil || store.selectedPhotoIDs.count <= 1)
                
                Divider()
                
                // View Mode
                Button("Detail-Ansicht") {
                    uiState.viewMode = .detail
                }
                .keyboardShortcut("1", modifiers: [.command, .control])
                
                Button("Grid-Ansicht") {
                    uiState.viewMode = .grid
                }
                .keyboardShortcut("2", modifiers: [.command, .control])
                
                Button("Compare / Culling") {
                    uiState.viewMode = .compare
                }
                .keyboardShortcut("3", modifiers: [.command, .control])
                
                Button("Survey") {
                    uiState.viewMode = .survey
                }
                .keyboardShortcut("4", modifiers: [.command, .control])
                
                Divider()
                
                // Before/After
                Button("Before/After umschalten") {
                    uiState.showBeforeAfter.toggle()
                }
                .keyboardShortcut("b", modifiers: [.command, .option])
                
                Divider()
                
                // Zoom
                Button("Zoom zurücksetzen") {
                    uiState.zoomLevel = 1.0
                }
                .keyboardShortcut("0", modifiers: [.command, .option])
                
                Button("Zoom vergrößern") {
                    uiState.zoomLevel = min(5.0, uiState.zoomLevel + 0.5)
                }
                .keyboardShortcut("=", modifiers: [.command, .option])
                
                Button("Zoom verkleinern") {
                    uiState.zoomLevel = max(0.5, uiState.zoomLevel - 0.5)
                }
                .keyboardShortcut("-", modifiers: [.command, .option])
            }
            
            CommandGroup(after: .appSettings) {
                Button("Einstellungen...") {
                    uiState.activeSheet = .settings
                }
                .keyboardShortcut(",", modifiers: .command)
                
                Divider()
                
                Button("Upload-Ziele verwalten...") {
                    uiState.activeSheet = .uploadSettings
                }
                
                Divider()
                
                Button("Batch Export...") {
                    uiState.activeSheet = .batchExport
                }
                .keyboardShortcut("b", modifiers: [.command, .shift])
                
                Button("Export-Queue Einstellungen...") {
                    uiState.activeSheet = .exportQueueSettings
                }
                
                Button("Backup & Wiederherstellung...") {
                    uiState.activeSheet = .backupRestore
                }
            }

            CommandGroup(replacing: .help) {
                Button("Hilfe & Anleitung") {
                    uiState.activeSheet = .help
                }
                .keyboardShortcut("?", modifiers: [.command, .shift])
                
                Button("Tastenkürzel…") {
                    uiState.activeSheet = .shortcutsHelp
                }
                .keyboardShortcut("/", modifiers: [.command])
            }
            
            CommandGroup(after: .help) {
                Divider()
                Button("Synchronisieren…") {
                    uiState.activeSheet = .syncAdjustments
                }
                .disabled(store.currentPhoto == nil || store.selectedPhotoIDs.count <= 1)
            }
            
        }
    }
    
    private func openFolder() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        
        panel.begin { response in
            if response == .OK, let url = panel.url {
                store.loadPhotos(from: url)
            }
        }
    }
    
    private func resetAdjustments() {
        guard let photo = store.currentPhoto else { return }
        store.registerUndoPoint(for: photo)
        var copy = photo.adjustments
        copy.reset()
        photo.adjustments = copy

        // Trigger Re-Render + persist non-destructive edits
        photo.objectWillChange.send()
        store.objectWillChange.send()
        NotificationCenter.default.post(
            name: NSNotification.Name("PhotoAdjustmentsChanged"),
            object: nil,
            userInfo: ["photoID": photo.id]
        )
    }

    // MARK: - Theme Application (Hell / Dunkel / Automatisch)
    @MainActor
    private func applyTheme(_ theme: String) {
        switch theme {
        case "dark":
            NSApp.appearance = NSAppearance(named: .darkAqua)
        case "light":
            NSApp.appearance = NSAppearance(named: .aqua)
        default:
            // Automatisch: System übernimmt
            NSApp.appearance = nil
        }
    }
    
    private func preferredColorScheme(for theme: String) -> ColorScheme? {
        switch theme {
        case "dark": return .dark
        case "light": return .light
        default: return nil
        }
    }
    
    private func handleSelectAll() {
        // Wenn wirklich ein Textfeld/Texteditor den Fokus hat, soll ⌘A Text selektieren.
        // Wichtig: NICHT über NSApp.sendAction(selectAll:) entscheiden (selectAll existiert auf NSResponder
        // und kann dadurch "handled" sein, ohne dass tatsächlich Text selektiert wird).
        if let responder = NSApp.keyWindow?.firstResponder {
            if let tv = responder as? NSTextView, tv.isEditable {
                tv.selectAll(nil)
                return
            }
            if let tf = responder as? NSTextField, tf.isEditable {
                tf.selectAll(nil)
                return
            }
        }
        
        // Sonst: alle sichtbaren Fotos auswählen (Filmstrip/Grid Workflow).
        uiState.selectionMode = true
        store.selectAllFilteredPhotos()
    }
    
    // MARK: - Fallback: Key Monitor (⌘A)
    
    /// SwiftUI/FirstResponder kann ⌘A in manchen Fällen "schlucken" (v.a. TextEditor-Fokus).
    /// Dieser Monitor stellt sicher, dass ⌘A im Filmstrip/Grid zuverlässig "alle Fotos auswählen" ausführt,
    /// solange kein editierbares Textfeld aktiv ist.
    @MainActor
    private func installSelectAllKeyMonitorIfNeeded() {
        guard selectAllKeyMonitor == nil else { return }
        
        selectAllKeyMonitor = NSEvent.addLocalMonitorForEvents(matching: .keyDown) { event in
            // ⌘A
            guard event.modifierFlags.contains(.command) else { return event }
            guard !event.modifierFlags.contains(.option),
                  !event.modifierFlags.contains(.control) else { return event }
            let chars = event.charactersIgnoringModifiers?.lowercased() ?? ""
            guard chars == "a" else { return event }
            
            // Wenn ein editierbares Textfeld aktiv ist → Standardverhalten (Text selektieren).
            if isEditableTextFirstResponderActive {
                return event
            }
            
            // Sonst: Fotos selektieren (und Event schlucken, damit nicht irgendwo "selectAll:" landet).
            DispatchQueue.main.async {
                self.uiState.selectionMode = true
                self.store.selectAllFilteredPhotos()
            }
            return nil
        }
    }
    
    private var isEditableTextFirstResponderActive: Bool {
        guard let responder = NSApp.keyWindow?.firstResponder else { return false }
        if let tv = responder as? NSTextView { return tv.isEditable }
        if let tf = responder as? NSTextField { return tf.isEditable }
        return false
    }
}
