//
//  WB_Foto_ManagerTests.swift
//  WB Foto ManagerTests
//
//  Created by Noël Guyaz on 14.12.2025.
//

import Testing
@testable import WB_Foto_Manager

struct WB_Foto_ManagerTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
